SGHelper = {};
(function(Tc) {
        function t(a, b) {
            function c() {}
            c.prototype = a;
            var d = new c,
                e;
            for (e in b) d[e] = b[e];
            b.toString !== Object.prototype.toString && (d.toString = b.toString);
            return d
        }

        function pg(a) {
            return a instanceof Array ? function() {
                return u.iter(a)
            } : "function" == typeof a.iterator ? r(a, a.iterator) : a.iterator
        }

        function r(a, b) {
            if (null == b) return null;
            null == b.__id__ && (b.__id__ = qg++);
            var c;
            null == a.hx__closures__ ? a.hx__closures__ = {} : c = a.hx__closures__[b.__id__];
            null == c && (c = function() {
                    return c.method.apply(c.scope, arguments)
                },
                c.scope = a, c.method = b, a.hx__closures__[b.__id__] = c);
            return c
        }
        Tc.openfl = Tc.openfl || {};
        Tc.lime = Tc.lime || {};
        var g = {},
            p = function() {
                return x.__string_rec(this, "")
            },
            oa = function() {};
        g.ApplicationMain = oa;
        oa.__name__ = ["ApplicationMain"];
        oa.config = null;
        oa.preloader = null;
        oa.create = function() {
            var a = new rd;
            a.create(oa.config);
            var b = new Ka;
            oa.preloader = new sd(b);
            oa.preloader.onComplete = oa.init;
            oa.preloader.create(oa.config);
            var b = [],
                c = [];
            b.push("assets/fonts/screengem.eot");
            c.push("BINARY");
            b.push("assets/fonts/screengem.svg");
            c.push("TEXT");
            b.push("Screengem-Regular");
            c.push("FONT");
            b.push("assets/fonts/screengem.woff");
            c.push("BINARY");
            b.push("assets/images/hd/bottom_panel.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_back.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_buy.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_buy2.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_coins.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_gift.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_gift2.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_hero.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_moreGames.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_play.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_plus.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_sound_off.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_sound_on.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_video.png");
            c.push("IMAGE");
            b.push("assets/images/hd/buttons/btn_video2.png");
            c.push("IMAGE");
            b.push("assets/images/hd/coins_ui.png");
            c.push("IMAGE");
            b.push("assets/images/hd/coins_ui2.png");
            c.push("IMAGE");
            b.push("assets/images/hd/hand.png");
            c.push("IMAGE");
            b.push("assets/images/hd/panel.png");
            c.push("IMAGE");
            b.push("assets/images/hd/progres.png");
            c.push("IMAGE");
            b.push("assets/images/hd/progres_marker.png");
            c.push("IMAGE");
            b.push("assets/images/hd/record_1.png");
            c.push("IMAGE");
            b.push("assets/images/hd/record_2.png");
            c.push("IMAGE");
            b.push("assets/images/hd/score_in_game.png");
            c.push("IMAGE");
            b.push("assets/images/hd/spritelists/main.png");
            c.push("IMAGE");
            b.push("assets/images/hd/spritelists/main.xml");
            c.push("TEXT");
            b.push("assets/images/hd/spritelists/shop.png");
            c.push("IMAGE");
            b.push("assets/images/hd/spritelists/shop.xml");
            c.push("TEXT");
            b.push("assets/images/hd/top_panel.png");
            c.push("IMAGE");
            b.push("assets/sound/music/theme.mp3");
            c.push("MUSIC");
            b.push("assets/sound/music/theme.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/achievement.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/achievement.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/click.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/click.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/coin.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/coin.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/collide.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/collide.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/crushing_wall.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/crushing_wall.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/fall.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/fall.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/new_record.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/new_record.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/revive.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/revive.ogg");
            c.push("SOUND");
            b.push("assets/sound/sfx/revive_window.mp3");
            c.push("MUSIC");
            b.push("assets/sound/sfx/revive_window.ogg");
            c.push("SOUND");
            b.push("assets/texts/localization.json");
            c.push("TEXT");
            if (null != oa.config.assetsPrefix)
                for (var d = 0, e = b.length; d <
                    e;) {
                    var f = d++;
                    "FONT" != c[f] && (b[f] = oa.config.assetsPrefix + b[f])
                }
            oa.preloader.load(b, c);
            a.exec()
        };
        oa.init = function() {
            oa.preloader = null;
            oa.start()
        };
        oa.main = function() {
            oa.config = {
                antialiasing: 0,
                background: 14409696,
                borderless: !1,
                depthBuffer: !1,
                fps: 0,
                fullscreen: !1,
                height: 0,
                orientation: "",
                resizable: !0,
                stencilBuffer: !1,
                title: "Tip tap 2",
                vsync: !1,
                width: 0
            }
        };
        oa.start = function() {
            for (var a = !1, b = O.resolveClass("Main"), c = 0, d = O.getClassFields(b); c < d.length;) {
                var e = d[c];
                ++c;
                if ("main" == e) {
                    a = !0;
                    break
                }
            }
            a ? z.callMethod(b,
                z.field(b, "main"), []) : O.createInstance(td, []);
            S.current.stage.dispatchEvent(new w(w.RESIZE, !1, !1))
        };
        var Sf = function() {};
        g["openfl.events.IEventDispatcher"] = Sf;
        Sf.__name__ = ["openfl", "events", "IEventDispatcher"];
        var U = function(a) {
            null != a && (this.__targetDispatcher = a)
        };
        g["openfl.events.EventDispatcher"] = U;
        U.__name__ = ["openfl", "events", "EventDispatcher"];
        U.__interfaces__ = [Sf];
        U.__sortByPriority = function(a, b) {
            return a.priority == b.priority ? 0 : a.priority > b.priority ? -1 : 1
        };
        U.prototype = {
            addEventListener: function(a,
                b, c, d, e) {
                null == d && (d = 0);
                null == c && (c = !1);
                null == this.__eventMap && (this.__eventMap = new pa);
                if (this.__eventMap.exists(a)) {
                    a = this.__eventMap.get(a);
                    e = 0;
                    for (var f = a.length; e < f;) {
                        var l = e++;
                        if (z.compareMethods(a[l].callback, b)) return
                    }
                    a.push(new ud(b, c, d));
                    a.sort(U.__sortByPriority)
                } else e = [], e.push(new ud(b, c, d)), this.__eventMap.set(a, e)
            },
            dispatchEvent: function(a) {
                if (null == this.__eventMap || null == a) return !1;
                var b = this.__eventMap.get(a.type);
                if (null == b) return !1;
                null == a.target && (a.target = null != this.__targetDispatcher ?
                    this.__targetDispatcher : this);
                a.currentTarget = this;
                for (var c = a.eventPhase == La.CAPTURING_PHASE, d = 0, e; d < b.length;) {
                    e = b[d];
                    if (e.useCapture == c && (e.callback(a), a.__isCancelledNow)) break;
                    e == b[d] && d++
                }
                return !0
            },
            hasEventListener: function(a) {
                return null == this.__eventMap ? !1 : this.__eventMap.exists(a)
            },
            removeEventListener: function(a, b, c) {
                null == c && (c = !1);
                if (null != this.__eventMap) {
                    var d = this.__eventMap.get(a);
                    if (null != d) {
                        for (var e = 0, f = d.length; e < f;) {
                            var l = e++;
                            if (d[l].match(b, c)) {
                                d.splice(l, 1);
                                break
                            }
                        }
                        0 == d.length &&
                            this.__eventMap.remove(a);
                        this.__eventMap.iterator().hasNext() || (this.__eventMap = null)
                    }
                }
            },
            __class__: U
        };
        var vd = function() {};
        g["openfl.display.IBitmapDrawable"] = vd;
        vd.__name__ = ["openfl", "display", "IBitmapDrawable"];
        vd.prototype = {
            __class__: vd
        };
        var V = function() {
            U.call(this);
            this.__alpha = 1;
            this.__rotation = 0;
            this.__scaleY = this.__scaleX = 1;
            this.__visible = !0;
            this.__y = this.__x = 0;
            this.__worldAlpha = 1;
            this.__worldTransform = new da;
            this.__rotationSine = this.__rotationCache = 0;
            this.__rotationCosine = 1;
            this.set_name("instance" +
                ++V.__instanceCount)
        };
        g["openfl.display.DisplayObject"] = V;
        V.__name__ = ["openfl", "display", "DisplayObject"];
        V.__interfaces__ = [vd];
        V.__super__ = U;
        V.prototype = t(U.prototype, {
            dispatchEvent: function(a) {
                var b = U.prototype.dispatchEvent.call(this, a);
                if (a.__isCancelled) return !0;
                a.bubbles && null != this.parent && this.parent != this && (a.eventPhase = La.BUBBLING_PHASE, this.parent.dispatchEvent(a));
                return b
            },
            globalToLocal: function(a) {
                return this.__getTransform().clone().invert().transformPoint(a)
            },
            localToGlobal: function(a) {
                return this.__getTransform().transformPoint(a)
            },
            __broadcast: function(a, b) {
                if (null != this.__eventMap && this.hasEventListener(a.type)) {
                    var c = U.prototype.dispatchEvent.call(this, a);
                    return a.__isCancelled ? !0 : c
                }
                return !1
            },
            __getBounds: function(a, b) {},
            __getTransform: function() {
                if (this.__transformDirty || 0 < V.__worldTransformDirty) {
                    var a = [],
                        b = this,
                        c = this.__transformDirty;
                    if (null == this.parent) c && this.__update(!0, !1);
                    else
                        for (; null != b.parent;) a.push(b), b = b.parent, b.__transformDirty && (c = !0);
                    if (c)
                        for (b = a.length; 0 <= --b;) a[b].__update(!0, !1)
                }
                return this.__worldTransform
            },
            __hitTest: function(a, b, c, d, e) {
                return !1
            },
            __renderCanvas: function(a) {},
            __renderDOM: function(a) {},
            __renderGL: function(a) {},
            __renderMask: function(a) {},
            __setStageReference: function(a) {
                this.stage != a && (null != this.stage && this.dispatchEvent(new w(w.REMOVED_FROM_STAGE, !1, !1)), this.stage = a, null != a && this.dispatchEvent(new w(w.ADDED_TO_STAGE, !1, !1)))
            },
            __setRenderDirty: function() {
                this.__renderDirty || (this.__renderDirty = !0, V.__worldRenderDirty++)
            },
            __update: function(a, b) {
                this.__renderable = this.get_visible() && 0 !=
                    this.get_scaleX() && 0 != this.get_scaleY() && !this.__isMask;
                if (this.get_rotation() != this.__rotationCache) {
                    this.__rotationCache = this.get_rotation();
                    var c = this.get_rotation() * (Math.PI / 180);
                    this.__rotationSine = Math.sin(c);
                    this.__rotationCosine = Math.cos(c)
                }
                if (null != this.parent) {
                    var c = this.parent.__worldTransform,
                        d = this.__rotationCosine * this.get_scaleX(),
                        e = this.__rotationSine * this.get_scaleX(),
                        f = -this.__rotationSine * this.get_scaleY(),
                        l = this.__rotationCosine * this.get_scaleY(),
                        E = c.a,
                        g = c.b,
                        h = c.c,
                        q = c.d;
                    null ==
                        this.__worldTransform && (this.__worldTransform = new da);
                    this.__worldTransform.a = d * E + e * h;
                    this.__worldTransform.b = d * g + e * q;
                    this.__worldTransform.c = f * E + l * h;
                    this.__worldTransform.d = f * g + l * q;
                    null == this.get_scrollRect() ? (this.__worldTransform.tx = this.get_x() * E + this.get_y() * h + c.tx, this.__worldTransform.ty = this.get_x() * g + this.get_y() * q + c.ty) : (this.__worldTransform.tx = (this.get_x() - this.get_scrollRect().x) * E + (this.get_y() - this.get_scrollRect().y) * h + c.tx, this.__worldTransform.ty = (this.get_x() - this.get_scrollRect().x) *
                        g + (this.get_y() - this.get_scrollRect().y) * q + c.ty)
                } else this.__worldTransform.a = this.__rotationCosine * this.get_scaleX(), this.__worldTransform.c = -this.__rotationSine * this.get_scaleY(), this.__worldTransform.b = this.__rotationSine * this.get_scaleX(), this.__worldTransform.d = this.__rotationCosine * this.get_scaleY(), null == this.get_scrollRect() ? (this.__worldTransform.tx = this.get_x(), this.__worldTransform.ty = this.get_y()) : (this.__worldTransform.tx = this.get_y() - this.get_scrollRect().x, this.__worldTransform.ty =
                    this.get_y() - this.get_scrollRect().y);
                b && this.__transformDirty && (this.__transformDirty = !1, V.__worldTransformDirty--);
                a || (this.__worldAlpha = null != this.parent ? this.get_alpha() * this.parent.__worldAlpha : this.get_alpha(), b && this.__renderDirty && (this.__renderDirty = !1))
            },
            __updateChildren: function(a) {
                if ((this.__renderable = this.get_visible() && 0 != this.get_scaleX() && 0 != this.get_scaleY() && !this.__isMask) || this.__isMask) this.__worldAlpha = this.get_alpha(), this.__transformDirty && (this.__transformDirty = !1, V.__worldTransformDirty--)
            },
            get_alpha: function() {
                return this.__alpha
            },
            set_alpha: function(a) {
                a == this.__alpha || this.__renderDirty || (this.__renderDirty = !0, V.__worldRenderDirty++);
                return this.__alpha = a
            },
            get_filters: function() {
                return null == this.__filters ? [] : this.__filters.slice()
            },
            set_filters: function(a) {
                return a
            },
            get_name: function() {
                return this.__name
            },
            set_name: function(a) {
                return this.__name = a
            },
            get_rotation: function() {
                return this.__rotation
            },
            set_rotation: function(a) {
                a == this.__rotation || this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++);
                return this.__rotation = a
            },
            get_scaleX: function() {
                return this.__scaleX
            },
            set_scaleX: function(a) {
                a == this.__scaleX || this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++);
                return this.__scaleX = a
            },
            get_scaleY: function() {
                return this.__scaleY
            },
            set_scaleY: function(a) {
                this.__scaleY == a || this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++);
                return this.__scaleY = a
            },
            get_scrollRect: function() {
                return this.__scrollRect
            },
            get_visible: function() {
                return this.__visible
            },
            set_visible: function(a) {
                a == this.__visible || this.__renderDirty || (this.__renderDirty = !0, V.__worldRenderDirty++);
                return this.__visible = a
            },
            get_width: function() {
                var a = new za;
                this.__getTransform();
                this.__getBounds(a, new da);
                return a.width * this.get_scaleX()
            },
            get_x: function() {
                return this.__x
            },
            set_x: function(a) {
                a == this.__x || this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++);
                return this.__x = a
            },
            get_y: function() {
                return this.__y
            },
            set_y: function(a) {
                a == this.__y || this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++);
                return this.__y = a
            },
            __class__: V,
            __properties__: {
                set_y: "set_y",
                get_y: "get_y",
                set_x: "set_x",
                get_x: "get_x",
                get_width: "get_width",
                set_visible: "set_visible",
                get_visible: "get_visible",
                get_scrollRect: "get_scrollRect",
                set_scaleY: "set_scaleY",
                get_scaleY: "get_scaleY",
                set_scaleX: "set_scaleX",
                get_scaleX: "get_scaleX",
                set_rotation: "set_rotation",
                get_rotation: "get_rotation",
                set_name: "set_name",
                get_name: "get_name",
                set_filters: "set_filters",
                get_filters: "get_filters",
                set_alpha: "set_alpha",
                get_alpha: "get_alpha"
            }
        });
        var $a = function() {
            V.call(this);
            this.doubleClickEnabled = !1;
            this.mouseEnabled = !0;
            this.needsSoftKeyboard = !1;
            this.tabEnabled = !0;
            this.tabIndex = -1
        };
        g["openfl.display.InteractiveObject"] = $a;
        $a.__name__ = ["openfl", "display", "InteractiveObject"];
        $a.__super__ = V;
        $a.prototype = t(V.prototype, {
            __getInteractive: function(a) {
                a.push(this);
                null != this.parent && this.parent.__getInteractive(a)
            },
            __class__: $a
        });
        var Ha = function() {
            $a.call(this);
            this.mouseChildren = !0;
            this.__children = [];
            this.__removedChildren = []
        };
        g["openfl.display.DisplayObjectContainer"] = Ha;
        Ha.__name__ = ["openfl", "display", "DisplayObjectContainer"];
        Ha.__super__ = $a;
        Ha.prototype = t($a.prototype, {
            addChild: function(a) {
                if (null != a) {
                    null != a.parent && a.parent.removeChild(a);
                    this.__children.push(a);
                    a.parent = this;
                    null != this.stage && a.__setStageReference(this.stage);
                    a.__transformDirty || (a.__transformDirty = !0, V.__worldTransformDirty++);
                    a.__renderDirty || (a.__renderDirty = !0, V.__worldRenderDirty++);
                    var b = new w(w.ADDED, !0);
                    b.target = a;
                    a.dispatchEvent(b)
                }
                return a
            },
            addChildAt: function(a, b) {
                if (b > this.__children.length || 0 > b) throw "Invalid index position " + b;
                if (a.parent == this) u.remove(this.__children, a);
                else {
                    null != a.parent && a.parent.removeChild(a);
                    a.parent = this;
                    null != this.stage && a.__setStageReference(this.stage);
                    a.__transformDirty || (a.__transformDirty = !0, V.__worldTransformDirty++);
                    a.__renderDirty || (a.__renderDirty = !0, V.__worldRenderDirty++);
                    var c = new w(w.ADDED, !0);
                    c.target = a;
                    a.dispatchEvent(c)
                }
                this.__children.splice(b, 0, a);
                return a
            },
            removeChild: function(a) {
                null !=
                    a && a.parent == this && (null != this.stage && a.__setStageReference(null), a.parent = null, u.remove(this.__children, a), this.__removedChildren.push(a), a.__transformDirty || (a.__transformDirty = !0, V.__worldTransformDirty++), a.__renderDirty || (a.__renderDirty = !0, V.__worldRenderDirty++), a.dispatchEvent(new w(w.REMOVED, !0)));
                return a
            },
            __broadcast: function(a, b) {
                null == a.target && (a.target = this);
                if (b)
                    for (var c = 0, d = this.__children; c < d.length;) {
                        var e = d[c];
                        ++c;
                        e.__broadcast(a, !0);
                        if (a.__isCancelled) return !0
                    }
                return $a.prototype.__broadcast.call(this,
                    a, b)
            },
            __getBounds: function(a, b) {
                if (0 != this.__children.length) {
                    var c = null;
                    null != b && (c = this.__worldTransform, this.__worldTransform = b, this.__updateChildren(!0));
                    for (var d = 0, e = this.__children; d < e.length;) {
                        var f = e[d];
                        ++d;
                        f.__renderable && f.__getBounds(a, null)
                    }
                    null != b && (this.__worldTransform = c, this.__updateChildren(!0))
                }
            },
            __hitTest: function(a, b, c, d, e) {
                if (!this.get_visible() || e && !this.mouseEnabled) return !1;
                var f = this.__children.length;
                if (e)
                    if (null == d || !this.mouseChildren)
                        for (; 0 <= --f;) {
                            if (this.__children[f].__hitTest(a,
                                    b, c, null, !0)) return null != d && d.push(this), !0
                        } else {
                            if (null != d)
                                for (var l = d.length; 0 <= --f;)
                                    if (this.__children[f].__hitTest(a, b, c, d, e)) return d.splice(l, 0, this), !0
                        } else
                            for (; 0 <= --f;) this.__children[f].__hitTest(a, b, c, d, !1);
                return !1
            },
            __renderCanvas: function(a) {
                if (this.__renderable && !(0 >= this.__worldAlpha)) {
                    this.get_scrollRect();
                    null != this.__mask && a.maskManager.pushMask(this.__mask);
                    for (var b = 0, c = this.__children; b < c.length;) {
                        var d = c[b];
                        ++b;
                        d.__renderCanvas(a)
                    }
                    this.__removedChildren = [];
                    null != this.__mask &&
                        a.maskManager.popMask();
                    this.get_scrollRect()
                }
            },
            __renderDOM: function(a) {
                null != this.__mask && a.maskManager.pushMask(this.__mask);
                for (var b = 0, c = this.__children; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.__renderDOM(a)
                }
                b = 0;
                for (c = this.__removedChildren; b < c.length;) d = c[b], ++b, null == d.stage && d.__renderDOM(a);
                this.__removedChildren = [];
                null != this.__mask && a.maskManager.popMask()
            },
            __renderGL: function(a) {
                if (this.__renderable && !(0 >= this.__worldAlpha)) {
                    for (var b = 0, c = this.__children; b < c.length;) {
                        var d = c[b];
                        ++b;
                        d.__renderGL(a)
                    }
                    this.__removedChildren = []
                }
            },
            __renderMask: function(a) {
                var b = new za;
                this.__getTransform();
                this.__getBounds(b, new da);
                a.context.rect(0, 0, b.width, b.height)
            },
            __setStageReference: function(a) {
                if (this.stage != a && (null != this.stage && this.dispatchEvent(new w(w.REMOVED_FROM_STAGE, !1, !1)), this.stage = a, null != a && this.dispatchEvent(new w(w.ADDED_TO_STAGE, !1, !1)), null != this.__children))
                    for (var b = 0, c = this.__children; b < c.length;) {
                        var d = c[b];
                        ++b;
                        d.__setStageReference(a)
                    }
            },
            __update: function(a, b) {
                $a.prototype.__update.call(this, a, b);
                if (this.__renderable &&
                    b)
                    for (var c = 0, d = this.__children; c < d.length;) {
                        var e = d[c];
                        ++c;
                        e.__update(a, !0)
                    }
            },
            __updateChildren: function(a) {
                $a.prototype.__updateChildren.call(this, a);
                for (var b = 0, c = this.__children; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.__update(a, !0)
                }
            },
            __class__: Ha
        });
        var y = function() {
            Ha.call(this);
            this.buttonMode = !1;
            this.useHandCursor = !0;
            this.loaderInfo = Wb.create(null)
        };
        g["openfl.display.Sprite"] = y;
        y.__name__ = ["openfl", "display", "Sprite"];
        y.__super__ = Ha;
        y.prototype = t(Ha.prototype, {
            __getBounds: function(a, b) {
                Ha.prototype.__getBounds.call(this,
                    a, b);
                null != this.__graphics && this.__graphics.__getBounds(a, null != b ? b : this.__worldTransform)
            },
            __hitTest: function(a, b, c, d, e) {
                return !this.get_visible() || e && !this.mouseEnabled ? !1 : Ha.prototype.__hitTest.call(this, a, b, c, d, e) ? e : null != this.__graphics && this.__graphics.__hitTest(a, b, c, this.__getTransform()) ? (null != d && d.push(this), !0) : !1
            },
            __renderCanvas: function(a) {
                Jf.render(this, a);
                Ha.prototype.__renderCanvas.call(this, a)
            },
            __renderDOM: function(a) {
                Kf.render(this, a);
                Ha.prototype.__renderDOM.call(this, a)
            },
            __renderGL: function(a) {
                !this.__renderable ||
                    0 >= this.__worldAlpha || (null != this.__graphics && F.render(this, a), Ha.prototype.__renderGL.call(this, a))
            },
            __renderMask: function(a) {
                null != this.__graphics ? h.renderMask(this.__graphics, a) : Ha.prototype.__renderMask.call(this, a)
            },
            get_graphics: function() {
                null == this.__graphics && (this.__graphics = new Ke);
                return this.__graphics
            },
            __class__: y,
            __properties__: t(Ha.prototype.__properties__, {
                get_graphics: "get_graphics"
            })
        });
        var wd = function() {};
        g.ResizeListener = wd;
        wd.__name__ = ["ResizeListener"];
        wd.prototype = {
            __class__: wd
        };
        var sa = function() {
            y.call(this);
            sa.instance = this;
            this.active = !0;
            this.init();
            this.completeIntro()
        };
        g.Main = sa;
        sa.__name__ = ["Main"];
        sa.__interfaces__ = [wd];
        sa.instance = null;
        sa.currentLevel = null;
        sa.initStage = function() {
            m.get_instance().init();
            K.get_instance().init(m.get_instance().id);
            Ba.get_instance().init("UA-59792812-10", "none");
            Ba.get_instance().save("load");
            Ca.create()
        };
        sa.completePreloader = function() {
            sa.initSounds()
        };
        sa.initSounds = function() {
            L.get_instance().addMusic("theme", "assets/sound/music/theme.ogg");
            L.get_instance().addSfx("click", "assets/sound/sfx/click.ogg");
            L.get_instance().addSfx("collide", "assets/sound/sfx/collide.ogg");
            L.get_instance().addSfx("coin", "assets/sound/sfx/coin.ogg");
            L.get_instance().addSfx("achievement", "assets/sound/sfx/achievement.ogg");
            L.get_instance().addSfx("fall", "assets/sound/sfx/fall.ogg");
            L.get_instance().addSfx("new_record", "assets/sound/sfx/new_record.ogg");
            L.get_instance().addSfx("crushing_wall", "assets/sound/sfx/crushing_wall.ogg");
            L.get_instance().addSfx("revive",
                "assets/sound/sfx/revive.ogg");
            L.get_instance().addSfx("revive_window", "assets/sound/sfx/revive_window.ogg");
            "true" == K.get_instance().get("soundMuted") ? L.get_instance().mute(!0) : K.get_instance().save("soundMuted", !1)
        };
        sa.__super__ = y;
        sa.prototype = t(y.prototype, {
            init: function() {
                this.firstPlay = !0;
                sa.currentLevel = 0;
                this.soundDeactivated = !1;
                this.timeStep = new Uc(60, 1);
                this.createBackground();
                this.sceneManager = new xd;
                this.addChild(this.sceneManager);
                S.current.stage.addEventListener(w.ACTIVATE, r(this, this.activate));
                S.current.stage.addEventListener(w.DEACTIVATE, r(this, this.deactivate));
                S.current.stage.addEventListener(w.ENTER_FRAME, r(this, this.update));
                window.document.addEventListener("visibilitychange", r(this, this.visibilityHandler));
                ia.get_instance().setOrientationHandler(r(this, this.onOrientation));
                ia.get_instance().setResizeHandler(r(this, this.onResize));
                ia.get_instance().setPauseHandler(r(this, this.pauseHandler));
                ia.get_instance().setUnpauseHandler(r(this, this.unpauseHandler));
                ia.get_instance().start();
                Da.get_instance().init();
                Ca.get_instance().addListener(this);
                this.resize()
            },
            onOrientation: function() {
                Ca.get_instance().newResize()
            },
            onResize: function() {
                Ca.get_instance().newResize()
            },
            pauseHandler: function() {
                N.get_instance().postNotify("softgames", this, {
                    id: "pause"
                })
            },
            unpauseHandler: function() {
                N.get_instance().postNotify("softgames", this, {
                    id: "resume"
                })
            },
            createBackground: function() {
                this.background = new y;
                this.addChild(this.background);
                this.tempBackground = new y;
                this.tempBackground.set_alpha(0);
                this.addChild(this.tempBackground);
                this.gradientBoxMatrix = new da;
                this.gradientBoxMatrix.createGradientBox(m.get_instance().width, m.get_instance().height, Math.PI / 2, 0, 0)
            },
            showBg: function(a) {
                null == a && (a = !0);
                1 == a ? (this.tempBackground.set_alpha(0), this.drawBg(this.tempBackground), A.tween(this.tempBackground, 2, {
                    alpha: 1
                }).ease(na.get_easeIn()).onComplete(r(this, this.completeShowBg))) : this.drawBg(this.background)
            },
            completeShowBg: function() {
                this.drawBg(this.background);
                this.tempBackground.set_alpha(0);
                this.tempBackground.get_graphics().clear()
            },
            drawBg: function(a) {
                var b = B.get_instance().getTheme();
                a.get_graphics().clear();
                a.get_graphics().beginGradientFill(Xb.LINEAR, [b.from, b.to], [1, 1], [70, 255], this.gradientBoxMatrix);
                a.get_graphics().drawRect(0, 0, m.get_instance().width, m.get_instance().height);
                a.get_graphics().endFill()
            },
            updateBg: function() {
                this.drawBg(this.tempBackground);
                this.drawBg(this.background)
            },
            visibilityHandler: function(a) {
                "hidden" == window.document.visibilityState ? this.deactivate(a) : this.activate(a)
            },
            completeIntro: function() {
                L.get_instance().playMusic("theme");
                this.showBg(!1);
                this.showScene("Menu")
            },
            activate: function(a) {
                this.activateSound()
            },
            activateSound: function() {
                1 == this.soundDeactivated && (this.soundDeactivated = !1, L.get_instance().mute(!1))
            },
            deactivate: function(a) {
                this.deactivateSound()
            },
            deactivateSound: function() {
                0 == L.get_instance().isMuted() && (L.get_instance().mute(!0), this.soundDeactivated = !0)
            },
            update: function(a) {
                0 != this.active && (this.timeStep.update(), 1 == this.sceneManager.isReady() && this.sceneManager.udpate(this.timeStep.getDelta(), this.timeStep.checkUpdate()))
            },
            moreGames: function(a) {
                //window.open("https://m.softgames.de");
                SG.redirectToPortal();
            },
            showScene: function(a, b) {
                null == b && (b = !0);
                if (0 == this.sceneManager.isReady()) return null;
                var c = "scenes." + a,
                    d = C.createObjectByClassName(c);
                if (null == d) return console.log("No scene: " + c + " founded"), null;
                this.sceneManager.show(d, b);
                return d
            },
            resize: function() {
                this.sceneManager.set_x(m.get_instance().viewX);
                this.sceneManager.set_y(m.get_instance().viewY);
                this.sceneManager.set_scaleX(m.get_instance().scale);
                this.sceneManager.set_scaleY(m.get_instance().scale);
                this.updateBg()
            },
            __class__: sa
        });
        var td = function() {
            S.current.addChild(this);
            sa.call(this);
            this.dispatchEvent(new w(w.ADDED_TO_STAGE, !1, !1))
        };
        g.DocumentClass = td;
        td.__name__ = ["DocumentClass"];
        td.__super__ = sa;
        td.prototype = t(sa.prototype, {
            __class__: td
        });
        var yd = function(a, b) {
            y.call(this);
            this.init(a, b)
        };
        g.BestScorePanel = yd;
        yd.__name__ = ["BestScorePanel"];
        yd.__super__ = y;
        yd.prototype = t(y.prototype, {
            init: function(a, b) {
                var c = m.formatAsset("assets/images/%25p%25/progres.html"),
                    c = ta.buildSprite(c);
                this.addChild(c); -
                1 != a && this.showNormal(a, b);
                a < b && this.showBest(b)
            },
            showNormal: function(a, b) {
                var c = m.formatAsset("assets/images/%25p%25/record_1.html"),
                    d = ta.buildSprite(c);
                d.setAnchorPoint(.5, 1);
                d.set_y(-35);
                this.addChild(d);
                a >= b ? (d.set_y(-25), d.set_x(246)) : 0 < a ? (c = -210 + 330 * C.toPercent(a, b), d.set_x(c), c = m.formatAsset("assets/images/%25p%25/progres_marker.html"), c = ta.buildSprite(c), c.set_x(0), c.set_y(35), d.addChild(c)) : (d.set_x(-245), d.set_y(-25));
                c = new qa;
                c.set_size(58);
                c.set_fieldWidth(140);
                c.set_fieldHeight(60);
                c.set_align("center");
                c.set_x(-70);
                c.set_y(-140);
                c.set_text("" + a);
                d.addChild(c)
            },
            showBest: function(a) {
                var b = m.formatAsset("assets/images/%25p%25/record_2.html"),
                    b = ta.buildSprite(b);
                b.setAnchorPoint(.5, 1);
                b.set_x(248);
                b.set_y(-25);
                this.addChild(b);
                var c = new qa;
                c.setSystemFont();
                c.set_size(16);
                c.set_fieldWidth(140);
                c.set_fieldHeight(40);
                c.set_align("center");
                c.set_x(-70);
                c.set_y(-100);
                var d = Da.get_instance().getPhrase("label0").toUpperCase();
                c.set_text(d);
                b.addChild(c);
                c = new qa;
                c.set_size(36);
                c.set_fieldWidth(140);
                c.set_fieldHeight(40);
                c.set_align("center");
                c.set_x(-70);
                c.set_y(-82);
                c.set_text("" + a);
                b.addChild(c)
            },
            __class__: yd
        });
        var zd = function() {};
        g["com.alagatar.entity.ComponentCleaner"] = zd;
        zd.__name__ = ["com", "alagatar", "entity", "ComponentCleaner"];
        zd.prototype = {
            clean: function(a) {},
            __class__: zd
        };
        var Ad = function() {};
        g.ComponentCleaner = Ad;
        Ad.__name__ = ["ComponentCleaner"];
        Ad.__super__ = zd;
        Ad.prototype = t(zd.prototype, {
            clean: function(a) {
                switch (O.getClassName(O.getClass(a))) {
                    case "components.Tile":
                        this.clearTile(a);
                        break;
                    case "components.Block":
                        this.clearBlock(a)
                }
            },
            clearBlock: function(a) {
                a.items = [];
                a.items = null;
                for (var b = a.tiles.length, c, d = 0; d < b;) c = d++, c = a.tiles[c], ba.stopTween(c), c.destroyToCache();
                a.tiles = [];
                a.tiles = null
            },
            clearTile: function(a) {
                null != a.graph ? (A.stop(a.graph), a.graph.parent.removeChild(a.graph), a.graph.destroyToCache(), a.graph = null) : null != a.group && (a.group.parent.removeChild(a.group), a.group.destroyChildsToCache(), a.group = null)
            },
            __class__: Ad
        });
        var oc = function() {};
        g["com.alagatar.interfaces.ISingleton"] = oc;
        oc.__name__ = ["com", "alagatar", "interfaces",
            "ISingleton"
        ];
        var m = function() {
            m._instance = this;
            U.call(this)
        };
        g.Configs = m;
        m.__name__ = ["Configs"];
        m.__interfaces__ = [oc];
        m.__properties__ = {
            get_instance: "get_instance"
        };
        m.formatAsset = function(a) {
            return M.replace(a, "%p%", m.get_instance().packFolder)
        };
        m.formatStageX = function(a) {
            return (a - m.get_instance().viewX) / m.get_instance().nativeScale
        };
        m.formatStageY = function(a) {
            return (a - m.get_instance().viewY) / m.get_instance().nativeScale
        };
        m.getMouseX = function(a) {
            a = S.current.stage.get_mouseX();
            return a = m.formatStageX(a)
        };
        m.getMouseY = function(a) {
            a = S.current.stage.get_mouseY();
            return a = m.formatStageY(a)
        };
        m._instance = null;
        m.get_instance = function() {
            null == m._instance && (m._instance = new m);
            return m._instance
        };
        m.__super__ = U;
        m.prototype = t(U.prototype, {
            init: function() {
                this.list = [];
                this.parseList = [];
                this.id = "game.tiptap2";
                this.nativeWidth = v.parseInt("720");
                this.nativeHeight = v.parseInt("1280");
                this.nativeOrientation = "portrait";
                null == this.nativeOrientation && (this.nativeOrientation = "auto");
                this.halfNativeWidth = this.nativeWidth /
                    2 | 0;
                this.halfNativeHeight = this.nativeHeight / 2 | 0;
                this.viewY = this.viewX = 0;
                this.initParseList()
            },
            initParseList: function() {
                this.list = [{
                    id: "config",
                    value: {
                        i: [{
                            i: [
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 1,
                                        x: 0
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 1,
                                        x: 1
                                    }]
                                }],
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 1,
                                        x: 0
                                    }, {
                                        y: 1,
                                        x: 1
                                    }]
                                }],
                                [{
                                    t: "top",
                                    r: !1,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }]
                                }, {
                                    t: "right",
                                    r: !0,
                                    o: 2,
                                    i: [{
                                        y: 1,
                                        x: 1
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 1,
                                        x: 0
                                    }]
                                }]
                            ],
                            rows: 2,
                            cols: 2
                        }, {
                            i: [
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 0,
                                        x: 2
                                    }, {
                                        y: 1,
                                        x: 0
                                    }, {
                                        y: 1,
                                        x: 1
                                    }, {
                                        y: 1,
                                        x: 2
                                    }, {
                                        y: 2,
                                        x: 0
                                    }, {
                                        y: 2,
                                        x: 2
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 2,
                                        x: 1
                                    }]
                                }],
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 0,
                                        x: 2
                                    }, {
                                        y: 1,
                                        x: 0
                                    }, {
                                        y: 1,
                                        x: 2
                                    }]
                                }, {
                                    t: "right",
                                    r: !0,
                                    o: 2,
                                    i: [{
                                        y: 2,
                                        x: 1
                                    }, {
                                        y: 2,
                                        x: 2
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 1,
                                        x: 1
                                    }, {
                                        y: 2,
                                        x: 0
                                    }]
                                }],
                                [{
                                    t: "left",
                                    r: !1,
                                    o: 4,
                                    i: [{
                                        y: 1,
                                        x: 0
                                    }]
                                }, {
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 0,
                                        x: 2
                                    }, {
                                        y: 1,
                                        x: 1
                                    }, {
                                        y: 1,
                                        x: 2
                                    }]
                                }, {
                                    t: "bottom",
                                    r: !0,
                                    o: 3,
                                    i: [{
                                        y: 2,
                                        x: 2
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 2,
                                        x: 0
                                    }, {
                                        y: 2,
                                        x: 1
                                    }]
                                }]
                            ],
                            rows: 3,
                            cols: 3
                        }, {
                            i: [
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 0,
                                        x: 2
                                    }, {
                                        y: 0,
                                        x: 3
                                    }, {
                                        y: 1,
                                        x: 0
                                    }, {
                                        y: 1,
                                        x: 1
                                    }, {
                                        y: 1,
                                        x: 2
                                    }, {
                                        y: 1,
                                        x: 3
                                    }, {
                                        y: 2,
                                        x: 0
                                    }, {
                                        y: 2,
                                        x: 1
                                    }, {
                                        y: 2,
                                        x: 3
                                    }, {
                                        y: 3,
                                        x: 0
                                    }, {
                                        y: 3,
                                        x: 3
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 2,
                                        x: 2
                                    }, {
                                        y: 3,
                                        x: 1
                                    }, {
                                        y: 3,
                                        x: 2
                                    }]
                                }],
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 0,
                                        x: 2
                                    }, {
                                        y: 0,
                                        x: 3
                                    }, {
                                        y: 1,
                                        x: 0
                                    }, {
                                        y: 1,
                                        x: 1
                                    }, {
                                        y: 1,
                                        x: 2
                                    }, {
                                        y: 2,
                                        x: 0
                                    }, {
                                        y: 2,
                                        x: 1
                                    }, {
                                        y: 3,
                                        x: 0
                                    }, {
                                        y: 3,
                                        x: 3
                                    }]
                                }, {
                                    t: "right",
                                    r: !0,
                                    o: 2,
                                    i: [{
                                        y: 1,
                                        x: 3
                                    }, {
                                        y: 2,
                                        x: 3
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 2,
                                        x: 2
                                    }, {
                                        y: 3,
                                        x: 1
                                    }, {
                                        y: 3,
                                        x: 2
                                    }]
                                }],
                                [{
                                    t: "top",
                                    r: !0,
                                    o: 1,
                                    i: [{
                                        y: 0,
                                        x: 0
                                    }, {
                                        y: 0,
                                        x: 1
                                    }, {
                                        y: 0,
                                        x: 2
                                    }, {
                                        y: 0,
                                        x: 3
                                    }, {
                                        y: 1,
                                        x: 0
                                    }, {
                                        y: 1,
                                        x: 1
                                    }, {
                                        y: 1,
                                        x: 2
                                    }, {
                                        y: 1,
                                        x: 3
                                    }, {
                                        y: 2,
                                        x: 0
                                    }, {
                                        y: 2,
                                        x: 1
                                    }, {
                                        y: 2,
                                        x: 3
                                    }, {
                                        y: 3,
                                        x: 0
                                    }]
                                }, {
                                    t: "right",
                                    r: !0,
                                    o: 2,
                                    i: [{
                                        y: 3,
                                        x: 2
                                    }, {
                                        y: 3,
                                        x: 3
                                    }]
                                }, {
                                    t: "center",
                                    i: [{
                                        y: 2,
                                        x: 2
                                    }, {
                                        y: 3,
                                        x: 1
                                    }]
                                }]
                            ],
                            rows: 4,
                            cols: 4
                        }]
                    }
                }]
            },
            getConfig: function(a) {
                for (var b = 0, c = this.list.length; b < c;) {
                    var d = b++;
                    if (this.list[d].id == a) return this.list[d].value
                }
                return null
            },
            __class__: m
        });
        var Hb = function() {};
        g.DateTools = Hb;
        Hb.__name__ = ["DateTools"];
        Hb.__format_get = function(a, b) {
            switch (b) {
                case "%":
                    return "%";
                case "C":
                    return M.lpad(v.string(v["int"](a.getFullYear() / 100)), "0", 2);
                case "d":
                    return M.lpad(v.string(a.getDate()), "0", 2);
                case "D":
                    return Hb.__format(a,
                        "%m/%d/%y");
                case "e":
                    return v.string(a.getDate());
                case "H":
                case "k":
                    return M.lpad(v.string(a.getHours()), "H" == b ? "0" : " ", 2);
                case "I":
                case "l":
                    var c = a.getHours() % 12;
                    return M.lpad(v.string(0 == c ? 12 : c), "I" == b ? "0" : " ", 2);
                case "m":
                    return M.lpad(v.string(a.getMonth() + 1), "0", 2);
                case "M":
                    return M.lpad(v.string(a.getMinutes()), "0", 2);
                case "n":
                    return "\n";
                case "p":
                    return 11 < a.getHours() ? "PM" : "AM";
                case "r":
                    return Hb.__format(a, "%I:%M:%S %p");
                case "R":
                    return Hb.__format(a, "%H:%M");
                case "s":
                    return v.string(v["int"](a.getTime() /
                        1E3));
                case "S":
                    return M.lpad(v.string(a.getSeconds()), "0", 2);
                case "t":
                    return "\t";
                case "T":
                    return Hb.__format(a, "%H:%M:%S");
                case "u":
                    return c = a.getDay(), 0 == c ? "7" : null == c ? "null" : "" + c;
                case "w":
                    return v.string(a.getDay());
                case "y":
                    return M.lpad(v.string(a.getFullYear() % 100), "0", 2);
                case "Y":
                    return v.string(a.getFullYear());
                default:
                    throw "Date.format %" + b + "- not implemented yet.";
            }
        };
        Hb.__format = function(a, b) {
            for (var c = new pc, d = 0;;) {
                var e = b.indexOf("%", d);
                if (0 > e) break;
                c.addSub(b, d, e - d);
                c.add(Hb.__format_get(a,
                    u.substr(b, e + 1, 1)));
                d = e + 2
            }
            c.addSub(b, d, b.length - d);
            return c.b
        };
        Hb.format = function(a, b) {
            return Hb.__format(a, b)
        };
        var Bd = function() {};
        g["lime.AssetLibrary"] = Bd;
        Bd.__name__ = ["lime", "AssetLibrary"];
        Bd.prototype = {
            exists: function(a, b) {
                return !1
            },
            getBytes: function(a) {
                return null
            },
            getFont: function(a) {
                return null
            },
            getImage: function(a) {
                return null
            },
            getPath: function(a) {
                return null
            },
            getText: function(a) {
                a = this.getBytes(a);
                return null == a ? null : a.readUTFBytes(a.length)
            },
            isLocal: function(a, b) {
                return !0
            },
            __class__: Bd
        };
        var Dd = function() {
            this.type = new pa;
            this.path = new pa;
            this.className = new pa;
            var a;
            a = "assets/fonts/screengem.eot";
            this.path.set(a, a);
            this.type.set(a, "BINARY");
            a = "assets/fonts/screengem.svg";
            this.path.set(a, a);
            this.type.set(a, "TEXT");
            a = "assets/fonts/screengem.ttf";
            this.className.set(a, Cd);
            this.type.set(a, "FONT");
            a = "assets/fonts/screengem.woff";
            this.path.set(a, a);
            this.type.set(a, "BINARY");
            a = "assets/images/hd/bottom_panel.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_back.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_buy.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_buy2.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_coins.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_gift.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_gift2.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_hero.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_moreGames.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_play.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_plus.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_sound_off.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_sound_on.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_video.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/buttons/btn_video2.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/coins_ui.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/coins_ui2.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/hand.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/panel.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/progres.png";
            this.path.set(a, a);
            this.type.set(a,
                "IMAGE");
            a = "assets/images/hd/progres_marker.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/record_1.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/record_2.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/score_in_game.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/spritelists/main.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/spritelists/main.xml";
            this.path.set(a, a);
            this.type.set(a, "TEXT");
            a = "assets/images/hd/spritelists/shop.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/images/hd/spritelists/shop.xml";
            this.path.set(a, a);
            this.type.set(a, "TEXT");
            a = "assets/images/hd/top_panel.png";
            this.path.set(a, a);
            this.type.set(a, "IMAGE");
            a = "assets/sound/music/theme.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/music/theme.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/achievement.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/achievement.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/click.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/click.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/coin.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/coin.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/collide.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/collide.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/crushing_wall.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/crushing_wall.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/fall.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/fall.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/new_record.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/new_record.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/revive.mp3";
            this.path.set(a, a);
            this.type.set(a,
                "MUSIC");
            a = "assets/sound/sfx/revive.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/sound/sfx/revive_window.mp3";
            this.path.set(a, a);
            this.type.set(a, "MUSIC");
            a = "assets/sound/sfx/revive_window.ogg";
            this.path.set(a, a);
            this.type.set(a, "SOUND");
            a = "assets/texts/localization.json";
            this.path.set(a, a);
            this.type.set(a, "TEXT");
            a = oa.config.assetsPrefix;
            if (null != a)
                for (var b = this.path.keys(); b.hasNext();) {
                    var c = b.next(),
                        d = a + this.path.get(c);
                    this.path.set(c, d)
                }
        };
        g.DefaultAssetLibrary = Dd;
        Dd.__name__ = ["DefaultAssetLibrary"];
        Dd.__super__ = Bd;
        Dd.prototype = t(Bd.prototype, {
            exists: function(a, b) {
                var c;
                c = null != b ? x.__cast(b, String) : null;
                var d = this.type.get(a);
                return null == d || d != c && ("SOUND" != c && "MUSIC" != c || "MUSIC" != d && "SOUND" != d) && "BINARY" != c && null != c && ("BINARY" != d || "TEXT" != c) ? !1 : !0
            },
            getBytes: function(a) {
                var b = null,
                    b = this.path.get(a);
                a = Ia.loaders.get(b).data;
                "string" == typeof a ? (b = new fb, b.writeUTFBytes(a)) : b = x.__instanceof(a, fb) ? a : null;
                return null != b ? (b.position = 0, b) : null
            },
            getFont: function(a) {
                a = x.__cast(O.createInstance(this.className.get(a), []), Ib);
                return new Vc(a.name)
            },
            getImage: function(a) {
                return gb.fromImageElement(function(b) {
                    b = b.path.get(a);
                    return Ia.images.get(b)
                }(this))
            },
            getPath: function(a) {
                return this.path.get(a)
            },
            getText: function(a) {
                var b = null;
                a = this.path.get(a);
                a = Ia.loaders.get(a).data;
                if ("string" == typeof a) return a;
                b = x.__instanceof(a, fb) ? a : null;
                return null != b ? (b.position = 0, b.readUTFBytes(b.length)) : null
            },
            isLocal: function(a, b) {
                null != b && x.__cast(b, String);
                return !0
            },
            __class__: Dd
        });
        var Ib = function(a) {
            this.name = a;
            null != this.__fontPath &&
                this.__fromFile(this.__fontPath)
        };
        g["lime.text.Font"] = Ib;
        Ib.__name__ = ["lime", "text", "Font"];
        Ib.prototype = {
            __fromFile: function(a) {
                this.__fontPath = a
            },
            __class__: Ib
        };
        var Cd = function() {
            Ib.call(this);
            this.name = "Screengem-Regular"
        };
        g.__ASSET__assets_fonts_screengem_ttf = Cd;
        Cd.__name__ = ["__ASSET__assets_fonts_screengem_ttf"];
        Cd.__super__ = Ib;
        Cd.prototype = t(Ib.prototype, {
            __class__: Cd
        });
        var ra = function(a, b) {
            b = b.split("u").join("");
            this.r = new RegExp(a, b)
        };
        g.EReg = ra;
        ra.__name__ = ["EReg"];
        ra.prototype = {
            match: function(a) {
                this.r.global &&
                    (this.r.lastIndex = 0);
                this.r.m = this.r.exec(a);
                this.r.s = a;
                return null != this.r.m
            },
            matched: function(a) {
                if (null != this.r.m && 0 <= a && a < this.r.m.length) return this.r.m[a];
                throw "EReg::matched";
            },
            replace: function(a, b) {
                return a.replace(this.r, b)
            },
            __class__: ra
        };
        var Le = function(a) {
            this.setChance(a)
        };
        g.FairRandom = Le;
        Le.__name__ = ["FairRandom"];
        Le.prototype = {
            setChance: function(a) {
                this.chance = a;
                0 > this.chance && (this.chance = 0);
                1 < this.chance && (this.chance = 1);
                this.initGenSize();
                this.genTable();
                this.genIndex()
            },
            initGenSize: function() {
                var a =
                    this.calcDecimal(this.chance);
                5 < a && (a = 5, this.chance = C.roundDec(this.chance, 5));
                this.count = this.total = 0;
                0 != this.chance && (this.total = v["int"](Math.pow(10, a)), this.count = v["int"](Math.round(this.chance * this.total)))
            },
            calcDecimal: function(a) {
                var b = "" + a;
                a = new ra("(?:\\.(\\d+))?(?:[eE]([+-]?\\d+))?$", "");
                if (0 == a.match(b)) return 0;
                b = 0;
                null != a.matched(1) && (b = a.matched(1).length);
                var c = 0;
                null != a.matched(2) && (c = v.parseFloat(a.matched(2)));
                return Math.max(0, b - c)
            },
            genTable: function() {
                this.table = [];
                for (var a =
                        0, b = this.total; a < b;) a++, this.table.push(!1);
                for (a = 0; a != this.count;) b = Math.floor((this.total - 1 + 1) * Math.random()), 0 == this.table[b] && (a++, this.table[b] = !0)
            },
            genIndex: function() {
                this.index = Math.floor((this.total - 1 + 1) * Math.random());
                this.gens = 0
            },
            check: function() {
                var a = this.table[this.index];
                this.index++;
                this.index == this.total && (this.index = 0);
                this.gens++;
                this.gens == this.total && this.complete();
                return a
            },
            complete: function() {
                this.genTable();
                this.genIndex()
            },
            __class__: Le
        };
        var u = function() {};
        g.HxOverrides = u;
        u.__name__ = ["HxOverrides"];
        u.dateStr = function(a) {
            var b = a.getMonth() + 1,
                c = a.getDate(),
                d = a.getHours(),
                e = a.getMinutes(),
                f = a.getSeconds();
            return a.getFullYear() + "-" + (10 > b ? "0" + b : "" + b) + "-" + (10 > c ? "0" + c : "" + c) + " " + (10 > d ? "0" + d : "" + d) + ":" + (10 > e ? "0" + e : "" + e) + ":" + (10 > f ? "0" + f : "" + f)
        };
        u.strDate = function(a) {
            switch (a.length) {
                case 8:
                    a = a.split(":");
                    var b = new Date;
                    b.setTime(0);
                    b.setUTCHours(a[0]);
                    b.setUTCMinutes(a[1]);
                    b.setUTCSeconds(a[2]);
                    return b;
                case 10:
                    return a = a.split("-"), new Date(a[0], a[1] - 1, a[2], 0, 0, 0);
                case 19:
                    return b =
                        a.split(" "), a = b[0].split("-"), b = b[1].split(":"), new Date(a[0], a[1] - 1, a[2], b[0], b[1], b[2]);
                default:
                    throw "Invalid date format : " + a;
            }
        };
        u.cca = function(a, b) {
            var c = a.charCodeAt(b);
            return c != c ? void 0 : c
        };
        u.substr = function(a, b, c) {
            if (null != b && 0 != b && null != c && 0 > c) return "";
            null == c && (c = a.length);
            0 > b ? (b = a.length + b, 0 > b && (b = 0)) : 0 > c && (c = a.length + c - b);
            return a.substr(b, c)
        };
        u.indexOf = function(a, b, c) {
            var d = a.length;
            0 > c && (c += d, 0 > c && (c = 0));
            for (; c < d;) {
                if (a[c] === b) return c;
                c++
            }
            return -1
        };
        u.remove = function(a, b) {
            var c = u.indexOf(a,
                b, 0);
            if (-1 == c) return !1;
            a.splice(c, 1);
            return !0
        };
        u.iter = function(a) {
            return {
                cur: 0,
                arr: a,
                hasNext: function() {
                    return this.cur < this.arr.length
                },
                next: function() {
                    return this.arr[this.cur++]
                }
            }
        };
        var qc = function(a, b, c) {
            y.call(this);
            this.button = null;
            this.startButtonX = 0;
            this.init(a, b, c)
        };
        g.IconField = qc;
        qc.__name__ = ["IconField"];
        qc.__super__ = y;
        qc.prototype = t(y.prototype, {
            init: function(a, b, c) {
                this.startIconX = b;
                this.startLabelX = c;
                a = m.formatAsset(a);
                this.icon = ta.buildSprite(a);
                this.icon.set_x(this.startIconX);
                this.addChild(this.icon);
                this.label = new qa;
                this.label.set_color(14804194);
                this.label.set_size(42);
                this.label.set_fieldWidth(200);
                this.label.set_fieldHeight(40);
                this.label.set_align("left");
                this.label.set_x(this.startLabelX);
                this.label.set_y(-22);
                this.addChild(this.label)
            },
            alignToCenter: function() {
                var a = this.startLabelX + this.label.get_textWidth() + 4;
                null != this.button && (a += a - this.startButtonX + this.button.get_width() / 2);
                a /= 2;
                this.icon.set_x(this.startIconX - a);
                this.label.set_x(this.startLabelX - a);
                null != this.button && this.button.set_x(this.label.get_x() +
                    this.label.get_textWidth() + this.startButtonX)
            },
            update: function(a) {
                this.label.set_text("" + a);
                this.alignToCenter()
            },
            animate: function(a) {
                this.label.set_text("" + a);
                A.tween(this.icon, .15, {
                    scaleX: 1.2,
                    scaleY: 1.2
                }).ease(na.get_easeOut()).reflect().repeat(1)
            },
            addButton: function(a, b) {
                this.button = a;
                this.startButtonX = b;
                this.addChild(this.button);
                this.alignToCenter()
            },
            free: function() {
                this.button = this.icon = this.label = null
            },
            __class__: qc
        });
        var Ed = function() {};
        g.Lambda = Ed;
        Ed.__name__ = ["Lambda"];
        Ed.indexOf = function(a,
            b) {
            for (var c = 0, d = pg(a)(); d.hasNext();) {
                var e = d.next();
                if (b == e) return c;
                c++
            }
            return -1
        };
        var Wc = function() {
            this.length = 0
        };
        g.List = Wc;
        Wc.__name__ = ["List"];
        Wc.prototype = {
            add: function(a) {
                a = [a];
                null == this.h ? this.h = a : this.q[1] = a;
                this.q = a;
                this.length++
            },
            iterator: function() {
                return {
                    h: this.h,
                    hasNext: function() {
                        return null != this.h
                    },
                    next: function() {
                        if (null == this.h) return null;
                        var a = this.h[0];
                        this.h = this.h[1];
                        return a
                    }
                }
            },
            __class__: Wc
        };
        var Fd = function() {};
        g.IMap = Fd;
        Fd.__name__ = ["IMap"];
        Math.__name__ = ["Math"];
        var yb =
            function() {
                y.call(this)
            };
        g.NMEPreloader = yb;
        yb.__name__ = ["NMEPreloader"];
        yb.__super__ = y;
        yb.prototype = t(y.prototype, {
            onInit: function() {
                this.createUi()
            },
            createUi: function() {
                var a = S.current.stage.stageWidth,
                    b = a - 6 - 200,
                    a = a / 2 - b / 2,
                    c = S.current.stage.stageHeight / 2 - 25;
                this.outline = new y;
                this.outline.get_graphics().lineStyle(2, 3352349, 1, !0);
                this.outline.get_graphics().drawRect(0, 0, b, 50);
                this.outline.set_x(a);
                this.outline.set_y(c);
                this.progressBar.addChild(this.outline);
                this.progress = new y;
                this.progress.get_graphics().beginFill(16724005,
                    1);
                this.progress.get_graphics().drawRect(0, 0, b - 6, 44);
                this.progress.set_x(a + 3);
                this.progress.set_y(c + 3);
                this.progress.set_scaleX(0);
                this.progressBar.addChild(this.progress)
            },
            onLoaded: function() {
                this.dispatchEvent(new w(w.COMPLETE))
            },
            onUpdate: function(a, b) {
                var c = a / b;
                1 < c && (c = 1);
                this.progress.set_scaleX(c)
            },
            handleAssets: function(a, b) {
                for (var c = a.length, d = 0, e = 0; e < c;) {
                    e++;
                    if (d >= a.length) break;
                    0 == this.checkAssetNeed(a[d], b[d]) ? (a.splice(d, 1), b.splice(d, 1)) : d++
                }
            },
            checkAssetNeed: function(a, b) {
                return !0
            },
            __class__: yb
        });
        var Aa = function(a, b, c, d) {
            null == d && (d = -1);
            null == c && (c = !0);
            this.transparent = c;
            if (0 < a && 0 < b) {
                this.width = a;
                this.height = b;
                this.rect = new za(0, 0, a, b);
                if (c) {
                    var e = d & -16777216;
                    0 == (0 > e ? 4294967296 + e : e + 0) && (d = 0)
                } else d = -16777216 | d & 16777215;
                this.__image = new gb(null, 0, 0, a, b, d);
                this.__image.set_transparent(c);
                this.__isValid = !0
            }
            this.__createUVs()
        };
        g["openfl.display.BitmapData"] = Aa;
        Aa.__name__ = ["openfl", "display", "BitmapData"];
        Aa.__interfaces__ = [vd];
        Aa.fromCanvas = function(a, b) {
            null == b && (b = !0);
            var c = new Aa(0, 0, b);
            c.__loadFromImage(gb.fromCanvas(a));
            c.__image.set_transparent(b);
            return c
        };
        Aa.fromImage = function(a, b) {
            null == b && (b = !0);
            var c = new Aa(0, 0, b);
            c.__loadFromImage(a);
            c.__image.set_transparent(b);
            return c
        };
        Aa.prototype = {
            copyPixels: function(a, b, c, d, e, f) {
                null == f && (f = !1);
                this.__isValid && null != a && this.__image.copyPixels(a.__image, b.__toLimeRectangle(), c.__toLimeVector2(), null != d ? d.__image : null, null != e ? e.__toLimeVector2() : null, f)
            },
            draw: function(a, b, c, d, e, f) {
                null == f && (f = !1);
                if (this.__isValid) switch (this.__image.type[1]) {
                    case 0:
                        W.convertToCanvas(this.__image),
                            W.sync(this.__image), c = this.__image.buffer, d = new Ec, d.context = c.__srcContext, d.roundPixels = !0, f || (c.__srcContext.mozImageSmoothingEnabled = !1, c.__srcContext.webkitImageSmoothingEnabled = !1, c.__srcContext.imageSmoothingEnabled = !1), e = a.__worldTransform, a.__worldTransform = null != b ? b : new da, a.__updateChildren(!1), a.__renderCanvas(d), a.__worldTransform = e, a.__updateChildren(!0), f || (c.__srcContext.mozImageSmoothingEnabled = !0, c.__srcContext.webkitImageSmoothingEnabled = !0, c.__srcContext.imageSmoothingEnabled = !0), c.__srcContext.setTransform(1, 0, 0, 1, 0, 0)
                }
            },
            getTexture: function(a) {
                null == this.__texture && (this.__texture = a.createTexture(), a.bindTexture(a.TEXTURE_2D, this.__texture), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_S, a.CLAMP_TO_EDGE), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_T, a.CLAMP_TO_EDGE), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, a.LINEAR), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, a.LINEAR), this.__image.dirty = !0);
                if (this.__image.dirty) {
                    a.bindTexture(a.TEXTURE_2D, this.__texture);
                    var b = this.__image.clone();
                    b.set_premultiplied(!0);
                    a.texImage2D(a.TEXTURE_2D, 0, a.RGBA, this.width, this.height, 0, a.RGBA, a.UNSIGNED_BYTE, b.get_data());
                    a.bindTexture(a.TEXTURE_2D, null);
                    this.__image.dirty = !1
                }
                return this.__texture
            },
            __createUVs: function() {
                null == this.__uvData && (this.__uvData = new Xc);
                this.__uvData.x0 = 0;
                this.__uvData.y0 = 0;
                this.__uvData.x1 = 1;
                this.__uvData.y1 = 0;
                this.__uvData.x2 = 1;
                this.__uvData.y2 = 1;
                this.__uvData.x3 = 0;
                this.__uvData.y3 = 1
            },
            __loadFromBase64: function(a, b, c) {
                var d = this;
                gb.fromBase64(a,
                    b,
                    function(a) {
                        d.__loadFromImage(a);
                        null != c && c(d)
                    })
            },
            __loadFromImage: function(a) {
                this.__image = a;
                this.width = a.width;
                this.height = a.height;
                this.rect = new za(0, 0, a.width, a.height);
                this.__isValid = !0
            },
            __renderCanvas: function(a) {
                if (this.__isValid) {
                    W.sync(this.__image);
                    var b = a.context;
                    null == this.__worldTransform && (this.__worldTransform = new da);
                    b.globalAlpha = 1;
                    var c = this.__worldTransform;
                    a.roundPixels ? b.setTransform(c.a, c.b, c.c, c.d, c.tx | 0, c.ty | 0) : b.setTransform(c.a, c.b, c.c, c.d, c.tx, c.ty);
                    b.drawImage(this.__image.buffer.get_src(),
                        0, 0)
                }
            },
            __sync: function() {
                W.sync(this.__image)
            },
            __updateChildren: function(a) {},
            __class__: Aa
        };
        var hb = function(a, b, c, d, e) {
            null == d && (d = -1);
            null == c && (c = !0);
            Aa.call(this, 0, 0, c, d);
            null != hb.preload ? this.__image = hb.preload : this.__loadFromBase64(Yb.getString(hb.resourceName), hb.resourceType, function(a) {
                null == hb.preload && (hb.preload = a.__image);
                null != e && e(a)
            })
        };
        g.Logo = hb;
        hb.__name__ = ["Logo"];
        hb.preload = null;
        hb.__super__ = Aa;
        hb.prototype = t(Aa.prototype, {
            __class__: hb
        });
        var ib = function(a, b, c, d, e) {
            null == d && (d = -1);
            null == c && (c = !0);
            Aa.call(this, 0, 0, c, d);
            null != ib.preload ? this.__image = ib.preload : this.__loadFromBase64(Yb.getString(ib.resourceName), ib.resourceType, function(a) {
                null == ib.preload && (ib.preload = a.__image);
                null != e && e(a)
            })
        };
        g.ProgressBarBg = ib;
        ib.__name__ = ["ProgressBarBg"];
        ib.preload = null;
        ib.__super__ = Aa;
        ib.prototype = t(Aa.prototype, {
            __class__: ib
        });
        var jb = function(a, b, c, d, e) {
            null == d && (d = -1);
            null == c && (c = !0);
            Aa.call(this, 0, 0, c, d);
            null != jb.preload ? this.__image = jb.preload : this.__loadFromBase64(Yb.getString(jb.resourceName),
                jb.resourceType,
                function(a) {
                    null == jb.preload && (jb.preload = a.__image);
                    null != e && e(a)
                })
        };
        g.ProgressBarBody = jb;
        jb.__name__ = ["ProgressBarBody"];
        jb.preload = null;
        jb.__super__ = Aa;
        jb.prototype = t(Aa.prototype, {
            __class__: jb
        });
        var kb = function(a, b, c, d, e) {
            null == d && (d = -1);
            null == c && (c = !0);
            Aa.call(this, 0, 0, c, d);
            null != kb.preload ? this.__image = kb.preload : this.__loadFromBase64(Yb.getString(kb.resourceName), kb.resourceType, function(a) {
                null == kb.preload && (kb.preload = a.__image);
                null != e && e(a)
            })
        };
        g.SoftgamesLogo = kb;
        kb.__name__ = ["SoftgamesLogo"];
        kb.preload = null;
        kb.__super__ = Aa;
        kb.prototype = t(Aa.prototype, {
            __class__: kb
        });
        var Ka = function() {
            y.call(this)
        };
        g.Preloader = Ka;
        Ka.__name__ = ["Preloader"];
        Ka.__interfaces__ = [wd];
        Ka.__super__ = yb;
        Ka.prototype = t(yb.prototype, {
            onInit: function() {
                this.init()
            },
            init: function() {
                this.checkIsMobile();
                sa.initStage();
                Ca.get_instance().addListener(this);
                this.resize();
                this.createUi();
                this.initElements();
                this.addRotatePic();
                this.addResizeListener()
            },
            createUi: function() {
                var a = new Zb(new hb(518, 982));
                a.smoothing = !0;
                a.set_x(101);
                a.set_y(30);
                this.addChild(a);
                this.softLogo = new Zb(new kb(916, 229));
                this.softLogo.smoothing = !0;
                this.softLogo.set_x(-98);
                this.softLogo.set_y(250);
                this.addChild(this.softLogo);
                this.updateLogo();
                this.progressBar = new y;
                this.progressBar.set_scaleX(1.5);
                this.progressBar.set_scaleY(1.5);
                this.progressBar.set_x(m.get_instance().halfNativeWidth - 291);
                this.progressBar.set_y(580);
                this.addChild(this.progressBar);
                a = new Zb(new ib(582, 55));
                a.smoothing = !0;
                this.progressBar.addChild(a);
                this.progress = new y;
                this.progress.set_x(18);
                this.progress.set_y(19);
                this.progressBar.addChild(this.progress);
                a = new Zb(new jb(1, 17));
                a.set_scaleX(352);
                a.set_scaleY(1.05);
                this.progress.addChild(a);
                this.progress.set_scaleX(0)
            },
            checkIsMobile: function() {
                var a = window.navigator.userAgent;
                if ((new ra("android", "i")).match(a) || (new ra("webOS", "i")).match(a) || (new ra("iPhone", "i")).match(a) || (new ra("iPad", "i")).match(a) || (new ra("iPod", "i")).match(a) || (new ra("BlackBerry", "i")).match(a) || (new ra("Windows Phone", "i")).match(a) ||
                    (new ra("IEMobile", "i")).match(a) || (new ra("Opera Mini", "i")).match(a) || (new ra("ZuneWP7", "i")).match(a) || (new ra("Opera Mobi", "i")).match(a) || (new ra("windows mobile", "i")).match(a) || (new ra("nokia", "i")).match(a) || (new ra("PSP", "i")).match(a) || (new ra("Kindle", "i")).match(a) || (new ra("PS Vita", "i")).match(a) || (new ra("Mobi", "i")).match(a) || (new ra("bada", "i")).match(a)) Ka.onMobile = !0;
                if ((new ra("windows mobile", "i")).match(a) || (new ra("windows phone", "i")).match(a) || (new ra("iemobile", "i")).match(a) ||
                    (new ra("windows nt", "i")).match(a) && (new ra("touch", "i")).match(a) || window.ActiveXObject || "ActiveXObject" in window) Ka.isIE = !0
            },
            initElements: function() {
                this.body = window.document.getElementsByTagName("body")[0];
                this.openfl_content = window.document.getElementById("openfl-content");
                this.openfl_canvas = this.openfl_content.getElementsByTagName("canvas")[0];
                0 == Ka.onMobile && (this.body.style.overflow = "hidden")
            },
            addRotatePic: function() {
                this.rotatePic = window.document.createElement("div");
                this.rotatePic.style.backgroundImage =
                    "url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPkAAACQCAMAAAD9aj0wAAAAV1BMVEXU0tK/vr6tra3U1NS3t7evr6/FxMQAAAD////g4ODu7u7MysrFxMSurq6wsLCsrKyvr6/CwcHU0tL///+vr6/X19fDw8Ps7Oy3t7fLysq/v7/5+fnf398/Cs2HAAAAEnRSTlN8wVytjMbBAHybi4ubOXoV66+01YRNAAAE1klEQVR42u3c7XKjIBSA4URFElvR4JHv+7/OxW43bXeDEkyygrx/O83MM4cc6J8eMO6KoqieECmKtsOb7YCL6lKW52dUlpeqxVvt0Fbl6Wk1dbXZqR+K+vTEmsvn0Dt0jRBStP//LBzsyJ9ZWeCPWlDsM/gTsqugxaGtl58DPCFyPnzFOTejZAJsPSKeizAF+TVuxg9/XxXL+qTkH2k+Mh99evKP+Cit3p587CxRuU1zqgB6Ej75cHnTnFfXND5y9+gFAArDh8ubsq6P66vrc7jcxqnFV0UAJlheH9/eDqt7e3s/NmvkNsOmwQdwwuTno3U/pEu9Tm7TVEAf8PQNlB8e1FvdrJVb+ygAfthjkB8b5+uVjiPn2vPQWzvB12KQ/ztzXKHfwe+EHDlftvPrmY9X/q22JQShic8M9znzNz4jTvlnbUEsX0iuF+wACDuKUz7VFVUPwIyetTNALXYWp3yqnUYv+ZxdLm26OOW2jvQgjJ7ddGhh0cUpt7UVAHXbNfNYdHHKp8HP2g1AhZeKU26z9nHtiY9TPs1dGRddKwCPHR+n/OP7zrTLLv3occqtvRfcRTeeey5OOe4QjGvpccqnTSf1WnqcclyA4g46t/SE5bhFwkU3vmsuTjnukDBueod9ilOOMQIXnQLqUpbP0CWgpOWWzp2vOZK0vHOuOe79VY9TjjsQ2rHlvM97nHLcghxux7xv9TjlmMC4+rzHKcfIdd5HIGnLO2CO/S68hx6nHBPX1Wb8hx6n/BFDj1M+DX31Nz1OuXvo0GPP4pTjCrTr+d5GIi8IQSGBcd3pPQqIkKJ7qbztAUCxgIQabieABQS24oXyDmDUQ1DUfdyDPlEbAe3r5ATGITDuOu4GTOgnotfJkRiCA+ra7nIIS8IL5Sxcrly/K9QQ1hiJXArn6BKXj+D8AU9drh2bKnW5Ae7c+nHKuWdOuQbJfduMnDPwz3mo4Z6k3oJcC1BKzqW+Em65UNfkfEqB2oJcgqSzKfje4DFzRRdiYDYgZ4LOJ0Hwr1xyafhnCiRdCsYNyJWgi3Q5+EeB0TjkduZLsTvoxsLTkd9B56BoSnJLN35wIWhacqq86NrCU5P70RXI9OSWzpfg0sITlFMhFugjMJqkfIluQNFE5XKWzi08Vfk0dT13nyUsl6AcdK0ETVnupiuQacstnbnus8Tl1Bpv32fJyykDees+24H8Xzq38F3ILd38fZ/tRE4VmJ/32W7kP+gM5I7kls6/3Wd7kl//ejHAaGxyyRi/ykPp030Wm5yDANDhcjnRuVA0OrkUVAIPltuEmu6z+ORstVwCAN2lnEoldyq3ZXmWZ3mWZ3mWZ3mWZ3mWZ3mWZ3mWZ3mWB8lhr3IOAGrYo3zg46j3KZ/K8qWyPMuzPMuzPMuzPMuzPMuzPMuzPMsfIT9FJW/q9wfJL2Vc8lN5vLw/okvdRCY/neuHZCcem/xRZfmcnAJ9eRL4BuQcXj50CUJvQD4YeHmCD/fKz+XNTdaEy218fHV6uFteX27fXnfKN5Sn/Hx0PVJTl9vX3U5n7nriNOnLXUUtJ2WAJ0guhg0l+0NxOT2x5r39/m/YN5MW1aGrnjj0pib4Tx0oPWwkraA74OK9PD8rC/+qACHHbST6Fh8wbkn1rFr8vRbBRkIdxr8A9bK+7dFKincAAAAASUVORK5CYII=')";
                this.rotatePic.style.position = "absolute";
                this.rotatePic.style.width = "249px";
                this.rotatePic.style.height = "144px";
                this.rotatePic.style.display = "none";
                this.body.appendChild(this.rotatePic)
            },
            addResizeListener: function() {
                window.addEventListener("resize", r(this, this.resizeHandler));
                this.onResize(!0)
            },
            resizeHandler: function(a) {
                this.onResize()
            },
            onResize: function(a) {
                1 == Ka.onMobile && this.checkOrientation()
            },
            checkOrientation: function() {
                1 == window.matchMedia("(orientation: portrait)").matches ? this.setPortrait() :
                    this.setLandscape()
            },
            setLandscape: function() {
                "landscape" == m.get_instance().nativeOrientation ? this.unLockView() : this.lockView()
            },
            setPortrait: function() {
                "portrait" == m.get_instance().nativeOrientation ? this.unLockView() : this.lockView()
            },
            lockView: function() {
                this.openfl_canvas.style.opacity = "0";
                S.current.set_visible(!1);
                this.showRotatePic()
            },
            unLockView: function() {
                this.openfl_canvas.style.opacity = "1";
                S.current.set_visible(!0);
                this.rotatePic.style.display = "none"
            },
            showRotatePic: function() {
                var a = window.innerHeight,
                    b = window.innerWidth / 2 - v.parseFloat(this.rotatePic.style.width) / 2,
                    a = a / 2 - v.parseFloat(this.rotatePic.style.height) / 2;
                this.rotatePic.style.left = b + "px";
                this.rotatePic.style.top = a + "px";
                this.rotatePic.style.display = "block"
            },
            onUpdate: function(a, b) {
                this.progress.set_scaleX(a / b)
            },
            onLoaded: function() {
                this.complete()
            },
            complete: function() {
                "complete" != window.document.readyState ? window.document.body.onload = r(this, this.allLoaded) : this.allLoaded()
            },
            allLoaded: function(a) {
                this.onResize(!0);
                this.hideAdressBar();
                this.completePreloader()
            },
            hideAdressBar: function() {
                setTimeout("window.scrollTo(0, 1)", 10)
            },
            completePreloader: function() {
                A.tween(this.progressBar, .5, {
                    alpha: 0
                }).ease(qb.get_easeNone());
                sa.completePreloader();
                this.showPlayButton()
            },
            showPlayButton: function() {
                var a = new xa("assets/images/hd/buttons/btn_play.png");
                a.onlyFirstClick = !0;
                a.addEventListener("complete", r(this, this.nextScreen));
                a.set_x(m.get_instance().halfNativeWidth);
                a.set_y(625);
                a.setSoundEffect("click");
                this.addChild(a);
                ba.animate(a, {
                    dir: 1,
                    delay: .2
                })
            },
            nextScreen: function(a) {
                Ca.get_instance().delListener(this);
                this.dispatchEvent(new w(w.COMPLETE))
            },
            checkAssetNeed: function(a, b) {
                return 1 == Ka.isIE && -1 != a.indexOf("sound") ? !1 : !0
            },
            resize: function() {
                this.set_x(m.get_instance().viewX);
                this.set_y(m.get_instance().viewY);
                this.set_scaleX(m.get_instance().scale);
                this.set_scaleY(m.get_instance().scale);
                null != this.softLogo && this.updateLogo()
            },
            updateLogo: function() {
                var a = 920 * this.get_scaleX();
                m.get_instance().width < a ? (this.softLogo.set_scaleX(.7), this.softLogo.set_scaleY(.7), this.softLogo.set_x(40)) : (this.softLogo.set_scaleX(1),
                    this.softLogo.set_scaleY(1), this.softLogo.set_x(-98))
            },
            __class__: Ka
        });
        var z = function() {};
        g.Reflect = z;
        z.__name__ = ["Reflect"];
        z.hasField = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        };
        z.field = function(a, b) {
            try {
                return a[b]
            } catch (c) {
                return null
            }
        };
        z.setField = function(a, b, c) {
            a[b] = c
        };
        z.getProperty = function(a, b) {
            var c;
            return null == a ? null : a.__properties__ && (c = a.__properties__["get_" + b]) ? a[c]() : a[b]
        };
        z.setProperty = function(a, b, c) {
            var d;
            if (a.__properties__ && (d = a.__properties__["set_" + b])) a[d](c);
            else a[b] = c
        };
        z.callMethod = function(a, b, c) {
            return b.apply(a, c)
        };
        z.fields = function(a) {
            var b = [];
            if (null != a) {
                var c = Object.prototype.hasOwnProperty,
                    d;
                for (d in a) "__id__" != d && "hx__closures__" != d && c.call(a, d) && b.push(d)
            }
            return b
        };
        z.isFunction = function(a) {
            return "function" == typeof a && !(a.__name__ || a.__ename__)
        };
        z.compare = function(a, b) {
            return a == b ? 0 : a > b ? 1 : -1
        };
        z.compareMethods = function(a, b) {
            return a == b ? !0 : z.isFunction(a) && z.isFunction(b) ? a.scope == b.scope && a.method == b.method && null != a.method : !1
        };
        z.isEnumValue =
            function(a) {
                return null != a && null != a.__enum__
            };
        z.deleteField = function(a, b) {
            if (!Object.prototype.hasOwnProperty.call(a, b)) return !1;
            delete a[b];
            return !0
        };
        var Gd = function() {
            y.call(this);
            this.init()
        };
        g.ScorePanel = Gd;
        Gd.__name__ = ["ScorePanel"];
        Gd.__super__ = y;
        Gd.prototype = t(y.prototype, {
            init: function() {
                var a = m.formatAsset("assets/images/%25p%25/score_in_game.html");
                this.background = ta.buildSprite(a);
                this.addChild(this.background);
                this.label = new qa;
                this.label.set_color(14804194);
                this.label.set_size(58);
                this.label.set_fieldWidth(140);
                this.label.set_fieldHeight(60);
                this.label.set_align("center");
                this.label.set_x(-70);
                this.label.set_y(-32);
                this.label.set_text("0");
                this.addChild(this.label)
            },
            update: function(a) {
                this.label.set_text("" + a);
                A.tween(this, .15, {
                    scaleX: 1.2,
                    scaleY: 1.2
                }).ease(na.get_easeOut()).reflect().repeat(1)
            },
            __class__: Gd
        });
        var v = function() {};
        g.Std = v;
        v.__name__ = ["Std"];
        v.string = function(a) {
            return x.__string_rec(a, "")
        };
        v["int"] = function(a) {
            return a | 0
        };
        v.parseInt = function(a) {
            var b = parseInt(a, 10);
            0 != b || 120 != u.cca(a, 1) && 88 !=
                u.cca(a, 1) || (b = parseInt(a));
            return isNaN(b) ? null : b
        };
        v.parseFloat = function(a) {
            return parseFloat(a)
        };
        var pc = function() {
            this.b = ""
        };
        g.StringBuf = pc;
        pc.__name__ = ["StringBuf"];
        pc.prototype = {
            add: function(a) {
                this.b += v.string(a)
            },
            addSub: function(a, b, c) {
                this.b = null == c ? this.b + u.substr(a, b, null) : this.b + u.substr(a, b, c)
            },
            __class__: pc
        };
        var M = function() {};
        g.StringTools = M;
        M.__name__ = ["StringTools"];
        M.urlEncode = function(a) {
            return encodeURIComponent(a)
        };
        M.urlDecode = function(a) {
            return decodeURIComponent(a.split("+").join(" "))
        };
        M.startsWith = function(a, b) {
            return a.length >= b.length && u.substr(a, 0, b.length) == b
        };
        M.lpad = function(a, b, c) {
            if (0 >= b.length) return a;
            for (; a.length < c;) a = b + a;
            return a
        };
        M.replace = function(a, b, c) {
            return a.split(b).join(c)
        };
        M.hex = function(a, b) {
            var c = "";
            do c = "0123456789ABCDEF".charAt(a & 15) + c, a >>>= 4; while (0 < a);
            if (null != b)
                for (; c.length < b;) c = "0" + c;
            return c
        };
        M.fastCodeAt = function(a, b) {
            return a.charCodeAt(b)
        };
        var $b = function() {
            this.init()
        };
        g.Tutorial = $b;
        $b.__name__ = ["Tutorial"];
        $b.checkNeed = function() {
            return 3 ==
                $b.getCountTutorial() ? !1 : !0
        };
        $b.getCountTutorial = function() {
            var a = 0;
            null != K.get_instance().get("tutorial") && (a = v.parseInt(K.get_instance().get("tutorial")));
            return a
        };
        $b.prototype = {
            init: function() {
                this.repeats = this.step = 0
            },
            update: function(a) {
                switch (this.step) {
                    case 0:
                        this.step0(a);
                        break;
                    case 1:
                        this.step1(a);
                        break;
                    case 2:
                        this.step2(a);
                        break;
                    case 3:
                        this.step3(a)
                }
            },
            step0: function(a) {
                this.step = 1;
                n.get_instance().eventManager.sendEvent("game", {
                    id: "controllOff"
                })
            },
            step1: function(a) {
                2 == a.dir && (this.step =
                    2)
            },
            step2: function(a) {
                1 == this.checkHeroOnConnection(a.hero, a.position) && (a.system.working = !1, this.step = 3, this.showHand(), n.get_instance().eventManager.sendEvent("game", {
                    id: "controllOn"
                }))
            },
            showHand: function() {
                var a = Pa.instance.layersManager.getLayer("foreground");
                if (null == this.hand) {
                    var b = m.formatAsset("assets/images/%25p%25/hand.html");
                    this.hand = ta.buildSprite(b);
                    this.hand.set_x(360);
                    a.addChild(this.hand)
                }
                this.hand.set_y(1E3 - a.get_y());
                this.hand.set_visible(!0);
                A.tween(this.hand, .4, {
                    scaleX: 1.2,
                    scaleY: 1.2,
                    y: this.hand.get_y() + 30
                }).ease(na.get_easeIn()).repeat().reflect()
            },
            hideHand: function() {
                this.hand.set_visible(!1);
                A.stop(this.hand, null, !1, !1)
            },
            checkHeroOnConnection: function(a, b) {
                var c = n.get_instance().getSystem("PathSystem").getPathEntityById(a.path),
                    c = n.get_instance().getComponentIn(c, ca),
                    c = C.calcDistOfDots(b.x, b.y, a.startX, a.startY) - c.connectionLength;
                return 5 >= Math.abs(c) ? !0 : !1
            },
            step3: function(a) {
                a.system.working = !0;
                this.hideHand();
                this.completeTutorial(a)
            },
            completeTutorial: function(a) {
                this.repeats +=
                    1;
                2 == this.repeats ? (a.system.tutorial = !1, a = $b.getCountTutorial(), a += 1, K.get_instance().save("tutorial", a)) : (this.step = 1, n.get_instance().eventManager.sendEvent("game", {
                    id: "controllOff"
                }))
            },
            __class__: $b
        };
        var X = g.ValueType = {
            __ename__: ["ValueType"],
            __constructs__: "TNull TInt TFloat TBool TObject TFunction TClass TEnum TUnknown".split(" ")
        };
        X.TNull = ["TNull", 0];
        X.TNull.toString = p;
        X.TNull.__enum__ = X;
        X.TInt = ["TInt", 1];
        X.TInt.toString = p;
        X.TInt.__enum__ = X;
        X.TFloat = ["TFloat", 2];
        X.TFloat.toString = p;
        X.TFloat.__enum__ =
            X;
        X.TBool = ["TBool", 3];
        X.TBool.toString = p;
        X.TBool.__enum__ = X;
        X.TObject = ["TObject", 4];
        X.TObject.toString = p;
        X.TObject.__enum__ = X;
        X.TFunction = ["TFunction", 5];
        X.TFunction.toString = p;
        X.TFunction.__enum__ = X;
        X.TClass = function(a) {
            a = ["TClass", 6, a];
            a.__enum__ = X;
            a.toString = p;
            return a
        };
        X.TEnum = function(a) {
            a = ["TEnum", 7, a];
            a.__enum__ = X;
            a.toString = p;
            return a
        };
        X.TUnknown = ["TUnknown", 8];
        X.TUnknown.toString = p;
        X.TUnknown.__enum__ = X;
        var O = function() {};
        g.Type = O;
        O.__name__ = ["Type"];
        O.getClass = function(a) {
            return null == a ?
                null : x.getClass(a)
        };
        O.getClassName = function(a) {
            return a.__name__.join(".")
        };
        O.getEnumName = function(a) {
            return a.__ename__.join(".")
        };
        O.resolveClass = function(a) {
            a = g[a];
            return null != a && a.__name__ ? a : null
        };
        O.resolveEnum = function(a) {
            a = g[a];
            return null != a && a.__ename__ ? a : null
        };
        O.createInstance = function(a, b) {
            switch (b.length) {
                case 0:
                    return new a;
                case 1:
                    return new a(b[0]);
                case 2:
                    return new a(b[0], b[1]);
                case 3:
                    return new a(b[0], b[1], b[2]);
                case 4:
                    return new a(b[0], b[1], b[2], b[3]);
                case 5:
                    return new a(b[0], b[1],
                        b[2], b[3], b[4]);
                case 6:
                    return new a(b[0], b[1], b[2], b[3], b[4], b[5]);
                case 7:
                    return new a(b[0], b[1], b[2], b[3], b[4], b[5], b[6]);
                case 8:
                    return new a(b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]);
                default:
                    throw "Too many arguments";
            }
        };
        O.createEmptyInstance = function(a) {
            function b() {}
            b.prototype = a.prototype;
            return new b
        };
        O.createEnum = function(a, b, c) {
            var d = z.field(a, b);
            if (null == d) throw "No such constructor " + b;
            if (z.isFunction(d)) {
                if (null == c) throw "Constructor " + b + " need parameters";
                return d.apply(a, c)
            }
            if (null != c && 0 !=
                c.length) throw "Constructor " + b + " does not need parameters";
            return d
        };
        O.getClassFields = function(a) {
            a = z.fields(a);
            u.remove(a, "__name__");
            u.remove(a, "__interfaces__");
            u.remove(a, "__properties__");
            u.remove(a, "__super__");
            u.remove(a, "prototype");
            return a
        };
        O.getEnumConstructs = function(a) {
            return a.__constructs__.slice()
        };
        O["typeof"] = function(a) {
            switch (typeof a) {
                case "boolean":
                    return X.TBool;
                case "string":
                    return X.TClass(String);
                case "number":
                    return Math.ceil(a) == a % 2147483648 ? X.TInt : X.TFloat;
                case "object":
                    if (null ==
                        a) return X.TNull;
                    var b = a.__enum__;
                    if (null != b) return X.TEnum(b);
                    a = x.getClass(a);
                    return null != a ? X.TClass(a) : X.TObject;
                case "function":
                    return a.__name__ || a.__ename__ ? X.TObject : X.TFunction;
                case "undefined":
                    return X.TNull;
                default:
                    return X.TUnknown
            }
        };
        var B = function() {
            this.additionalButtonId = "";
            B._instance = this;
            this.init()
        };
        g.Variables = B;
        B.__name__ = ["Variables"];
        B.__interfaces__ = [oc];
        B.__properties__ = {
            get_instance: "get_instance"
        };
        B._instance = null;
        B.get_instance = function() {
            null == B._instance && (B._instance =
                new B);
            return B._instance
        };
        B.prototype = {
            init: function() {
                this.bestScore = this.score = -1;
                this.coins = 0;
                this.newRecord = !1;
                null != K.get_instance().get("coins") ? this.coins = v.parseInt("" + v.string(K.get_instance().get("coins"))) : K.get_instance().save("coins", 0);
                this.hero = 1;
                null != K.get_instance().get("hero") ? this.hero = v.parseInt("" + v.string(K.get_instance().get("hero"))) : (K.get_instance().save("hero", 1), K.get_instance().save("hero_1", !0));
                this.theme = 1;
                null != K.get_instance().get("theme") ? this.theme = v.parseInt("" +
                    v.string(K.get_instance().get("theme"))) : K.get_instance().save("theme", 1);
                this.giftTimeout = 0;
                null != K.get_instance().get("giftTimeout") ? this.giftTimeout = v.parseInt("" + v.string(K.get_instance().get("giftTimeout"))) : K.get_instance().save("giftTimeout", 0);
                this.themes = [];
                this.themes.push({
                    from: 4671039,
                    to: 13404180
                });
                this.themes.push({
                    from: 4408393,
                    to: 5538255
                });
                this.themes.push({
                    from: 4801607,
                    to: 13527493
                });
                this.themes.push({
                    from: 4212292,
                    to: 3253334
                })
            },
            getCoins: function() {
                return this.coins
            },
            changeCoins: function(a) {
                this.coins +=
                    a;
                K.get_instance().save("coins", this.coins)
            },
            getHero: function() {
                return this.hero
            },
            buyHero: function(a) {
                this.setHero(a);
                K.get_instance().save("hero_" + a, !0)
            },
            setHero: function(a) {
                this.hero = a;
                K.get_instance().save("hero", this.hero)
            },
            checkHero: function(a) {
                return null == K.get_instance().get("hero_" + a) ? !1 : !0
            },
            checkAllHeroEnabled: function() {
                for (var a, b = 0; 16 > b;)
                    if (a = b++ + 1, 0 == this.checkHero(a)) return !1;
                return !0
            },
            getTheme: function() {
                return this.themes[this.theme - 1]
            },
            getThemeId: function() {
                return this.theme
            },
            nextThemeId: function() {
                this.theme +=
                    1;
                this.theme > this.themes.length && (this.theme = 1);
                K.get_instance().save("theme", this.theme)
            },
            getGiftTimeout: function() {
                return this.giftTimeout
            },
            completeGiftTimeout: function() {
                this.giftTimeout += 300;
                86400 < this.giftTimeout && (this.giftTimeout = 86400);
                K.get_instance().save("giftTimeout", this.giftTimeout)
            },
            saveScore: function(a, b) {
                null == b && (b = this.getTodayScoreKey());
                var c = this.getScoresByKey(b);
                c.push("" + a);
                c = c.join(",");
                K.get_instance().save(b, c)
            },
            getTodayScoreKey: function() {
                return Hb.format(new Date, "scores_%d_%m_%Y")
            },
            getScoresByKey: function(a) {
                var b = K.get_instance().get(a);
                return null == b || 0 == b.length ? (this.addScoreKey(a), []) : b.split(",")
            },
            addScoreKey: function(a) {
                var b = this.getScoresKeys();
                b.push(a);
                a = b.join(",");
                K.get_instance().save("scoresKeys", a)
            },
            getScoresKeys: function() {
                var a = K.get_instance().get("scoresKeys");
                return null == a || 0 == a.length ? [] : a.split(",")
            },
            getTodayBest: function() {
                var a = this.getTodayScoreKey();
                return this.getMaxScoreOf(a)
            },
            getMaxScoreOf: function(a) {
                a = this.getScoresByKey(a);
                for (var b = 0, c = a.length,
                        d, e = 0; e < c;) d = e++, d = v.parseInt(a[d]), d > b && (b = d);
                return b
            },
            getAverageScore: function() {
                for (var a = this.getScoresKeys(), b = 0, c = 0, d = a.length, e, f = 0; f < d;) e = f++, e = this.getScoresByKey(a[e]), b += e.length, c += this.getSumScores(e);
                return 0 == b ? 0 : v["int"](Math.floor(c / b))
            },
            getSumScores: function(a) {
                for (var b = a.length, c = 0, d, e = 0; e < b;) d = e++, d = v.parseInt(a[d]), c += d;
                return c
            },
            getBestScore: function() {
                return -1 != this.bestScore ? this.bestScore : this.bestScore = this.calcBestScore()
            },
            calcBestScore: function() {
                for (var a = this.getScoresKeys(),
                        b = a.length, c = 0, d = 0, e = 0; e < b;) d = e++, d = this.getMaxScoreOf(a[d]), d > c && (c = d);
                return c
            },
            __class__: B
        };
        g.XmlType = {
            __ename__: ["XmlType"],
            __constructs__: []
        };
        var I = function() {};
        g.Xml = I;
        I.__name__ = ["Xml"];
        I.Element = null;
        I.PCData = null;
        I.CData = null;
        I.Comment = null;
        I.DocType = null;
        I.ProcessingInstruction = null;
        I.Document = null;
        I.parse = function(a) {
            return ac.parse(a)
        };
        I.createElement = function(a) {
            var b = new I;
            b.nodeType = I.Element;
            b._children = [];
            b._attributes = new pa;
            b.set_nodeName(a);
            return b
        };
        I.createPCData = function(a) {
            var b =
                new I;
            b.nodeType = I.PCData;
            b.set_nodeValue(a);
            return b
        };
        I.createCData = function(a) {
            var b = new I;
            b.nodeType = I.CData;
            b.set_nodeValue(a);
            return b
        };
        I.createComment = function(a) {
            var b = new I;
            b.nodeType = I.Comment;
            b.set_nodeValue(a);
            return b
        };
        I.createDocType = function(a) {
            var b = new I;
            b.nodeType = I.DocType;
            b.set_nodeValue(a);
            return b
        };
        I.createProcessingInstruction = function(a) {
            var b = new I;
            b.nodeType = I.ProcessingInstruction;
            b.set_nodeValue(a);
            return b
        };
        I.createDocument = function() {
            var a = new I;
            a.nodeType = I.Document;
            a._children = [];
            return a
        };
        I.prototype = {
            get_nodeName: function() {
                if (this.nodeType != I.Element) throw "bad nodeType";
                return this._nodeName
            },
            set_nodeName: function(a) {
                if (this.nodeType != I.Element) throw "bad nodeType";
                return this._nodeName = a
            },
            set_nodeValue: function(a) {
                if (this.nodeType == I.Element || this.nodeType == I.Document) throw "bad nodeType";
                return this._nodeValue = a
            },
            get: function(a) {
                if (this.nodeType != I.Element) throw "bad nodeType";
                return this._attributes.get(a)
            },
            set: function(a, b) {
                if (this.nodeType != I.Element) throw "bad nodeType";
                this._attributes.set(a, b)
            },
            exists: function(a) {
                if (this.nodeType != I.Element) throw "bad nodeType";
                return this._attributes.exists(a)
            },
            elementsNamed: function(a) {
                if (null == this._children) throw "bad nodetype";
                return {
                    cur: 0,
                    x: this._children,
                    hasNext: function() {
                        for (var b = this.cur, c = this.x.length; b < c;) {
                            var d = this.x[b];
                            if (d.nodeType == I.Element && d._nodeName == a) break;
                            b++
                        }
                        this.cur = b;
                        return b < c
                    },
                    next: function() {
                        for (var b = this.cur, c = this.x.length; b < c;) {
                            var d = this.x[b];
                            b++;
                            if (d.nodeType == I.Element && d._nodeName == a) return this.cur =
                                b, d
                        }
                        return null
                    }
                }
            },
            firstElement: function() {
                if (null == this._children) throw "bad nodetype";
                for (var a = 0, b = this._children.length; a < b;) {
                    var c = this._children[a];
                    if (c.nodeType == I.Element) return c;
                    a++
                }
                return null
            },
            addChild: function(a) {
                if (null == this._children) throw "bad nodetype";
                null != a._parent && u.remove(a._parent._children, a);
                a._parent = this;
                this._children.push(a)
            },
            __class__: I,
            __properties__: {
                set_nodeValue: "set_nodeValue",
                set_nodeName: "set_nodeName",
                get_nodeName: "get_nodeName"
            }
        };
        var Me = function() {
            this.list = [];
            this.runs = this.elapsed = 0
        };
        g["aze.display.DrawList"] = Me;
        Me.__name__ = ["aze", "display", "DrawList"];
        Me.prototype = {
            begin: function(a, b, c, d, e) {
                this.flags = 0;
                this.fields = 3;
                1 == b ? (this.offsetTransform = this.fields, this.fields += 4, this.flags |= 16) : this.offsetTransform = 0;
                1 == d ? (this.offsetRGB = this.fields, this.fields += 3, this.flags |= 4) : this.offsetRGB = 0;
                1 == c ? (this.offsetAlpha = this.fields, this.fields++, this.flags |= 8) : this.offsetAlpha = 0;
                1 == e && (this.flags |= 65536);
                0 < a ? this.elapsed = a : (this.index = 0, a = Math.abs(S.getTimer()),
                    0 < this.time && (this.elapsed = Math.abs(Math.min(67, a - this.time))), this.time = a)
            },
            end: function() {
                if (this.list.length > this.index)
                    if (60 < ++this.runs) this.list.splice(this.index, this.list.length - this.index), this.runs = 0;
                    else
                        for (; this.index < this.list.length;) this.list[this.index + 2] = -2, this.index += this.fields
            },
            __class__: Me
        };
        var ja = function(a, b) {
            null == b && (b = 0);
            null == a && (a = 0);
            this.x = a;
            this.y = b
        };
        g["openfl.geom.Point"] = ja;
        ja.__name__ = ["openfl", "geom", "Point"];
        ja.prototype = {
            setTo: function(a, b) {
                this.x = a;
                this.y = b
            },
            __toLimeVector2: function() {
                return new rc(this.x, this.y)
            },
            __class__: ja
        };
        var sc = function(a) {
            this.__bitmap = a;
            this.__centerPoints = [];
            this.__tileRects = [];
            this.__tileUVs = [];
            this.__rectTile = new za;
            this.__rectUV = new za;
            this.__point = new ja
        };
        g["openfl.display.Tilesheet"] = sc;
        sc.__name__ = ["openfl", "display", "Tilesheet"];
        sc.prototype = {
            addTileRect: function(a, b) {
                this.__tileRects.push(a);
                null == b && (b = sc.__defaultPoint);
                this.__centerPoints.push(b);
                this.__tileUVs.push(new za(a.get_left() / this.__bitmap.width, a.get_top() /
                    this.__bitmap.height, a.get_right() / this.__bitmap.width, a.get_bottom() / this.__bitmap.height));
                return this.__tileRects.length - 1
            },
            drawTiles: function(a, b, c, d, e) {
                null == e && (e = -1);
                null == d && (d = 0);
                null == c && (c = !1);
                a.drawTiles(this, b, c, d, e)
            },
            __class__: sc
        };
        var Fc = function(a, b, c) {
            null == c && (c = 0);
            null == b && (b = 1);
            sc.call(this, a);
            this.scale = 1 / b;
            this.defs = [];
            this.anims = new pa;
            this.tiles = new pa;
            this.sizes = [];
            this.rotation = c;
            0 != c && (this.rotations = [])
        };
        g["aze.display.TilesheetEx"] = Fc;
        Fc.__name__ = ["aze", "display", "TilesheetEx"];
        Fc.__super__ = sc;
        Fc.prototype = t(sc.prototype, {
            addDefinition: function(a, b, c, d, e) {
                null == e && (e = !1);
                this.defs.push(a);
                this.sizes.push(b);
                1 != this.scale && (c.x /= this.scale, c.y /= this.scale, c.width /= this.scale, c.height /= this.scale, d.x /= this.scale, d.y /= this.scale);
                this.addTileRect(c, d);
                this.rotations.push(e)
            },
            getAnim: function(a) {
                if (this.anims.exists(a)) return this.anims.get(a);
                for (var b = [], c = 0, d = this.defs.length; c < d;) {
                    var e = c++;
                    1 == M.startsWith(this.defs[e], a) && b.push(e)
                }
                this.anims.set(a, b);
                return b
            },
            getIndex: function(a) {
                if (1 ==
                    this.tiles.exists(a)) return this.tiles.get(a);
                var b = u.indexOf(this.defs, a, 0);
                this.tiles.set(a, b);
                return b
            },
            getSize: function(a) {
                return a < this.sizes.length ? this.sizes[a] : new za
            },
            getRotation: function(a) {
                return a < this.rotations.length ? this.rotations[a] ? this.rotation : 0 : 0
            },
            __class__: Fc
        });
        var Hd = function(a, b, c, d) {
            null == d && (d = !0);
            null == c && (c = 1);
            Fc.call(this, a, c, -Math.PI / 2);
            new ja(0, 0);
            a = !1;
            for (b = (new Yc(I.parse(b).firstElement())).nodes.resolve("SubTexture").iterator(); b.hasNext();) {
                var e = b.next();
                c = e.att.resolve("name");
                a = e.has.resolve("rotated") && "true" == e.att.resolve("rotated");
                var f = new za;
                f.x = v.parseFloat(e.att.resolve("x"));
                f.y = v.parseFloat(e.att.resolve("y"));
                f.width = v.parseFloat(e.att.resolve("width"));
                f.height = v.parseFloat(e.att.resolve("height"));
                var l = new za;
                1 == e.has.resolve("frameX") ? (0 == a ? (l.x = v.parseInt(e.att.resolve("frameX")), l.y = v.parseInt(e.att.resolve("frameY"))) : (l.x = v.parseInt(e.att.resolve("frameY")), l.y = v.parseInt(e.att.resolve("frameX"))), l.width = v.parseInt(e.att.resolve("frameWidth")), l.height =
                    v.parseInt(e.att.resolve("frameHeight"))) : (l.width = f.width, l.height = f.height);
                new ja(l.x + l.width / 2, l.y + l.height / 2);
                e = 1 == d ? new ja(l.x + l.width / 2, l.y + l.height / 2) : 1 == e.has.resolve("frameX") ? new ja(l.x, l.y) : null;
                this.addDefinition(c, l, f, e, a)
            }
        };
        g["aze.display.SparrowTilesheet"] = Hd;
        Hd.__name__ = ["aze", "display", "SparrowTilesheet"];
        Hd.__super__ = Fc;
        Hd.prototype = t(Fc.prototype, {
            __class__: Hd
        });
        var bc = function(a) {
            this.layer = a;
            this.x = this.y = 0;
            this.visible = !0;
            this.animated = !1
        };
        g["aze.display.TileBase"] = bc;
        bc.__name__ = ["aze", "display", "TileBase"];
        bc.prototype = {
            init: function(a) {
                this.layer = a
            },
            step: function(a) {},
            __class__: bc
        };
        var P = function(a, b) {
            this.r = this.g = this.b = 1;
            bc.call(this, a);
            this._defaultRotation = this._rotation = 0;
            this.alpha = this._scaleX = this._scaleY = 1;
            this._mirror = 0;
            this._indice = -1;
            this.referenceY = this.referenceX = 0;
            this._transform = [];
            this.dirty = !0;
            this.set_tile(b)
        };
        g["aze.display.TileSprite"] = P;
        P.__name__ = ["aze", "display", "TileSprite"];
        P.pool = null;
        P.create = function(a, b, c) {
            null == c && (c = !0);
            null == P.pool && (P.pool = []);
            if (0 == P.pool.length || 0 == c) return new P(a, b);
            c = P.pool.pop();
            c.set_tile(b);
            c.layer = a;
            c.set_scaleX(1);
            c.set_scaleY(1);
            c.alpha = 1;
            return c
        };
        P.clearPool = function() {
            P.pool = []
        };
        P.__super__ = bc;
        P.prototype = t(bc.prototype, {
            init: function(a) {
                this.layer = a;
                this.set_indice(a.tilesheet.getIndex(this._tile));
                this.size = a.tilesheet.getSize(this._indice);
                this._defaultRotation = a.tilesheet.getRotation(this._indice)
            },
            test: function(a, b) {
                this._rotation = 0;
                this.alpha = this._scaleX = this._scaleY = 1;
                this._mirror = 0;
                this._indice = -1;
                this.referenceY = this.referenceX = 0;
                this._transform = [];
                this.dirty = !0;
                this.set_tile(b);
                this.layer = a;
                this.set_indice(a.tilesheet.getIndex(b));
                this.size = a.tilesheet.getSize(this._indice);
                this._defaultRotation = a.tilesheet.getRotation(this._indice)
            },
            get_tile: function() {
                return this._tile
            },
            set_tile: function(a) {
                this._tile != a && (this._tile = a, null != this.layer && this.init(this.layer));
                return a
            },
            get_indice: function() {
                return this._indice
            },
            set_indice: function(a) {
                this._indice != a && (this._indice = a);
                return a
            },
            get_mirror: function() {
                return this._mirror
            },
            set_mirror: function(a) {
                this._mirror != a && (this._mirror = a, this.dirty = !0);
                return a
            },
            get_rotation: function() {
                return this._defaultRotation + this._rotation
            },
            set_rotation: function(a) {
                this._rotation != a && (this._rotation = a, this.dirty = !0);
                return a
            },
            get_scale: function() {
                return this._scaleX
            },
            set_scale: function(a) {
                this._scaleX != a && (this._scaleY = this._scaleX = a, this.dirty = !0);
                return a
            },
            get_scaleX: function() {
                return this._scaleX
            },
            set_scaleX: function(a) {
                this._scaleX != a && (this._scaleX = a, this.dirty = !0);
                return a
            },
            get_scaleY: function() {
                return this._scaleY
            },
            set_scaleY: function(a) {
                this._scaleY != a && (this._scaleY = a, this.dirty = !0);
                return a
            },
            get_color: function() {
                return (256 * this.r | 0) << 16 + (256 * this.g | 0) << 8 + (256 * this.b | 0)
            },
            set_color: function(a) {
                this.r = (a >> 16) / 255;
                this.g = (a >> 8 & 255) / 255;
                this.b = (a & 255) / 255;
                return a
            },
            get_transform: function() {
                if (1 == this.dirty) {
                    this.dirty = !1;
                    var a;
                    a = 1 == this._mirror ? -1 : 1;
                    var b;
                    b = 2 == this._mirror ? -1 : 1;
                    var c = this._scaleX * this.layer.tilesheet.scale,
                        d = this._scaleY * this.layer.tilesheet.scale;
                    if (0 != this._defaultRotation + this._rotation) {
                        var e =
                            Math.cos(this._defaultRotation + this._rotation),
                            f = Math.sin(this._defaultRotation + this._rotation);
                        this._transform[0] = a * e * c;
                        this._transform[1] = -b * f * d;
                        this._transform[2] = a * f * c;
                        this._transform[3] = b * e * d
                    } else this._transform[0] = a * c, this._transform[1] = 0, this._transform[2] = 0, this._transform[3] = b * d
                }
                return this._transform
            },
            get_height: function() {
                return this.size.height * this._scaleY
            },
            get_width: function() {
                return this.size.width * this._scaleX
            },
            get_offset: function() {
                return this._offset
            },
            set_offset: function(a) {
                return this._offset =
                    null == a ? null : new ja(a.x / this.layer.tilesheet.scale, a.y / this.layer.tilesheet.scale)
            },
            destroyToCache: function() {
                this.reset();
                P.pool.push(this)
            },
            reset: function() {
                this._rotation = 0;
                this.alpha = this._scaleX = this._scaleY = 1;
                this._mirror = 0;
                this._indice = -1;
                this.x = this.y = 0;
                this.visible = !0;
                this.layer = this._tile = null;
                this.dirty = !0;
                this._offset = null;
                this.referenceY = this.referenceX = 0;
                this.size = null;
                null != this.parent && this.parent.removeChild(this);
                this._transform = []
            },
            free: function() {
                this.reset();
                this._transform = null
            },
            __class__: P,
            __properties__: {
                get_transform: "get_transform",
                set_offset: "set_offset",
                get_offset: "get_offset",
                get_width: "get_width",
                get_height: "get_height",
                set_color: "set_color",
                get_color: "get_color",
                set_scaleY: "set_scaleY",
                get_scaleY: "get_scaleY",
                set_scaleX: "set_scaleX",
                get_scaleX: "get_scaleX",
                set_scale: "set_scale",
                get_scale: "get_scale",
                set_rotation: "set_rotation",
                get_rotation: "get_rotation",
                set_mirror: "set_mirror",
                get_mirror: "get_mirror",
                set_indice: "set_indice",
                get_indice: "get_indice",
                set_tile: "set_tile",
                get_tile: "get_tile"
            }
        });
        var Ua = function(a, b, c) {
            null == c && (c = 18);
            P.call(this, a, b);
            this.fps = c;
            this.loop = this.animated = !0
        };
        g["aze.display.TileClip"] = Ua;
        Ua.__name__ = ["aze", "display", "TileClip"];
        Ua.pool = null;
        Ua.create = function(a, b, c) {
            null == c && (c = 18);
            null == Ua.pool && (Ua.pool = []);
            if (0 == Ua.pool.length) return new Ua(a, b, c);
            a = Ua.pool.pop();
            a.fps = c;
            a.set_tile(b);
            return a
        };
        Ua.clearPool = function() {
            Ua.pool = [];
            Ua.pool = null
        };
        Ua.__super__ = P;
        Ua.prototype = t(P.prototype, {
            init: function(a) {
                this.layer = a;
                this.frames = a.tilesheet.getAnim(this._tile);
                this.set_indice(this.frames[0]);
                this.size = a.tilesheet.getSize(this._indice);
                this.time = 0;
                this.prevFrame = -1
            },
            step: function(a) {
                this.time += a;
                a = this.get_currentFrame();
                if (a != this.prevFrame) {
                    var b = a < this.prevFrame;
                    this.prevFrame = a;
                    if (1 == b) {
                        if (0 == this.loop ? (this.animated = !1, this.set_currentFrame(this.frames.length - 1)) : this.set_indice(this.frames[a]), null != this.onComplete) this.onComplete(this)
                    } else this.set_indice(this.frames[a])
                }
            },
            get_currentFrame: function() {
                return Math.floor(this.time / 1E3 * this.fps) % this.frames.length
            },
            set_currentFrame: function(a) {
                a >= this.frames.length && (a = this.frames.length - 1);
                this.time = Math.floor(1E3 * a / this.fps) + 1;
                this.set_indice(this.frames[a]);
                return a
            },
            destroyToCache: function() {
                this.reset();
                Ua.pool.push(this)
            },
            reset: function() {
                P.prototype.reset.call(this);
                this.loop = this.animated = !0;
                this.time = 0;
                this.prevFrame = -1;
                this.frames = []
            },
            __class__: Ua,
            __properties__: t(P.prototype.__properties__, {
                set_currentFrame: "set_currentFrame",
                get_currentFrame: "get_currentFrame"
            })
        });
        var cc = function(a) {
            bc.call(this,
                a);
            this.children = []
        };
        g["aze.display.TileGroup"] = cc;
        cc.__name__ = ["aze", "display", "TileGroup"];
        cc.__super__ = bc;
        cc.prototype = t(bc.prototype, {
            init: function(a) {
                this.layer = a;
                null != this.children && this.initChildren()
            },
            initChildren: function() {
                for (var a = 0, b = this.children; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.parent = this;
                    null != this.layer && c.init(this.layer)
                }
            },
            addChild: function(a) {
                this.removeChild(a);
                a.parent = this;
                null != this.layer && a.init(this.layer);
                return this.children.push(a)
            },
            addChildAt: function(a, b) {
                this.removeChild(a);
                a.parent = this;
                null != this.layer && a.init(this.layer);
                this.children.splice(b, 0, a);
                return b
            },
            removeChild: function(a) {
                if (null == a.parent) return a;
                if (a.parent != this) return console.log("Invalid parent"), a;
                var b = Ed.indexOf(this.children, a);
                0 <= b && (this.children.splice(b, 1), a.parent = null);
                return a
            },
            getChildIndex: function(a) {
                return Ed.indexOf(this.children, a)
            },
            setChildIndex: function(a, b) {
                var c = Ed.indexOf(this.children, a);
                0 <= c && b != c && (this.children.splice(c, 1), this.children.splice(b, 0, a))
            },
            destroyChildsToCache: function() {
                for (var a =
                        0, b = this.children; a < b.length;) {
                    var c = b[a];
                    ++a;
                    1 == x.__instanceof(c, P) && x.__cast(c, P).destroyToCache()
                }
            },
            __class__: cc
        });
        var Id = function(a, b, c, d) {
            null == c && (c = !1);
            null == b && (b = !0);
            cc.call(this, this);
            null == d ? (this.view = new y, this.view.mouseEnabled = !1, this.view.mouseChildren = !1) : this.view = d;
            this.view.get_graphics().renderWidth = m.get_instance().nativeWidth;
            this.view.get_graphics().renderHeight = m.get_instance().nativeHeight;
            this.tilesheet = a;
            this.useSmoothing = b;
            this.useAdditive = c;
            this.useTransforms = this.useAlpha = !0;
            this.drawList = new Me
        };
        g["aze.display.TileLayer"] = Id;
        Id.__name__ = ["aze", "display", "TileLayer"];
        Id.__super__ = cc;
        Id.prototype = t(cc.prototype, {
            render: function(a) {
                this.drawList.begin(null == a ? 0 : a, this.useTransforms, this.useAlpha, this.useTint, this.useAdditive);
                this.renderGroup(this, 0, 0, 0);
                this.drawList.end();
                this.view.get_graphics().clear();
                this.tilesheet.drawTiles(this.view.get_graphics(), this.drawList.list, this.useSmoothing, this.drawList.flags);
                return this.drawList.elapsed
            },
            renderGroup: function(a, b,
                c, d) {
                var e = this.drawList.list,
                    f = this.drawList.fields,
                    l = this.drawList.offsetTransform,
                    E = this.drawList.offsetRGB,
                    g = this.drawList.offsetAlpha,
                    h = this.drawList.elapsed;
                c += a.x;
                d += a.y;
                var q;
                q = null != a.children ? a.children.length : 0;
                for (var n = 0; n < q;) {
                    var k = n++,
                        k = a.children[k];
                    1 == k.animated && k.step(h);
                    if (0 != k.visible) {
                        var m;
                        m = x.__instanceof(k, cc) ? k : null;
                        if (null != m) b = this.renderGroup(m, b, c, d);
                        else if (!(0 >= k.alpha)) {
                            e[b + 2] = k._indice;
                            if (null != k._offset)
                                if (m = k._offset, 0 < l) {
                                    var p = k.get_transform();
                                    e[b] = k.x + k.referenceX -
                                        m.x * p[0] - m.y * p[1] + c;
                                    e[b + 1] = k.y + k.referenceY - m.x * p[2] - m.y * p[3] + d;
                                    e[b + l] = p[0];
                                    e[b + l + 1] = p[2];
                                    e[b + l + 2] = p[1];
                                    e[b + l + 3] = p[3]
                                } else e[b] = k.x + k.referenceX - m.x + c, e[b + 1] = k.y + k.referenceY - m.y + d;
                            else e[b] = k.x + k.referenceX + c, e[b + 1] = k.y + k.referenceY + d, 0 < l && (m = k.get_transform(), e[b + l] = m[0], e[b + l + 1] = m[2], e[b + l + 2] = m[1], e[b + l + 3] = m[3]);
                            0 < E && (e[b + E] = k.r, e[b + E + 1] = k.g, e[b + E + 2] = k.b);
                            0 < g && (e[b + g] = k.alpha);
                            b += f
                        }
                    }
                }
                return this.drawList.index = b
            },
            __class__: Id
        });
        var Qa = function() {
            y.call(this)
        };
        g["com.alagatar.BasicScene"] = Qa;
        Qa.__name__ = ["com", "alagatar", "BasicScene"];
        Qa.__super__ = y;
        Qa.prototype = t(y.prototype, {
            init: function() {},
            start: function() {},
            update: function(a, b) {},
            free: function() {},
            __class__: Qa
        });
        var xd = function() {
            this.ready = !0;
            y.call(this);
            this.init()
        };
        g["com.alagatar.BasicSceneManager"] = xd;
        xd.__name__ = ["com", "alagatar", "BasicSceneManager"];
        xd.__super__ = y;
        xd.prototype = t(y.prototype, {
            init: function() {
                this.ready = !0;
                this.scenesList = [];
                this.sceneLayer = new y;
                this.addChild(this.sceneLayer);
                this.effectLayer = new y;
                this.addChild(this.effectLayer)
            },
            isReady: function() {
                return this.ready
            },
            show: function(a, b) {
                null == b && (b = !0);
                null != a && (this.ready = !1, a.set_visible(!1), this.scenesList.push(a), this.sceneLayer.addChild(a), 1 == b ? this.showHideEffect() : (this.initScene(), this.startScene()))
            },
            showHideEffect: function() {
                this.hideComplete()
            },
            hideComplete: function() {
                this.initScene();
                this.showEffect()
            },
            initScene: function() {
                this.freeOldScene();
                this.initNewScene()
            },
            freeOldScene: function() {
                if (2 == this.scenesList.length) {
                    var a = this.scenesList.shift();
                    a.free();
                    this.sceneLayer.removeChild(a)
                }
            },
            initNewScene: function() {
                var a = this.scenesList[0];
                a.init();
                a.set_visible(!0)
            },
            showEffect: function() {
                this.showComplete()
            },
            showComplete: function() {
                this.startScene()
            },
            startScene: function() {
                this.ready = !0;
                this.scenesList[0].start()
            },
            udpate: function(a, b) {
                0 != this.scenesList.length && this.scenesList[0].update(a, b)
            },
            __class__: xd
        });
        var ta = function() {
            y.call(this);
            this.set_anchorPoint(new ja(.5, .5))
        };
        g["com.alagatar.BasicSprite"] = ta;
        ta.__name__ = ["com", "alagatar", "BasicSprite"];
        ta.buildSprite = function(a) {
            var b =
                new ta;
            b.buildBySource(a);
            b.set_smooth(!0);
            return b
        };
        ta.buildSpriteByData = function(a) {
            var b = new ta;
            b.buildByData(a);
            b.set_smooth(!0);
            return b
        };
        ta.__super__ = y;
        ta.prototype = t(y.prototype, {
            buildBySource: function(a) {
                this.initSprite(Y.getBitmapData(a))
            },
            buildByData: function(a) {
                this.initSprite(a)
            },
            initSprite: function(a) {
                this.graph = new Zb(a);
                this.addChild(this.graph);
                this.set_scaleX(1.00001);
                this.set_scaleY(1.00001);
                this._scale = 1.00001;
                this.upTransform()
            },
            get_anchorPoint: function() {
                return this._anchorPoint
            },
            set_anchorPoint: function(a) {
                -1 > a.x && (a.x = -1);
                1 < a.x && (a.x = 1); - 1 > a.y && (a.y = -1);
                1 < a.y && (a.y = 1);
                this._anchorPoint = a;
                this.upTransform();
                return this._anchorPoint
            },
            setAnchorPoint: function(a, b) {
                -1 > a && (a = -1);
                1 < a && (a = 1); - 1 > b && (b = -1);
                1 < b && (b = 1);
                this._anchorPoint.x = a;
                this._anchorPoint.y = b;
                this.upTransform()
            },
            set_scale: function(a) {
                this.set_scaleX(a);
                this.set_scaleY(a);
                this._scale = a;
                this.upTransform();
                return this._scale
            },
            upTransform: function() {
                null != this.graph && (this.graph.set_x(-this.graph.get_width() * this.get_anchorPoint().x),
                    this.graph.set_y(-this.graph.get_height() * this.get_anchorPoint().y))
            },
            set_smooth: function(a) {
                if (null == this.graph) return !1;
                this._smooth = a;
                return this.graph.smoothing = this._smooth
            },
            __class__: ta,
            __properties__: t(y.prototype.__properties__, {
                set_smooth: "set_smooth",
                set_scale: "set_scale",
                set_anchorPoint: "set_anchorPoint",
                get_anchorPoint: "get_anchorPoint"
            })
        });
        var K = function() {
            if (null != K._instance) throw "Error: Allready inited. Use instance instead;";
        };
        g["com.alagatar.DataManager"] = K;
        K.__name__ = ["com", "alagatar",
            "DataManager"
        ];
        K.__properties__ = {
            get_instance: "get_instance"
        };
        K._instance = null;
        K.get_instance = function() {
            null == K._instance && (K._instance = new K);
            return K._instance
        };
        K.prototype = {
            init: function(a) {
                this.name = a;
                this.storage = rb.getLocal(this.name, "http://games.softgames.de/");
                this.data = this.storage.data;
                null == this.data.inited && this.createDb();
                this.uuid = this.get("uuid")
            },
            createDb: function() {
                this.save("inited", !0, !0);
                this.save("uuid", C.generateUUID(), !0);
                this.storage.flush()
            },
            save: function(a, b, c) {
                ia.get_instance().setStorageItem(a,
                    b);
                N.get_instance().postNotify("saveNewData", this, {
                    key: a
                })
            },
            get: function(a) {
                return ia.get_instance().getStorageItem(a)
            },
            smartSave: function(a, b, c) {
                null == c && (c = "replace");
                var d = v.parseInt(this.get(a)),
                    e = !1;
                null == d && (d = 0);
                switch (c) {
                    case "add":
                        d += b;
                        e = !0;
                        break;
                    case "max":
                        b > d && (d = b, e = !0);
                        break;
                    case "min":
                        b < d && (d = b, e = !0);
                        break;
                    case "replace":
                        d = b, e = !0
                }
                1 == e && this.save(a, d)
            },
            increaseValue: function(a) {
                this.smartSave(a, 1, "add")
            },
            __class__: K
        };
        var zb = function() {
            this.initParams()
        };
        g["com.alagatar.GAnalytics"] = zb;
        zb.__name__ = ["com", "alagatar", "GAnalytics"];
        zb.__properties__ = {
            get_instance: "get_instance"
        };
        zb._instance = null;
        zb.get_instance = function() {
            null == zb._instance && (zb._instance = new zb);
            return zb._instance
        };
        zb.prototype = {
            initParams: function() {
                this.cid = K.get_instance().uuid;
                this.analyticsUrl = "http://www.google-analytics.com/collect";
                this.shortedUrl = this.url = window.location.href;
                90 < this.shortedUrl.length && (this.shortedUrl = u.substr(this.shortedUrl, 0, 87), this.shortedUrl += "...");
                this.host = window.location.host;
                this.protocol = window.location.protocol;
                "https:" == this.protocol && (this.analyticsUrl = "https://ssl.google-analytics.com/collect")
            },
            init: function(a, b) {
                this.tid = a;
                this.campainId = b;
                this.viewPage("main", !0)
            },
            viewPage: function(a, b) {
                null == b && (b = !1);
                var c = "" + Math.round((new Date).getTime() / 1E3),
                    d = new Zc;
                d.v = "1";
                d.tid = this.tid;
                d.cid = this.cid;
                d.t = "screenview";
                d.an = m.get_instance().id;
                d.cd = a;
                1 == b && (d.cs = this.host, d.ck = this.shortedUrl, d.cn = this.campainId);
                d.z = c;
                this.sendStats(d)
            },
            sendEvent: function(a, b) {
                null ==
                    b && (b = "");
                var c = "" + Math.round((new Date).getTime() / 1E3),
                    d = new Zc;
                d.v = "1";
                d.tid = this.tid;
                d.cid = this.cid;
                d.t = "event";
                d.an = m.get_instance().id;
                d.ec = a;
                0 != b.length && (d.ea = b);
                d.z = c;
                this.sendStats(d)
            },
            sendStats: function(a) {
                var b = new Dc(this.analyticsUrl);
                b.method = $c.POST;
                b.data = a;
                (new Jd).load(b)
            },
            __class__: zb
        };
        var Ne = function(a) {
            this.target = a;
            this.init()
        };
        g["com.alagatar.LayersManager"] = Ne;
        Ne.__name__ = ["com", "alagatar", "LayersManager"];
        Ne.prototype = {
            init: function() {
                this.list = new pa
            },
            addLayer: function(a,
                b, c) {
                null == c && (c = !0);
                null == b && (b = !0);
                if (1 == this.list.exists(a)) console.log("Layer " + a + " already exist");
                else {
                    var d = new y;
                    d.mouseEnabled = b;
                    d.mouseChildren = c;
                    this.target.addChild(d);
                    this.list.set(a, d)
                }
            },
            getLayer: function(a) {
                return 1 == this.list.exists(a) ? this.list.get(a) : null
            },
            free: function() {
                this.target = this.list = null
            },
            __class__: Ne
        };
        var dc = function() {};
        g["com.alagatar.NotifiReceiver"] = dc;
        dc.__name__ = ["com", "alagatar", "NotifiReceiver"];
        var N = function() {
            this.init()
        };
        g["com.alagatar.NotificationCenter"] =
            N;
        N.__name__ = ["com", "alagatar", "NotificationCenter"];
        N.__properties__ = {
            get_instance: "get_instance"
        };
        N._instance = null;
        N.get_instance = function() {
            null == N._instance && (N._instance = new N);
            return N._instance
        };
        N.prototype = {
            init: function() {
                this.notifiList = []
            },
            postNotify: function(a, b, c) {
                for (var d = 0, e = this.notifiList; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.notifi == a && f.sender.receiveNotify(a, b, c)
                }
            },
            signToNotify: function(a, b, c) {
                null == c && (c = "local");
                if (1 == this.isSignedToNotify(a, b)) return !1;
                this.notifiList.push({
                    notifi: a,
                    sender: b,
                    group: c
                });
                return !0
            },
            unSignToNotify: function(a, b) {
                var c = this.seekNotificationItem(a, b);
                if (null == c) return !1;
                u.remove(this.notifiList, c);
                return !0
            },
            seekNotificationItem: function(a, b) {
                for (var c = null, d = this.notifiList.length, e = 0; e < d;) {
                    var f = e++;
                    this.notifiList[f].notifi == a && this.notifiList[f].sender == b && (c = this.notifiList[f])
                }
                return c
            },
            isSignedToNotify: function(a, b) {
                return null != this.seekNotificationItem(a, b) ? !0 : !1
            },
            clear: function(a) {
                null == a && (a = "local");
                for (var b = 0, c = this.notifiList.length, d,
                        e = 0; e < c;) {
                    e++;
                    d = this.notifiList.length;
                    if (0 == d || b >= d) break;
                    this.notifiList[b].group == a ? this.notifiList.splice(b, 1) : b++
                }
            },
            __class__: N
        };
        var Oe = function(a) {
            this.pullClass = a;
            this.list = []
        };
        g["com.alagatar.Pool"] = Oe;
        Oe.__name__ = ["com", "alagatar", "Pool"];
        Oe.prototype = {
            pop: function() {
                return 0 < this.list.length ? this.list.pop() : this.createNew()
            },
            createNew: function() {
                return O.createInstance(this.pullClass, [])
            },
            push: function(a) {
                this.list.push(a)
            },
            clean: function() {
                this.list = []
            },
            free: function() {
                this.clean();
                this.pullClass =
                    this.list = null
            },
            __class__: Oe
        };
        var Uc = function(a, b) {
            null == b && (b = 2);
            null == a && (a = 60);
            Uc.instance = this;
            this.mode = b;
            this.init(a);
            this.reset()
        };
        g["com.alagatar.Timestep"] = Uc;
        Uc.__name__ = ["com", "alagatar", "Timestep"];
        Uc.instance = null;
        Uc.prototype = {
            init: function(a) {
                this.fixedTime = 1 / a;
                this.fixedTime = C.roundDec(this.fixedTime, 8);
                this.minDelta = this.fixedTime / 10;
                this.maxDelta = 3 * this.fixedTime;
                this.frameDeltaCache = [];
                this.frameDeltaCacheFiltered = [];
                this.lerpInCoef = this.fixedTime;
                this.lerpOutCoef = 1 - this.lerpInCoef
            },
            reset: function() {
                this.accumulator = this.prevTime = 0
            },
            update: function() {
                this.curTime = tc.stamp();
                0 == this.prevTime && (this.prevTime = this.curTime);
                this.deltaTime = this.curTime - this.prevTime;
                this.prevTime = this.curTime;
                this.accumulator += this.deltaTime;
                1 == this.mode && this.smoothDelta()
            },
            smoothDelta: function() {
                if (11 > this.frameDeltaCache.length) this.frameDeltaCache.push(this.deltaTime);
                else {
                    this.frameDeltaCacheFiltered = this.frameDeltaCache.slice();
                    this.frameDeltaCacheFiltered.sort(r(this, this.sortMax));
                    this.frameDeltaCacheFiltered.splice(0,
                        2);
                    this.frameDeltaCacheFiltered.splice(7, 9);
                    this.frameDeltaCacheAverage = C.calcFloatAverage(this.frameDeltaCacheFiltered);
                    var a = this.lerpInCoef * this.frameDeltaCacheAverage + this.lerpOutCoef * this.frameDeltaCache[10];
                    this.frameDeltaCache.shift();
                    this.frameDeltaCache.push(this.deltaTime);
                    this.deltaTime = a
                }
            },
            sortMax: function(a, b) {
                return a > b ? -1 : a < b ? 1 : 0
            },
            checkUpdate: function() {
                return 1 == this.mode ? !0 : this.accumulator >= this.fixedTime ? (this.accumulator -= this.fixedTime, !0) : !1
            },
            getDelta: function() {
                return 2 == this.mode ?
                    this.fixedTime : this.deltaTime
            },
            __class__: Uc
        };
        var C = function() {};
        g["com.alagatar.Tools"] = C;
        C.__name__ = ["com", "alagatar", "Tools"];
        C.randTo = function(a, b, c) {
            null == c && (c = 0);
            if (0 == c) return Math.floor(Math.random() * (b - a + 1)) + a;
            a += (b - a) * Math.random();
            a = C.roundDec(a, c);
            a > b && (a = b);
            return a
        };
        C.roundDec = function(a, b) {
            null == b && (b = 0);
            a *= Math.pow(10, b);
            return Math.round(a) / Math.pow(10, b)
        };
        C.shuffle = function(a) {
            if (null == a) return null;
            for (var b = 0, c = a.length; b < c;) {
                var d = b++,
                    e = Math.floor((a.length - 1 + 1) * Math.random()),
                    f = a[d];
                a[d] = a[e];
                a[e] = f
            }
            return a
        };
        C.clamp = function(a, b, c) {
            return Math.max(b, Math.min(c, a))
        };
        C.toRad = function(a) {
            return Math.PI / 180 * a
        };
        C.calcDistOfDots = function(a, b, c, d) {
            return Math.sqrt((c - a) * (c - a) + (d - b) * (d - b))
        };
        C.toPercent = function(a, b) {
            return a / b
        };
        C.createObjectByClassName = function(a, b) {
            var c = O.resolveClass(a);
            if (null == c) return console.log("Can't create instance of " + a + ". Import this class anywhere!"), null;
            null == b && (b = []);
            return O.createInstance(c, b)
        };
        C.parseConfig = function(a) {
            if (0 == Y.exists(a)) return console.log(a +
                " not found!"), null;
            a = Y.getText(a);
            return C.parseConfigFromData(a)
        };
        C.parseConfigFromData = function(a) {
            return ad.parse(a)
        };
        C.generateUUID = function() {
            var a;
            a = new uc;
            a.data = Array(36);
            a.length = 36;
            a.fixed = !1;
            for (var b = 0; 36 > b;) {
                var c = b++,
                    d;
                d = Math.floor(16 * Math.random());
                d = u.substr("0123456789abcdef", d, 1);
                if (!a.fixed && (c >= a.length && (a.length = c + 1), a.data.length < a.length)) {
                    var e;
                    e = Array(a.data.length + 10);
                    ab.blit(a.data, 0, e, 0, a.data.length);
                    a.data = e
                }
                a.data[c] = d
            }
            a.fixed || (14 >= a.length && (a.length = 15), a.data.length <
                a.length && (b = Array(a.data.length + 10), ab.blit(a.data, 0, b, 0, a.data.length), a.data = b));
            a.data[14] = "4";
            b = v.parseInt(a.data[19]) & 3 | 8;
            b = u.substr("0123456789abcdef", b, 1);
            a.fixed || (19 >= a.length && (a.length = 20), a.data.length < a.length && (c = Array(a.data.length + 10), ab.blit(a.data, 0, c, 0, a.data.length), a.data = c));
            a.data[19] = b;
            a.fixed || (23 >= a.length && (a.length = 24), a.data.length < a.length && (b = Array(a.data.length + 10), ab.blit(a.data, 0, b, 0, a.data.length), a.data = b));
            b = a.data[23] = "-";
            a.fixed || (18 >= a.length && (a.length = 19),
                a.data.length < a.length && (c = Array(a.data.length + 10), ab.blit(a.data, 0, c, 0, a.data.length), a.data = c));
            b = a.data[18] = b;
            a.fixed || (13 >= a.length && (a.length = 14), a.data.length < a.length && (c = Array(a.data.length + 10), ab.blit(a.data, 0, c, 0, a.data.length), a.data = c));
            b = a.data[13] = b;
            a.fixed || (8 >= a.length && (a.length = 9), a.data.length < a.length && (c = Array(a.data.length + 10), ab.blit(a.data, 0, c, 0, a.data.length), a.data = c));
            a.data[8] = b;
            b = "";
            c = 0;
            for (d = a.length; c < d;) e = c++, 0 < e && (b += ""), b += v.string(a.data[e]);
            return b
        };
        C.formatTime =
            function(a, b, c, d) {
                null == d && (d = !0);
                null == c && (c = !0);
                null == b && (b = !0);
                var e = Math.floor(a / 3600),
                    f = C.formatTimeString(e);
                a -= 3600 * e;
                var l = Math.floor(a / 60),
                    e = C.formatTimeString(l);
                a = C.formatTimeString(a - 60 * l);
                l = "";
                1 == b && (l += f);
                1 == c && (0 != l.length && (l += ":"), l += e);
                1 == d && (0 != l.length && (l += ":"), l += a);
                return l
            };
        C.formatTimeString = function(a) {
            return 10 > a ? "0" + a : "" + a
        };
        C.lerp = function(a, b, c) {
            return a + (b - a) * C.clamp(c, 0, 1)
        };
        C.pointInsideCirc = function(a, b, c, d, e) {
            return C.calcDistOfDots(a, b, c, d) <= e
        };
        C.pointInsideRect =
            function(a, b, c, d, e, f) {
                return a >= c && b >= d && a < c + e && b < d + f
            };
        C.calcFloatAverage = function(a) {
            for (var b = 0, c = a.length, d = 0; d < c;) var e = d++,
                b = b + a[e];
            return b / c
        };
        C.randomRangeFloatExclude = function(a, b, c, d, e) {
            null == e && (e = -1);
            null == d && (d = -1);
            for (var f = c, l = 0; f == c;) {
                l += 1;
                f = C.randTo(a, b, 6);
                if (-1 != e && l > e) break; - 1 != d && Math.abs(c - f) < d && (f = c)
            }
            return f
        };
        C.randomRangeIntExclude = function(a, b, c, d, e) {
            null == e && (e = -1);
            null == d && (d = -1);
            for (var f = c, l = 0; f == c;) {
                l += 1;
                f = a + Math.floor((b - a + 1) * Math.random());
                if (-1 != e && l > e) break; - 1 != d &&
                    Math.abs(c - f) < d && (f = c)
            }
            return f
        };
        C.alignToCenter = function(a, b, c) {
            var d = a.length;
            b -= (d - 1) * c / 2;
            for (var e, f = 0; f < d;) {
                var l = f++;
                e = b + c * l;
                a[l].set_x(e)
            }
        };
        var ec = function(a, b) {
            this.x = a;
            this.y = b
        };
        g["com.alagatar.VecDefault"] = ec;
        ec.__name__ = ["com", "alagatar", "VecDefault"];
        ec.prototype = {
            __class__: ec
        };
        var Kd = function() {
            y.call(this);
            this.init()
        };
        g["com.alagatar.awards.Award"] = Kd;
        Kd.__name__ = ["com", "alagatar", "awards", "Award"];
        Kd.__super__ = y;
        Kd.prototype = t(y.prototype, {
            init: function() {
                var a = ta.buildSprite(m.formatAsset("assets/images/%25p%25/award_block.html"));
                this.addChild(a);
                a = new qa;
                a.set_size(26);
                a.mouseEnabled = !0;
                a.set_align("center");
                a.set_fieldWidth(360);
                a.set_text("ACHIEVEMENT UNLOCKED");
                a.set_x(-150);
                a.set_y(-40);
                this.addChild(a);
                this.captionLabel = new qa;
                this.captionLabel.set_size(24);
                this.captionLabel.mouseEnabled = !0;
                this.captionLabel.set_align("center");
                this.captionLabel.set_fieldWidth(360);
                this.captionLabel.set_x(-150);
                this.captionLabel.set_y(-15);
                this.addChild(this.captionLabel);
                this.prizeLabel = new qa;
                this.prizeLabel.set_size(24);
                this.prizeLabel.mouseEnabled = !0;
                this.prizeLabel.set_align("center");
                this.prizeLabel.set_fieldWidth(360);
                this.prizeLabel.set_x(-150);
                this.prizeLabel.set_y(10);
                this.addChild(this.prizeLabel)
            },
            setText: function(a, b) {
                this.captionLabel.set_text(a);
                this.prizeLabel.set_text(b)
            },
            __class__: Kd
        });
        var vc = function() {
            y.call(this);
            this.init()
        };
        g["com.alagatar.awards.AwardShower"] = vc;
        vc.__name__ = ["com", "alagatar", "awards", "AwardShower"];
        vc.__interfaces__ = [dc];
        vc.__super__ = y;
        vc.prototype = t(y.prototype, {
            init: function() {
                N.get_instance().signToNotify("newAchievement",
                    this, "global");
                N.get_instance().signToNotify("clearSaves", this);
                this.startY = -80;
                this.endY = 70;
                this.showed = !1;
                this.pool = [];
                this.award = new Kd;
                this.award.set_x(640);
                this.award.set_y(this.startY);
                this.award.set_visible(!1);
                this.addChild(this.award)
            },
            receiveNotify: function(a, b, c) {
                "newAchievement" == a ? this.newAchievement(c.id) : this.reset()
            },
            newAchievement: function(a) {
                this.pool.push(a);
                this.showAward()
            },
            showAward: function() {
                if (1 != this.showed) {
                    L.get_instance().playSound("award");
                    this.showed = !0;
                    this.award.set_visible(!0);
                    var a = this.pool.shift(),
                        a = m.get_instance().getConfig("awards").awards[a],
                        b = M.replace(a.dsc, "%c%", "" + v.string(a.count)),
                        c = M.replace("+%c% SCORE", "%c%", "" + v.string(a.prize));
                    this.award.setText(b, c);
                    a = v.parseInt(a.prize);
                    if (null != this.onAwardPrize) this.onAwardPrize(a);
                    A.tween(this.award, .9, {
                        y: this.endY
                    }).ease(bd.get_easeOut()).onComplete(r(this, this.completeShow))
                }
            },
            completeShow: function() {
                A.timer(3).onComplete(r(this, this.hide))
            },
            hide: function() {
                A.tween(this.award, .3, {
                    y: this.startY
                }).ease(bd.get_easeIn()).onComplete(r(this,
                    this.completeHide))
            },
            completeHide: function() {
                this.award.set_visible(!1);
                this.showed = !1;
                0 != this.pool.length && this.showAward()
            },
            reset: function() {
                A.stop(this.award, null, !1, !1);
                this.award.set_y(this.startY);
                this.award.set_visible(!1);
                this.pool = []
            },
            __class__: vc
        });
        var lb = function() {
            lb._instance = this;
            this.awards = [];
            N.get_instance().signToNotify("saveNewData", this, "global");
            N.get_instance().signToNotify("clearSaves", this)
        };
        g["com.alagatar.awards.AwardsManager"] = lb;
        lb.__name__ = ["com", "alagatar", "awards", "AwardsManager"];
        lb.__interfaces__ = [dc, oc];
        lb.__properties__ = {
            get_instance: "get_instance"
        };
        lb._instance = null;
        lb.instance = null;
        lb.get_instance = function() {
            null == lb._instance && (lb._instance = new lb);
            return lb._instance
        };
        lb.prototype = {
            receiveNotify: function(a, b, c) {
                "saveNewData" == a ? this.updateStatistic(c.key) : this.reset()
            },
            init: function() {
                for (var a, b = m.get_instance().getConfig("awards").awards, c = b.length, d, e = 0; e < c;) {
                    var f = e++;
                    a = "award" + f;
                    d = b[f];
                    this.register(f, a);
                    this.addCondition(a, d.statId, d.count)
                }
            },
            getCount: function() {
                return this.awards.length
            },
            register: function(a, b, c) {
                null != this.get(b) ? console.log("Award " + b + " already registered") : (null == c && (c = []), this.awards.push({
                    id: a,
                    key: b,
                    conditions: c,
                    earned: !1
                }))
            },
            get: function(a) {
                for (var b = 0, c = this.awards; b < c.length;) {
                    var d = c[b];
                    ++b;
                    if (d.key == a) return d
                }
                return null
            },
            getAwardById: function(a) {
                return a > this.awards.length - 1 ? null : this.awards[a]
            },
            addCondition: function(a, b, c) {
                null == c && (c = 1);
                var d = this.get(a);
                null == d ? console.log("Award " + a + " not registered") : (d.conditions.push({
                        statistic: b,
                        count: c,
                        complete: !1
                    }),
                    this.checkConditions(d))
            },
            dump: function() {
                var a = this.awards.length;
                if (0 == a) console.log("No awards registered");
                else {
                    console.log("Awards:");
                    for (var b = 0; b < a;) {
                        var c = b++;
                        0 != c && console.log("");
                        console.log(this.awards[c].key + " earned:" + v.string(this.awards[c].earned));
                        for (var d = 0, c = this.awards[c].conditions; d < c.length;) {
                            var e = c[d];
                            ++d;
                            console.log("stat:" + e.statistic + " count:" + e.count + " complete:" + (null == e.complete ? "null" : "" + e.complete))
                        }
                    }
                }
            },
            isEarned: function(a) {
                var b = this.get(a);
                if (null == b) return console.log("Award " +
                    a + " not registered"), !1;
                0 == b.earned && this.checkConditions(b);
                return b.earned
            },
            checkConditions: function(a) {
                for (var b = !0, c = 0, d = a.conditions; c < d.length;) {
                    var e = d[c];
                    ++c;
                    if (0 == this.checkCondition(e)) {
                        b = !1;
                        break
                    }
                }
                1 == b && (a.earned = !0)
            },
            checkCondition: function(a) {
                if (1 == a.complete) return !0;
                var b = K.get_instance().get(a.statistic);
                return null != b && b >= a.count ? a.complete = !0 : !1
            },
            updateStatistic: function(a) {
                var b = this.awards.length;
                if (0 != b)
                    for (var c = 0; c < b;) {
                        var d = c++;
                        1 != this.awards[d].earned && this.updateAwardWithStat(this.awards[d],
                            a)
                    }
            },
            updateAwardWithStat: function(a, b) {
                for (var c = !1, d = 0, e = a.conditions; d < e.length;) {
                    var f = e[d];
                    ++d;
                    if (1 != f.complete && (c = !1, f.statistic == b)) {
                        c = !0;
                        this.checkCondition(f);
                        break
                    }
                }
                1 == c && (this.checkConditions(a), 1 == a.earned && this.earnAward(a))
            },
            earnAward: function(a) {
                N.get_instance().postNotify("newAchievement", this, {
                    id: a.id
                })
            },
            reset: function() {
                var a = this.awards.length;
                if (0 != a)
                    for (var b = 0; b < a;) {
                        var c = b++;
                        this.awards[c].earned = !1;
                        for (var d = 0, c = this.awards[c].conditions; d < c.length;) {
                            var e = c[d];
                            ++d;
                            e.complete = !1
                        }
                    }
            },
            __class__: lb
        };
        var ya = function() {
            this.cleanable = !1
        };
        g["com.alagatar.entity.Component"] = ya;
        ya.__name__ = ["com", "alagatar", "entity", "Component"];
        ya.prototype = {
            __class__: ya
        };
        var Pe = function() {
            this.init()
        };
        g["com.alagatar.entity.ComponentManager"] = Pe;
        Pe.__name__ = ["com", "alagatar", "entity", "ComponentManager"];
        Pe.prototype = {
            init: function() {
                this.componentList = [];
                this.componentClassIdList = [];
                this.poolList = []
            },
            getComponentClassId: function(a) {
                a = O.getClassName(a);
                var b = u.indexOf(this.componentClassIdList,
                    a, 0); - 1 == b && (b = this.componentClassIdList.push(a), b--, this.componentList.push([]));
                return b
            },
            getComponent: function(a, b) {
                null == b && (b = !1);
                var c = this.getComponentClassId(a);
                1 == b && 0 == this.checkPoolExist(c) && this.addPoolFor(a);
                c = this.getPoolFor(c);
                return null != c ? c.pop() : O.createInstance(a, [])
            },
            checkPoolExist: function(a) {
                return this.poolList.length > a && null != this.poolList[a] ? !0 : !1
            },
            addPoolFor: function(a) {
                var b = this.getComponentClassId(a),
                    c = this.poolList.length - 1;
                if (c < b)
                    for (; c < b;) c++, this.poolList.push(null);
                a = new Oe(a);
                this.poolList[b] = a
            },
            getPoolFor: function(a) {
                return 0 == this.checkPoolExist(a) ? null : this.poolList[a]
            },
            addComponent: function(a, b) {
                var c = this.getComponentClassIdFromObject(b);
                this.createSpaceForEntity(c, a);
                this.componentList[c][a] = b
            },
            getComponentClassIdFromObject: function(a) {
                a = O.getClass(a);
                return this.getComponentClassId(a)
            },
            createSpaceForEntity: function(a, b) {
                var c = this.componentList[a].length - 1;
                if (c < b)
                    for (; c < b;) c++, this.componentList[a].push(null)
            },
            getComponentIn: function(a, b) {
                var c = this.getComponentClassId(b);
                return this.componentList[c][a]
            },
            delComponentIn: function(a, b) {
                var c = this.getComponentClassIdFromObject(b);
                this.cleanComponent(a, c)
            },
            cleanComponent: function(a, b, c) {
                null == c && (c = !1);
                var d = this.componentList[b][a];
                1 == c && (c = this.getPoolFor(b), null != c && c.push(d));
                this.componentList[b][a] = null
            },
            delComponentsIn: function(a, b) {
                null == b && (b = !1);
                for (var c = this.componentList.length, d = 0; d < c;) {
                    var e = d++;
                    null != this.componentList[e][a] && this.cleanComponent(a, e, b)
                }
            },
            getComponentsIn: function(a) {
                for (var b = null, c = this.componentList.length,
                        d = 0; d < c;) {
                    var e = d++;
                    null != this.componentList[e][a] && (null == b && (b = []), b.push(this.componentList[e][a]))
                }
                return b
            },
            containsComponents: function(a, b) {
                for (var c = b.length, d, e = 0; e < c;)
                    if (d = e++, d = b[d], null == this.componentList[d][a]) return !1;
                return !0
            },
            removeCache: function() {
                if (null != this.poolList) {
                    for (var a = 0, b = this.poolList; a < b.length;) {
                        var c = b[a];
                        ++a;
                        null != c && c.free()
                    }
                    this.poolList = [];
                    this.poolList = null
                }
            },
            free: function() {
                for (var a = this.componentList.length, b, c = 0; c < a;) {
                    var d = c++;
                    b = this.componentList[d].length;
                    for (var e = 0; e < b;) {
                        var f = e++;
                        this.componentList[d][f] = null
                    }
                }
                this.componentList = [];
                this.componentList = null;
                this.removeCache()
            },
            __class__: Pe
        };
        var n = function() {
            null != n._instance && console.log("Already present instance");
            n._instance = this;
            this.init()
        };
        g["com.alagatar.entity.Engine"] = n;
        n.__name__ = ["com", "alagatar", "entity", "Engine"];
        n.__properties__ = {
            get_instance: "get_instance"
        };
        n._instance = null;
        n.get_instance = function() {
            null == n._instance && console.log("No entity engine created");
            return n._instance
        };
        n.prototype = {
            init: function() {
                this.systemList = [];
                this.entityManager = new Qe;
                this.componentManager = new Pe;
                this.eventManager = new Re
            },
            addSystem: function(a, b) {
                var c = O.createEmptyInstance(a);
                null != b && (c.id = b);
                c.init();
                this.systemList.push(c)
            },
            getSystem: function(a) {
                for (var b = this.systemList.length, c = 0; c < b;) {
                    var d = c++;
                    if (this.systemList[d].id == a) return this.systemList[d]
                }
                return null
            },
            addCleaner: function(a) {
                this.componentCleaner = O.createEmptyInstance(a)
            },
            activate: function() {
                for (var a = this.systemList.length, b = 0; b < a;) {
                    var c =
                        b++;
                    this.systemList[c].activate()
                }
            },
            update: function(a) {
                for (var b = this.systemList.length, c = 0; c < b;) {
                    var d = c++;
                    this.systemList[d].update(a)
                }
            },
            saveEntity: function(a) {
                for (var b = this.systemList.length, c = 0; c < b;) {
                    var d = c++;
                    this.systemList[d].added(a)
                }
            },
            createEntity: function() {
                return this.entityManager.createEntity()
            },
            destroyEntity: function(a, b, c) {
                null == c && (c = !0);
                null == b && (b = !1);
                this.cleanComponents(a);
                this.componentManager.delComponentsIn(a, b);
                if (1 == c)
                    for (b = this.systemList.length, c = 0; c < b;) {
                        var d = c++;
                        this.systemList[d].deleted(a)
                    }
                this.entityManager.destroyEntity(a)
            },
            cleanComponents: function(a) {
                a = this.componentManager.getComponentsIn(a);
                for (var b = a.length, c = 0; c < b;) {
                    var d = c++;
                    this.cleanComponent(a[d])
                }
            },
            cleanComponent: function(a) {
                null != this.componentCleaner && 1 == a.cleanable && this.componentCleaner.clean(a)
            },
            getComponentClassId: function(a) {
                return this.componentManager.getComponentClassId(a)
            },
            containsComponents: function(a, b) {
                return this.componentManager.containsComponents(a, b)
            },
            getComponentIn: function(a, b) {
                return this.componentManager.getComponentIn(a, b)
            },
            getComponent: function(a,
                b) {
                null == b && (b = !1);
                return this.componentManager.getComponent(a, b)
            },
            addComponent: function(a, b) {
                this.componentManager.addComponent(a, b)
            },
            delComponent: function(a, b) {
                this.componentManager.delComponentIn(a, b);
                this.cleanComponent(b)
            },
            changedEntity: function(a) {
                for (var b = this.systemList.length, c = 0; c < b;) {
                    var d = c++;
                    this.systemList[d].changed(a)
                }
            },
            addTag: function(a, b) {
                this.entityManager.addTag(a, b)
            },
            getEntityByTag: function(a) {
                return this.entityManager.getEntityByTag(a)
            },
            free: function() {
                for (var a = this.systemList.length,
                        b = 0; b < a;) {
                    var c = b++;
                    this.systemList[c].free()
                }
                this.systemList = [];
                this.systemList = null;
                this.entityManager.free();
                this.entityManager = null;
                this.componentManager.free();
                this.componentCleaner = this.componentManager = null;
                this.eventManager.free();
                this.eventManager = null;
                n._instance = null
            },
            __class__: n
        };
        var Qe = function() {
            this.init()
        };
        g["com.alagatar.entity.EntityManager"] = Qe;
        Qe.__name__ = ["com", "alagatar", "entity", "EntityManager"];
        Qe.prototype = {
            init: function() {
                this.cache = [];
                this.tagList = [];
                this.lastId = 0
            },
            createEntity: function() {
                var a;
                0 < this.cache.length ? a = this.cache.pop() : (a = this.lastId, this.lastId++);
                return a
            },
            destroyEntity: function(a) {
                this.delTag(a);
                this.cache.push(a)
            },
            addTag: function(a, b) {
                1 != this.checkPresentTag(b) && this.tagList.push({
                    entity: a,
                    tag: b
                })
            },
            checkPresentTag: function(a) {
                for (var b = 0, c = this.tagList.length; b < c;) {
                    var d = b++;
                    if (this.tagList[d].tag == a) return !0
                }
                return !1
            },
            getEntityByTag: function(a) {
                for (var b = 0, c = this.tagList.length; b < c;) {
                    var d = b++;
                    if (this.tagList[d].tag == a) return this.tagList[d].entity
                }
                return -1
            },
            delTag: function(a) {
                for (var b =
                        0, c = this.tagList.length; b < c;) {
                    var d = b++;
                    if (this.tagList[d].entity == a) {
                        this.tagList.splice(d, 1);
                        break
                    }
                }
            },
            free: function() {
                this.cache = [];
                this.cache = null;
                this.tagList = [];
                this.tagList = null;
                this.lastId = 0
            },
            __class__: Qe
        };
        var Re = function() {
            this.init()
        };
        g["com.alagatar.entity.EventManager"] = Re;
        Re.__name__ = ["com", "alagatar", "entity", "EventManager"];
        Re.prototype = {
            init: function() {
                this.listeners = []
            },
            addListener: function(a, b) {
                1 != this.isAdded(a, b) && this.listeners.push({
                    listener: a,
                    event: b
                })
            },
            isAdded: function(a, b) {
                for (var c =
                        this.listeners.length, d, e = 0; e < c;)
                    if (d = e++, d = this.listeners[d], d.listener == a && d.event == b) return !0;
                return !1
            },
            sendEvent: function(a, b) {
                for (var c = 0, d = this.listeners; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.event == a && e.listener.receiveEvent(a, b)
                }
            },
            free: function() {
                this.listeners = [];
                this.listeners = null
            },
            __class__: Re
        };
        var Z = function() {};
        g["com.alagatar.entity.System"] = Z;
        Z.__name__ = ["com", "alagatar", "entity", "System"];
        Z.prototype = {
            init: function() {
                this.entityList = [];
                this.addList = [];
                this.delList = [];
                this.countEntitys = 0;
                this.requiredComponentsClass = []
            },
            addRequiredComponentClass: function(a) {
                a = n.get_instance().getComponentClassId(a);
                this.requiredComponentsClass.push(a)
            },
            activate: function() {},
            update: function(a) {
                if (0 != this.countEntitys || 0 != this.addList.length) this.cleanDisabledEntitys(), this.addNewEntitys(), this.beforeProcess(), this.processAll(a), this.afterProcess()
            },
            addNewEntitys: function() {
                var a = this.addList.length;
                if (0 != a) {
                    for (var b = 0; b < a;) {
                        var c = b++; - 1 == u.indexOf(this.entityList, this.addList[c], 0) && this.inserted(this.addList[c])
                    }
                    this.addList = []
                }
            },
            inserted: function(a) {
                this.countEntitys++;
                this.entityList.push(a)
            },
            isEntityDisabled: function(a) {
                return -1 == u.indexOf(this.delList, a, 0) ? !1 : !0
            },
            beforeProcess: function() {},
            processAll: function(a) {
                for (var b, c = 0, d = this.countEntitys; c < d;) b = c++, b = this.entityList[b], 0 == this.isEntityDisabled(b) && this.process(b, a)
            },
            process: function(a, b) {},
            afterProcess: function() {},
            cleanDisabledEntitys: function() {
                var a = this.delList.length;
                if (0 != a) {
                    for (var b = 0; b < a;) {
                        var c = b++;
                        this.removed(this.delList[c])
                    }
                    this.delList = []
                }
            },
            removed: function(a) {
                this.countEntitys--;
                u.remove(this.entityList, a)
            },
            checkRequired: function(a) {
                return 0 == this.requiredComponentsClass.length ? !1 : 1 == n.get_instance().containsComponents(a, this.requiredComponentsClass) ? !0 : !1
            },
            receiveEvent: function(a, b) {},
            added: function(a) {
                1 == this.checkRequired(a) && -1 == u.indexOf(this.addList, a, 0) && this.addList.push(a)
            },
            changed: function(a) {
                1 == this.checkRequired(a) ? -1 == u.indexOf(this.addList, a, 0) && this.addList.push(a) : -1 != u.indexOf(this.entityList, a, 0) && -1 == u.indexOf(this.delList,
                    a, 0) && this.delList.push(a)
            },
            deleted: function(a) {
                null != this.entityList && -1 != u.indexOf(this.entityList, a, 0) && -1 == u.indexOf(this.delList, a, 0) && this.delList.push(a)
            },
            destroyEntitys: function(a, b) {
                null == b && (b = !0);
                null == a && (a = !0);
                for (var c, d = 0, e = this.countEntitys; d < e;) c = d++, c = this.entityList[c], 0 == this.isEntityDisabled(c) && n.get_instance().destroyEntity(c, a, b);
                this.entityList = []
            },
            free: function() {
                this.entityList = [];
                this.entityList = null;
                this.addList = [];
                this.addList = null;
                this.delList = [];
                this.delList = null;
                this.requiredComponentsClass = [];
                this.requiredComponentsClass = null
            },
            __class__: Z
        };
        var Vf = function() {};
        g["com.alagatar.macros.OnCompile"] = Vf;
        Vf.__name__ = ["com", "alagatar", "macros", "OnCompile"];
        var Va = function(a) {
            null == a && (a = !1);
            this.bgAlpha = .7;
            this.bgColor = 1118481;
            this.showTime = this.hideTime = .25;
            y.call(this);
            this.testMode = a;
            this.init()
        };
        g["com.alagatar.menu.BaseMenu"] = Va;
        Va.__name__ = ["com", "alagatar", "menu", "BaseMenu"];
        Va.__super__ = y;
        Va.prototype = t(y.prototype, {
            init: function() {
                this.bg = new y;
                this.bg.set_x(m.get_instance().halfNativeWidth);
                this.bg.set_y(m.get_instance().halfNativeHeight);
                this.addChild(this.bg);
                this.baseTween = null;
                this.mouseChildren = this.mouseEnabled = !1;
                this.set_visible(!1);
                this.set_alpha(0);
                this.active = !0;
                this.createUi()
            },
            createUi: function() {
                var a = m.get_instance().width / m.get_instance().scale,
                    b = m.get_instance().height / m.get_instance().scale,
                    c = -(a / 2 + 1),
                    d = -(b / 2 + 1),
                    a = a + 2,
                    b = b + 2;
                this.bg.get_graphics().beginFill(this.bgColor, this.bgAlpha);
                this.bg.get_graphics().drawRect(c, d, a, b);
                this.bg.get_graphics().endFill()
            },
            show: function() {
                1 !=
                    this.get_visible() && (this.mouseChildren = this.mouseEnabled = !0, this.set_visible(!0), this.baseTween = A.tween(this, this.showTime, {
                        alpha: 1
                    }).ease(qb.get_easeNone()).onComplete(r(this, this.completeShow)))
            },
            completeShow: function() {},
            hide: function() {
                this.mouseChildren = this.mouseEnabled = !1;
                this.baseTween = A.tween(this, this.hideTime, {
                    alpha: 0
                }).ease(qb.get_easeNone()).onComplete(r(this, this.completeHide))
            },
            completeHide: function() {
                this.set_visible(!1);
                this.active = !0
            },
            free: function() {
                null != this.baseTween && (A.stop(this.baseTween,
                    null, !1, !1), this.baseTween = null);
                this.active = !1;
                this.bg = null
            },
            __class__: Va
        });
        var Se = function(a, b) {
            this.groupId = a;
            this.chanelId = b;
            this.volume = 1;
            this.looped = !1;
            this.position = 0;
            this.paused = this.muted = this.active = !1;
            this.transform = new Gc;
            this.transform.volume = this.volume
        };
        g["com.alagatar.sound.SoundNode"] = Se;
        Se.__name__ = ["com", "alagatar", "sound", "SoundNode"];
        Se.prototype = {
            play: function(a, b) {
                null == b && (b = !1);
                if (this.sound != a || 1 != this.looped || 1 != this.active) "music" == this.groupId && this.stop(), this.position =
                    0, this.active = !0, this.sound = a, this.looped = b, 0 == this.muted && this.startPlay()
            },
            startPlay: function() {
                this.chanel = this.sound.play(this.position, 0, this.transform);
                1 == this.looped && null != this.chanel && 0 == this.chanel.hasEventListener(w.SOUND_COMPLETE) && this.chanel.addEventListener(w.SOUND_COMPLETE, r(this, this.complete))
            },
            complete: function(a) {
                this.position = 0;
                this.startPlay()
            },
            mute: function(a) {
                this.muted = a;
                0 != this.active && (1 == this.muted ? this.pausePlay() : 1 == this.looped && 0 == this.paused && this.startPlay())
            },
            pausePlay: function() {
                this.position =
                    0;
                null != this.chanel && (1 == this.looped && (this.position = this.chanel.get_position()), this.chanel.stop())
            },
            pause: function(a) {
                a != this.paused && (this.paused = a, 0 != this.active && (1 == this.paused ? this.pausePlay() : 1 == this.looped && 0 == this.muted && this.startPlay()))
            },
            stop: function() {
                this.pausePlay();
                this.position = 0;
                this.active = !1
            },
            __class__: Se
        };
        L = Tc.SoundSystem = function() {
            null != L._instance && console.log("Error: Object allready inited. Use SoundSystem.instance instead");
            L._instance = this;
            L.inited = !0;
            this.init()
        };
        g["com.alagatar.sound.SoundSystem"] = L;
        L.__name__ = ["com", "alagatar", "sound", "SoundSystem"];
        L.__properties__ = {
            get_instance: "get_instance"
        };
        L._instance = null;
        L.get_instance = function() {
            null == L._instance && (L._instance = new L);
            return L._instance
        };
        L.prototype = {
            init: function() {
                this.sfxMuted = this.musicMuted = !1;
                this.mediaList = [];
                this.nodesList = []
            },
            isMuted: function() {
                return 1 == this.musicMuted && 1 == this.sfxMuted ? !0 : !1
            },
            addMusic: function(a, b, c) {
                null == c && (c = "music");
                this.addMedia(a, b, "music", c)
            },
            addSfx: function(a,
                b, c) {
                null == c && (c = "sfx");
                this.addMedia(a, b, "sfx", c)
            },
            addMedia: function(a, b, c, d) {
                0 == Y.exists(b) ? console.log("Media path " + b + " no exist") : (this.createMedia(a, b, c, d), null == this.findSoundNode(c, d) && this.createSoundNode(c, d))
            },
            createMedia: function(a, b, c, d) {
                a = {
                    id: a,
                    group: c,
                    chanel: d,
                    sound: Y.getSound(b)
                };
                this.mediaList.push(a)
            },
            findSoundNode: function(a, b) {
                for (var c = null, d = 0, e = this.nodesList.length; d < e;) {
                    var f = d++;
                    if (this.nodesList[f].groupId == a && this.nodesList[f].chanelId == b) {
                        c = this.nodesList[f];
                        break
                    }
                }
                return c
            },
            createSoundNode: function(a, b) {
                var c = new Se(a, b);
                this.nodesList.push(c)
            },
            playMusic: function(a, b) {
                null == b && (b = !0);
                this.playMedia(a, b)
            },
            playSound: function(a, b) {
                null == b && (b = !1);
                this.playMedia(a, b)
            },
            playMedia: function(a, b) {
                var c = this.findMedia(a);
                null == c ? console.log("Media " + a + " no founded") : this.findSoundNode(c.group, c.chanel).play(c.sound, b)
            },
            findMedia: function(a) {
                for (var b = null, c = 0, d = this.mediaList.length; c < d;) {
                    var e = c++;
                    if (this.mediaList[e].id == a) {
                        b = this.mediaList[e];
                        break
                    }
                }
                return b
            },
            mute: function(a) {
                this.muteMusic(a);
                this.muteSfx(a)
            },
            muteMusic: function(a) {
                this.musicMuted = a;
                this.muteSoundNodes("music", a)
            },
            muteSfx: function(a) {
                this.sfxMuted = a;
                this.muteSoundNodes("sfx", a)
            },
            muteSoundNodes: function(a, b) {
                for (var c = 0, d = this.nodesList.length; c < d;) {
                    var e = c++;
                    this.nodesList[e].groupId == a && this.nodesList[e].mute(b)
                }
            },
            pauseMusic: function(a) {
                this.pauseSoundNodes("music", a)
            },
            pauseSfx: function(a) {
                this.pauseSoundNodes("sfx", a)
            },
            pauseSoundNodes: function(a, b) {
                for (var c = 0, d = this.nodesList.length; c < d;) {
                    var e = c++;
                    this.nodesList[e].groupId ==
                        a && this.nodesList[e].pause(b)
                }
            },
            stopSfx: function() {
                this.stopSoundNodes("sfx")
            },
            stopSoundNodes: function(a) {
                for (var b = 0, c = this.nodesList.length; b < c;) {
                    var d = b++;
                    this.nodesList[d].groupId == a && this.nodesList[d].stop()
                }
            },
            __class__: L
        };
        var Ra = function() {
            y.call(this)
        };
        g["com.alagatar.ui.UiItem"] = Ra;
        Ra.__name__ = ["com", "alagatar", "ui", "UiItem"];
        Ra.__super__ = y;
        Ra.prototype = t(y.prototype, {
            onMouseDown: function(a) {},
            onMouseUp: function(a) {},
            onMouseMove: function(a) {},
            __class__: Ra
        });
        var va = function() {
            y.call(this);
            this.children = [];
            this.containerY = this.containerX = 0;
            this.tiles = [];
            this.containers = [];
            this.reference = new ja
        };
        g["com.alagatar.tiles.TileContainer"] = va;
        va.__name__ = ["com", "alagatar", "tiles", "TileContainer"];
        va.__super__ = Ra;
        va.prototype = t(Ra.prototype, {
            addTile: function(a) {
                this.tiles.push(a);
                this.initTilePosition(a);
                this.add(a)
            },
            initTilePosition: function(a) {
                var b = this.calcGlobalPos();
                this.updateTilePosition(a, b)
            },
            delTile: function(a) {
                u.remove(this.tiles, a);
                this.del(a)
            },
            addChild: function(a) {
                var b = Ra.prototype.addChild.call(this,
                    a);
                1 == x.__instanceof(a, va) && (this.containers.push(a), x.__cast(a, va).updatePosition());
                this.add(a);
                return b
            },
            addTileContainer: function(a) {
                Ra.prototype.addChild.call(this, a);
                this.containers.push(a);
                a.updatePosition();
                this.add(a)
            },
            removeChild: function(a) {
                1 == x.__instanceof(a, va) && u.remove(this.containers, a);
                this.del(a);
                return Ra.prototype.removeChild.call(this, a)
            },
            add: function(a) {
                var b = 0,
                    c = 0,
                    d = 0;
                1 == x.__instanceof(a, P) ? (b = x.__cast(a, P).get_rotation(), c = x.__cast(a, P).get_scaleX(), d = x.__cast(a, P).get_scaleY()) :
                    (b = a.rotation, c = a.scaleX, d = a.scaleY);
                this.children.push({
                    item: a,
                    x: a.x,
                    y: a.y,
                    rotation: b,
                    scaleX: c,
                    scaleY: d,
                    alpha: a.alpha
                })
            },
            del: function(a) {
                a = this.getIndex(a); - 1 != a && this.children.splice(a, 1)
            },
            getIndex: function(a) {
                for (var b = 0, c = this.children.length; b < c;) {
                    var d = b++;
                    if (this.children[d].item == a) return d
                }
                return -1
            },
            removeAllChildren: function() {
                for (var a = 0, b = this.children.length; a < b;) {
                    var c = a++;
                    0 == x.__instanceof(this.children[c].item, P) && this.removeChild(this.children[c].item)
                }
                this.children = []
            },
            get_countChildren: function() {
                return null !=
                    this.children ? this.children.length : 0
            },
            destroyChildsToCache: function() {
                for (var a = 0, b = this.children.length; a < b;) {
                    var c = a++;
                    1 == x.__instanceof(this.children[c].item, P) && x.__cast(this.children[c].item, P).destroyToCache()
                }
            },
            set_x: function(a) {
                Ra.prototype.set_x.call(this, a);
                this.updatePosition();
                return a
            },
            updatePosition: function() {
                var a = this.calcGlobalPos();
                this.updateTilesPosition(a);
                this.updateContainersPosition(a)
            },
            calcGlobalPos: function() {
                var a = this.localToGlobal(this.reference);
                a.x = m.formatStageX(a.x);
                a.y = m.formatStageY(a.y);
                return a
            },
            updateTilesPosition: function(a) {
                if (null != this.tiles)
                    for (var b = 0, c = this.tiles.length; b < c;) {
                        var d = b++;
                        this.updateTilePosition(this.tiles[d], a)
                    }
            },
            updateTilePosition: function(a, b) {
                null != a && (a.referenceX = b.x, a.referenceY = b.y)
            },
            updateContainersPosition: function(a) {
                if (null != this.containers) {
                    a = 0;
                    for (var b = this.containers.length; a < b;) {
                        var c = a++;
                        this.containers[c].updatePosition()
                    }
                }
            },
            set_y: function(a) {
                Ra.prototype.set_y.call(this, a);
                this.updatePosition();
                return a
            },
            set_rotation: function(a) {
                Ra.prototype.set_rotation.call(this,
                    a);
                this.updateRotation(a);
                return a
            },
            updateRotation: function(a) {
                for (var b = 0, c = this.children.length; b < c;) {
                    var d = b++;
                    this.updateItemRotation(this.children[d], a)
                }
            },
            updateItemRotation: function(a, b) {
                1 == x.__instanceof(a.item, P) ? x.__cast(a.item, P).set_rotation(a.rotation + C.toRad(b)) : 1 == x.__instanceof(a.item, va) && a.item.updateRotation(b)
            },
            set_scaleX: function(a) {
                Ra.prototype.set_scaleX.call(this, a);
                this.updateScaleX(a);
                return a
            },
            updateScaleX: function(a) {
                for (var b = 0, c = this.children.length; b < c;) {
                    var d = b++;
                    this.updateItemScaleX(this.children[d],
                        a)
                }
            },
            updateItemScaleX: function(a, b) {
                1 == x.__instanceof(a.item, P) ? x.__cast(a.item, P).set_scaleX(a.scaleX * b) : 1 == x.__instanceof(a.item, va) && a.item.updateScaleX(b)
            },
            set_scaleY: function(a) {
                Ra.prototype.set_scaleY.call(this, a);
                this.updateScaleY(a);
                return a
            },
            updateScaleY: function(a) {
                for (var b = 0, c = this.children.length; b < c;) {
                    var d = b++;
                    this.updateItemScaleY(this.children[d], a)
                }
            },
            updateItemScaleY: function(a, b) {
                1 == x.__instanceof(a.item, P) ? x.__cast(a.item, P).set_scaleY(a.scaleY * b) : 1 == x.__instanceof(a.item, va) &&
                    a.item.updateScaleY(b)
            },
            set_alpha: function(a) {
                Ra.prototype.set_alpha.call(this, a);
                this.updateAlpha(a);
                return a
            },
            updateAlpha: function(a) {
                if (null != this.children)
                    for (var b = 0, c = this.children.length; b < c;) {
                        var d = b++;
                        this.updateItemAlpha(this.children[d], a)
                    }
            },
            updateItemAlpha: function(a, b) {
                1 == x.__instanceof(a.item, P) ? a.item.alpha = a.alpha * b : 1 == x.__instanceof(a.item, va) && a.item.updateAlpha(b)
            },
            set_visible: function(a) {
                Ra.prototype.set_visible.call(this, a);
                this.updateVisible(a);
                return a
            },
            updateVisible: function(a) {
                for (var b =
                        0, c = this.children.length; b < c;) {
                    var d = b++;
                    this.updateItemVisible(this.children[d], a)
                }
            },
            updateItemVisible: function(a, b) {
                1 == x.__instanceof(a.item, P) ? a.item.visible = b : 1 == x.__instanceof(a.item, va) && a.item.updateVisible(b)
            },
            setChildreEnabled: function(a) {
                for (var b = 0, c = this.children; b < c.length;) {
                    var d = c[b];
                    ++b;
                    1 == x.__instanceof(d.item, Pb) ? x.__cast(d.item, Pb).active = a : 1 == x.__instanceof(d.item, va) && d.item.setChildreEnabled(a)
                }
            },
            free: function() {
                this.children = [];
                this.children = null;
                for (var a = 0, b = this.tiles; a <
                    b.length;) {
                    var c = b[a];
                    ++a;
                    null != c.parent && c.parent.removeChild(c)
                }
                this.tiles = [];
                this.tiles = null;
                this.containers = [];
                this.containers = null
            },
            __class__: va,
            __properties__: t(Ra.prototype.__properties__, {
                get_countChildren: "get_countChildren"
            })
        });
        var aa = function() {
            if (null != aa._instance) throw "Error: Allready inited. Use instance instead;";
            this.layers = [];
            this.groups = []
        };
        g["com.alagatar.tiles.TilelayerManager"] = aa;
        aa.__name__ = ["com", "alagatar", "tiles", "TilelayerManager"];
        aa.__properties__ = {
            get_instance: "get_instance"
        };
        aa._instance = null;
        aa.get_instance = function() {
            null == aa._instance && (aa._instance = new aa);
            return aa._instance
        };
        aa.prototype = {
            create: function(a, b, c, d, e) {
                b = Y.getText(b);
                c = Y.getBitmapData(c);
                c = new Hd(c, b);
                c = new Id(c, !0, !1);
                d.addChild(c.view);
                this.layers.push({
                    id: a,
                    layer: c
                })
            },
            get: function(a) {
                for (var b = 0, c = this.layers; b < c.length;) {
                    var d = c[b];
                    ++b;
                    if (d.id == a) return d.layer
                }
                return null
            },
            update: function() {
                for (var a = this.layers.length, b = 0; b < a;) {
                    var c = b++;
                    this.layers[c].layer.render()
                }
            },
            createGroup: function(a,
                b) {
                if (null != this.getGroup(a, b)) return console.log("Group with id:" + a + " on layer:" + b + " already present"), null;
                var c = this.get(b);
                if (null == c) return console.log("No layer with id:" + b + " founded!"), null;
                var d = new cc(c);
                c.addChild(d);
                this.groups.push({
                    id: a,
                    group: d,
                    layerId: b
                });
                return d
            },
            getGroup: function(a, b) {
                for (var c = 0, d = this.groups; c < d.length;) {
                    var e = d[c];
                    ++c;
                    if (e.id == a && e.layerId == b) return e.group
                }
                return null
            },
            free: function() {
                P.clearPool();
                Ua.clearPool();
                this.layers = [];
                this.groups = []
            },
            __class__: aa
        };
        var xa =
            function(a, b) {
                null == b && (b = !0);
                y.call(this);
                null != a && this.createGraphFrom(a, b);
                this.init()
            };
        g["com.alagatar.ui.Button"] = xa;
        xa.__name__ = ["com", "alagatar", "ui", "Button"];
        xa.__super__ = y;
        xa.prototype = t(y.prototype, {
            init: function() {
                this.setAlphaMode();
                this.tileMode = this.touchActive = this.paramsSet = !1;
                this.soundEffect = null;
                this.activated = this.onlyFirstClick = !1;
                this.enabled = this.active = !0;
                this.addControls()
            },
            setAlphaMode: function() {
                this.animCoef = .6;
                this.animInTime = .2;
                this.animOutTime = .1;
                this.animMode = 2
            },
            createGraphFrom: function(a,
                b) {
                null == b && (b = !0);
                var c = ta.buildSprite(a);
                c.set_smooth(b);
                this.setGraph(c)
            },
            setGraph: function(a) {
                null != this.graph && (this.removeChild(this.graph), this.graph = null);
                this.addChildAt(a, 0);
                this.graph = a
            },
            addControls: function() {
                this.addEventListener(D.MOUSE_DOWN, r(this, this.touchDown));
                this.addEventListener(D.MOUSE_UP, r(this, this.touchUp))
            },
            touchDown: function(a) {
                0 != this.active && 0 != this.enabled && (this.touchActive = !0)
            },
            touchUp: function(a) {
                0 != this.active && 0 != this.enabled && 0 != this.touchActive && (this.touchActive = !1, 1 == this.onlyFirstClick && 1 == this.activated || null == this.graph || (0 == this.paramsSet && (this.paramsSet = !0, this.initParams()), this.startAnim()))
            },
            startAnim: function() {
                this.activated = !0;
                null != this.soundEffect && L.get_instance().playSound(this.soundEffect);
                this.reset();
                1 == this.animMode ? this.zoomIn() : this.alphaIn();
                this.dispatchEvent(new w("start", !0))
            },
            initParams: function() {
                this.config = {
                    alpha: this.get_alpha(),
                    scaleX: this.get_scaleX(),
                    scaleY: this.get_scaleY()
                }
            },
            zoomIn: function() {
                var a = this.config.scaleX *
                    this.animCoef,
                    b = this.config.scaleY * this.animCoef;
                A.tween(this, this.animInTime, {
                    scaleX: a,
                    scaleY: b
                }).ease(Qb.get_easeInOut()).onComplete(r(this, this.zoomOut));
                1 == this.tileMode && A.tween(this.tileGraph, this.animInTime, {
                    scaleX: a,
                    scaleY: b
                }).ease(Qb.get_easeInOut())
            },
            zoomOut: function() {
                A.tween(1 == this.tileMode ? this.tileGraph : this, this.animOutTime, {
                    scaleX: this.config.scaleX,
                    scaleY: this.config.scaleY
                }).ease(qb.get_easeNone()).onComplete(r(this, this.completeAnim))
            },
            alphaIn: function() {
                var a = this.config.alpha *
                    this.animCoef;
                A.tween(this, this.animInTime, {
                    alpha: a
                }).ease(Qb.get_easeInOut()).onComplete(r(this, this.alphaOut));
                1 == this.tileMode && A.tween(this.tileGraph, this.animInTime, {
                    alpha: a
                }).ease(Qb.get_easeInOut())
            },
            alphaOut: function() {
                A.tween(this, this.animOutTime, {
                    alpha: this.config.alpha
                }).ease(qb.get_easeNone()).onComplete(r(this, this.completeAnim));
                1 == this.tileMode && A.tween(this.tileGraph, this.animOutTime, {
                    alpha: this.config.alpha
                }).ease(qb.get_easeNone())
            },
            completeAnim: function() {
                this.reset();
                this.dispatchEvent(new w("complete"))
            },
            reset: function() {
                1 == this.animMode ? (this.set_scaleX(this.config.scaleX), this.set_scaleY(this.config.scaleY)) : this.set_alpha(this.config.alpha)
            },
            addChild: function(a) {
                y.prototype.addChild.call(this, a);
                1 == this.animMode && this.fixScale();
                return a
            },
            fixScale: function() {
                this.set_scaleX(1.0001 * this.get_scaleX());
                this.set_scaleY(1.0001 * this.get_scaleY())
            },
            setSoundEffect: function(a) {
                this.soundEffect = a
            },
            setLabel: function(a) {
                this.label = a;
                this.addChild(this.label)
            },
            setEnabled: function(a) {
                this.enabled = a;
                1 == this.enabled ?
                    1 == this.active && this.enabledState() : this.disabledState()
            },
            enabledState: function() {
                this.graph.set_alpha(1)
            },
            disabledState: function() {
                this.graph.set_alpha(.6)
            },
            isEnabled: function() {
                return this.enabled
            },
            __class__: xa
        });
        var Ma = g["com.alagatar.ui.ButtonState"] = {
            __ename__: ["com", "alagatar", "ui", "ButtonState"],
            __constructs__: ["ON", "OFF"]
        };
        Ma.ON = ["ON", 0];
        Ma.ON.toString = p;
        Ma.ON.__enum__ = Ma;
        Ma.OFF = ["OFF", 1];
        Ma.OFF.toString = p;
        Ma.OFF.__enum__ = Ma;
        var wc = function(a, b, c) {
            null == c && (c = !0);
            y.call(this);
            null != a && this.setGraph(ta.buildSprite(a),
                Ma.ON);
            null != b && this.setGraph(ta.buildSprite(b), Ma.OFF);
            this.setSmooth(c);
            this.setState(Ma.ON);
            this.init()
        };
        g["com.alagatar.ui.ButtonToggle"] = wc;
        wc.__name__ = ["com", "alagatar", "ui", "ButtonToggle"];
        wc.__super__ = y;
        wc.prototype = t(y.prototype, {
            init: function() {
                this.setAlphaMode();
                this.touchActive = this.paramsSet = !1;
                this.soundEffect = null;
                this.addControls()
            },
            setAlphaMode: function() {
                this.animCoef = .6;
                this.animInTime = .2;
                this.animOutTime = .1;
                this.animMode = 2
            },
            setGraph: function(a, b) {
                this.removeState(b);
                this.addChild(a);
                b == Ma.ON ? this.graph1 = a : this.graph2 = a
            },
            removeState: function(a) {
                a = a == Ma.ON ? this.graph1 : this.graph2;
                null != a && this.removeChild(a)
            },
            setState: function(a) {
                this.state = a;
                null != this.graph1 && null != this.graph2 && (this.state == Ma.ON ? (this.graph1.set_visible(!0), this.graph2.set_visible(!1)) : (this.graph1.set_visible(!1), this.graph2.set_visible(!0)))
            },
            addControls: function() {
                this.addEventListener(D.MOUSE_DOWN, r(this, this.touchDown));
                this.addEventListener(D.MOUSE_UP, r(this, this.touchUp))
            },
            touchDown: function(a) {
                this.touchActive = !0
            },
            touchUp: function(a) {
                0 != this.touchActive && (this.touchActive = !1, 0 == this.paramsSet && (this.paramsSet = !0, this.initParams()), this.startAnim())
            },
            initParams: function() {
                this.config = {
                    alpha: this.get_alpha(),
                    scaleX: this.get_scaleX(),
                    scaleY: this.get_scaleY()
                }
            },
            startAnim: function() {
                null != this.soundEffect && L.get_instance().playSound(this.soundEffect);
                this.reset();
                1 == this.animMode ? this.zoomIn() : this.alphaIn();
                this.dispatchEvent(new w("start", !0))
            },
            zoomIn: function() {
                A.tween(this, this.animInTime, {
                    scaleX: this.config.scaleX *
                        this.animCoef,
                    scaleY: this.config.scaleY * this.animCoef
                }).ease(Qb.get_easeInOut()).onComplete(r(this, this.zoomOut))
            },
            zoomOut: function() {
                A.tween(this, this.animOutTime, {
                    scaleX: this.config.scaleX,
                    scaleY: this.config.scaleY
                }).ease(qb.get_easeNone()).onComplete(r(this, this.completeAnim))
            },
            alphaIn: function() {
                A.tween(this, this.animInTime, {
                    alpha: this.config.alpha * this.animCoef
                }).ease(Qb.get_easeInOut()).onComplete(r(this, this.alphaOut))
            },
            alphaOut: function() {
                A.tween(this, this.animOutTime, {
                    alpha: this.config.alpha
                }).ease(qb.get_easeNone()).onComplete(r(this,
                    this.completeAnim))
            },
            completeAnim: function() {
                this.reset();
                this.switchState();
                this.dispatchEvent(new w("complete", !0));
                this.dispatchEvent(new w("change", !0))
            },
            reset: function() {
                this.set_alpha(this.config.alpha);
                this.set_scaleX(this.config.scaleX);
                this.set_scaleY(this.config.scaleY)
            },
            switchState: function() {
                var a = Ma.ON;
                this.state == Ma.ON && (a = Ma.OFF);
                this.setState(a)
            },
            addChild: function(a) {
                y.prototype.addChild.call(this, a);
                this.fixScale();
                return a
            },
            fixScale: function() {
                this.set_scaleX(1.0001 * this.get_scaleX());
                this.set_scaleY(1.0001 * this.get_scaleY())
            },
            setSmooth: function(a) {
                1 == x.__instanceof(this.graph1, ta) && x.__cast(this.graph1, ta).set_smooth(a);
                1 == x.__instanceof(this.graph2, ta) && x.__cast(this.graph2, ta).set_smooth(a)
            },
            setSoundEffect: function(a) {
                this.soundEffect = a
            },
            __class__: wc
        });
        var Na = function() {
            $a.call(this);
            this.__height = this.__width = 100;
            this.__text = "";
            this.set_type(Rb.DYNAMIC);
            this.set_autoSize(wa.NONE);
            this.embedFonts = this.displayAsPassword = !1;
            this.selectable = !0;
            this.set_borderColor(0);
            this.set_border(!1);
            this.set_backgroundColor(16777215);
            this.set_background(!1);
            this.gridFitType = Ab.PIXEL;
            this.maxChars = 0;
            this.multiline = !1;
            this.scrollH = this.sharpness = 0;
            this.scrollV = 1;
            this.set_wordWrap(!1);
            null == Na.__defaultTextFormat && (Na.__defaultTextFormat = new cd("Times New Roman", 12, 0, !1, !1, !1, "", "", Ea.LEFT, 0, 0, 0, 0), Na.__defaultTextFormat.blockIndent = 0, Na.__defaultTextFormat.bullet = !1, Na.__defaultTextFormat.letterSpacing = 0, Na.__defaultTextFormat.kerning = !1);
            this.__textFormat = Na.__defaultTextFormat.clone()
        };
        g["openfl.text.TextField"] =
            Na;
        Na.__name__ = ["openfl", "text", "TextField"];
        Na.__defaultTextFormat = null;
        Na.__super__ = $a;
        Na.prototype = t($a.prototype, {
            setTextFormat: function(a, b, c) {
                null != a.font && (this.__textFormat.font = a.font);
                null != a.size && (this.__textFormat.size = a.size);
                null != a.color && (this.__textFormat.color = a.color);
                null != a.bold && (this.__textFormat.bold = a.bold);
                null != a.italic && (this.__textFormat.italic = a.italic);
                null != a.underline && (this.__textFormat.underline = a.underline);
                null != a.url && (this.__textFormat.url = a.url);
                null != a.target &&
                    (this.__textFormat.target = a.target);
                null != a.align && (this.__textFormat.align = a.align);
                null != a.leftMargin && (this.__textFormat.leftMargin = a.leftMargin);
                null != a.rightMargin && (this.__textFormat.rightMargin = a.rightMargin);
                null != a.indent && (this.__textFormat.indent = a.indent);
                null != a.leading && (this.__textFormat.leading = a.leading);
                null != a.blockIndent && (this.__textFormat.blockIndent = a.blockIndent);
                null != a.bullet && (this.__textFormat.bullet = a.bullet);
                null != a.kerning && (this.__textFormat.kerning = a.kerning);
                null !=
                    a.letterSpacing && (this.__textFormat.letterSpacing = a.letterSpacing);
                null != a.tabStops && (this.__textFormat.tabStops = a.tabStops);
                this.__dirty = !0
            },
            __disableInputMode: function() {
                this.this_onRemovedFromStage(null)
            },
            __enableInputMode: function() {
                this.__cursorPosition = -1;
                null == this.__hiddenInput && (this.__hiddenInput = window.document.createElement("input"), this.__hiddenInput.type = "text", this.__hiddenInput.style.position = "absolute", this.__hiddenInput.style.opacity = "0", this.__hiddenInput.style.pointerEvents = "none",
                    this.__hiddenInput.style.left = this.get_x() + (null != this.__canvas ? this.__canvas.offsetLeft : 0) + "px", this.__hiddenInput.style.top = this.get_y() + (null != this.__canvas ? this.__canvas.offsetTop : 0) + "px", this.__hiddenInput.style.width = this.__width + "px", this.__hiddenInput.style.height = this.__height + "px", this.__hiddenInput.style.zIndex = "0", 0 < this.maxChars && (this.__hiddenInput.maxLength = this.maxChars), window.document.body.appendChild(this.__hiddenInput), this.__hiddenInput.value = this.__text);
                null != this.stage ? this.this_onAddedToStage(null) :
                    (this.addEventListener(w.ADDED_TO_STAGE, r(this, this.this_onAddedToStage)), this.addEventListener(w.REMOVED_FROM_STAGE, r(this, this.this_onRemovedFromStage)))
            },
            __getBounds: function(a, b) {
                var c = new za(0, 0, this.__width, this.__height);
                c.transform(this.__worldTransform);
                a.__expand(c.x, c.y, c.width, c.height)
            },
            __getFont: function(a) {
                var b;
                b = a.italic ? "italic " : "normal ";
                b += "normal ";
                b = a.bold ? b + "bold " : b + "normal ";
                b += a.size + "px";
                b += "/" + (a.size + a.leading + 4) + "px ";
                switch (a.font) {
                    case "_sans":
                        a = "sans-serif";
                        break;
                    case "_serif":
                        a = "serif";
                        break;
                    case "_typewriter":
                        a = "monospace";
                        break;
                    default:
                        a = a.font
                }
                b += "'" + a;
                return b + "'"
            },
            __getPosition: function(a, b) {
                var c = this.get_text(),
                    d = 0,
                    e = c.length;
                if (a < this.__getTextWidth(c))
                    for (var f = 0, l = c.length; f < l;) {
                        var E = f++,
                            d = d + this.__getTextWidth(c.charAt(E));
                        if (d >= a) {
                            e = E;
                            break
                        }
                    }
                return e
            },
            __getTextWidth: function(a) {
                null == this.__context && (this.__canvas = window.document.createElement("canvas"), this.__context = this.__canvas.getContext("2d"));
                this.__context.font = this.__getFont(this.__textFormat);
                this.__context.textAlign = "left";
                return this.__context.measureText(a).width
            },
            __hitTest: function(a, b, c, d, e) {
                if (!this.get_visible() || e && !this.mouseEnabled) return !1;
                a = this.globalToLocal(new ja(a, b));
                return 0 < a.x && 0 < a.y && a.x <= this.__width && a.y <= this.__height ? (null != d && d.push(this), !0) : !1
            },
            __measureText: function() {
                if (null == this.__ranges) return this.__context.font = this.__getFont(this.__textFormat), [this.__context.measureText(this.__text).width];
                for (var a = [], b = 0, c = this.__ranges; b < c.length;) {
                    var d = c[b];
                    ++b;
                    this.__context.font = this.__getFont(d.format);
                    a.push(this.__context.measureText(this.get_text().substring(d.start, d.end)).width)
                }
                return a
            },
            __measureTextWithDOM: function() {
                var a = this.__div;
                null == this.__div && (a = window.document.createElement("div"), a.innerHTML = (new ra("\n", "g")).replace(this.__text, "<br>"), a.style.setProperty("font", this.__getFont(this.__textFormat), null), a.style.position = "absolute", a.style.top = "110%", window.document.body.appendChild(a));
                this.__measuredWidth = a.clientWidth;
                null == this.__div &&
                    (a.style.width = v.string(this.__width) + "px");
                this.__measuredHeight = a.clientHeight;
                null == this.__div && window.document.body.removeChild(a)
            },
            __renderCanvas: function(a) {
                ga.render(this, a)
            },
            __renderDOM: function(a) {
                Lf.render(this, a)
            },
            __renderGL: function(a) {
                Mf.render(this, a)
            },
            __startCursorTimer: function() {
                this.__cursorTimer = tc.delay(r(this, this.__startCursorTimer), 500);
                this.__showCursor = !this.__showCursor;
                this.__dirty = !0
            },
            __stopCursorTimer: function() {
                null != this.__cursorTimer && this.__cursorTimer.stop()
            },
            input_onKeyUp: function(a) {
                this.__isKeyDown = !1;
                null == a && a == window.event;
                this.__text = this.__hiddenInput.value;
                this.__ranges = null;
                this.__isHTML = !1;
                this.__selectionStart = this.__cursorPosition = this.__hiddenInput.selectionStart;
                this.__dirty = !0;
                this.dispatchEvent(new w(w.CHANGE, !0))
            },
            input_onKeyDown: function(a) {
                this.__isKeyDown = !0;
                null == a && a == window.event;
                var b = a.which;
                65 == b && (a.ctrlKey || a.metaKey) ? (this.__hiddenInput.selectionStart = 0, this.__hiddenInput.selectionEnd = this.get_text().length, a.preventDefault(), this.__dirty = !0) : 17 == b || a.metaKey || a.ctrlKey ||
                    (this.__text = this.__hiddenInput.value, this.__ranges = null, this.__isHTML = !1, this.__selectionStart = this.__hiddenInput.selectionStart, this.__dirty = !0)
            },
            stage_onFocusOut: function(a) {
                this.__cursorPosition = -1;
                this.__hasFocus = !1;
                this.__stopCursorTimer();
                this.__hiddenInput.blur();
                this.__dirty = !0
            },
            stage_onMouseMove: function(a) {
                this.__hasFocus && 0 <= this.__selectionStart && (this.__cursorPosition = this.__getPosition(a.localX, a.localY), this.__dirty = !0)
            },
            stage_onMouseUp: function(a) {
                var b = this.__getPosition(a.localX,
                    a.localY);
                a = v["int"](Math.min(this.__selectionStart, b));
                b = v["int"](Math.max(this.__selectionStart, b));
                this.__selectionStart = a;
                this.__cursorPosition = b;
                this.stage.removeEventListener(D.MOUSE_MOVE, r(this, this.stage_onMouseMove));
                this.stage.addEventListener(D.MOUSE_UP, r(this, this.stage_onMouseUp));
                this.stage.set_focus(this);
                0 > this.__cursorPosition && (this.__selectionStart = this.__cursorPosition = this.__text.length);
                this.__hiddenInput.focus();
                this.__hiddenInput.selectionStart = this.__selectionStart;
                this.__hiddenInput.selectionEnd =
                    this.__cursorPosition;
                this.__stopCursorTimer();
                this.__startCursorTimer();
                this.__dirty = this.__hasFocus = !0
            },
            this_onAddedToStage: function(a) {
                this.stage.addEventListener(Bb.FOCUS_OUT, r(this, this.stage_onFocusOut));
                this.__hiddenInput.addEventListener("keydown", r(this, this.input_onKeyDown));
                this.__hiddenInput.addEventListener("keyup", r(this, this.input_onKeyUp));
                this.__hiddenInput.addEventListener("input", r(this, this.input_onKeyUp));
                this.addEventListener(D.MOUSE_DOWN, r(this, this.this_onMouseDown))
            },
            this_onMouseDown: function(a) {
                this.__selectionStart =
                    this.__getPosition(a.localX, a.localY);
                this.stage.addEventListener(D.MOUSE_MOVE, r(this, this.stage_onMouseMove));
                this.stage.addEventListener(D.MOUSE_UP, r(this, this.stage_onMouseUp))
            },
            this_onRemovedFromStage: function(a) {
                null != this.stage && this.stage.removeEventListener(Bb.FOCUS_OUT, r(this, this.stage_onFocusOut));
                null != this.__hiddenInput && this.__hiddenInput.removeEventListener("keydown", r(this, this.input_onKeyDown));
                null != this.__hiddenInput && this.__hiddenInput.removeEventListener("keyup", r(this, this.input_onKeyUp));
                null != this.__hiddenInput && this.__hiddenInput.removeEventListener("input", r(this, this.input_onKeyUp));
                this.removeEventListener(D.MOUSE_DOWN, r(this, this.this_onMouseDown));
                null != this.stage && this.stage.removeEventListener(D.MOUSE_MOVE, r(this, this.stage_onMouseMove));
                null != this.stage && this.stage.removeEventListener(D.MOUSE_UP, r(this, this.stage_onMouseUp))
            },
            set_autoSize: function(a) {
                a != this.autoSize && (this.__dirty = !0);
                return this.autoSize = a
            },
            set_background: function(a) {
                a != this.background && (this.__dirty = !0);
                return this.background = a
            },
            set_backgroundColor: function(a) {
                a != this.backgroundColor && (this.__dirty = !0);
                return this.backgroundColor = a
            },
            set_border: function(a) {
                a != this.border && (this.__dirty = !0);
                return this.border = a
            },
            set_borderColor: function(a) {
                a != this.borderColor && (this.__dirty = !0);
                return this.borderColor = a
            },
            get_defaultTextFormat: function() {
                return this.__textFormat.clone()
            },
            set_defaultTextFormat: function(a) {
                this.__textFormat.__merge(a);
                return a
            },
            get_height: function() {
                return this.__height * this.get_scaleY()
            },
            set_height: function(a) {
                if (1 != this.get_scaleY() || a != this.__height) this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++), this.__dirty = !0;
                this.set_scaleY(1);
                return this.__height = a
            },
            get_text: function() {
                return this.__text
            },
            set_text: function(a) {
                this.__text != a && null != this.__hiddenInput && (this.__hiddenInput.value = a);
                if (this.__isHTML || this.__text != a) this.__dirty = !0;
                this.__ranges = null;
                this.__isHTML = !1;
                return this.__text = a
            },
            get_textWidth: function() {
                if (null != this.__canvas) {
                    for (var a = this.__measureText(),
                            b = 0, c = 0; c < a.length;) {
                        var d = a[c];
                        ++c;
                        b += d
                    }
                    return b
                }
                if (null != this.__div) return this.__div.clientWidth;
                this.__measureTextWithDOM();
                return this.__measuredWidth
            },
            get_textHeight: function() {
                if (null != this.__canvas) return 1.185 * this.__textFormat.size;
                if (null != this.__div) return this.__div.clientHeight;
                this.__measureTextWithDOM();
                return this.__measuredHeight + .185 * this.__textFormat.size
            },
            set_type: function(a) {
                a != this.type && (a == Rb.INPUT ? this.__enableInputMode() : this.__disableInputMode(), this.__dirty = !0);
                return this.type =
                    a
            },
            get_width: function() {
                return this.autoSize == wa.LEFT ? (this.get_textWidth() + 4) * this.get_scaleX() : this.__width * this.get_scaleX()
            },
            set_width: function(a) {
                if (1 != this.get_scaleX() || this.__width != a) this.__transformDirty || (this.__transformDirty = !0, V.__worldTransformDirty++), this.__dirty = !0;
                this.set_scaleX(1);
                return this.__width = a
            },
            set_wordWrap: function(a) {
                return this.wordWrap = a
            },
            __class__: Na,
            __properties__: t($a.prototype.__properties__, {
                get_textHeight: "get_textHeight",
                get_textWidth: "get_textWidth",
                set_text: "set_text",
                get_text: "get_text",
                set_defaultTextFormat: "set_defaultTextFormat",
                get_defaultTextFormat: "get_defaultTextFormat",
                set_wordWrap: "set_wordWrap",
                set_type: "set_type",
                set_borderColor: "set_borderColor",
                set_border: "set_border",
                set_backgroundColor: "set_backgroundColor",
                set_background: "set_background",
                set_autoSize: "set_autoSize"
            })
        });
        var xc = function() {
            Na.call(this);
            this.init()
        };
        g["com.alagatar.ui.Label"] = xc;
        xc.__name__ = ["com", "alagatar", "ui", "Label"];
        xc.__super__ = Na;
        xc.prototype = t(Na.prototype, {
            init: function() {
                var a =
                    new cd(null, 12, 0);
                a.align = Ea.LEFT;
                this.set_autoSize(wa.LEFT);
                this.set_defaultTextFormat(a);
                this.setTextFormat(a);
                this.mouseEnabled = this.selectable = !1;
                this.set_align("left")
            },
            set_color: function(a) {
                this.color = a;
                a = this.get_defaultTextFormat();
                a.color = this.color;
                this.set_defaultTextFormat(a);
                this.setTextFormat(a);
                return this.color
            },
            set_size: function(a) {
                this.size = a;
                a = this.get_defaultTextFormat();
                a.size = this.size;
                this.set_defaultTextFormat(a);
                this.setTextFormat(a);
                return this.size
            },
            set_font: function(a) {
                this.font =
                    a;
                a = this.get_defaultTextFormat();
                var b = Y.getFont(this.font);
                a.font = b.get_fontName();
                this.set_defaultTextFormat(a);
                this.setTextFormat(a);
                this.embedFonts = !0;
                return this.font
            },
            setSystemFont: function() {
                var a = this.get_defaultTextFormat();
                a.bold = true;
                a.font = "_sans";
                this.set_defaultTextFormat(a);
                this.setTextFormat(a);
                this.embedFonts = !1
            },
            set_fieldWidth: function(a) {
                this.fieldWidth = a;
                this.set_autoSize(wa.NONE);
                this.set_width(this.fieldWidth);
                this.set_align(this.align);
                return this.fieldWidth
            },
            set_fieldHeight: function(a) {
                this.fieldHeight =
                    a;
                this.set_autoSize(wa.NONE);
                this.set_height(this.fieldHeight);
                this.set_align(this.align);
                return this.fieldWidth
            },
            set_align: function(a) {
                this.align = a;
                a = this.get_defaultTextFormat();
                switch (this.align) {
                    case "left":
                        a.align = Ea.LEFT;
                        break;
                    case "center":
                        a.align = Ea.CENTER;
                        break;
                    case "right":
                        a.align = Ea.RIGHT
                }
                this.set_defaultTextFormat(a);
                this.setTextFormat(a);
                return this.align
            },
            set_y: function(a) {
                Na.prototype.set_y.call(this, a);
                return a
            },
            __class__: xc,
            __properties__: t(Na.prototype.__properties__, {
                set_align: "set_align",
                set_fieldHeight: "set_fieldHeight",
                set_fieldWidth: "set_fieldWidth",
                set_font: "set_font",
                set_size: "set_size",
                set_color: "set_color"
            })
        });
        var Pb = function(a) {
            va.call(this);
            null != a && this.setGraph(a);
            this.init()
        };
        g["com.alagatar.ui.TileButton"] = Pb;
        Pb.__name__ = ["com", "alagatar", "ui", "TileButton"];
        Pb.__super__ = va;
        Pb.prototype = t(va.prototype, {
            setGraph: function(a) {
                this.graph = a;
                this.addTile(this.graph)
            },
            init: function() {
                this.hitConfig = null;
                this.mouseDown = !1;
                this.scaleChange = .9;
                this.alphaChange = .6;
                this.animInTime =
                    .2;
                this.animOutTime = .1;
                this.manualDisabled = this.paramsSet = !1;
                this.soundEffect = null;
                this.firstClick = this.manualStartAnim = this.activated = this.onlyFirstClick = this.animationWorking = !1;
                this.enabled = this.active = !0
            },
            setHitRect: function(a, b, c, d) {
                this.hitConfig = {
                    mode: 1,
                    x: a - c / 2,
                    y: b - d / 2,
                    w: c,
                    h: d
                }
            },
            onMouseDown: function(a) {
                if ((1 != this.onlyFirstClick || 1 != this.firstClick) && 0 != this.get_alpha() && 0 != this.get_visible() && 0 != this.active && 0 != this.enabled && 1 != this.manualDisabled && null != this.hitConfig) {
                    a = m.getMouseX();
                    var b =
                        m.getMouseY();
                    0 != this.hitTest(a, b) && (this.mouseDown = !0)
                }
            },
            hitTest: function(a, b) {
                return 1 == this.hitConfig.mode ? this.hitTestRect(a, b) : this.hitTestCirc(a, b)
            },
            hitTestRect: function(a, b) {
                var c = this.calcGlobalPos();
                return C.pointInsideRect(a, b, c.x + this.graph.x + this.hitConfig.x, c.y + this.graph.y + this.hitConfig.y, this.hitConfig.w, this.hitConfig.h)
            },
            hitTestCirc: function(a, b) {
                var c = this.calcGlobalPos();
                return C.pointInsideCirc(a, b, c.x + this.graph.x + this.hitConfig.x, c.y + this.graph.y + this.hitConfig.y, this.hitConfig.w)
            },
            onMouseUp: function(a) {
                if (0 != this.mouseDown && (this.mouseDown = !1, 0 != this.active && 0 != this.enabled && 1 != this.manualDisabled && 0 != this.get_alpha() && 0 != this.get_visible() && null != this.hitConfig && (1 != this.onlyFirstClick || 1 != this.firstClick))) {
                    var b = m.formatStageX(a.stageX);
                    a = m.formatStageY(a.stageY);
                    0 != this.hitTest(b, a) && (0 == this.paramsSet && (this.paramsSet = !0, this.initParams()), this.activated = !0, 0 == this.manualStartAnim && this.startAnim())
                }
            },
            initParams: function() {
                this.graphAlpha = this.get_alpha();
                this.graphScaleX =
                    this.get_scaleX();
                this.graphScaleY = this.get_scaleY()
            },
            startAnim: function() {
                1 == this.onlyFirstClick && (this.firstClick = !0);
                1 == this.manualStartAnim && (this.activated = !1);
                null != this.soundEffect && L.get_instance().playSound(this.soundEffect);
                this.animationWorking = !0;
                this.reset();
                this.alphaIn();
                this.dispatchEvent(new w("b_start", !0))
            },
            reset: function() {
                this.set_alpha(this.graphAlpha)
            },
            completeAnim: function() {
                this.animationWorking = !1;
                this.reset();
                this.dispatchEvent(new w("b_complete"))
            },
            alphaIn: function() {
                A.tween(this,
                    this.animInTime, {
                        alpha: this.graphAlpha * this.alphaChange
                    }).ease(Qb.get_easeInOut()).onComplete(r(this, this.alphaOut))
            },
            alphaOut: function() {
                A.tween(this, this.animOutTime, {
                    alpha: this.graphAlpha
                }).ease(qb.get_easeNone()).onComplete(r(this, this.completeAnim))
            },
            setSoundEffect: function(a) {
                this.soundEffect = a
            },
            free: function() {
                va.prototype.free.call(this);
                this.graph.destroyToCache();
                this.hitConfig = this.graph = null
            },
            __class__: Pb
        });
        var dd = function() {
            y.call(this);
            this.init()
        };
        g["com.alagatar.ui.UiLayer"] = dd;
        dd.__name__ = ["com", "alagatar", "ui", "UiLayer"];
        dd.__super__ = y;
        dd.prototype = t(y.prototype, {
            init: function() {
                this.items = [];
                S.current.stage.addEventListener(D.MOUSE_DOWN, r(this, this.onMouseDown));
                S.current.stage.addEventListener(D.MOUSE_UP, r(this, this.onMouseUp));
                S.current.stage.addEventListener(D.MOUSE_MOVE, r(this, this.onMouseMove))
            },
            onMouseDown: function(a) {
                for (var b = 0, c = this.items.length; b < c;) {
                    var d = b++;
                    this.items[d].onMouseDown(a)
                }
            },
            onMouseUp: function(a) {
                for (var b = 0, c = this.items.length; b < c;) {
                    var d = b++;
                    this.items[d].onMouseUp(a)
                }
            },
            onMouseMove: function(a) {
                for (var b = 0, c = this.items.length; b < c;) {
                    var d = b++;
                    this.items[d].onMouseMove(a)
                }
            },
            add: function(a) {
                this.items.push(a)
            },
            free: function() {
                S.current.stage.removeEventListener(D.MOUSE_DOWN, r(this, this.onMouseDown));
                S.current.stage.removeEventListener(D.MOUSE_UP, r(this, this.onMouseUp));
                S.current.stage.removeEventListener(D.MOUSE_MOVE, r(this, this.onMouseMove));
                this.items = [];
                this.items = null
            },
            __class__: dd
        });
        var Te = function() {
            this.cleanable = !1;
            this.cleanable = !0
        };
        g["components.Block"] = Te;
        Te.__name__ = ["components", "Block"];
        Te.__super__ = ya;
        Te.prototype = t(ya.prototype, {
            __class__: Te
        });
        var Jb = function() {};
        g["components.Coin"] = Jb;
        Jb.__name__ = ["components", "Coin"];
        Jb.__super__ = ya;
        Jb.prototype = t(ya.prototype, {
            __class__: Jb
        });
        var Kb = function() {};
        g["components.Collider"] = Kb;
        Kb.__name__ = ["components", "Collider"];
        Kb.__super__ = ya;
        Kb.prototype = t(ya.prototype, {
            __class__: Kb
        });
        var Sa = function() {};
        g["components.Hero"] = Sa;
        Sa.__name__ = ["components", "Hero"];
        Sa.__super__ = ya;
        Sa.prototype = t(ya.prototype, {
            __class__: Sa
        });
        var yc = function() {};
        g["components.Particle"] = yc;
        yc.__name__ = ["components", "Particle"];
        yc.__super__ = ya;
        yc.prototype = t(ya.prototype, {
            __class__: yc
        });
        var ca = function() {};
        g["components.Path"] = ca;
        ca.__name__ = ["components", "Path"];
        ca.__super__ = ya;
        ca.prototype = t(ya.prototype, {
            __class__: ca
        });
        var bb = function() {};
        g["components.Position"] = bb;
        bb.__name__ = ["components", "Position"];
        bb.__super__ = ya;
        bb.prototype = t(ya.prototype, {
            __class__: bb
        });
        var fc = function() {};
        g["components.RigidBody"] = fc;
        fc.__name__ = ["components", "RigidBody"];
        fc.__super__ = ya;
        fc.prototype = t(ya.prototype, {
            __class__: fc
        });
        var Ue = function() {
            this.cleanable = !1;
            this.cleanable = !0
        };
        g["components.Tile"] = Ue;
        Ue.__name__ = ["components", "Tile"];
        Ue.__super__ = ya;
        Ue.prototype = t(ya.prototype, {
            __class__: Ue
        });
        var gc = function() {};
        g["components.Velocity"] = gc;
        gc.__name__ = ["components", "Velocity"];
        gc.__super__ = ya;
        gc.prototype = t(ya.prototype, {
            __class__: gc
        });
        var mb = function() {};
        g["components.Wall"] = mb;
        mb.__name__ = ["components", "Wall"];
        mb.__super__ = ya;
        mb.prototype =
            t(ya.prototype, {
                __class__: mb
            });
        var Yb = function() {};
        g["haxe.Resource"] = Yb;
        Yb.__name__ = ["haxe", "Resource"];
        Yb.content = null;
        Yb.getString = function(a) {
            for (var b = 0, c = Yb.content; b < c.length;) {
                var d = c[b];
                ++b;
                if (d.name == a) return null != d.str ? d.str : Hc.decode(d.data).toString()
            }
            return null
        };
        var Cb = function() {
            this.buf = new pc;
            this.cache = [];
            this.useCache = Cb.USE_CACHE;
            this.useEnumIndex = Cb.USE_ENUM_INDEX;
            this.shash = new pa;
            this.scount = 0
        };
        g["haxe.Serializer"] = Cb;
        Cb.__name__ = ["haxe", "Serializer"];
        Cb.run = function(a) {
            var b =
                new Cb;
            b.serialize(a);
            return b.toString()
        };
        Cb.prototype = {
            toString: function() {
                return this.buf.b
            },
            serializeString: function(a) {
                var b = this.shash.get(a);
                null != b ? (this.buf.b += "R", this.buf.b = null == b ? this.buf.b + "null" : this.buf.b + ("" + b)) : (this.shash.set(a, this.scount++), this.buf.b += "y", a = encodeURIComponent(a), this.buf.b = null == a.length ? this.buf.b + "null" : this.buf.b + ("" + a.length), this.buf.b += ":", this.buf.b = null == a ? this.buf.b + "null" : this.buf.b + ("" + a))
            },
            serializeRef: function(a) {
                for (var b = typeof a, c = 0, d = this.cache.length; c <
                    d;) {
                    var e = c++,
                        f = this.cache[e];
                    if (typeof f == b && f == a) return this.buf.b += "r", this.buf.b = null == e ? this.buf.b + "null" : this.buf.b + ("" + e), !0
                }
                this.cache.push(a);
                return !1
            },
            serializeFields: function(a) {
                for (var b = 0, c = z.fields(a); b < c.length;) {
                    var d = c[b];
                    ++b;
                    this.serializeString(d);
                    this.serialize(z.field(a, d))
                }
                this.buf.b += "g"
            },
            serialize: function(a) {
                var b = O["typeof"](a);
                switch (b[1]) {
                    case 0:
                        this.buf.b += "n";
                        break;
                    case 1:
                        if (0 == a) {
                            this.buf.b += "z";
                            break
                        }
                        this.buf.b += "i";
                        this.buf.b = null == a ? this.buf.b + "null" : this.buf.b + ("" +
                            a);
                        break;
                    case 2:
                        Math.isNaN(a) ? this.buf.b += "k" : Math.isFinite(a) ? (this.buf.b += "d", this.buf.b = null == a ? this.buf.b + "null" : this.buf.b + ("" + a)) : this.buf.b = 0 > a ? this.buf.b + "m" : this.buf.b + "p";
                        break;
                    case 3:
                        this.buf.b = a ? this.buf.b + "t" : this.buf.b + "f";
                        break;
                    case 6:
                        b = b[2];
                        if (b == String) {
                            this.serializeString(a);
                            break
                        }
                        if (this.useCache && this.serializeRef(a)) break;
                        switch (b) {
                            case Array:
                                b = 0;
                                this.buf.b += "a";
                                for (var c = a.length, d = 0; d < c;) {
                                    var e = d++;
                                    null == a[e] ? b++ : (0 < b && (1 == b ? this.buf.b += "n" : (this.buf.b += "u", this.buf.b = null ==
                                        b ? this.buf.b + "null" : this.buf.b + ("" + b)), b = 0), this.serialize(a[e]))
                                }
                                0 < b && (1 == b ? this.buf.b += "n" : (this.buf.b += "u", this.buf.b = null == b ? this.buf.b + "null" : this.buf.b + ("" + b)));
                                this.buf.b += "h";
                                break;
                            case Wc:
                                this.buf.b += "l";
                                for (a = a.iterator(); a.hasNext();) b = a.next(), this.serialize(b);
                                this.buf.b += "h";
                                break;
                            case Date:
                                this.buf.b += "v";
                                this.buf.add(u.dateStr(a));
                                break;
                            case pa:
                                this.buf.b += "b";
                                for (b = a.keys(); b.hasNext();) c = b.next(), this.serializeString(c), this.serialize(a.get(c));
                                this.buf.b += "h";
                                break;
                            case ed:
                                this.buf.b +=
                                    "q";
                                for (b = a.keys(); b.hasNext();) c = b.next(), this.buf.b += ":", this.buf.b = null == c ? this.buf.b + "null" : this.buf.b + ("" + c), this.serialize(a.get(c));
                                this.buf.b += "h";
                                break;
                            case hc:
                                this.buf.b += "M";
                                for (b = a.keys(); b.hasNext();) c = b.next(), d = z.field(c, "__id__"), z.deleteField(c, "__id__"), this.serialize(c), c.__id__ = d, this.serialize(a.h[c.__id__]);
                                this.buf.b += "h";
                                break;
                            case Db:
                                d = 0;
                                e = a.length - 2;
                                b = new pc;
                                for (c = Cb.BASE64; d < e;) {
                                    var f = a.get(d++),
                                        l = a.get(d++),
                                        E = a.get(d++);
                                    b.add(c.charAt(f >> 2));
                                    b.add(c.charAt((f << 4 | l >> 4) &
                                        63));
                                    b.add(c.charAt((l << 2 | E >> 6) & 63));
                                    b.add(c.charAt(E & 63))
                                }
                                d == e ? (e = a.get(d++), a = a.get(d++), b.add(c.charAt(e >> 2)), b.add(c.charAt((e << 4 | a >> 4) & 63)), b.add(c.charAt(a << 2 & 63))) : d == e + 1 && (a = a.get(d++), b.add(c.charAt(a >> 2)), b.add(c.charAt(a << 4 & 63)));
                                a = b.b;
                                this.buf.b += "s";
                                this.buf.b = null == a.length ? this.buf.b + "null" : this.buf.b + ("" + a.length);
                                this.buf.b += ":";
                                this.buf.b = null == a ? this.buf.b + "null" : this.buf.b + ("" + a);
                                break;
                            default:
                                this.useCache && this.cache.pop(), null != a.hxSerialize ? (this.buf.b += "C", this.serializeString(O.getClassName(b)),
                                    this.useCache && this.cache.push(a), a.hxSerialize(this), this.buf.b += "g") : (this.buf.b += "c", this.serializeString(O.getClassName(b)), this.useCache && this.cache.push(a), this.serializeFields(a))
                        }
                        break;
                    case 4:
                        if (this.useCache && this.serializeRef(a)) break;
                        this.buf.b += "o";
                        this.serializeFields(a);
                        break;
                    case 7:
                        b = b[2];
                        if (this.useCache) {
                            if (this.serializeRef(a)) break;
                            this.cache.pop()
                        }
                        this.buf.b = this.useEnumIndex ? this.buf.b + "j" : this.buf.b + "w";
                        this.serializeString(O.getEnumName(b));
                        this.useEnumIndex ? (this.buf.b += ":",
                            this.buf.b += v.string(a[1])) : this.serializeString(a[0]);
                        this.buf.b += ":";
                        b = a.length;
                        this.buf.b += v.string(b - 2);
                        for (c = 2; c < b;) d = c++, this.serialize(a[d]);
                        this.useCache && this.cache.push(a);
                        break;
                    case 5:
                        throw "Cannot serialize function";
                    default:
                        throw "Cannot serialize " + v.string(a);
                }
            },
            __class__: Cb
        };
        var tc = function(a) {
            var b = this;
            this.id = setInterval(function() {
                b.run()
            }, a)
        };
        g["haxe.Timer"] = tc;
        tc.__name__ = ["haxe", "Timer"];
        tc.delay = function(a, b) {
            var c = new tc(b);
            c.run = function() {
                c.stop();
                a()
            };
            return c
        };
        tc.stamp =
            function() {
                return (new Date).getTime() / 1E3
            };
        tc.prototype = {
            stop: function() {
                null != this.id && (clearInterval(this.id), this.id = null)
            },
            run: function() {},
            __class__: tc
        };
        var cb = function(a) {
            this.buf = a;
            this.length = a.length;
            this.pos = 0;
            this.scache = [];
            this.cache = [];
            a = cb.DEFAULT_RESOLVER;
            null == a && (a = O, cb.DEFAULT_RESOLVER = a);
            this.setResolver(a)
        };
        g["haxe.Unserializer"] = cb;
        cb.__name__ = ["haxe", "Unserializer"];
        cb.initCodes = function() {
            for (var a = [], b = 0, c = cb.BASE64.length; b < c;) {
                var d = b++;
                a[cb.BASE64.charCodeAt(d)] = d
            }
            return a
        };
        cb.prototype = {
            setResolver: function(a) {
                this.resolver = null == a ? {
                    resolveClass: function(a) {
                        return null
                    },
                    resolveEnum: function(a) {
                        return null
                    }
                } : a
            },
            get: function(a) {
                return this.buf.charCodeAt(a)
            },
            readDigits: function() {
                for (var a = 0, b = !1, c = this.pos;;) {
                    var d = this.buf.charCodeAt(this.pos);
                    if (d != d) break;
                    if (45 == d) {
                        if (this.pos != c) break;
                        b = !0
                    } else {
                        if (48 > d || 57 < d) break;
                        a = 10 * a + (d - 48)
                    }
                    this.pos++
                }
                b && (a *= -1);
                return a
            },
            unserializeObject: function(a) {
                for (;;) {
                    if (this.pos >= this.length) throw "Invalid object";
                    if (103 == this.buf.charCodeAt(this.pos)) break;
                    var b = this.unserialize();
                    if ("string" != typeof b) throw "Invalid object key";
                    var c = this.unserialize();
                    a[b] = c
                }
                this.pos++
            },
            unserializeEnum: function(a, b) {
                if (58 != this.get(this.pos++)) throw "Invalid enum format";
                var c = this.readDigits();
                if (0 == c) return O.createEnum(a, b);
                for (var d = []; 0 < c--;) d.push(this.unserialize());
                return O.createEnum(a, b, d)
            },
            unserialize: function() {
                switch (this.get(this.pos++)) {
                    case 110:
                        return null;
                    case 116:
                        return !0;
                    case 102:
                        return !1;
                    case 122:
                        return 0;
                    case 105:
                        return this.readDigits();
                    case 100:
                        for (var a =
                                this.pos;;) {
                            var b = this.buf.charCodeAt(this.pos);
                            if (43 <= b && 58 > b || 101 == b || 69 == b) this.pos++;
                            else break
                        }
                        return v.parseFloat(u.substr(this.buf, a, this.pos - a));
                    case 121:
                        a = this.readDigits();
                        if (58 != this.get(this.pos++) || this.length - this.pos < a) throw "Invalid string length";
                        b = u.substr(this.buf, this.pos, a);
                        this.pos += a;
                        b = decodeURIComponent(b.split("+").join(" "));
                        this.scache.push(b);
                        return b;
                    case 107:
                        return Math.NaN;
                    case 109:
                        return Math.NEGATIVE_INFINITY;
                    case 112:
                        return Math.POSITIVE_INFINITY;
                    case 97:
                        a = [];
                        for (this.cache.push(a);;) {
                            b =
                                this.buf.charCodeAt(this.pos);
                            if (104 == b) {
                                this.pos++;
                                break
                            }
                            117 == b ? (this.pos++, b = this.readDigits(), a[a.length + b - 1] = null) : a.push(this.unserialize())
                        }
                        return a;
                    case 111:
                        return a = {}, this.cache.push(a), this.unserializeObject(a), a;
                    case 114:
                        a = this.readDigits();
                        if (0 > a || a >= this.cache.length) throw "Invalid reference";
                        return this.cache[a];
                    case 82:
                        a = this.readDigits();
                        if (0 > a || a >= this.scache.length) throw "Invalid string reference";
                        return this.scache[a];
                    case 120:
                        throw this.unserialize();
                    case 99:
                        a = this.unserialize();
                        b = this.resolver.resolveClass(a);
                        if (null == b) throw "Class not found " + a;
                        a = O.createEmptyInstance(b);
                        this.cache.push(a);
                        this.unserializeObject(a);
                        return a;
                    case 119:
                        a = this.unserialize();
                        b = this.resolver.resolveEnum(a);
                        if (null == b) throw "Enum not found " + a;
                        a = this.unserializeEnum(b, this.unserialize());
                        this.cache.push(a);
                        return a;
                    case 106:
                        a = this.unserialize();
                        b = this.resolver.resolveEnum(a);
                        if (null == b) throw "Enum not found " + a;
                        this.pos++;
                        var c = this.readDigits(),
                            d = O.getEnumConstructs(b)[c];
                        if (null == d) throw "Unknown enum index " +
                            a + "@" + c;
                        a = this.unserializeEnum(b, d);
                        this.cache.push(a);
                        return a;
                    case 108:
                        a = new Wc;
                        for (this.cache.push(a); 104 != this.buf.charCodeAt(this.pos);) a.add(this.unserialize());
                        this.pos++;
                        return a;
                    case 98:
                        a = new pa;
                        for (this.cache.push(a); 104 != this.buf.charCodeAt(this.pos);) b = this.unserialize(), a.set(b, this.unserialize());
                        this.pos++;
                        return a;
                    case 113:
                        a = new ed;
                        this.cache.push(a);
                        for (b = this.get(this.pos++); 58 == b;) b = this.readDigits(), a.set(b, this.unserialize()), b = this.get(this.pos++);
                        if (104 != b) throw "Invalid IntMap format";
                        return a;
                    case 77:
                        a = new hc;
                        for (this.cache.push(a); 104 != this.buf.charCodeAt(this.pos);) b = this.unserialize(), a.set(b, this.unserialize());
                        this.pos++;
                        return a;
                    case 118:
                        return a = u.substr(this.buf, this.pos, 19), a = u.strDate(a), this.cache.push(a), this.pos += 19, a;
                    case 115:
                        a = this.readDigits();
                        d = this.buf;
                        if (58 != this.get(this.pos++) || this.length - this.pos < a) throw "Invalid bytes length";
                        var e = cb.CODES;
                        null == e && (e = cb.initCodes(), cb.CODES = e);
                        for (var f = this.pos, l = a & 3, E = f + (a - l), b = Db.alloc(3 * (a >> 2) + (2 <= l ? l - 1 : 0)), c = 0; f <
                            E;) {
                            var g = e[M.fastCodeAt(d, f++)],
                                h = e[M.fastCodeAt(d, f++)];
                            b.set(c++, g << 2 | h >> 4);
                            g = e[M.fastCodeAt(d, f++)];
                            b.set(c++, h << 4 | g >> 2);
                            h = e[M.fastCodeAt(d, f++)];
                            b.set(c++, g << 6 | h)
                        }
                        2 <= l && (h = e[M.fastCodeAt(d, f++)], E = e[M.fastCodeAt(d, f++)], b.set(c++, h << 2 | E >> 4), 3 == l && (d = e[M.fastCodeAt(d, f++)], b.set(c++, E << 4 | d >> 2)));
                        this.pos += a;
                        this.cache.push(b);
                        return b;
                    case 67:
                        a = this.unserialize();
                        b = this.resolver.resolveClass(a);
                        if (null == b) throw "Class not found " + a;
                        a = O.createEmptyInstance(b);
                        this.cache.push(a);
                        a.hxUnserialize(this);
                        if (103 != this.get(this.pos++)) throw "Invalid custom data";
                        return a
                }
                this.pos--;
                throw "Invalid char " + this.buf.charAt(this.pos) + " at position " + this.pos;
            },
            __class__: cb
        };
        var Ve = function(a) {
            this.__b = ""
        };
        g["haxe.Utf8"] = Ve;
        Ve.__name__ = ["haxe", "Utf8"];
        Ve.prototype = {
            __class__: Ve
        };
        var Db = function(a, b) {
            this.length = a;
            this.b = b
        };
        g["haxe.io.Bytes"] = Db;
        Db.__name__ = ["haxe", "io", "Bytes"];
        Db.alloc = function(a) {
            for (var b = [], c = 0; c < a;) c++, b.push(0);
            return new Db(a, b)
        };
        Db.ofString = function(a) {
            for (var b = [], c = 0; c < a.length;) {
                var d =
                    M.fastCodeAt(a, c++);
                55296 <= d && 56319 >= d && (d = d - 55232 << 10 | M.fastCodeAt(a, c++) & 1023);
                127 >= d ? b.push(d) : (2047 >= d ? b.push(192 | d >> 6) : (65535 >= d ? b.push(224 | d >> 12) : (b.push(240 | d >> 18), b.push(128 | d >> 12 & 63)), b.push(128 | d >> 6 & 63)), b.push(128 | d & 63))
            }
            return new Db(b.length, b)
        };
        Db.prototype = {
            get: function(a) {
                return this.b[a]
            },
            set: function(a, b) {
                this.b[a] = b & 255
            },
            getString: function(a, b) {
                if (0 > a || 0 > b || a + b > this.length) throw nb.OutsideBounds;
                for (var c = "", d = this.b, e = String.fromCharCode, f = a, l = a + b; f < l;) {
                    var E = d[f++];
                    if (128 > E) {
                        if (0 ==
                            E) break;
                        c += e(E)
                    } else if (224 > E) c += e((E & 63) << 6 | d[f++] & 127);
                    else if (240 > E) var g = d[f++],
                        c = c + e((E & 31) << 12 | (g & 127) << 6 | d[f++] & 127);
                    else var g = d[f++],
                        h = d[f++],
                        E = (E & 15) << 18 | (g & 127) << 12 | (h & 127) << 6 | d[f++] & 127,
                        c = c + e((E >> 10) + 55232),
                        c = c + e(E & 1023 | 56320)
                }
                return c
            },
            toString: function() {
                return this.getString(0, this.length)
            },
            __class__: Db
        };
        var Hc = function() {};
        g["haxe.crypto.Base64"] = Hc;
        Hc.__name__ = ["haxe", "crypto", "Base64"];
        Hc.decode = function(a, b) {
            null == b && (b = !0);
            if (b)
                for (; 61 == u.cca(a, a.length - 1);) a = u.substr(a, 0, -1);
            return (new We(Hc.BYTES)).decodeBytes(Db.ofString(a))
        };
        var We = function(a) {
            for (var b = a.length, c = 1; b > 1 << c;) c++;
            if (8 < c || b != 1 << c) throw "BaseCode : base length must be a power of two.";
            this.base = a;
            this.nbits = c
        };
        g["haxe.crypto.BaseCode"] = We;
        We.__name__ = ["haxe", "crypto", "BaseCode"];
        We.prototype = {
            initTable: function() {
                for (var a = [], b = 0; 256 > b;) {
                    var c = b++;
                    a[c] = -1
                }
                b = 0;
                for (c = this.base.length; b < c;) {
                    var d = b++;
                    a[this.base.b[d]] = d
                }
                this.tbl = a
            },
            decodeBytes: function(a) {
                var b = this.nbits;
                null == this.tbl && this.initTable();
                for (var c = this.tbl, d = a.length * b >> 3, e = Db.alloc(d), f = 0, l = 0, E = 0, g = 0; g < d;) {
                    for (; 8 > l;) {
                        var l = l + b,
                            f = f << b,
                            h = c[a.get(E++)];
                        if (-1 == h) throw "BaseCode : invalid encoded char";
                        f |= h
                    }
                    l -= 8;
                    e.set(g++, f >> l & 255)
                }
                return e
            },
            __class__: We
        };
        var Ld = function() {};
        g["haxe.ds.BalancedTree"] = Ld;
        Ld.__name__ = ["haxe", "ds", "BalancedTree"];
        Ld.prototype = {
            set: function(a, b) {
                this.root = this.setLoop(a, b, this.root)
            },
            get: function(a) {
                for (var b = this.root; null != b;) {
                    var c = this.compare(a, b.key);
                    if (0 == c) return b.value;
                    b = 0 > c ? b.left : b.right
                }
                return null
            },
            setLoop: function(a, b, c) {
                if (null == c) return new Wa(null, a, b, null);
                var d = this.compare(a, c.key);
                if (0 == d) return new Wa(c.left, a, b, c.right, null == c ? 0 : c._height);
                if (0 > d) return a = this.setLoop(a, b, c.left), this.balance(a, c.key, c.value, c.right);
                a = this.setLoop(a, b, c.right);
                return this.balance(c.left, c.key, c.value, a)
            },
            balance: function(a, b, c, d) {
                var e;
                e = null == a ? 0 : a._height;
                var f;
                f = null == d ? 0 : d._height;
                return e > f + 2 ? function(b) {
                        b = a.left;
                        return null == b ? 0 : b._height
                    }(this) >= function(b) {
                        b = a.right;
                        return null == b ? 0 : b._height
                    }(this) ?
                    new Wa(a.left, a.key, a.value, new Wa(a.right, b, c, d)) : new Wa(new Wa(a.left, a.key, a.value, a.right.left), a.right.key, a.right.value, new Wa(a.right.right, b, c, d)) : f > e + 2 ? function(a) {
                        a = d.right;
                        return null == a ? 0 : a._height
                    }(this) > function(a) {
                        a = d.left;
                        return null == a ? 0 : a._height
                    }(this) ? new Wa(new Wa(a, b, c, d.left), d.key, d.value, d.right) : new Wa(new Wa(a, b, c, d.left.left), d.left.key, d.left.value, new Wa(d.left.right, d.key, d.value, d.right)) : new Wa(a, b, c, d, (e > f ? e : f) + 1)
            },
            compare: function(a, b) {
                return z.compare(a, b)
            },
            __class__: Ld
        };
        var Wa = function(a, b, c, d, e) {
            null == e && (e = -1);
            this.left = a;
            this.key = b;
            this.value = c;
            this.right = d;
            this._height = -1 == e ? (function(a) {
                a = a.left;
                return null == a ? 0 : a._height
            }(this) > function(a) {
                a = a.right;
                return null == a ? 0 : a._height
            }(this) ? function(a) {
                a = a.left;
                return null == a ? 0 : a._height
            }(this) : function(a) {
                a = a.right;
                return null == a ? 0 : a._height
            }(this)) + 1 : e
        };
        g["haxe.ds.TreeNode"] = Wa;
        Wa.__name__ = ["haxe", "ds", "TreeNode"];
        Wa.prototype = {
            __class__: Wa
        };
        var fd = function() {};
        g["haxe.ds.EnumValueMap"] = fd;
        fd.__name__ = ["haxe", "ds",
            "EnumValueMap"
        ];
        fd.__interfaces__ = [Fd];
        fd.__super__ = Ld;
        fd.prototype = t(Ld.prototype, {
            compare: function(a, b) {
                var c = a[1] - b[1];
                if (0 != c) return c;
                var c = a.slice(2),
                    d = b.slice(2);
                return 0 == c.length && 0 == d.length ? 0 : this.compareArgs(c, d)
            },
            compareArgs: function(a, b) {
                var c = a.length - b.length;
                if (0 != c) return c;
                for (var c = 0, d = a.length; c < d;) {
                    var e = c++,
                        e = this.compareArg(a[e], b[e]);
                    if (0 != e) return e
                }
                return 0
            },
            compareArg: function(a, b) {
                return z.isEnumValue(a) && z.isEnumValue(b) ? this.compare(a, b) : a instanceof Array && null == a.__enum__ &&
                    b instanceof Array && null == b.__enum__ ? this.compareArgs(a, b) : z.compare(a, b)
            },
            __class__: fd
        });
        var ed = function() {
            this.h = {}
        };
        g["haxe.ds.IntMap"] = ed;
        ed.__name__ = ["haxe", "ds", "IntMap"];
        ed.__interfaces__ = [Fd];
        ed.prototype = {
            set: function(a, b) {
                this.h[a] = b
            },
            get: function(a) {
                return this.h[a]
            },
            keys: function() {
                var a = [],
                    b;
                for (b in this.h) this.h.hasOwnProperty(b) && a.push(b | 0);
                return u.iter(a)
            },
            __class__: ed
        };
        var hc = function() {
            this.h = {};
            this.h.__keys__ = {}
        };
        g["haxe.ds.ObjectMap"] = hc;
        hc.__name__ = ["haxe", "ds", "ObjectMap"];
        hc.__interfaces__ = [Fd];
        hc.prototype = {
            set: function(a, b) {
                var c = a.__id__ || (a.__id__ = ++hc.count);
                this.h[c] = b;
                this.h.__keys__[c] = a
            },
            remove: function(a) {
                a = a.__id__;
                if (null == this.h.__keys__[a]) return !1;
                delete this.h[a];
                delete this.h.__keys__[a];
                return !0
            },
            keys: function() {
                var a = [],
                    b;
                for (b in this.h.__keys__) this.h.hasOwnProperty(b) && a.push(this.h.__keys__[b]);
                return u.iter(a)
            },
            iterator: function() {
                return {
                    ref: this.h,
                    it: this.keys(),
                    hasNext: function() {
                        return this.it.hasNext()
                    },
                    next: function() {
                        var a = this.it.next();
                        return this.ref[a.__id__]
                    }
                }
            },
            __class__: hc
        };
        var pa = function() {
            this.h = {}
        };
        g["haxe.ds.StringMap"] = pa;
        pa.__name__ = ["haxe", "ds", "StringMap"];
        pa.__interfaces__ = [Fd];
        pa.prototype = {
            set: function(a, b) {
                this.h["$" + a] = b
            },
            get: function(a) {
                return this.h["$" + a]
            },
            exists: function(a) {
                return this.h.hasOwnProperty("$" + a)
            },
            remove: function(a) {
                a = "$" + a;
                if (!this.h.hasOwnProperty(a)) return !1;
                delete this.h[a];
                return !0
            },
            keys: function() {
                var a = [],
                    b;
                for (b in this.h) this.h.hasOwnProperty(b) && a.push(b.substr(1));
                return u.iter(a)
            },
            iterator: function() {
                return {
                    ref: this.h,
                    it: this.keys(),
                    hasNext: function() {
                        return this.it.hasNext()
                    },
                    next: function() {
                        var a = this.it.next();
                        return this.ref["$" + a]
                    }
                }
            },
            __class__: pa
        };
        var ab = function() {};
        g["haxe.ds._Vector.Vector_Impl_"] = ab;
        ab.__name__ = ["haxe", "ds", "_Vector", "Vector_Impl_"];
        ab.blit = function(a, b, c, d, e) {
            for (var f = 0; f < e;) {
                var l = f++;
                c[d + l] = a[b + l]
            }
        };
        var Nf = function() {};
        g["haxe.io.Eof"] = Nf;
        Nf.__name__ = ["haxe", "io", "Eof"];
        Nf.prototype = {
            toString: function() {
                return "Eof"
            },
            __class__: Nf
        };
        var nb = g["haxe.io.Error"] = {
            __ename__: ["haxe", "io", "Error"],
            __constructs__: ["Blocked", "Overflow", "OutsideBounds", "Custom"]
        };
        nb.Blocked = ["Blocked", 0];
        nb.Blocked.toString = p;
        nb.Blocked.__enum__ = nb;
        nb.Overflow = ["Overflow", 1];
        nb.Overflow.toString = p;
        nb.Overflow.__enum__ = nb;
        nb.OutsideBounds = ["OutsideBounds", 2];
        nb.OutsideBounds.toString = p;
        nb.OutsideBounds.__enum__ = nb;
        nb.Custom = function(a) {
            a = ["Custom", 3, a];
            a.__enum__ = nb;
            a.toString = p;
            return a
        };
        var Ic = function(a) {
            var b = a.lastIndexOf("http://games.softgames.de/"),
                c = a.lastIndexOf("\\");
            b < c ? (this.dir = u.substr(a,
                0, c), a = u.substr(a, c + 1, null), this.backslash = !0) : c < b ? (this.dir = u.substr(a, 0, b), a = u.substr(a, b + 1, null)) : this.dir = null;
            b = a.lastIndexOf("."); - 1 != b ? (this.ext = u.substr(a, b + 1, null), this.file = u.substr(a, 0, b)) : (this.ext = null, this.file = a)
        };
        g["haxe.io.Path"] = Ic;
        Ic.__name__ = ["haxe", "io", "Path"];
        Ic.withoutExtension = function(a) {
            a = new Ic(a);
            a.ext = null;
            return a.toString()
        };
        Ic.prototype = {
            toString: function() {
                return (null == this.dir ? "" : this.dir + (this.backslash ? "\\" : "/")) + this.file + (null == this.ext ? "" : "." + this.ext)
            },
            __class__: Ic
        };
        var Xe = function(a) {
            this.__x = a
        };
        g["haxe.xml._Fast.NodeAccess"] = Xe;
        Xe.__name__ = ["haxe", "xml", "_Fast", "NodeAccess"];
        Xe.prototype = {
            __class__: Xe
        };
        var Ye = function(a) {
            this.__x = a
        };
        g["haxe.xml._Fast.AttribAccess"] = Ye;
        Ye.__name__ = ["haxe", "xml", "_Fast", "AttribAccess"];
        Ye.prototype = {
            resolve: function(a) {
                if (this.__x.nodeType == I.Document) throw "Cannot access document attribute " + a;
                var b = this.__x.get(a);
                if (null == b) throw this.__x.get_nodeName() + " is missing attribute " + a;
                return b
            },
            __class__: Ye
        };
        var Ze = function(a) {
            this.__x =
                a
        };
        g["haxe.xml._Fast.HasAttribAccess"] = Ze;
        Ze.__name__ = ["haxe", "xml", "_Fast", "HasAttribAccess"];
        Ze.prototype = {
            resolve: function(a) {
                if (this.__x.nodeType == I.Document) throw "Cannot access document attribute " + a;
                return this.__x.exists(a)
            },
            __class__: Ze
        };
        var $e = function(a) {
            this.__x = a
        };
        g["haxe.xml._Fast.HasNodeAccess"] = $e;
        $e.__name__ = ["haxe", "xml", "_Fast", "HasNodeAccess"];
        $e.prototype = {
            __class__: $e
        };
        var af = function(a) {
            this.__x = a
        };
        g["haxe.xml._Fast.NodeListAccess"] = af;
        af.__name__ = ["haxe", "xml", "_Fast", "NodeListAccess"];
        af.prototype = {
            resolve: function(a) {
                var b = new Wc;
                for (a = this.__x.elementsNamed(a); a.hasNext();) {
                    var c = a.next();
                    b.add(new Yc(c))
                }
                return b
            },
            __class__: af
        };
        var Yc = function(a) {
            if (a.nodeType != I.Document && a.nodeType != I.Element) throw "Invalid nodeType " + v.string(a.nodeType);
            this.x = a;
            this.node = new Xe(a);
            this.nodes = new af(a);
            this.att = new Ye(a);
            this.has = new Ze(a);
            this.hasNode = new $e(a)
        };
        g["haxe.xml.Fast"] = Yc;
        Yc.__name__ = ["haxe", "xml", "Fast"];
        Yc.prototype = {
            __class__: Yc
        };
        var ac = function() {};
        g["haxe.xml.Parser"] = ac;
        ac.__name__ = ["haxe", "xml", "Parser"];
        ac.parse = function(a) {
            var b = I.createDocument();
            ac.doParse(a, 0, b);
            return b
        };
        ac.doParse = function(a, b, c) {
            null == b && (b = 0);
            for (var d = null, e = 1, f = 1, l = null, E = 0, g = 0, h = 0, q = a.charCodeAt(b), k = new pc; q == q;) {
                switch (e) {
                    case 0:
                        switch (q) {
                            case 10:
                            case 13:
                            case 9:
                            case 32:
                                break;
                            default:
                                e = f;
                                continue
                        }
                        break;
                    case 1:
                        switch (q) {
                            case 60:
                                e = 0;
                                f = 2;
                                break;
                            default:
                                E = b;
                                e = 13;
                                continue
                        }
                        break;
                    case 13:
                        60 == q ? (f = I.createPCData(k.b + u.substr(a, E, b - E)), k = new pc, c.addChild(f), g++, e = 0, f = 2) : 38 == q && (k.addSub(a, E,
                            b - E), e = 18, f = 13, E = b + 1);
                        break;
                    case 17:
                        93 == q && 93 == a.charCodeAt(b + 1) && 62 == a.charCodeAt(b + 2) && (e = I.createCData(u.substr(a, E, b - E)), c.addChild(e), g++, b += 2, e = 1);
                        break;
                    case 2:
                        switch (q) {
                            case 33:
                                if (91 == a.charCodeAt(b + 1)) {
                                    b += 2;
                                    if ("CDATA[" != u.substr(a, b, 6).toUpperCase()) throw "Expected <![CDATA[";
                                    b += 5;
                                    e = 17
                                } else if (68 == a.charCodeAt(b + 1) || 100 == a.charCodeAt(b + 1)) {
                                    if ("OCTYPE" != u.substr(a, b + 2, 6).toUpperCase()) throw "Expected <!DOCTYPE";
                                    b += 8;
                                    e = 16
                                } else {
                                    if (45 != a.charCodeAt(b + 1) || 45 != a.charCodeAt(b + 2)) throw "Expected \x3c!--";
                                    b += 2;
                                    e = 15
                                }
                                E = b + 1;
                                break;
                            case 63:
                                e = 14;
                                E = b;
                                break;
                            case 47:
                                if (null == c) throw "Expected node name";
                                E = b + 1;
                                e = 0;
                                f = 10;
                                break;
                            default:
                                e = 3;
                                E = b;
                                continue
                        }
                        break;
                    case 3:
                        if (!(97 <= q && 122 >= q || 65 <= q && 90 >= q || 48 <= q && 57 >= q || 58 == q || 46 == q || 95 == q || 45 == q)) {
                            if (b == E) throw "Expected node name";
                            d = I.createElement(u.substr(a, E, b - E));
                            c.addChild(d);
                            e = 0;
                            f = 4;
                            continue
                        }
                        break;
                    case 4:
                        switch (q) {
                            case 47:
                                e = 11;
                                g++;
                                break;
                            case 62:
                                e = 9;
                                g++;
                                break;
                            default:
                                e = 5;
                                E = b;
                                continue
                        }
                        break;
                    case 5:
                        if (!(97 <= q && 122 >= q || 65 <= q && 90 >= q || 48 <= q && 57 >= q || 58 == q || 46 == q || 95 == q ||
                                45 == q)) {
                            if (E == b) throw "Expected attribute name";
                            l = u.substr(a, E, b - E);
                            if (d.exists(l)) throw "Duplicate attribute";
                            e = 0;
                            f = 6;
                            continue
                        }
                        break;
                    case 6:
                        switch (q) {
                            case 61:
                                e = 0;
                                f = 7;
                                break;
                            default:
                                throw "Expected =";
                        }
                        break;
                    case 7:
                        switch (q) {
                            case 34:
                            case 39:
                                e = 8;
                                E = b;
                                break;
                            default:
                                throw 'Expected "';
                        }
                        break;
                    case 8:
                        q == a.charCodeAt(E) && (f = u.substr(a, E + 1, b - E - 1), d.set(l, f), e = 0, f = 4);
                        break;
                    case 9:
                        E = b = ac.doParse(a, b, d);
                        e = 1;
                        break;
                    case 11:
                        switch (q) {
                            case 62:
                                e = 1;
                                break;
                            default:
                                throw "Expected >";
                        }
                        break;
                    case 12:
                        switch (q) {
                            case 62:
                                return 0 ==
                                    g && c.addChild(I.createPCData("")), b;
                            default:
                                throw "Expected >";
                        }
                    case 10:
                        if (!(97 <= q && 122 >= q || 65 <= q && 90 >= q || 48 <= q && 57 >= q || 58 == q || 46 == q || 95 == q || 45 == q)) {
                            if (E == b) throw "Expected node name";
                            if (u.substr(a, E, b - E) != c.get_nodeName()) throw "Expected </" + c.get_nodeName() + ">";
                            e = 0;
                            f = 12;
                            continue
                        }
                        break;
                    case 15:
                        45 == q && 45 == a.charCodeAt(b + 1) && 62 == a.charCodeAt(b + 2) && (c.addChild(I.createComment(u.substr(a, E, b - E))), b += 2, e = 1);
                        break;
                    case 16:
                        91 == q ? h++ : 93 == q ? h-- : 62 == q && 0 == h && (c.addChild(I.createDocType(u.substr(a, E, b - E))), e =
                            1);
                        break;
                    case 14:
                        63 == q && 62 == a.charCodeAt(b + 1) && (b++, e = u.substr(a, E + 1, b - E - 2), c.addChild(I.createProcessingInstruction(e)), e = 1);
                        break;
                    case 18:
                        59 == q && (E = u.substr(a, E, b - E), 35 == E.charCodeAt(0) ? (E = 120 == E.charCodeAt(1) ? v.parseInt("0" + u.substr(E, 1, E.length - 1)) : v.parseInt(u.substr(E, 1, E.length - 1)), k.add(String.fromCharCode(E))) : ac.escapes.exists(E) ? k.add(ac.escapes.get(E)) : k.b += v.string("&" + E + ";"), E = b + 1, e = f)
                }
                q = M.fastCodeAt(a, ++b)
            }
            1 == e && (E = b, e = 13);
            if (13 == e) return b == E && 0 != g || c.addChild(I.createPCData(k.b + u.substr(a,
                E, b - E))), b;
            throw "Unexpected end";
        };
        var x = function() {};
        g["js.Boot"] = x;
        x.__name__ = ["js", "Boot"];
        x.getClass = function(a) {
            if (a instanceof Array && null == a.__enum__) return Array;
            var b = a.__class__;
            if (null != b) return b;
            a = x.__nativeClassName(a);
            return null != a ? x.__resolveNativeClass(a) : null
        };
        x.__string_rec = function(a, b) {
            if (null == a) return "null";
            if (5 <= b.length) return "<...>";
            var c = typeof a;
            "function" == c && (a.__name__ || a.__ename__) && (c = "object");
            switch (c) {
                case "object":
                    if (a instanceof Array) {
                        if (a.__enum__) {
                            if (2 == a.length) return a[0];
                            c = a[0] + "(";
                            b += "\t";
                            for (var d = 2, e = a.length; d < e;) var f = d++,
                                c = 2 != f ? c + ("," + x.__string_rec(a[f], b)) : c + x.__string_rec(a[f], b);
                            return c + ")"
                        }
                        c = a.length;
                        d = "[";
                        b += "\t";
                        for (e = 0; e < c;) f = e++, d += (0 < f ? "," : "") + x.__string_rec(a[f], b);
                        return d + "]"
                    }
                    try {
                        d = a.toString
                    } catch (l) {
                        return "???"
                    }
                    if (null != d && d != Object.toString && "function" == typeof d && (c = a.toString(), "[object Object]" != c)) return c;
                    c = null;
                    d = "{\n";
                    b += "\t";
                    e = null != a.hasOwnProperty;
                    for (c in a) e && !a.hasOwnProperty(c) || "prototype" == c || "__class__" == c || "__super__" == c || "__interfaces__" ==
                        c || "__properties__" == c || (2 != d.length && (d += ", \n"), d += b + c + " : " + x.__string_rec(a[c], b));
                    b = b.substring(1);
                    return d + ("\n" + b + "}");
                case "function":
                    return "<function>";
                case "string":
                    return a;
                default:
                    return String(a)
            }
        };
        x.__interfLoop = function(a, b) {
            if (null == a) return !1;
            if (a == b) return !0;
            var c = a.__interfaces__;
            if (null != c)
                for (var d = 0, e = c.length; d < e;) {
                    var f = d++,
                        f = c[f];
                    if (f == b || x.__interfLoop(f, b)) return !0
                }
            return x.__interfLoop(a.__super__, b)
        };
        x.__instanceof = function(a, b) {
            if (null == b) return !1;
            switch (b) {
                case rg:
                    return (a |
                        0) === a;
                case Wf:
                    return "number" == typeof a;
                case Xf:
                    return "boolean" == typeof a;
                case String:
                    return "string" == typeof a;
                case Array:
                    return a instanceof Array && null == a.__enum__;
                case sg:
                    return !0;
                default:
                    if (null != a)
                        if ("function" == typeof b) {
                            if (a instanceof b || x.__interfLoop(x.getClass(a), b)) return !0
                        } else {
                            if ("object" == typeof b && x.__isNativeObj(b) && a instanceof b) return !0
                        }
                    else return !1;
                    return b == Yf && null != a.__name__ || b == tg && null != a.__ename__ ? !0 : a.__enum__ == b
            }
        };
        x.__cast = function(a, b) {
            if (x.__instanceof(a, b)) return a;
            throw "Cannot cast " + v.string(a) + " to " + v.string(b);
        };
        x.__nativeClassName = function(a) {
            a = x.__toStr.call(a).slice(8, -1);
            return "Object" == a || "Function" == a || "Math" == a || "JSON" == a ? null : a
        };
        x.__isNativeObj = function(a) {
            return null != x.__nativeClassName(a)
        };
        x.__resolveNativeClass = function(a) {
            return "undefined" != typeof window ? window[a] : global[a]
        };
        var Of = function() {};
        g["js.Browser"] = Of;
        Of.__name__ = ["js", "Browser"];
        Of.getLocalStorage = function() {
            try {
                var a = window.localStorage;
                a.getItem("");
                return a
            } catch (b) {
                return null
            }
        };
        var bf = function() {
            this.enabled = !0;
            this.audio = new pa;
            this.font = new pa;
            this.image = new pa
        };
        g["lime.AssetCache"] = bf;
        bf.__name__ = ["lime", "AssetCache"];
        bf.prototype = {
            clear: function(a) {
                if (null == a) this.audio = new pa, this.font = new pa, this.image = new pa;
                else {
                    for (var b = this.audio.keys(); b.hasNext();) {
                        var c = b.next();
                        M.startsWith(c, a) && this.audio.remove(c)
                    }
                    for (b = this.font.keys(); b.hasNext();) c = b.next(), M.startsWith(c, a) && this.font.remove(c);
                    for (b = this.image.keys(); b.hasNext();) c = b.next(), M.startsWith(c, a) && this.image.remove(c)
                }
            },
            __class__: bf
        };
        var H = function() {};
        g["lime.Assets"] = H;
        H.__name__ = ["lime", "Assets"];
        H.exists = function(a, b) {
            H.initialize();
            null == b && (b = "BINARY");
            var c = a.substring(0, a.indexOf(":")),
                d;
            d = a.indexOf(":") + 1;
            d = u.substr(a, d, null);
            c = H.getLibrary(c);
            return null != c ? c.exists(d, b) : !1
        };
        H.getFont = function(a, b) {
            null == b && (b = !0);
            H.initialize();
            if (b && H.cache.enabled && H.cache.font.exists(a)) return H.cache.font.get(a);
            var c = a.substring(0, a.indexOf(":")),
                d;
            d = a.indexOf(":") + 1;
            d = u.substr(a, d, null);
            var e = H.getLibrary(c);
            if (null !=
                e)
                if (e.exists(d, "FONT")) {
                    if (e.isLocal(d, "FONT")) return c = e.getFont(d), b && H.cache.enabled && H.cache.font.set(a, c), c;
                    console.log('[Assets] Font asset "' + a + '" exists, but only asynchronously')
                } else console.log('[Assets] There is no Font asset with an ID of "' + a + '"');
            else console.log('[Assets] There is no asset library named "' + c + '"');
            return null
        };
        H.getImage = function(a, b) {
            null == b && (b = !0);
            H.initialize();
            if (b && H.cache.enabled && H.cache.image.exists(a)) {
                var c = H.cache.image.get(a);
                if (H.isValidImage(c)) return c
            }
            var c =
                a.substring(0, a.indexOf(":")),
                d;
            d = a.indexOf(":") + 1;
            d = u.substr(a, d, null);
            var e = H.getLibrary(c);
            if (null != e)
                if (e.exists(d, "IMAGE")) {
                    if (e.isLocal(d, "IMAGE")) return c = e.getImage(d), b && H.cache.enabled && H.cache.image.set(a, c), c;
                    console.log('[Assets] Image asset "' + a + '" exists, but only asynchronously')
                } else console.log('[Assets] There is no Image asset with an ID of "' + a + '"');
            else console.log('[Assets] There is no asset library named "' + c + '"');
            return null
        };
        H.getLibrary = function(a) {
            if (null == a || "" == a) a = "default";
            return H.libraries.get(a)
        };
        H.getPath = function(a) {
            H.initialize();
            var b = a.substring(0, a.indexOf(":")),
                c;
            c = a.indexOf(":") + 1;
            c = u.substr(a, c, null);
            var d = H.getLibrary(b);
            if (null != d) {
                if (d.exists(c, null)) return d.getPath(c);
                console.log('[Assets] There is no asset with an ID of "' + a + '"')
            } else console.log('[Assets] There is no asset library named "' + b + '"');
            return null
        };
        H.getText = function(a) {
            H.initialize();
            var b = a.substring(0, a.indexOf(":")),
                c;
            c = a.indexOf(":") + 1;
            c = u.substr(a, c, null);
            var d = H.getLibrary(b);
            if (null !=
                d)
                if (d.exists(c, "TEXT")) {
                    if (d.isLocal(c, "TEXT")) return d.getText(c);
                    console.log('[Assets] String asset "' + a + '" exists, but only asynchronously')
                } else console.log('[Assets] There is no String asset with an ID of "' + a + '"');
            else console.log('[Assets] There is no asset library named "' + b + '"');
            return null
        };
        H.initialize = function() {
            H.initialized || (H.registerLibrary("default", new Dd), H.initialized = !0)
        };
        H.isValidImage = function(a) {
            return !0
        };
        H.registerLibrary = function(a, b) {
            H.libraries.exists(a) && H.unloadLibrary(a);
            null != b && (b.eventCallback = H.library_onEvent);
            H.libraries.set(a, b)
        };
        H.unloadLibrary = function(a) {
            H.initialize();
            var b = H.libraries.get(a);
            null != b && (H.cache.clear(a + ":"), b.eventCallback = null);
            H.libraries.remove(a)
        };
        H.library_onEvent = function(a, b) {
            "change" == b && H.cache.clear()
        };
        var cf = function(a) {
            this.parent = a;
            zc.init()
        };
        g["lime._backend.html5.HTML5Application"] = cf;
        cf.__name__ = ["lime", "_backend", "html5", "HTML5Application"];
        cf.prototype = {
            convertKeyCode: function(a) {
                if (65 <= a && 90 >= a) return a + 32;
                switch (a) {
                    case 16:
                        return 1073742049;
                    case 17:
                        return 1073742048;
                    case 18:
                        return 1073742050;
                    case 20:
                        return 1073741881;
                    case 144:
                        return 1073741907;
                    case 37:
                        return 1073741904;
                    case 38:
                        return 1073741906;
                    case 39:
                        return 1073741903;
                    case 40:
                        return 1073741905;
                    case 45:
                        return 1073741897;
                    case 46:
                        return 127;
                    case 36:
                        return 1073741898;
                    case 35:
                        return 1073741901;
                    case 33:
                        return 1073741899;
                    case 34:
                        return 1073741902;
                    case 112:
                        return 1073741882;
                    case 113:
                        return 1073741883;
                    case 114:
                        return 1073741884;
                    case 115:
                        return 1073741885;
                    case 116:
                        return 1073741886;
                    case 117:
                        return 1073741887;
                    case 118:
                        return 1073741888;
                    case 119:
                        return 1073741889;
                    case 120:
                        return 1073741890;
                    case 121:
                        return 1073741891;
                    case 122:
                        return 1073741892;
                    case 123:
                        return 1073741893
                }
                return a
            },
            create: function(a) {
                this.parent.config = a;
                if (null != a) {
                    a = new df(a);
                    var b = new ef(a);
                    this.parent.addWindow(a);
                    this.parent.addRenderer(b);
                    this.parent.init(b.context)
                }
            },
            exec: function() {
                window.addEventListener("keydown", r(this, this.handleKeyEvent), !1);
                window.addEventListener("keyup", r(this, this.handleKeyEvent), !1);
                window.addEventListener("focus",
                    r(this, this.handleWindowEvent), !1);
                window.addEventListener("blur", r(this, this.handleWindowEvent), !1);
                window.addEventListener("resize", r(this, this.handleWindowEvent), !1);
                window.addEventListener("beforeunload", r(this, this.handleWindowEvent), !1);
                for (var a = 0, b = ["ms", "moz", "webkit", "o"], c = 0; c < b.length && !window.requestAnimationFrame; ++c) window.requestAnimationFrame = window[b[c] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[b[c] + "CancelAnimationFrame"] || window[b[c] + "CancelRequestAnimationFrame"];
                window.requestAnimationFrame || (window.requestAnimationFrame = function(b, c) {
                    var f = (new Date).getTime(),
                        l = Math.max(0, 16 - (f - a)),
                        E = window.setTimeout(function() {
                            b(f + l)
                        }, l);
                    a = f + l;
                    return E
                });
                window.cancelAnimationFrame || (window.cancelAnimationFrame = function(a) {
                    clearTimeout(a)
                });
                window.requestAnimFrame = window.requestAnimationFrame;
                this.cacheTime = (new Date).getTime();
                this.handleUpdateEvent();
                return 0
            },
            handleKeyEvent: function(a) {
                if (null != this.parent.windows[0]) {
                    switch (a.keyCode) {
                        case 32:
                        case 37:
                        case 38:
                        case 39:
                        case 40:
                            a.preventDefault()
                    }
                    var b =
                        this.convertKeyCode(null != a.keyCode ? a.keyCode : a.which),
                        c;
                    c = (a.shiftKey ? 3 : 0) | (a.ctrlKey ? 192 : 0) | (a.altKey ? 768 : 0) | (a.metaKey ? 3072 : 0);
                    if ("keydown" == a.type) {
                        a = this.parent.windows[0].onKeyDown.listeners;
                        for (var d = this.parent.windows[0].onKeyDown.repeat, e = a.length, f = 0; f < e;) a[f](b, c), d[f] ? f++ : (this.parent.windows[0].onKeyDown.remove(a[f]), e--)
                    } else
                        for (a = this.parent.windows[0].onKeyUp.listeners, d = this.parent.windows[0].onKeyUp.repeat, e = a.length, f = 0; f < e;) a[f](b, c), d[f] ? f++ : (this.parent.windows[0].onKeyUp.remove(a[f]),
                            e--)
                }
            },
            handleUpdateEvent: function(a) {
                var b = (new Date).getTime();
                a = b - this.cacheTime;
                this.cacheTime = b;
                for (var b = this.parent.onUpdate.listeners, c = this.parent.onUpdate.repeat, d = b.length, e = 0; e < d;) b[e](a | 0), c[e] ? e++ : (this.parent.onUpdate.remove(b[e]), d--);
                if (null != this.parent.renderers[0]) {
                    a = this.parent.renderers[0].onRender.listeners;
                    b = this.parent.renderers[0].onRender.repeat;
                    c = a.length;
                    for (d = 0; d < c;) a[d](this.parent.renderers[0].context), b[d] ? d++ : (this.parent.renderers[0].onRender.remove(a[d]), c--);
                    this.parent.renderers[0].flip()
                }
                window.requestAnimationFrame(r(this,
                    this.handleUpdateEvent))
            },
            handleWindowEvent: function(a) {
                if (null != this.parent.windows[0]) switch (a.type) {
                    case "focus":
                        a = this.parent.windows[0].onWindowFocusIn.listeners;
                        for (var b = this.parent.windows[0].onWindowFocusIn.repeat, c = a.length, d = 0; d < c;) a[d](), b[d] ? d++ : (this.parent.windows[0].onWindowFocusIn.remove(a[d]), c--);
                        a = this.parent.windows[0].onWindowActivate.listeners;
                        b = this.parent.windows[0].onWindowActivate.repeat;
                        c = a.length;
                        for (d = 0; d < c;) a[d](), b[d] ? d++ : (this.parent.windows[0].onWindowActivate.remove(a[d]),
                            c--);
                        break;
                    case "blur":
                        a = this.parent.windows[0].onWindowFocusOut.listeners;
                        b = this.parent.windows[0].onWindowFocusOut.repeat;
                        c = a.length;
                        for (d = 0; d < c;) a[d](), b[d] ? d++ : (this.parent.windows[0].onWindowFocusOut.remove(a[d]), c--);
                        a = this.parent.windows[0].onWindowDeactivate.listeners;
                        b = this.parent.windows[0].onWindowDeactivate.repeat;
                        c = a.length;
                        for (d = 0; d < c;) a[d](), b[d] ? d++ : (this.parent.windows[0].onWindowDeactivate.remove(a[d]), c--);
                        break;
                    case "resize":
                        a = this.parent.windows[0].__width;
                        b = this.parent.windows[0].__height;
                        this.parent.windows[0].backend.handleResize();
                        if (this.parent.windows[0].__width != a || this.parent.windows[0].__height != b)
                            for (a = this.parent.windows[0].onWindowResize.listeners, b = this.parent.windows[0].onWindowResize.repeat, c = a.length, d = 0; d < c;) a[d](this.parent.windows[0].__width, this.parent.windows[0].__height), b[d] ? d++ : (this.parent.windows[0].onWindowResize.remove(a[d]), c--);
                        break;
                    case "beforeunload":
                        for (a = this.parent.windows[0].onWindowClose.listeners, b = this.parent.windows[0].onWindowClose.repeat, c =
                            a.length, d = 0; d < c;) a[d](), b[d] ? d++ : (this.parent.windows[0].onWindowClose.remove(a[d]), c--)
                }
            },
            __class__: cf
        };
        var ic = function() {};
        g["lime._backend.html5.HTML5Mouse"] = ic;
        ic.__name__ = ["lime", "_backend", "html5", "HTML5Mouse"];
        ic.__cursor = null;
        ic.__hidden = null;
        ic.set_cursor = function(a) {
            if (ic.__cursor != a) {
                if (!ic.__hidden)
                    for (var b = 0, c = Xa.current.windows; b < c.length;) {
                        var d = c[b];
                        ++b;
                        switch (a[1]) {
                            case 0:
                                d.backend.element.style.cursor = "default";
                                break;
                            case 1:
                                d.backend.element.style.cursor = "crosshair";
                                break;
                            case 3:
                                d.backend.element.style.cursor =
                                    "move";
                                break;
                            case 4:
                                d.backend.element.style.cursor = "pointer";
                                break;
                            case 5:
                                d.backend.element.style.cursor = "nesw-resize";
                                break;
                            case 6:
                                d.backend.element.style.cursor = "ns-resize";
                                break;
                            case 7:
                                d.backend.element.style.cursor = "nwse-resize";
                                break;
                            case 8:
                                d.backend.element.style.cursor = "ew-resize";
                                break;
                            case 9:
                                d.backend.element.style.cursor = "text";
                                break;
                            case 10:
                                d.backend.element.style.cursor = "wait";
                                break;
                            case 11:
                                d.backend.element.style.cursor = "wait";
                                break;
                            default:
                                d.backend.element.style.cursor = "auto"
                        }
                    }
                ic.__cursor =
                    a
            }
            return ic.__cursor
        };
        var ff = function(a) {
            this.parent = a
        };
        g["lime._backend.html5.HTML5Renderer"] = ff;
        ff.__name__ = ["lime", "_backend", "html5", "HTML5Renderer"];
        ff.prototype = {
            create: function() {
                this.createContext();
                switch (this.parent.context[1]) {
                    case 0:
                        this.parent.window.backend.canvas.addEventListener("webglcontextlost", r(this, this.handleEvent), !1), this.parent.window.backend.canvas.addEventListener("webglcontextrestored", r(this, this.handleEvent), !1)
                }
            },
            createContext: function() {
                null != this.parent.window.backend.div ?
                    this.parent.context = sb.DOM(this.parent.window.backend.div) : null != this.parent.window.backend.canvas && (this.parent.context = sb.CANVAS(this.parent.window.backend.canvas.getContext("2d")))
            },
            flip: function() {},
            handleEvent: function(a) {
                switch (a.type) {
                    case "webglcontextlost":
                        a.preventDefault();
                        this.parent.context = null;
                        a = this.parent.onRenderContextLost.listeners;
                        for (var b = this.parent.onRenderContextLost.repeat, c = a.length, d = 0; d < c;) a[d](), b[d] ? d++ : (this.parent.onRenderContextLost.remove(a[d]), c--);
                        break;
                    case "webglcontextrestored":
                        for (this.createContext(),
                            a = this.parent.onRenderContextRestored.listeners, b = this.parent.onRenderContextRestored.repeat, c = a.length, d = 0; d < c;) a[d](this.parent.context), b[d] ? d++ : (this.parent.onRenderContextRestored.remove(a[d]), c--)
                }
            },
            __class__: ff
        };
        var gd = function(a) {
            gd.instance = this;
            this.parent = a;
            null != a.config && Object.prototype.hasOwnProperty.call(a.config, "element") && (this.element = a.config.element)
        };
        g["lime._backend.html5.HTML5Window"] = gd;
        gd.__name__ = ["lime", "_backend", "html5", "HTML5Window"];
        gd.instance = null;
        gd.prototype = {
            create: function(a) {
                this.setWidth =
                    this.parent.__width;
                this.setHeight = this.parent.__height;
                x.__instanceof(this.element, HTMLCanvasElement) ? this.canvas = this.element : this.canvas = window.document.createElement("canvas");
                null != this.canvas ? (a = this.canvas.style, a.setProperty("-webkit-transform", "translateZ(0)", null), a.setProperty("transform", "translateZ(0)", null)) : null != this.div && (a = this.div.style, a.setProperty("-webkit-transform", "translate3D(0,0,0)", null), a.setProperty("transform", "translate3D(0,0,0)", null), a.position = "relative", a.overflow =
                    "hidden", a.setProperty("-webkit-user-select", "none", null), a.setProperty("-moz-user-select", "none", null), a.setProperty("-ms-user-select", "none", null), a.setProperty("-o-user-select", "none", null));
                0 == this.parent.__width && 0 == this.parent.__height && (null != this.element ? (this.parent.set_width(this.element.clientWidth), this.parent.set_height(this.element.clientHeight)) : (this.parent.set_width(window.innerWidth), this.parent.set_height(window.innerHeight)), this.parent.set_fullscreen(!0));
                null != this.canvas ? (this.canvas.width =
                    this.parent.__width, this.canvas.height = this.parent.__height) : (this.div.style.width = this.parent.__width + "px", this.div.style.height = this.parent.__height + "px");
                this.handleResize();
                if (null != this.element) {
                    null != this.canvas ? this.element != this.canvas && this.element.appendChild(this.canvas) : this.element.appendChild(this.div);
                    a = ["mousedown", "mousemove", "mouseup", "wheel"];
                    for (var b = 0; b < a.length;) {
                        var c = a[b];
                        ++b;
                        this.element.addEventListener(c, r(this, this.handleMouseEvent), !0)
                    }
                    window.document.addEventListener("dragstart",
                        function(a) {
                            return "img" == a.target.nodeName.toLowerCase() ? (a.preventDefault(), !1) : !0
                        }, !1);
                    this.element.addEventListener("touchstart", r(this, this.handleTouchEvent), !0);
                    this.element.addEventListener("touchmove", r(this, this.handleTouchEvent), !0);
                    this.element.addEventListener("touchend", r(this, this.handleTouchEvent), !0)
                }
            },
            handleMouseEvent: function(a) {
                var b = 0,
                    c = 0;
                if ("wheel" != a.type) switch (null != this.element ? null != this.canvas ? (c = this.canvas.getBoundingClientRect(), b = this.parent.__width / c.width * (a.clientX -
                    c.left), c = this.parent.__height / c.height * (a.clientY - c.top)) : null != this.div ? (c = this.div.getBoundingClientRect(), b = a.clientX - c.left, c = a.clientY - c.top) : (c = this.element.getBoundingClientRect(), b = this.parent.__width / c.width * (a.clientX - c.left), c = this.parent.__height / c.height * (a.clientY - c.top)) : (b = a.clientX, c = a.clientY), a.type) {
                    case "mousedown":
                        for (var d = this.parent.onMouseDown.listeners, e = this.parent.onMouseDown.repeat, f = d.length, l = 0; l < f;) d[l](b, c, a.button), e[l] ? l++ : (this.parent.onMouseDown.remove(d[l]),
                            f--);
                        break;
                    case "mouseup":
                        d = this.parent.onMouseUp.listeners;
                        e = this.parent.onMouseUp.repeat;
                        f = d.length;
                        for (l = 0; l < f;) d[l](b, c, a.button), e[l] ? l++ : (this.parent.onMouseUp.remove(d[l]), f--);
                        break;
                    case "mousemove":
                        for (d = this.parent.onMouseMove.listeners, e = this.parent.onMouseMove.repeat, f = d.length, l = 0; l < f;) d[l](b, c, a.button), e[l] ? l++ : (this.parent.onMouseMove.remove(d[l]), f--)
                } else
                    for (b = this.parent.onMouseWheel.listeners, c = this.parent.onMouseWheel.repeat, d = b.length, e = 0; e < d;) b[e](a.deltaX, -a.deltaY), c[e] ?
                        e++ : (this.parent.onMouseWheel.remove(b[e]), d--)
            },
            handleResize: function() {
                var a = this.parent.__fullscreen || 0 == this.setWidth && 0 == this.setHeight;
                if (null != this.element && (null == this.div || null != this.div && a))
                    if (a) {
                        if (this.parent.__width != this.element.clientWidth || this.parent.__height != this.element.clientHeight) this.parent.set_width(this.element.clientWidth), this.parent.set_height(this.element.clientHeight), null != this.canvas ? this.element != this.canvas && (this.canvas.width = this.element.clientWidth, this.canvas.height =
                            this.element.clientHeight) : (this.div.style.width = this.element.clientWidth + "px", this.div.style.height = this.element.clientHeight + "px")
                    } else a = Math.min(this.element.clientWidth / this.setWidth, this.element.clientHeight / this.setHeight), null != this.canvas ? this.element != this.canvas && (this.canvas.style.width = this.setWidth * a + "px", this.canvas.style.height = this.setHeight * a + "px", this.canvas.style.marginLeft = (this.element.clientWidth - this.setWidth * a) / 2 + "px", this.canvas.style.marginTop = (this.element.clientHeight -
                        this.setHeight * a) / 2 + "px") : (this.div.style.width = this.setWidth * a + "px", this.div.style.height = this.setHeight * a + "px", this.div.style.marginLeft = (this.element.clientWidth - this.setWidth * a) / 2 + "px", this.div.style.marginTop = (this.element.clientHeight - this.setHeight * a) / 2 + "px")
            },
            handleTouchEvent: function(a) {
                a.preventDefault();
                var b = a.changedTouches[0],
                    c = b.identifier,
                    d = 0,
                    e = 0;
                null != this.element ? null != this.canvas ? (e = this.canvas.getBoundingClientRect(), d = this.parent.__width / e.width * (b.clientX - e.left), e = this.parent.__height /
                    e.height * (b.clientY - e.top)) : null != this.div ? (e = this.div.getBoundingClientRect(), d = b.clientX - e.left, e = b.clientY - e.top) : (e = this.element.getBoundingClientRect(), d = this.parent.__width / e.width * (b.clientX - e.left), e = this.parent.__height / e.height * (b.clientY - e.top)) : (d = b.clientX, e = b.clientY);
                switch (a.type) {
                    case "touchstart":
                        a = this.parent.onTouchStart.listeners;
                        for (var b = this.parent.onTouchStart.repeat, f = a.length, l = 0; l < f;) a[l](d, e, c), b[l] ? l++ : (this.parent.onTouchStart.remove(a[l]), f--);
                        break;
                    case "touchmove":
                        a =
                            this.parent.onTouchMove.listeners;
                        b = this.parent.onTouchMove.repeat;
                        f = a.length;
                        for (l = 0; l < f;) a[l](d, e, c), b[l] ? l++ : (this.parent.onTouchMove.remove(a[l]), f--);
                        break;
                    case "touchend":
                        for (a = this.parent.onTouchEnd.listeners, b = this.parent.onTouchEnd.repeat, f = a.length, l = 0; l < f;) a[l](d, e, c), b[l] ? l++ : (this.parent.onTouchEnd.remove(a[l]), f--)
                }
            },
            resize: function(a, b) {},
            setFullscreen: function(a) {
                return !1
            },
            __class__: gd
        };
        var gf = function() {};
        g["lime.app.IModule"] = gf;
        gf.__name__ = ["lime", "app", "IModule"];
        gf.prototype = {
            __class__: gf
        };
        var hd = function() {};
        g["lime.app.Module"] = hd;
        hd.__name__ = ["lime", "app", "Module"];
        hd.__interfaces__ = [gf];
        hd.prototype = {
            init: function(a) {},
            onGamepadAxisMove: function(a, b, c) {},
            onGamepadButtonDown: function(a, b) {},
            onGamepadButtonUp: function(a, b) {},
            onGamepadConnect: function(a) {},
            onGamepadDisconnect: function(a) {},
            onKeyDown: function(a, b) {},
            onKeyUp: function(a, b) {},
            onMouseDown: function(a, b, c) {},
            onMouseMove: function(a, b, c) {},
            onMouseUp: function(a, b, c) {},
            onMouseWheel: function(a, b) {},
            onRenderContextLost: function() {},
            onRenderContextRestored: function(a) {},
            onTouchEnd: function(a, b, c) {},
            onTouchMove: function(a, b, c) {},
            onTouchStart: function(a, b, c) {},
            onWindowActivate: function() {},
            onWindowClose: function() {},
            onWindowDeactivate: function() {},
            onWindowFocusIn: function() {},
            onWindowFocusOut: function() {},
            onWindowFullscreen: function() {},
            onWindowMinimize: function() {},
            onWindowMove: function(a, b) {},
            onWindowResize: function(a, b) {},
            onWindowRestore: function() {},
            render: function(a) {},
            update: function(a) {},
            __class__: hd
        };
        var Xa = function() {
            this.onUpdate =
                new ea;
            null == Xa.current && (Xa.current = this);
            this.modules = [];
            this.renderers = [];
            this.windows = [];
            this.backend = new cf(this);
            this.onUpdate.add(r(this, this.update))
        };
        g["lime.app.Application"] = Xa;
        Xa.__name__ = ["lime", "app", "Application"];
        Xa.current = null;
        Xa.__super__ = hd;
        Xa.prototype = t(hd.prototype, {
            addRenderer: function(a) {
                a.onRender.add(r(this, this.render));
                a.onRenderContextLost.add(r(this, this.onRenderContextLost));
                a.onRenderContextRestored.add(r(this, this.onRenderContextRestored));
                this.renderers.push(a)
            },
            addWindow: function(a) {
                this.windows.push(a);
                a.onGamepadAxisMove.add(r(this, this.onGamepadAxisMove));
                a.onGamepadButtonDown.add(r(this, this.onGamepadButtonDown));
                a.onGamepadButtonUp.add(r(this, this.onGamepadButtonUp));
                a.onGamepadConnect.add(r(this, this.onGamepadConnect));
                a.onGamepadDisconnect.add(r(this, this.onGamepadDisconnect));
                a.onKeyDown.add(r(this, this.onKeyDown));
                a.onKeyUp.add(r(this, this.onKeyUp));
                a.onMouseDown.add(r(this, this.onMouseDown));
                a.onMouseMove.add(r(this, this.onMouseMove));
                a.onMouseUp.add(r(this,
                    this.onMouseUp));
                a.onMouseWheel.add(r(this, this.onMouseWheel));
                a.onTouchStart.add(r(this, this.onTouchStart));
                a.onTouchMove.add(r(this, this.onTouchMove));
                a.onTouchEnd.add(r(this, this.onTouchEnd));
                a.onWindowActivate.add(r(this, this.onWindowActivate));
                a.onWindowClose.add(r(this, this.onWindowClose));
                a.onWindowDeactivate.add(r(this, this.onWindowDeactivate));
                a.onWindowFocusIn.add(r(this, this.onWindowFocusIn));
                a.onWindowFocusOut.add(r(this, this.onWindowFocusOut));
                a.onWindowFullscreen.add(r(this, this.onWindowFullscreen));
                a.onWindowMinimize.add(r(this, this.onWindowMinimize));
                a.onWindowMove.add(r(this, this.onWindowMove));
                a.onWindowResize.add(r(this, this.onWindowResize));
                a.onWindowRestore.add(r(this, this.onWindowRestore));
                a.create(this)
            },
            create: function(a) {
                this.backend.create(a)
            },
            exec: function() {
                Xa.current = this;
                return this.backend.exec()
            },
            init: function(a) {
                for (var b = 0, c = this.modules; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.init(a)
                }
                this.initialized = !0
            },
            onGamepadAxisMove: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f =
                        e[d];
                    ++d;
                    f.onGamepadAxisMove(a, b, c)
                }
            },
            onGamepadButtonDown: function(a, b) {
                for (var c = 0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onGamepadButtonDown(a, b)
                }
            },
            onGamepadButtonUp: function(a, b) {
                for (var c = 0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onGamepadButtonUp(a, b)
                }
            },
            onGamepadConnect: function(a) {
                for (var b = 0, c = this.modules; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.onGamepadConnect(a)
                }
            },
            onGamepadDisconnect: function(a) {
                for (var b = 0, c = this.modules; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.onGamepadDisconnect(a)
                }
            },
            onKeyDown: function(a,
                b) {
                for (var c = 0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onKeyDown(a, b)
                }
            },
            onKeyUp: function(a, b) {
                for (var c = 0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onKeyUp(a, b)
                }
            },
            onMouseDown: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.onMouseDown(a, b, c)
                }
            },
            onMouseMove: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.onMouseMove(a, b, c)
                }
            },
            onMouseUp: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.onMouseUp(a, b, c)
                }
            },
            onMouseWheel: function(a,
                b) {
                for (var c = 0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onMouseWheel(a, b)
                }
            },
            onRenderContextLost: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onRenderContextLost()
                }
            },
            onRenderContextRestored: function(a) {
                for (var b = 0, c = this.modules; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.onRenderContextRestored(a)
                }
            },
            onTouchEnd: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.onTouchEnd(a, b, c)
                }
            },
            onTouchMove: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.onTouchMove(a, b, c)
                }
            },
            onTouchStart: function(a, b, c) {
                for (var d = 0, e = this.modules; d < e.length;) {
                    var f = e[d];
                    ++d;
                    f.onTouchStart(a, b, c)
                }
            },
            onWindowActivate: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowActivate()
                }
            },
            onWindowClose: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowClose()
                }
            },
            onWindowDeactivate: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowDeactivate()
                }
            },
            onWindowFocusIn: function() {
                for (var a = 0, b = this.modules; a <
                    b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowFocusIn()
                }
            },
            onWindowFocusOut: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowFocusOut()
                }
            },
            onWindowFullscreen: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowFullscreen()
                }
            },
            onWindowMinimize: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowMinimize()
                }
            },
            onWindowMove: function(a, b) {
                for (var c = 0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onWindowMove(a, b)
                }
            },
            onWindowResize: function(a, b) {
                for (var c =
                        0, d = this.modules; c < d.length;) {
                    var e = d[c];
                    ++c;
                    e.onWindowResize(a, b)
                }
            },
            onWindowRestore: function() {
                for (var a = 0, b = this.modules; a < b.length;) {
                    var c = b[a];
                    ++a;
                    c.onWindowRestore()
                }
            },
            render: function(a) {
                for (var b = 0, c = this.modules; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.render(a)
                }
            },
            update: function(a) {
                for (var b = 0, c = this.modules; b < c.length;) {
                    var d = c[b];
                    ++b;
                    d.update(a)
                }
            },
            __class__: Xa
        });
        var ea = function() {
            this.listeners = [];
            this.priorities = [];
            this.repeat = []
        };
        g["lime.app.Event"] = ea;
        ea.__name__ = ["lime", "app", "Event"];
        ea.prototype = {
            add: function(a, b, c) {
                null == c && (c = 0);
                null == b && (b = !1);
                for (var d = 0, e = this.priorities.length; d < e;) {
                    var f = d++;
                    if (c > this.priorities[f]) {
                        this.listeners.splice(f, 0, a);
                        this.priorities.splice(f, 0, c);
                        this.repeat.splice(f, 0, !b);
                        return
                    }
                }
                this.listeners.push(a);
                this.priorities.push(c);
                this.repeat.push(!b)
            },
            remove: function(a) {
                a = u.indexOf(this.listeners, a, 0); - 1 < a && (this.listeners.splice(a, 1), this.priorities.splice(a, 1), this.repeat.splice(a, 1))
            },
            __class__: ea
        };
        var Ia = function() {
            this.loaded = this.total = 0
        };
        g["lime.app.Preloader"] =
            Ia;
        Ia.__name__ = ["lime", "app", "Preloader"];
        Ia.prototype = {
            create: function(a) {},
            load: function(a, b) {
                for (var c = null, d = 0, e = a.length; d < e;) {
                    var f = d++,
                        c = a[f];
                    switch (b[f]) {
                        case "IMAGE":
                            f = new Image;
                            Ia.images.set(c, f);
                            f.onload = r(this, this.image_onLoad);
                            f.src = c;
                            this.total++;
                            break;
                        case "BINARY":
                            f = new Md;
                            f.set_dataFormat(db.BINARY);
                            Ia.loaders.set(c, f);
                            this.total++;
                            break;
                        case "TEXT":
                            f = new Md;
                            Ia.loaders.set(c, f);
                            this.total++;
                            break;
                        case "FONT":
                            this.total++, this.loadFont(c)
                    }
                }
                for (c = Ia.loaders.keys(); c.hasNext();) d = c.next(),
                    e = Ia.loaders.get(d), e.onComplete.add(r(this, this.loader_onComplete)), e.load(new hf(d));
                0 == this.total && this.start()
            },
            loadFont: function(a) {
                var b = this;
                if (window.document.fonts && window.document.fonts.load) window.document.fonts.load("1em '" + a + "'").then(function(a) {
                    b.loaded++;
                    b.update(b.loaded, b.total);
                    b.loaded == b.total && b.start()
                });
                else {
                    var c = window.document.createElement("span");
                    c.innerHTML = "giItT1WQy%40%21-/index.html#";
                    var d = c.style;
                    d.position = "absolute";
                    d.left = "-10000px";
                    d.top = "-10000px";
                    d.fontSize = "300px";
                    d.fontFamily =
                        "sans-serif";
                    d.fontVariant = "normal";
                    d.fontStyle = "normal";
                    d.fontWeight = "normal";
                    d.letterSpacing = "0";
                    window.document.body.appendChild(c);
                    var e = c.offsetWidth;
                    d.fontFamily = "'" + a + "', sans-serif";
                    var f = null,
                        l = !1;
                    a = function() {
                        if (c.offsetWidth != e) {
                            if (!l) return l = !0, !1;
                            b.loaded++;
                            null != f && window.clearInterval(f);
                            c.parentNode.removeChild(c);
                            c = null;
                            b.update(b.loaded, b.total);
                            b.loaded == b.total && b.start();
                            return !0
                        }
                        return !1
                    };
                    a() || (f = window.setInterval(a, 50))
                }
            },
            start: function() {
                if (null != this.onComplete) this.onComplete()
            },
            update: function(a, b) {},
            image_onLoad: function(a) {
                this.loaded++;
                this.update(this.loaded, this.total);
                this.loaded == this.total && this.start()
            },
            loader_onComplete: function(a) {
                this.loaded++;
                this.update(this.loaded, this.total);
                this.loaded == this.total && this.start()
            },
            __class__: Ia
        };
        var Zf = function() {};
        g["lime.audio.ALAudioContext"] = Zf;
        Zf.__name__ = ["lime", "audio", "ALAudioContext"];
        var $f = function() {};
        g["lime.audio.ALCAudioContext"] = $f;
        $f.__name__ = ["lime", "audio", "ALCAudioContext"];
        var ag = function() {};
        g["lime.audio.AudioBuffer"] =
            ag;
        ag.__name__ = ["lime", "audio", "AudioBuffer"];
        var Lb = g["lime.audio.AudioContext"] = {
            __ename__: ["lime", "audio", "AudioContext"],
            __constructs__: ["OPENAL", "HTML5", "WEB", "FLASH", "CUSTOM"]
        };
        Lb.OPENAL = function(a, b) {
            var c = ["OPENAL", 0, a, b];
            c.__enum__ = Lb;
            c.toString = p;
            return c
        };
        Lb.HTML5 = function(a) {
            a = ["HTML5", 1, a];
            a.__enum__ = Lb;
            a.toString = p;
            return a
        };
        Lb.WEB = function(a) {
            a = ["WEB", 2, a];
            a.__enum__ = Lb;
            a.toString = p;
            return a
        };
        Lb.FLASH = function(a) {
            a = ["FLASH", 3, a];
            a.__enum__ = Lb;
            a.toString = p;
            return a
        };
        Lb.CUSTOM = function(a) {
            a = ["CUSTOM", 4, a];
            a.__enum__ = Lb;
            a.toString = p;
            return a
        };
        var zc = function() {};
        g["lime.audio.AudioManager"] = zc;
        zc.__name__ = ["lime", "audio", "AudioManager"];
        zc.context = null;
        zc.init = function(a) {
            if (null == zc.context)
                if (null == a) try {
                    window.AudioContext = window.AudioContext || window.webkitAudioContext, zc.context = Lb.WEB(new AudioContext)
                } catch (b) {
                    zc.context = Lb.HTML5(new jf)
                } else zc.context = a
        };
        var bg = function() {};
        g["lime.audio.FlashAudioContext"] = bg;
        bg.__name__ = ["lime", "audio", "FlashAudioContext"];
        var jf = function() {};
        g["lime.audio.HTML5AudioContext"] = jf;
        jf.__name__ = ["lime", "audio", "HTML5AudioContext"];
        jf.prototype = {
            __class__: jf
        };
        var cg = function() {};
        g["lime.graphics.ConsoleRenderContext"] = cg;
        cg.__name__ = ["lime", "graphics", "ConsoleRenderContext"];
        var dg = function() {};
        g["lime.graphics.FlashRenderContext"] = dg;
        dg.__name__ = ["lime", "graphics", "FlashRenderContext"];
        var id = function(a) {
            Ib.call(this, a)
        };
        g["lime.graphics.Font"] = id;
        id.__name__ = ["lime", "graphics", "Font"];
        id.__super__ = Ib;
        id.prototype = t(Ib.prototype, {
            get_fontName: function() {
                return this.name
            },
            __class__: id,
            __properties__: {
                get_fontName: "get_fontName"
            }
        });
        var gb = function(a, b, c, d, e, f, l) {
            null == e && (e = -1);
            null == d && (d = -1);
            null == c && (c = 0);
            null == b && (b = 0);
            this.offsetX = b;
            this.offsetY = c;
            this.width = d;
            this.height = e;
            if (null == l)
                if (null != Xa.current && null != Xa.current.renderers[0]) switch (Xa.current.renderers[0].context[1]) {
                    case 2:
                    case 1:
                        this.type = Fa.CANVAS;
                        break;
                    case 3:
                        this.type = Fa.FLASH;
                        break;
                    default:
                        this.type = Fa.DATA
                } else this.type = Fa.DATA;
                else this.type = l;
            if (null == a) {
                if (0 < d && 0 < e) switch (this.type[1]) {
                    case 0:
                        this.buffer =
                            new jc(null, d, e);
                        W.createCanvas(this, d, e);
                        null != f && this.fillRect(new Ac(0, 0, d, e), f);
                        break;
                    case 1:
                        this.buffer = new jc(new Uint8Array(d * e * 4), d, e), null != f && this.fillRect(new Ac(0, 0, d, e), f)
                }
            } else this.__fromImageBuffer(a)
        };
        g["lime.graphics.Image"] = gb;
        gb.__name__ = ["lime", "graphics", "Image"];
        gb.fromBase64 = function(a, b, c) {
            var d = new gb;
            d.__fromBase64(a, b, c);
            return d
        };
        gb.fromCanvas = function(a) {
            var b = new jc(null, a.width, a.height);
            b.set_src(a);
            return new gb(b)
        };
        gb.fromImageElement = function(a) {
            var b = new jc(null,
                a.width, a.height);
            b.set_src(a);
            return new gb(b)
        };
        gb.prototype = {
            clone: function() {
                return new gb(this.buffer.clone(), this.offsetX, this.offsetY, this.width, this.height, null, this.type)
            },
            copyChannel: function(a, b, c, d, e) {
                b = this.__clipRect(b);
                if (null != this.buffer && null != b && !(e == Ga.ALPHA && !this.get_transparent() || 0 >= b.width || 0 >= b.height)) switch (b.x + b.width > a.width && (b.width = a.width - b.x), b.y + b.height > a.height && (b.height = a.height - b.y), this.type[1]) {
                    case 0:
                        W.copyChannel(this, a, b, c, d, e);
                        break;
                    case 1:
                        W.convertToData(this);
                        ua.copyChannel(this, a, b, c, d, e);
                        break;
                    case 2:
                        var f;
                        switch (d[1]) {
                            case 0:
                                f = 1;
                                break;
                            case 1:
                                f = 2;
                                break;
                            case 2:
                                f = 4;
                                break;
                            case 3:
                                f = 8
                        }
                        var l;
                        switch (e[1]) {
                            case 0:
                                l = 1;
                                break;
                            case 1:
                                l = 2;
                                break;
                            case 2:
                                l = 4;
                                break;
                            case 3:
                                l = 8
                        }
                        b.offset(a.offsetX, a.offsetY);
                        c.offset(this.offsetX, this.offsetY);
                        this.buffer.__srcBitmapData.copyChannel(a.buffer.get_src(), b.__toFlashRectangle(), c.__toFlashPoint(), f, l)
                }
            },
            copyPixels: function(a, b, c, d, e, f) {
                null == f && (f = !1);
                if (null != this.buffer && null != a && (b.x + b.width > a.width && (b.width = a.width - b.x),
                        b.y + b.height > a.height && (b.height = a.height - b.y), !(0 >= b.width || 0 >= b.height))) switch (this.type[1]) {
                    case 0:
                        W.convertToCanvas(this);
                        W.copyPixels(this, a, b, c, d, e, f);
                        break;
                    case 1:
                        W.convertToData(this);
                        W.convertToData(a);
                        ua.copyPixels(this, a, b, c, d, e, f);
                        break;
                    case 2:
                        b.offset(a.offsetX, a.offsetY), c.offset(this.offsetX, this.offsetY), null != d && null != e && e.offset(d.offsetX, d.offsetY), this.buffer.__srcBitmapData.copyPixels(a.buffer.__srcBitmapData, b.__toFlashRectangle(), c.__toFlashPoint(), null != d ? d.buffer.get_src() :
                            null, null != e ? e.__toFlashPoint() : null, f)
                }
            },
            fillRect: function(a, b) {
                a = this.__clipRect(a);
                if (null != this.buffer && null != a) switch (this.type[1]) {
                    case 0:
                        W.fillRect(this, a, b);
                        break;
                    case 1:
                        W.convertToData(this);
                        ua.fillRect(this, a, b);
                        break;
                    case 2:
                        a.offset(this.offsetX, this.offsetY), this.buffer.__srcBitmapData.fillRect(a.__toFlashRectangle(), b)
                }
            },
            __clipRect: function(a) {
                return null == a || 0 > a.x && (a.width -= -a.x, a.x = 0, 0 >= a.x + a.width) || 0 > a.y && (a.height -= -a.y, a.y = 0, 0 >= a.y + a.height) || a.x + a.width >= this.width && (a.width -=
                    a.x + a.width - this.width, 0 >= a.width) || a.y + a.height >= this.height && (a.height -= a.y + a.height - this.height, 0 >= a.height) ? null : a
            },
            __fromBase64: function(a, b, c) {
                var d = this,
                    e = new Image;
                e.addEventListener("load", function(a) {
                    d.buffer = new jc(null, e.width, e.height);
                    d.buffer.__srcImage = e;
                    d.offsetX = 0;
                    d.offsetY = 0;
                    d.width = d.buffer.width;
                    d.height = d.buffer.height;
                    null != c && c(d)
                }, !1);
                e.src = "data:" + b + ";base64," + a
            },
            __fromImageBuffer: function(a) {
                this.buffer = a;
                null != a && (-1 == this.width && (this.width = a.width), -1 == this.height && (this.height =
                    a.height))
            },
            get_data: function() {
                null == this.buffer.data && 0 < this.buffer.width && 0 < this.buffer.height && (W.convertToCanvas(this), W.sync(this), W.createImageData(this));
                return this.buffer.data
            },
            get_powerOfTwo: function() {
                return 0 != this.buffer.width && (this.buffer.width & ~this.buffer.width + 1) == this.buffer.width && 0 != this.buffer.height && (this.buffer.height & ~this.buffer.height + 1) == this.buffer.height
            },
            set_premultiplied: function(a) {
                if (a && !this.buffer.premultiplied) switch (this.type[1]) {
                        case 1:
                            W.convertToData(this),
                                ua.multiplyAlpha(this)
                    } else if (!a && this.buffer.premultiplied) switch (this.type[1]) {
                        case 1:
                            W.convertToData(this), ua.unmultiplyAlpha(this)
                    }
                    return a
            },
            get_src: function() {
                return this.buffer.get_src()
            },
            get_transparent: function() {
                return this.buffer.transparent
            },
            set_transparent: function(a) {
                return this.buffer.transparent = a
            },
            __class__: gb,
            __properties__: {
                set_transparent: "set_transparent",
                get_transparent: "get_transparent",
                get_src: "get_src",
                set_premultiplied: "set_premultiplied",
                get_powerOfTwo: "get_powerOfTwo",
                get_data: "get_data"
            }
        };
        var Ga = g["lime.graphics.ImageChannel"] = {
            __ename__: ["lime", "graphics", "ImageChannel"],
            __constructs__: ["RED", "GREEN", "BLUE", "ALPHA"]
        };
        Ga.RED = ["RED", 0];
        Ga.RED.toString = p;
        Ga.RED.__enum__ = Ga;
        Ga.GREEN = ["GREEN", 1];
        Ga.GREEN.toString = p;
        Ga.GREEN.__enum__ = Ga;
        Ga.BLUE = ["BLUE", 2];
        Ga.BLUE.toString = p;
        Ga.BLUE.__enum__ = Ga;
        Ga.ALPHA = ["ALPHA", 3];
        Ga.ALPHA.toString = p;
        Ga.ALPHA.__enum__ = Ga;
        var jc = function(a, b, c, d) {
            null == d && (d = 4);
            null == c && (c = 0);
            null == b && (b = 0);
            this.data = a;
            this.width = b;
            this.height = c;
            this.bitsPerPixel =
                d;
            this.transparent = !0
        };
        g["lime.graphics.ImageBuffer"] = jc;
        jc.__name__ = ["lime", "graphics", "ImageBuffer"];
        jc.prototype = {
            clone: function() {
                var a = new jc(this.data, this.width, this.height, this.bitsPerPixel);
                if (null != this.data) {
                    a.data = new Uint8Array(this.data.byteLength);
                    var b = new Uint8Array(this.data);
                    a.data.set(b)
                } else null != this.__srcImageData ? (a.__srcCanvas = window.document.createElement("canvas"), a.__srcContext = a.__srcCanvas.getContext("2d"), a.__srcCanvas.width = this.__srcImageData.width, a.__srcCanvas.height =
                    this.__srcImageData.height, a.__srcImageData = a.__srcContext.createImageData(this.__srcImageData.width, this.__srcImageData.height), b = new Uint8ClampedArray(this.__srcImageData.data), a.__srcImageData.data.set(b)) : null != this.__srcCanvas ? (a.__srcCanvas = window.document.createElement("canvas"), a.__srcContext = a.__srcCanvas.getContext("2d"), a.__srcCanvas.width = this.__srcCanvas.width, a.__srcCanvas.height = this.__srcCanvas.height, a.__srcContext.drawImage(this.__srcCanvas, 0, 0)) : a.__srcImage = this.__srcImage;
                a.premultiplied =
                    this.premultiplied;
                a.transparent = this.transparent;
                return a
            },
            get_src: function() {
                return null != this.__srcImage ? this.__srcImage : this.__srcCanvas
            },
            set_src: function(a) {
                x.__instanceof(a, Image) ? this.__srcImage = a : x.__instanceof(a, HTMLCanvasElement) && (this.__srcCanvas = a, this.__srcContext = this.__srcCanvas.getContext("2d"));
                return a
            },
            __class__: jc,
            __properties__: {
                set_src: "set_src",
                get_src: "get_src"
            }
        };
        var Fa = g["lime.graphics.ImageType"] = {
            __ename__: ["lime", "graphics", "ImageType"],
            __constructs__: ["CANVAS", "DATA",
                "FLASH", "CUSTOM"
            ]
        };
        Fa.CANVAS = ["CANVAS", 0];
        Fa.CANVAS.toString = p;
        Fa.CANVAS.__enum__ = Fa;
        Fa.DATA = ["DATA", 1];
        Fa.DATA.toString = p;
        Fa.DATA.__enum__ = Fa;
        Fa.FLASH = ["FLASH", 2];
        Fa.FLASH.toString = p;
        Fa.FLASH.__enum__ = Fa;
        Fa.CUSTOM = ["CUSTOM", 3];
        Fa.CUSTOM.toString = p;
        Fa.CUSTOM.__enum__ = Fa;
        var sb = g["lime.graphics.RenderContext"] = {
            __ename__: ["lime", "graphics", "RenderContext"],
            __constructs__: "OPENGL CANVAS DOM FLASH CONSOLE CUSTOM".split(" ")
        };
        sb.OPENGL = function(a) {
            a = ["OPENGL", 0, a];
            a.__enum__ = sb;
            a.toString = p;
            return a
        };
        sb.CANVAS = function(a) {
            a = ["CANVAS", 1, a];
            a.__enum__ = sb;
            a.toString = p;
            return a
        };
        sb.DOM = function(a) {
            a = ["DOM", 2, a];
            a.__enum__ = sb;
            a.toString = p;
            return a
        };
        sb.FLASH = function(a) {
            a = ["FLASH", 3, a];
            a.__enum__ = sb;
            a.toString = p;
            return a
        };
        sb.CONSOLE = function(a) {
            a = ["CONSOLE", 4, a];
            a.__enum__ = sb;
            a.toString = p;
            return a
        };
        sb.CUSTOM = function(a) {
            a = ["CUSTOM", 5, a];
            a.__enum__ = sb;
            a.toString = p;
            return a
        };
        var ef = function(a) {
            this.onRender = new ea;
            this.onRenderContextRestored = new ea;
            this.onRenderContextLost = new ea;
            this.window = a;
            this.backend =
                new ff(this);
            this.window.currentRenderer = this
        };
        g["lime.graphics.Renderer"] = ef;
        ef.__name__ = ["lime", "graphics", "Renderer"];
        ef.prototype = {
            create: function() {
                this.backend.create()
            },
            flip: function() {
                this.backend.flip()
            },
            __class__: ef
        };
        var Tf = function() {};
        g["lime.graphics.opengl.GL"] = Tf;
        Tf.__name__ = ["lime", "graphics", "opengl", "GL"];
        Tf.context = null;
        var W = function() {};
        g["lime.graphics.utils.ImageCanvasUtil"] = W;
        W.__name__ = ["lime", "graphics", "utils", "ImageCanvasUtil"];
        W.convertToCanvas = function(a) {
            var b = a.buffer;
            null != b.__srcImage && (null == b.__srcCanvas && (W.createCanvas(a, b.__srcImage.width, b.__srcImage.height), b.__srcContext.drawImage(b.__srcImage, 0, 0)), b.__srcImage = null)
        };
        W.convertToData = function(a) {
            null == a.buffer.data && (W.convertToCanvas(a), W.sync(a), W.createImageData(a), a.buffer.__srcCanvas = null, a.buffer.__srcContext = null)
        };
        W.copyChannel = function(a, b, c, d, e, f) {
            W.convertToCanvas(b);
            W.createImageData(b);
            W.convertToCanvas(a);
            W.createImageData(a);
            ua.copyChannel(a, b, c, d, e, f)
        };
        W.copyPixels = function(a, b, c, d, e,
            f, l) {
            null == l && (l = !1);
            null != e && e.get_transparent() && (null == f && (f = new rc), b = a.clone(), b.copyChannel(e, new Ac(f.x, f.y, c.width, c.height), new rc(c.x, c.y), Ga.ALPHA, Ga.ALPHA));
            W.sync(a);
            l || a.get_transparent() && b.get_transparent() && a.buffer.__srcContext.clearRect(d.x + a.offsetX, d.y + a.offsetY, c.width + a.offsetX, c.height + a.offsetY);
            W.sync(b);
            null != b.buffer.get_src() && a.buffer.__srcContext.drawImage(b.buffer.get_src(), c.x + b.offsetX | 0, c.y + b.offsetY | 0, c.width | 0, c.height | 0, d.x + a.offsetX | 0, d.y + a.offsetY | 0, c.width |
                0, c.height | 0)
        };
        W.createCanvas = function(a, b, c) {
            var d = a.buffer;
            null == d.__srcCanvas && (d.__srcCanvas = window.document.createElement("canvas"), d.__srcCanvas.width = b, d.__srcCanvas.height = c, a.get_transparent() ? d.__srcContext = d.__srcCanvas.getContext("2d") : (a.get_transparent() || d.__srcCanvas.setAttribute("moz-opaque", "true"), d.__srcContext = d.__srcCanvas.getContext("2d", {
                alpha: !1
            })), d.__srcContext.mozImageSmoothingEnabled = !1, d.__srcContext.webkitImageSmoothingEnabled = !1, d.__srcContext.imageSmoothingEnabled = !1)
        };
        W.createImageData = function(a) {
            a = a.buffer;
            null == a.data && (a.__srcImageData = a.__srcContext.getImageData(0, 0, a.width, a.height), a.data = new Uint8Array(a.__srcImageData.data.buffer))
        };
        W.fillRect = function(a, b, c) {
            W.convertToCanvas(a);
            W.sync(a);
            if (0 == b.x && 0 == b.y && b.width == a.width && b.height == a.height && a.get_transparent() && 0 == (c & -16777216)) a.buffer.__srcCanvas.width = a.buffer.width;
            else {
                var d;
                d = a.get_transparent() ? (c & -16777216) >>> 24 : 255;
                a.buffer.__srcContext.fillStyle = "rgba(" + ((c & 16711680) >>> 16) + ", " + ((c &
                    65280) >>> 8) + ", " + (c & 255) + ", " + d / 255 + ")";
                a.buffer.__srcContext.fillRect(b.x + a.offsetX, b.y + a.offsetY, b.width + a.offsetX, b.height + a.offsetY)
            }
        };
        W.sync = function(a) {
            a.dirty && a.type != Fa.DATA && (a.buffer.__srcContext.putImageData(a.buffer.__srcImageData, 0, 0), a.buffer.data = null, a.dirty = !1)
        };
        var ua = function() {};
        g["lime.graphics.utils.ImageDataUtil"] = ua;
        ua.__name__ = ["lime", "graphics", "utils", "ImageDataUtil"];
        ua.__alpha16 = null;
        ua.__clamp = null;
        ua.copyChannel = function(a, b, c, d, e, f) {
            var l;
            switch (f[1]) {
                case 0:
                    l = 0;
                    break;
                case 1:
                    l = 1;
                    break;
                case 2:
                    l = 2;
                    break;
                case 3:
                    l = 3
            }
            var E;
            switch (e[1]) {
                case 0:
                    E = 0;
                    break;
                case 1:
                    E = 1;
                    break;
                case 2:
                    E = 2;
                    break;
                case 3:
                    E = 3
            }
            e = 4 * b.buffer.width | 0;
            E = 4 * (c.x + b.offsetX) + e * (c.y + b.offsetY) + E | 0;
            f = e - (4 * (c.width + b.offsetX) | 0);
            var g = 4 * (c.x + b.offsetX + c.width) | 0;
            b = b.buffer.data;
            var h = 4 * a.buffer.width | 0;
            l = 4 * (d.x + a.offsetX) + h * (d.y + a.offsetY) + l | 0;
            var q = h - (4 * (c.width + a.offsetX) | 0);
            d = 4 * (d.x + a.offsetX + c.width) | 0;
            var k = a.buffer.data;
            c = c.width * c.height | 0;
            for (var n = 0; n < c;) n++, k[l] = b[E], E += 4, l += 4, E % e > g && (E += f), l % h > d &&
                (l += q);
            a.dirty = !0
        };
        ua.copyPixels = function(a, b, c, d, e, f, l) {
            null == l && (l = !1);
            null != e && e.get_transparent() && (null == f && (f = new rc), b = a.clone(), b.copyChannel(e, new Ac(f.x, f.y, c.width, c.height), new rc(c.x, c.y), Ga.ALPHA, Ga.ALPHA));
            e = d.y + a.offsetY - c.y - b.offsetY | 0;
            d = d.x + a.offsetX - c.x - b.offsetY | 0;
            f = b.buffer.data;
            var E = 4 * b.buffer.width,
                g = 0,
                h = a.buffer.data,
                q = 4 * a.buffer.width,
                k = 0;
            if (l && b.get_transparent()) {
                var n;
                l = v["int"](c.get_top() + b.offsetY);
                for (var m = v["int"](c.get_bottom() + b.offsetY); l < m;)
                    for (var p = l++, r = v["int"](c.get_left() +
                            b.offsetX), t = v["int"](c.get_right() + b.offsetX); r < t;) k = r++, g = p * E + 4 * k, k = (p + e) * q + 4 * (k + d), n = f[g + 3] / 255, n = 1 - n, h[k] = ua.__clamp[f[g] + h[k] * n | 0], h[k + 1] = ua.__clamp[f[g + 1] + h[k + 1] * n | 0], h[k + 2] = ua.__clamp[f[g + 2] + h[k + 2] * n | 0], h[k + 3] = ua.__clamp[f[g + 3] + h[k + 3] * n | 0]
            } else
                for (l = v["int"](c.get_top() + b.offsetY), m = v["int"](c.get_bottom() + b.offsetY); l < m;)
                    for (p = l++, r = v["int"](c.get_left() + b.offsetX), t = v["int"](c.get_right() + b.offsetX); r < t;) k = r++, g = p * E + 4 * k, k = (p + e) * q + 4 * (k + d), h[k] = f[g], h[k + 1] = f[g + 1], h[k + 2] = f[g + 2], h[k + 3] = f[g +
                        3];
            a.dirty = !0
        };
        ua.fillRect = function(a, b, c) {
            var d;
            d = a.get_transparent() ? (c & -16777216) >>> 24 : 255;
            var e = (c & 16711680) >>> 16,
                f = (c & 65280) >>> 8;
            c &= 255;
            var l = a.buffer.data;
            if (b.width == a.buffer.width && b.height == a.buffer.height && 0 == b.x && 0 == b.y && 0 == a.offsetX && 0 == a.offsetY)
                for (var g = a.buffer.width * a.buffer.height, h = 0, k = 0; k < g;) h = 4 * k++, l[h] = e, l[h + 1] = f, l[h + 2] = c, l[h + 3] = d;
            else {
                var g = 4 * a.buffer.width,
                    q, n = b.y + a.offsetY | 0,
                    h = v["int"](b.get_bottom() + a.offsetY),
                    k = b.x + a.offsetX | 0;
                for (b = v["int"](b.get_right() + a.offsetX); n < h;)
                    for (var m =
                            n++, p = k; p < b;) q = p++, q = m * g + 4 * q, l[q] = e, l[q + 1] = f, l[q + 2] = c, l[q + 3] = d
            }
            a.dirty = !0
        };
        ua.multiplyAlpha = function(a) {
            var b = a.buffer.data;
            if (null != b) {
                for (var c, d = b.length / 4 | 0, e = 0; e < d;) {
                    c = 4 * e++;
                    var f = ua.__alpha16[b[c + 3]];
                    b[c] = b[c] * f >> 16;
                    b[c + 1] = b[c + 1] * f >> 16;
                    b[c + 2] = b[c + 2] * f >> 16
                }
                a.buffer.premultiplied = !0;
                a.dirty = !0
            }
        };
        ua.unmultiplyAlpha = function(a) {
            for (var b = a.buffer.data, c, d, e = b.length / 4 | 0, f = 0; f < e;) c = 4 * f++, d = b[c + 3], 0 != d && (d = 255 / d, b[c] = ua.__clamp[b[c] * d | 0], b[c + 1] = ua.__clamp[b[c + 1] * d | 0], b[c + 2] = ua.__clamp[b[c + 2] * d | 0]);
            a.buffer.premultiplied = !1;
            a.dirty = !0
        };
        var Ac = function(a, b, c, d) {
            null == d && (d = 0);
            null == c && (c = 0);
            null == b && (b = 0);
            null == a && (a = 0);
            this.x = a;
            this.y = b;
            this.width = c;
            this.height = d
        };
        g["lime.math.Rectangle"] = Ac;
        Ac.__name__ = ["lime", "math", "Rectangle"];
        Ac.prototype = {
            offset: function(a, b) {
                this.x += a;
                this.y += b
            },
            __toFlashRectangle: function() {
                return null
            },
            get_bottom: function() {
                return this.y + this.height
            },
            get_left: function() {
                return this.x
            },
            get_right: function() {
                return this.x + this.width
            },
            get_top: function() {
                return this.y
            },
            __class__: Ac,
            __properties__: {
                get_top: "get_top",
                get_right: "get_right",
                get_left: "get_left",
                get_bottom: "get_bottom"
            }
        };
        var rc = function(a, b) {
            null == b && (b = 0);
            null == a && (a = 0);
            this.x = a;
            this.y = b
        };
        g["lime.math.Vector2"] = rc;
        rc.__name__ = ["lime", "math", "Vector2"];
        rc.prototype = {
            offset: function(a, b) {
                this.x += a;
                this.y += b
            },
            __toFlashPoint: function() {
                return null
            },
            __class__: rc
        };
        var Md = function(a) {
            this.onSecurityError = new ea;
            this.onProgress = new ea;
            this.onOpen = new ea;
            this.onIOError = new ea;
            this.onHTTPStatus = new ea;
            this.onComplete =
                new ea;
            this.bytesTotal = this.bytesLoaded = 0;
            this.set_dataFormat(db.TEXT);
            null != a && this.load(a)
        };
        g["lime.net.URLLoader"] = Md;
        Md.__name__ = ["lime", "net", "URLLoader"];
        Md.prototype = {
            getData: function() {
                return null
            },
            load: function(a) {
                this.requestUrl(a.url, a.method, a.data, a.formatRequestHeaders())
            },
            registerEvents: function(a) {
                var b = this,
                    c = this;
                "undefined" != typeof XMLHttpRequestProgressEvent && a.addEventListener("progress", r(this, this.__onProgress), !1);
                a.onreadystatechange = function() {
                    if (4 == a.readyState) {
                        var d;
                        try {
                            d =
                                a.status
                        } catch (e) {
                            d = null
                        }
                        void 0 == d && (d = null);
                        if (null != d)
                            for (var f = c.onHTTPStatus.listeners, l = c.onHTTPStatus.repeat, g = f.length, h = 0; h < g;) f[h](b, d), l[h] ? h++ : (c.onHTTPStatus.remove(f[h]), g--);
                        if (null != d && 200 <= d && 400 > d) c.__onData(a.response);
                        else if (null == d)
                            for (d = c.onIOError.listeners, f = c.onIOError.repeat, l = d.length, g = 0; g < l;) d[g](b, "Failed to connect or resolve host"), f[g] ? g++ : (c.onIOError.remove(d[g]), l--);
                        else if (12029 == d)
                            for (d = c.onIOError.listeners, f = c.onIOError.repeat, l = d.length, g = 0; g < l;) d[g](b, "Failed to connect to host"),
                                f[g] ? g++ : (c.onIOError.remove(d[g]), l--);
                        else if (12007 == d)
                            for (d = c.onIOError.listeners, f = c.onIOError.repeat, l = d.length, g = 0; g < l;) d[g](b, "Unknown host"), f[g] ? g++ : (c.onIOError.remove(d[g]), l--);
                        else if (0 == d) {
                            d = c.onIOError.listeners;
                            f = c.onIOError.repeat;
                            l = d.length;
                            for (g = 0; g < l;) d[g](b, "Unable to make request (may be blocked due to cross-domain permissions)"), f[g] ? g++ : (c.onIOError.remove(d[g]), l--);
                            d = c.onSecurityError.listeners;
                            f = c.onSecurityError.repeat;
                            l = d.length;
                            for (g = 0; g < l;) d[g](b, "Unable to make request (may be blocked due to cross-domain permissions)"),
                                f[g] ? g++ : (c.onSecurityError.remove(d[g]), l--)
                        } else
                            for (d = c.onIOError.listeners, f = c.onIOError.repeat, l = d.length, g = 0; g < l;) d[g](b, "Http Error #" + a.status), f[g] ? g++ : (c.onIOError.remove(d[g]), l--)
                    }
                }
            },
            requestUrl: function(a, b, c, d) {
                var e = new XMLHttpRequest;
                this.registerEvents(e);
                var f = "";
                if (x.__instanceof(c, fb)) switch (this.dataFormat[1]) {
                    case 0:
                        f = c.data.buffer;
                        break;
                    default:
                        f = c.readUTFBytes(c.length)
                } else if (x.__instanceof(c, Uf))
                    for (var l = 0, g = z.fields(c); l < g.length;) {
                        var h = g[l];
                        ++l;
                        0 != f.length && (f += "&");
                        f += encodeURIComponent(h) + "=" + M.urlEncode(z.field(c, h))
                    } else null != c && (f = c.toString());
                try {
                    if ("GET" == b && null != f && "" != f) {
                        var k = 1 >= a.split("?").length;
                        e.open("GET.html", a + (k ? "?" : "&") + v.string(f), !0);
                        f = ""
                    } else e.open(x.__cast(b, String), a, !0)
                } catch (q) {
                    d = this.onIOError.listeners;
                    f = this.onIOError.repeat;
                    a = d.length;
                    for (b = 0; b < a;) d[b](this, q.toString()), f[b] ? b++ : (this.onIOError.remove(d[b]), a--);
                    return
                }
                switch (this.dataFormat[1]) {
                    case 0:
                        e.responseType = "arraybuffer"
                }
                for (a = 0; a < d.length;) b = d[a], ++a, e.setRequestHeader(b.name,
                    b.value);
                e.send(f);
                d = this.onOpen.listeners;
                f = this.onOpen.repeat;
                a = d.length;
                for (b = 0; b < a;) d[b](this), f[b] ? b++ : (this.onOpen.remove(d[b]), a--);
                this.getData = function() {
                    return null != e.response ? e.response : e.responseText
                }
            },
            __onData: function(a) {
                a = this.getData();
                switch (this.dataFormat[1]) {
                    case 0:
                        this.data = fb.__ofBuffer(a);
                        break;
                    default:
                        this.data = v.string(a)
                }
                a = this.onComplete.listeners;
                for (var b = this.onComplete.repeat, c = a.length, d = 0; d < c;) a[d](this), b[d] ? d++ : (this.onComplete.remove(a[d]), c--)
            },
            __onProgress: function(a) {
                this.bytesLoaded =
                    a.loaded;
                this.bytesTotal = a.total;
                a = this.onProgress.listeners;
                for (var b = this.onProgress.repeat, c = a.length, d = 0; d < c;) a[d](this, this.bytesLoaded, this.bytesTotal), b[d] ? d++ : (this.onProgress.remove(a[d]), c--)
            },
            set_dataFormat: function(a) {
                a != db.BINARY || z.hasField(window, "ArrayBuffer") ? this.dataFormat = a : this.dataFormat = db.TEXT;
                return this.dataFormat
            },
            __class__: Md,
            __properties__: {
                set_dataFormat: "set_dataFormat"
            }
        };
        var db = g["lime.net.URLLoaderDataFormat"] = {
            __ename__: ["lime", "net", "URLLoaderDataFormat"],
            __constructs__: ["BINARY",
                "TEXT", "VARIABLES"
            ]
        };
        db.BINARY = ["BINARY", 0];
        db.BINARY.toString = p;
        db.BINARY.__enum__ = db;
        db.TEXT = ["TEXT", 1];
        db.TEXT.toString = p;
        db.TEXT.__enum__ = db;
        db.VARIABLES = ["VARIABLES", 2];
        db.VARIABLES.toString = p;
        db.VARIABLES.__enum__ = db;
        var hf = function(a) {
            null != a && (this.url = a);
            this.requestHeaders = [];
            this.method = "GET";
            this.contentType = null
        };
        g["lime.net.URLRequest"] = hf;
        hf.__name__ = ["lime", "net", "URLRequest"];
        hf.prototype = {
            formatRequestHeaders: function() {
                var a = this.requestHeaders;
                null == a && (a = []);
                if ("GET" == this.method ||
                    null == this.data) return a;
                if ("string" == typeof this.data || x.__instanceof(this.data, fb)) a = a.slice(), a.push(new kf("Content-Type", null != this.contentType ? this.contentType : "application/x-www-form-urlencoded"));
                return a
            },
            __class__: hf
        };
        var kf = function(a, b) {
            null == b && (b = "");
            null == a && (a = "");
            this.name = a;
            this.value = b
        };
        g["lime.net.URLRequestHeader"] = kf;
        kf.__name__ = ["lime", "net", "URLRequestHeader"];
        kf.prototype = {
            __class__: kf
        };
        var Uf = function() {};
        g["lime.net.URLVariables"] = Uf;
        Uf.__name__ = ["lime", "net", "URLVariables"];
        var Nd = function() {};
        g["lime.system.System"] = Nd;
        Nd.__name__ = ["lime", "system", "System"];
        Nd.embed = Tc.lime.embed = function(a, b, c, d, e) {
            var f = null,
                f = "string" == typeof a ? window.document.getElementById(x.__cast(a, String)) : null == a ? window.document.createElement("div") : a;
            a = null;
            null != d && (d = M.replace(d, "#", ""), a = -1 < d.indexOf("0x") ? v.parseInt(d) : v.parseInt("0x" + d));
            null == b && (b = 0);
            null == c && (c = 0);
            oa.config.background = a;
            oa.config.element = f;
            oa.config.width = b;
            oa.config.height = c;
            oa.config.assetsPrefix = e;
            oa.create()
        };
        Nd.getTimer = function() {
            return (new Date).getTime()
        };
        var eg = function() {};
        g["lime.ui.Gamepad"] = eg;
        eg.__name__ = ["lime", "ui", "Gamepad"];
        var ob = function() {};
        g["lime.ui._KeyModifier.KeyModifier_Impl_"] = ob;
        ob.__name__ = ["lime", "ui", "_KeyModifier", "KeyModifier_Impl_"];
        ob.__properties__ = {
            get_shiftKey: "get_shiftKey",
            get_metaKey: "get_metaKey",
            get_ctrlKey: "get_ctrlKey",
            get_altKey: "get_altKey"
        };
        ob.get_altKey = function(a) {
            return 0 < (a & 256) || 0 < (a & 512)
        };
        ob.get_ctrlKey = function(a) {
            return 0 < (a & 64) || 0 < (a & 128)
        };
        ob.get_metaKey =
            function(a) {
                return 0 < (a & 1024) || 0 < (a & 2048)
            };
        ob.get_shiftKey = function(a) {
            return 0 < (a & 1) || 0 < (a & 2)
        };
        var Sb = function() {};
        g["lime.ui.Mouse"] = Sb;
        Sb.__name__ = ["lime", "ui", "Mouse"];
        Sb.__properties__ = {
            set_cursor: "set_cursor"
        };
        Sb.set_cursor = function(a) {
            return ic.set_cursor(a)
        };
        var J = g["lime.ui.MouseCursor"] = {
            __ename__: ["lime", "ui", "MouseCursor"],
            __constructs__: "ARROW CROSSHAIR DEFAULT MOVE POINTER RESIZE_NESW RESIZE_NS RESIZE_NWSE RESIZE_WE TEXT WAIT WAIT_ARROW CUSTOM".split(" ")
        };
        J.ARROW = ["ARROW", 0];
        J.ARROW.toString =
            p;
        J.ARROW.__enum__ = J;
        J.CROSSHAIR = ["CROSSHAIR", 1];
        J.CROSSHAIR.toString = p;
        J.CROSSHAIR.__enum__ = J;
        J.DEFAULT = ["DEFAULT", 2];
        J.DEFAULT.toString = p;
        J.DEFAULT.__enum__ = J;
        J.MOVE = ["MOVE", 3];
        J.MOVE.toString = p;
        J.MOVE.__enum__ = J;
        J.POINTER = ["POINTER", 4];
        J.POINTER.toString = p;
        J.POINTER.__enum__ = J;
        J.RESIZE_NESW = ["RESIZE_NESW", 5];
        J.RESIZE_NESW.toString = p;
        J.RESIZE_NESW.__enum__ = J;
        J.RESIZE_NS = ["RESIZE_NS", 6];
        J.RESIZE_NS.toString = p;
        J.RESIZE_NS.__enum__ = J;
        J.RESIZE_NWSE = ["RESIZE_NWSE", 7];
        J.RESIZE_NWSE.toString = p;
        J.RESIZE_NWSE.__enum__ =
            J;
        J.RESIZE_WE = ["RESIZE_WE", 8];
        J.RESIZE_WE.toString = p;
        J.RESIZE_WE.__enum__ = J;
        J.TEXT = ["TEXT", 9];
        J.TEXT.toString = p;
        J.TEXT.__enum__ = J;
        J.WAIT = ["WAIT", 10];
        J.WAIT.toString = p;
        J.WAIT.__enum__ = J;
        J.WAIT_ARROW = ["WAIT_ARROW", 11];
        J.WAIT_ARROW.toString = p;
        J.WAIT_ARROW.__enum__ = J;
        J.CUSTOM = ["CUSTOM", 12];
        J.CUSTOM.toString = p;
        J.CUSTOM.__enum__ = J;
        var df = function(a) {
            this.onWindowRestore = new ea;
            this.onWindowResize = new ea;
            this.onWindowMove = new ea;
            this.onWindowMinimize = new ea;
            this.onWindowFullscreen = new ea;
            this.onWindowFocusOut =
                new ea;
            this.onWindowFocusIn = new ea;
            this.onWindowDeactivate = new ea;
            this.onWindowClose = new ea;
            this.onWindowActivate = new ea;
            this.onTouchStart = new ea;
            this.onTouchMove = new ea;
            this.onTouchEnd = new ea;
            this.onMouseWheel = new ea;
            this.onMouseUp = new ea;
            this.onMouseMove = new ea;
            this.onMouseDown = new ea;
            this.onKeyUp = new ea;
            this.onKeyDown = new ea;
            this.onGamepadDisconnect = new ea;
            this.onGamepadConnect = new ea;
            this.onGamepadButtonUp = new ea;
            this.onGamepadButtonDown = new ea;
            this.onGamepadAxisMove = new ea;
            this.config = a;
            this.__height =
                this.__width = 0;
            this.__fullscreen = !1;
            this.__y = this.__x = 0;
            null != a && (Object.prototype.hasOwnProperty.call(a, "width") && (this.__width = a.width), Object.prototype.hasOwnProperty.call(a, "height") && (this.__height = a.height), Object.prototype.hasOwnProperty.call(a, "fullscreen") && (this.__fullscreen = a.fullscreen));
            this.backend = new gd(this)
        };
        g["lime.ui.Window"] = df;
        df.__name__ = ["lime", "ui", "Window"];
        df.prototype = {
            create: function(a) {
                this.backend.create(a);
                null != this.currentRenderer && this.currentRenderer.create()
            },
            resize: function(a, b) {
                this.backend.resize(a, b);
                this.__width = a;
                this.__height = b
            },
            set_fullscreen: function(a) {
                return this.__fullscreen = this.backend.setFullscreen(a)
            },
            set_height: function(a) {
                this.resize(this.__width, a);
                return this.__height
            },
            set_width: function(a) {
                this.resize(a, this.__height);
                return this.__width
            },
            __class__: df,
            __properties__: {
                set_width: "set_width",
                set_height: "set_height",
                set_fullscreen: "set_fullscreen"
            }
        };
        var fb = function(a) {
            null == a && (a = 0);
            this.length = this.position = this.allocated = 0;
            0 < a && (this.allocated =
                a);
            this.___resizeBuffer(this.allocated);
            this.set_length(this.allocated)
        };
        g["lime.utils.ByteArray"] = fb;
        fb.__name__ = ["lime", "utils", "ByteArray"];
        fb.__ofBuffer = function(a) {
            var b = new fb;
            b.set_length(b.allocated = a.byteLength);
            b.data = new DataView(a);
            b.byteView = new Uint8Array(a);
            return b
        };
        fb.prototype = {
            readUTFBytes: function(a) {
                var b = "";
                for (a = this.position + a; this.position < a;) {
                    var c = this.data,
                        d = c.getUint8(this.position++);
                    if (128 > d) {
                        if (0 == d) break;
                        b += String.fromCharCode(d)
                    } else if (224 > d) b += String.fromCharCode((d &
                        63) << 6 | c.getUint8(this.position++) & 127);
                    else if (240 > d) var e = c.getUint8(this.position++),
                        b = b + String.fromCharCode((d & 31) << 12 | (e & 127) << 6 | c.getUint8(this.position++) & 127);
                    else var e = c.getUint8(this.position++),
                        f = c.getUint8(this.position++),
                        b = b + String.fromCharCode((d & 15) << 18 | (e & 127) << 12 | f << 6 & 127 | c.getUint8(this.position++) & 127)
                }
                return b
            },
            writeByte: function(a) {
                var b = this.position + 1;
                this.length < b && (this.allocated < b ? this.___resizeBuffer(this.allocated = v["int"](Math.max(b, 2 * this.allocated))) : this.allocated >
                    2 * b && this.___resizeBuffer(this.allocated = b), this.length = b, b);
                this.data.setInt8(this.position, a);
                this.position += 1
            },
            writeUTFBytes: function(a) {
                for (var b = 0, c = a.length; b < c;) {
                    var d = b++,
                        d = a.charCodeAt(d);
                    127 >= d ? this.writeByte(d) : (2047 >= d ? this.writeByte(192 | d >> 6) : (65535 >= d ? this.writeByte(224 | d >> 12) : (this.writeByte(240 | d >> 18), this.writeByte(128 | d >> 12 & 63)), this.writeByte(128 | d >> 6 & 63)), this.writeByte(128 | d & 63))
                }
            },
            __get: function(a) {
                return this.data.getInt8(a)
            },
            ___resizeBuffer: function(a) {
                var b = this.byteView,
                    c = new Uint8Array(a);
                null != b && (b.length <= a ? c.set(b) : c.set(b.subarray(0, a)));
                this.byteView = c;
                this.data = new DataView(c.buffer)
            },
            __set: function(a, b) {
                this.data.setUint8(a, b)
            },
            set_length: function(a) {
                this.allocated < a ? this.___resizeBuffer(this.allocated = v["int"](Math.max(a, 2 * this.allocated))) : this.allocated > 2 * a && this.___resizeBuffer(this.allocated = a);
                return this.length = a
            },
            __class__: fb,
            __properties__: {
                set_length: "set_length"
            }
        };
        var fa = function() {
            fa._instance = this;
            this.init()
        };
        g["managers.LevelManager"] = fa;
        fa.__name__ = ["managers", "LevelManager"];
        fa.__interfaces__ = [oc, dc];
        fa.__properties__ = {
            get_instance: "get_instance"
        };
        fa._instance = null;
        fa.get_instance = function() {
            null == fa._instance && (fa._instance = new fa);
            return fa._instance
        };
        fa.prototype = {
            init: function() {
                N.get_instance().signToNotify("incomeCoin", this);
                N.get_instance().signToNotify("completePath", this);
                this.angleLeftRadians = C.toRad(-153);
                this.angleRightRadians = C.toRad(-26);
                this.vectorLeft = new ec(1, 0);
                var a = this.angleLeftRadians,
                    b = this.vectorLeft;
                Math.cos(a);
                Math.sin(a);
                var c = b.x,
                    d = b.y;
                b.x = c * Math.cos(a) - d * Math.sin(a);
                b.y = c * Math.sin(a) + d * Math.cos(a);
                b;
                a = this.vectorLeft;
                b = Math.sqrt(a.x * a.x + a.y * a.y);
                0 < b && (a.x /= b, a.y /= b, a);
                a;
                this.vectorRight = new ec(1, 0);
                a = this.angleRightRadians;
                b = this.vectorRight;
                Math.cos(a);
                Math.sin(a);
                c = b.x;
                d = b.y;
                b.x = c * Math.cos(a) - d * Math.sin(a);
                b.y = c * Math.sin(a) + d * Math.cos(a);
                b;
                a = this.vectorRight;
                b = Math.sqrt(a.x * a.x + a.y * a.y);
                0 < b && (a.x /= b, a.y /= b, a);
                a;
                a = Pa.instance.layersManager.getLayer("debug");
                this.debug = new y;
                a.addChild(this.debug)
            },
            receiveNotify: function(a, b, c) {
                switch (a) {
                    case "incomeCoin":
                        this.incomeCoin();
                        break;
                    case "completePath":
                        this.updateScore()
                }
            },
            build: function() {},
            incomeCoin: function() {
                B.get_instance().changeCoins(1);
                var a = B.get_instance().getCoins();
                N.get_instance().postNotify("levelEvent", this, {
                    id: "changeCoins",
                    value: a
                })
            },
            calcPosOnPath: function(a, b, c, d) {
                var e = {
                    x: 0,
                    y: 0
                };
                d = 3 == d ? this.vectorLeft : this.vectorRight;
                var f = d = new ec(d.x, d.y),
                    l;
                l = Math.sqrt(f.x * f.x + f.y * f.y);
                0 < l && (f.x /= l, f.y /= l, f);
                f;
                f.x *= c;
                f.y *= c;
                f;
                f;
                e.x = a + d.x;
                e.y = b + d.y;
                return e
            },
            updateScore: function() {
                B.get_instance().score += 1;
                Pa.instance.updateScore(B.get_instance().score)
            },
            free: function() {
                fa._instance = null
            },
            __class__: fa
        };
        var Ca = function() {
            Ca._instance = this;
            this.init()
        };
        g["managers.ScaleManager"] = Ca;
        Ca.__name__ = ["managers", "ScaleManager"];
        Ca.__interfaces__ = [oc];
        Ca.__properties__ = {
            get_instance: "get_instance"
        };
        Ca.create = function() {
            return new Ca
        };
        Ca._instance = null;
        Ca.get_instance = function() {
            null == Ca._instance && (Ca._instance = new Ca);
            return Ca._instance
        };
        Ca.prototype = {
            init: function() {
                this.listeners = [];
                this.selectGraphpack();
                S.current.stage.align = ka.TOP_LEFT;
                S.current.stage.scaleMode = Oa.NO_SCALE;
                m.get_instance().viewX = 0;
                m.get_instance().viewY = 0;
                m.get_instance().scaledWidth = m.get_instance().nativeWidth;
                m.get_instance().scaledHeight = m.get_instance().nativeHeight;
                S.current.stage.addEventListener(w.RESIZE, r(this, this.newResize));
                this.newResize()
            },
            selectGraphpack: function() {
                var a = this.getScreenSize();
                m.get_instance().width = a.x;
                m.get_instance().height = a.y;
                var a = this.searchProperPack([{
                        scale: "1",
                        name: "hd"
                    }], m.get_instance().width, m.get_instance().height),
                    b = v.parseFloat(a.scale);
                m.get_instance();
                m.get_instance();
                m.get_instance().packWidth = m.get_instance().nativeWidth * b | 0;
                m.get_instance().packHeight = m.get_instance().nativeHeight * b | 0;
                m.get_instance().packScale = b;
                m.get_instance().packFolder = a.name
            },
            getScreenSize: function() {
                var a = S.current.stage.stageWidth,
                    b = S.current.stage.stageHeight,
                    a = window.innerWidth | 0,
                    b = window.innerHeight | 0,
                    c;
                "landscape" == m.get_instance().nativeOrientation ?
                    a < b && (c = a, a = b, b = c) : "portrait" == m.get_instance().nativeOrientation && a > b && (c = a, a = b, b = c);
                return {
                    x: a,
                    y: b
                }
            },
            searchProperPack: function(a, b, c) {
                for (var d = null, e = 0, f, l, g = 0, h = a.length; g < h;) {
                    var k = g++;
                    if (null != a[k].only) {
                        if ("desktop" == a[k].only && 1 == Ka.onMobile) continue;
                        if ("mobile" == a[k].only && 0 == Ka.onMobile) continue
                    }
                    l = v.parseFloat(a[k].scale);
                    f = b / (m.get_instance().nativeWidth * l);
                    l = c / (m.get_instance().nativeHeight * l);
                    f = Math.min(f, l);
                    f = C.roundDec(f, 5);
                    if (1 == f || 1 < f && 1.15 >= f) d = a[k], e = f;
                    1 > f && f > e && (d = a[k], e = f)
                }
                if (null ==
                    d)
                    for (g = 0, h = a.length; g < h;) {
                        k = g++;
                        if (null != a[k].only) {
                            if ("desktop" == a[k].only && 1 == Ka.onMobile) continue;
                            if ("mobile" == a[k].only && 0 == Ka.onMobile) continue
                        }
                        l = v.parseFloat(a[k].scale);
                        f = b / (m.get_instance().nativeWidth * l);
                        l = c / (m.get_instance().nativeHeight * l);
                        f = Math.min(f, l);
                        f = C.roundDec(f, 5);
                        if (null == d || f < e) d = a[k], e = f
                    }
                return d
            },
            addListener: function(a) {
                this.listeners.push(a);
                a.resize()
            },
            delListener: function(a) {
                u.remove(this.listeners, a)
            },
            newResize: function(a) {
                a = window.innerWidth | 0;
                var b = window.innerHeight |
                    0;
                m.get_instance().width = a;
                m.get_instance().height = b;
                a = m.get_instance().width / m.get_instance().nativeWidth;
                b = m.get_instance().height / m.get_instance().nativeHeight;
                m.get_instance().nativeScale = Math.min(a, b);
                if (m.get_instance().width != this.lastStageWidth || m.get_instance().height != this.lastStageHeight) {
                    this.lastStageWidth = m.get_instance().width;
                    this.lastStageHeight = m.get_instance().height;
                    a = m.get_instance().width / m.get_instance().packWidth;
                    var b = m.get_instance().height / m.get_instance().packHeight,
                        c =
                        Math.min(a, b);
                    m.get_instance().scale = c;
                    m.get_instance().viewX = 0;
                    m.get_instance().viewY = 0;
                    m.get_instance().scaledWidth = m.get_instance().packWidth * m.get_instance().scale;
                    m.get_instance().scaledHeight = m.get_instance().packHeight * m.get_instance().scale;
                    c = 0;
                    a > b ? (c = (m.get_instance().width - m.get_instance().scaledWidth) / 2, m.get_instance().viewX = c) : (c = (m.get_instance().height - m.get_instance().scaledHeight) / 2, m.get_instance().viewY = c);
                    this.updateListeners()
                }
            },
            updateListeners: function() {
                for (var a = this.listeners.length,
                        b = 0; b < a;) {
                    var c = b++;
                    this.listeners[c].resize()
                }
            },
            __class__: Ca
        };
        var ba = function() {};
        g["managers.TweenManager"] = ba;
        ba.__name__ = ["managers", "TweenManager"];
        ba.animate = function(a, b) {
            var c = 0;
            null != b.dir && (c = b.dir);
            var d = {
                    alpha: 1
                },
                e = 0;
            null != b.delay && (e = b.delay);
            var f = .6;
            null != b.time && (f = b.time);
            switch (c) {
                case 3:
                    d.x = a.get_x();
                    a.set_x(a.get_x() + 100);
                    break;
                case 4:
                    d.x = a.get_x();
                    a.set_x(a.get_x() - 100);
                    break;
                case 1:
                    d.y = a.get_y();
                    a.set_y(a.get_y() + 100);
                    break;
                case 2:
                    d.y = a.get_y(), a.set_y(a.get_y() - 100)
            }
            a.set_alpha(0);
            c = Bc.get_easeOut();
            null != b.ease && (c = b.ease);
            A.tween(a, f, d, !1).ease(c).delay(e)
        };
        ba.animateAlpha = function(a, b) {
            var c = 0;
            null != b.delay && (c = b.delay);
            a.set_alpha(0);
            A.tween(a, .6, {
                alpha: 1
            }, !1).ease(na.get_easeOut()).delay(c)
        };
        ba.stopTween = function(a) {
            A.stop(a, null, !1, !1)
        };
        var jd = function(a) {
            Va.call(this, a)
        };
        g["menus.PrizeMenu"] = jd;
        jd.__name__ = ["menus", "PrizeMenu"];
        jd.__super__ = Va;
        jd.prototype = t(Va.prototype, {
            createUi: function() {
                Va.prototype.createUi.call(this);
                var a = m.formatAsset("assets/images/%25p%25/panel.html");
                this.panel = ta.buildSprite(a);
                this.panel.set_x(360);
                this.panel.set_y(600);
                this.addChild(this.panel)
            },
            showPrize: function(a, b) {
                null == b && (b = -1);
                switch (a) {
                    case "hero":
                        this.createHeroPrize(b);
                        break;
                    case "coins":
                        this.createCoinsPrize(b);
                        break;
                    case "record":
                        this.createRecord()
                }
                this.show()
            },
            createCoinsPrize: function(a) {
                this.createCoins(a);
                L.get_instance().playSound("achievement")
            },
            createHeroPrize: function(a) {
                var b = new Od,
                    c = m.formatAsset("assets/images/%25p%25/spritelists/shop.html"),
                    d = m.formatAsset("assets/images/%25p%25/spritelists/shop-2.html");
                this.hero = b.getSprite("hero_" + a + "_1", c, d);
                this.hero.set_x(20);
                this.hero.set_y(5);
                this.hero.set_scale(1.5);
                this.panel.addChild(this.hero);
                ba.animate(this.hero, {
                    dir: 2,
                    delay: .15,
                    ease: Bc.get_easeOut()
                });
                N.get_instance().postNotify("prize", this, {
                    id: "hero",
                    value: a
                });
                L.get_instance().playSound("achievement")
            },
            createCoins: function(a, b, c) {
                null == c && (c = 0);
                null == b && (b = 0);
                null == this.field ? (this.field = new qc("assets/images/%25p%25/coins_ui2.html", 20, 50), this.field.label.set_color(3422005), this.field.label.set_size(120),
                    this.field.label.set_fieldHeight(150), this.field.label.set_y(-60), this.field.set_x(b), this.field.set_y(c), this.panel.addChild(this.field)) : (this.field.set_alpha(1), this.field.set_x(b), this.field.set_y(c));
                this.field.update(a);
                ba.animate(this.field, {
                    dir: 2,
                    delay: .15,
                    ease: Bc.get_easeOut()
                });
                N.get_instance().postNotify("prize", this, {
                    id: "coins",
                    value: a
                })
            },
            completeShow: function() {
                A.timer(2).onComplete(r(this, this.hide))
            },
            createRecord: function() {
                var a = Da.get_instance().getPhrase("label2").toUpperCase();
                this.recordTitle = new qa;
                this.recordTitle.set_color(3422005);
                this.recordTitle.set_size(55);
                this.recordTitle.set_fieldWidth(400);
                this.recordTitle.set_fieldHeight(100);
                this.recordTitle.set_align("center");
                this.recordTitle.set_x(-180);
                this.recordTitle.set_y(-105);
                this.recordTitle.set_text(a);
                this.panel.addChild(this.recordTitle);
                ba.animate(this.recordTitle, {
                    delay: .15
                });
                this.createCoins(10, 0, 50);
                L.get_instance().playSound("new_record")
            },
            hide: function() {
                Va.prototype.hide.call(this);
                null != this.hero && (this.panel.removeChild(this.hero),
                    this.hero = null);
                null != this.field && this.field.set_alpha(0);
                null != this.recordTitle && (this.panel.removeChild(this.recordTitle), this.recordTitle = null)
            },
            free: function() {
                Va.prototype.free.call(this);
                this.panel = this.coinsField = null;
                null != this.field && (this.field.free(), this.field = null);
                this.hero = null
            },
            __class__: jd
        });
        var kd = function(a) {
            Va.call(this, a)
        };
        g["menus.ReviveMenu"] = kd;
        kd.__name__ = ["menus", "ReviveMenu"];
        kd.__interfaces__ = [dc];
        kd.__super__ = Va;
        kd.prototype = t(Va.prototype, {
            createUi: function() {
                Va.prototype.createUi.call(this);
                this.price = 20;
                N.get_instance().signToNotify("prize", this);
                var a = m.formatAsset("assets/images/%25p%25/panel.html"),
                    a = ta.buildSprite(a);
                a.set_x(360);
                a.set_y(600);
                this.addChild(a);
                var b = B.get_instance().getCoins();
                this.coinsPanel = new qc("assets/images/%25p%25/coins_ui.html", 14, 40);
                this.coinsPanel.label.set_color(3422005);
                this.coinsPanel.update(b);
                this.coinsPanel.set_x(20);
                this.coinsPanel.set_y(-110);
                a.addChild(this.coinsPanel);
                ia.get_instance().isEnabledIncentiviseButton() && (b = m.formatAsset("assets/images/%25p%25/buttons/btn_plus.html"),
                    b = new xa(b), b.addEventListener("complete", r(this, this.buyCoins)), b.setSoundEffect("click"), b.set_y(-3), this.coinsPanel.addButton(b, 55));
                b = m.formatAsset("assets/images/%25p%25/buttons/btn_back.html");
                b = new xa(b);
                b.onlyFirstClick = !0;
                b.addEventListener("complete", r(this, this.onClose));
                b.set_x(-230);
                b.set_y(-130);
                b.setSoundEffect("click");
                a.addChild(b);
                b = new qa;
                b.setSystemFont();
                b.set_size(45);
                b.set_fieldWidth(700);
                b.set_fieldHeight(200);
                b.set_align("center");
                b.set_x(-320);
                b.set_y(-30);
                var c = Da.get_instance().getPhrase("label1").toUpperCase();
                b.set_text(c);
                b.mouseEnabled = !1;
                a.addChild(b);
                b = m.formatAsset("assets/images/%25p%25/buttons/btn_coins.html");
                this.saveCoinsButton = new xa(b);
                this.saveCoinsButton.addEventListener("complete", r(this, this.saveByCoins));
                this.saveCoinsButton.set_x(-90);
                this.saveCoinsButton.set_y(130);
                this.saveCoinsButton.setSoundEffect("click");
                a.addChild(this.saveCoinsButton);
                this.statusField = new qa;
                this.statusField.set_color(14804194);
                this.statusField.set_size(34);
                this.statusField.set_fieldWidth(60);
                this.statusField.set_fieldHeight(40);
                this.statusField.set_align("left");
                this.statusField.set_x(-7);
                this.statusField.set_y(-16);
                this.saveCoinsButton.setLabel(this.statusField);
                ia.get_instance().isEnabledIncentiviseButton() ? (b = m.formatAsset("assets/images/%25p%25/buttons/btn_video2.html"), this.videoButton = new xa(b), this.videoButton.addEventListener("complete", r(this, this.watchVideo)), this.videoButton.set_x(140), this.videoButton.set_y(130), this.videoButton.setSoundEffect("click"), a.addChild(this.videoButton)) : this.saveCoinsButton.set_x(30)
            },
            show: function() {
                this.statusField.set_text("" + this.price);
                var a = B.get_instance().getCoins();
                this.coinsPanel.update(a);
                L.get_instance().playSound("revive_window");
                Va.prototype.show.call(this)
            },
            buyCoins: function(a) {
                L.get_instance().pauseMusic(true);
                ia.get_instance().triggerIncentivise(r(this, this.onCompleteBuy));
                null != a && Ba.get_instance().save("buyCoins")
            },
            onCompleteBuy: function(a) {
                0 != a && (L.get_instance().playSound("achievement"), null == this.prizeMenu && (this.prizeMenu = new jd, this.addChild(this.prizeMenu)), this.prizeMenu.showPrize("coins",
                    100))
                L.get_instance().pauseMusic(false);
            },
            watchVideo: function(a) {
                this.videoButton.setEnabled(!1);
                L.get_instance().pauseMusic(true);
                ia.get_instance().triggerIncentivise(r(this, this.onCompleteVideo));
                Ba.get_instance().save("watchVideoAds")
            },
            onCompleteVideo: function(a) {
                0 != a && this.saveHero()
                L.get_instance().pauseMusic(false);
            },
            onClose: function(a) {
                this.hide();
                N.get_instance().postNotify("levelEvent", this, {
                    id: "loseForce"
                })
            },
            saveByCoins: function(a) {
                B.get_instance().getCoins() < this.price ? ia.get_instance().isEnabledIncentiviseButton() ? this.buyCoins() : A.tween(this.coinsPanel, .5, {
                        scaleX: 2.5,
                        scaleY: 2.5
                    }).ease(na.get_easeInOut()).repeat(2).reverse() :
                    (B.get_instance().changeCoins(-this.price), this.saveHero(), this.price *= 2, a = B.get_instance().getCoins(), N.get_instance().postNotify("levelEvent", this, {
                        id: "changeCoins",
                        value: a
                    }), Ba.get_instance().save("saveByCoins", "" + this.price))
            },
            saveHero: function() {
                L.get_instance().playSound("achievement");
                this.hide();
                N.get_instance().postNotify("revive")
            },
            receiveNotify: function(a, b, c) {
                this.onPrize(c.id, c.value)
            },
            onPrize: function(a, b) {
                B.get_instance().changeCoins(b);
                var c = B.get_instance().getCoins();
                N.get_instance().postNotify("levelEvent",
                    this, {
                        id: "changeCoins",
                        value: c
                    });
                this.coinsPanel.update(c);
                ba.animateAlpha(this.coinsPanel, {
                    delay: 2
                })
            },
            free: function() {
                Va.prototype.free.call(this);
                N.get_instance().unSignToNotify("prize", this);
                this.coinsPanel.free();
                this.coinsPanel = null;
                null != this.prizeMenu && (this.prizeMenu.free(), this.prizeMenu = null)
            },
            __class__: kd
        });
        var Pd = function() {};
        g["motion.actuators.IGenericActuator"] = Pd;
        Pd.__name__ = ["motion", "actuators", "IGenericActuator"];
        Pd.prototype = {
            __class__: Pd
        };
        var kc = function(a, b, c) {
            this._autoVisible = !0;
            this._delay = 0;
            this._reflect = !1;
            this._repeat = 0;
            this.special = this._snapping = this._smartRotation = this._reverse = !1;
            this.target = a;
            this.properties = c;
            this.duration = b;
            this._ease = A.defaultEase
        };
        g["motion.actuators.GenericActuator"] = kc;
        kc.__name__ = ["motion", "actuators", "GenericActuator"];
        kc.__interfaces__ = [Pd];
        kc.prototype = {
            apply: function() {
                for (var a = 0, b = z.fields(this.properties); a < b.length;) {
                    var c = b[a];
                    ++a;
                    Object.prototype.hasOwnProperty.call(this.target, c) ? z.setField(this.target, c, z.field(this.properties,
                        c)) : z.setProperty(this.target, c, z.field(this.properties, c))
                }
            },
            autoVisible: function(a) {
                null == a && (a = !0);
                this._autoVisible = a;
                return this
            },
            callMethod: function(a, b) {
                null == b && (b = []);
                return a.apply(a, b)
            },
            change: function() {
                null != this._onUpdate && this.callMethod(this._onUpdate, this._onUpdateParams)
            },
            complete: function(a) {
                null == a && (a = !0);
                a && (this.change(), null != this._onComplete && this.callMethod(this._onComplete, this._onCompleteParams));
                A.unload(this)
            },
            delay: function(a) {
                this._delay = a;
                return this
            },
            ease: function(a) {
                this._ease =
                    a;
                return this
            },
            move: function() {},
            onComplete: function(a, b) {
                this._onComplete = a;
                this._onCompleteParams = null == b ? [] : b;
                0 == this.duration && this.complete();
                return this
            },
            onRepeat: function(a, b) {
                this._onRepeat = a;
                this._onRepeatParams = null == b ? [] : b;
                return this
            },
            onUpdate: function(a, b) {
                this._onUpdate = a;
                this._onUpdateParams = null == b ? [] : b;
                return this
            },
            onPause: function(a, b) {
                this._onPause = a;
                this._onPauseParams = null == b ? [] : b;
                return this
            },
            onResume: function(a, b) {
                this._onResume = a;
                this._onResumeParams = null == b ? [] : b;
                return this
            },
            pause: function() {
                null != this._onPause && this.callMethod(this._onPause, this._onPauseParams)
            },
            reflect: function(a) {
                null == a && (a = !0);
                this._reflect = a;
                this.special = !0;
                return this
            },
            repeat: function(a) {
                null == a && (a = -1);
                this._repeat = a;
                return this
            },
            resume: function() {
                null != this._onResume && this.callMethod(this._onResume, this._onResumeParams)
            },
            reverse: function(a) {
                null == a && (a = !0);
                this._reverse = a;
                this.special = !0;
                return this
            },
            smartRotation: function(a) {
                null == a && (a = !0);
                this._smartRotation = a;
                this.special = !0;
                return this
            },
            snapping: function(a) {
                null == a && (a = !0);
                this._snapping = a;
                this.special = !0;
                return this
            },
            stop: function(a, b, c) {},
            __class__: kc
        };
        var la = function(a, b, c) {
            this.active = !0;
            this.propertyDetails = [];
            this.toggleVisible = this.setVisible = this.initialized = this.cacheVisible = this.paused = this.sendChange = !1;
            this.startTime = S.getTimer() / 1E3;
            kc.call(this, a, b, c);
            la.addedEvent || (la.addedEvent = !0, S.current.stage.addEventListener(w.ENTER_FRAME, la.stage_onEnterFrame))
        };
        g["motion.actuators.SimpleActuator"] = la;
        la.__name__ = ["motion",
            "actuators", "SimpleActuator"
        ];
        la.stage_onEnterFrame = function(a) {
            a = S.getTimer() / 1E3;
            for (var b, c = 0, d = 0, e = la.actuatorsLength; d < e;) d++, b = la.actuators[c], null != b && b.active ? (a >= b.timeOffset && b.update(a), c++) : (la.actuators.splice(c, 1), --la.actuatorsLength)
        };
        la.__super__ = kc;
        la.prototype = t(kc.prototype, {
            setField_motion_actuators_SimpleActuator_T: function(a, b, c) {
                Object.prototype.hasOwnProperty.call(a, b) ? a[b] = c : z.setProperty(a, b, c)
            },
            autoVisible: function(a) {
                null == a && (a = !0);
                this._autoVisible = a;
                a || (this.toggleVisible = !1, this.setVisible && this.setField_motion_actuators_SimpleActuator_T(this.target, "visible", this.cacheVisible));
                return this
            },
            delay: function(a) {
                this._delay = a;
                this.timeOffset = this.startTime + a;
                return this
            },
            getField: function(a, b) {
                var c = null;
                return c = Object.prototype.hasOwnProperty.call(a, b) ? z.field(a, b) : z.getProperty(a, b)
            },
            initialize: function() {
                for (var a, b = 0, c = z.fields(this.properties); b < c.length;) {
                    var d = c[b];
                    ++b;
                    var e = !0;
                    !Object.prototype.hasOwnProperty.call(this.target, d) || this.target.__properties__ &&
                        this.target.__properties__["set_" + d] ? (e = !1, a = z.getProperty(this.target, d)) : a = z.field(this.target, d);
                    if ("number" == typeof a) {
                        var f = this.getField(this.properties, d);
                        null == a && (a = 0);
                        null == f && (f = 0);
                        a = new Eb(this.target, d, a, f - a, e);
                        this.propertyDetails.push(a)
                    }
                }
                this.detailsLength = this.propertyDetails.length;
                this.initialized = !0
            },
            move: function() {
                (this.toggleVisible = Object.prototype.hasOwnProperty.call(this.properties, "alpha") && x.__instanceof(this.target, V)) && 0 != this.properties.alpha && !this.getField(this.target,
                    "visible") && (this.setVisible = !0, this.cacheVisible = this.getField(this.target, "visible"), this.setField_motion_actuators_SimpleActuator_T(this.target, "visible", !0));
                this.timeOffset = this.startTime;
                la.actuators.push(this);
                ++la.actuatorsLength
            },
            onUpdate: function(a, b) {
                this._onUpdate = a;
                this._onUpdateParams = null == b ? [] : b;
                this.sendChange = !0;
                return this
            },
            pause: function() {
                this.paused || (this.paused = !0, kc.prototype.pause.call(this), this.pauseTime = S.getTimer())
            },
            resume: function() {
                this.paused && (this.paused = !1, this.timeOffset +=
                    (S.getTimer() - this.pauseTime) / 1E3, kc.prototype.resume.call(this))
            },
            setProperty: function(a, b) {
                a.isField ? a.target[a.propertyName] = b : z.setProperty(a.target, a.propertyName, b)
            },
            stop: function(a, b, c) {
                if (this.active)
                    if (null == a) this.active = !1, b && this.apply(), this.complete(c);
                    else {
                        var d = 0;
                        for (a = z.fields(a); d < a.length;) {
                            var e = a[d];
                            ++d;
                            if (Object.prototype.hasOwnProperty.call(this.properties, e)) {
                                this.active = !1;
                                b && this.apply();
                                this.complete(c);
                                break
                            }
                        }
                    }
            },
            update: function(a) {
                if (!this.paused) {
                    var b, c, d = (a - this.timeOffset) /
                        this.duration;
                    1 < d && (d = 1);
                    this.initialized || this.initialize();
                    if (this.special) {
                        c = this._reverse ? this._ease.calculate(1 - d) : this._ease.calculate(d);
                        for (var e, f = 0, l = this.detailsLength; f < l;) b = f++, b = this.propertyDetails[b], !this._smartRotation || "rotation" != b.propertyName && "rotationX" != b.propertyName && "rotationY" != b.propertyName && "rotationZ" != b.propertyName ? e = b.start + b.change * c : (e = b.change % 360, 180 < e ? e -= 360 : -180 > e && (e += 360), e = b.start + e * c), this._snapping ? this.setProperty(b, Math.round(e)) : b.isField ? b.target[b.propertyName] =
                            e : z.setProperty(b.target, b.propertyName, e)
                    } else
                        for (c = this._ease.calculate(d), f = 0, l = this.detailsLength; f < l;) b = f++, b = this.propertyDetails[b], this.setProperty(b, b.start + b.change * c);
                    if (1 == d) {
                        if (0 == this._repeat) {
                            this.active = !1;
                            this.toggleVisible && 0 == this.getField(this.target, "alpha") && this.setField_motion_actuators_SimpleActuator_T(this.target, "visible", !1);
                            this.complete(!0);
                            return
                        }
                        null != this._onRepeat && this.callMethod(this._onRepeat, this._onRepeatParams);
                        this._reflect && (this._reverse = !this._reverse);
                        this.startTime = a;
                        this.timeOffset = this.startTime + this._delay;
                        0 < this._repeat && this._repeat--
                    }
                    this.sendChange && this.change()
                }
            },
            __class__: la
        });
        var lf = function() {};
        g["motion.easing.Expo"] = lf;
        lf.__name__ = ["motion", "easing", "Expo"];
        lf.__properties__ = {
            get_easeOut: "get_easeOut"
        };
        lf.get_easeOut = function() {
            return new Qd
        };
        var tb = function() {};
        g["motion.easing.IEasing"] = tb;
        tb.__name__ = ["motion", "easing", "IEasing"];
        tb.prototype = {
            __class__: tb
        };
        var Qd = function() {};
        g["motion.easing.ExpoEaseOut"] = Qd;
        Qd.__name__ = ["motion",
            "easing", "ExpoEaseOut"
        ];
        Qd.__interfaces__ = [tb];
        Qd.prototype = {
            calculate: function(a) {
                return 1 == a ? 1 : 1 - Math.pow(2, -10 * a)
            },
            __class__: Qd
        };
        var A = function() {};
        g["motion.Actuate"] = A;
        A.__name__ = ["motion", "Actuate"];
        A.apply = function(a, b, c) {
            A.stop(a, b);
            null == c && (c = A.defaultActuator);
            a = O.createInstance(c, [a, 0, b]);
            a.apply();
            return a
        };
        A.getLibrary = function(a, b) {
            null == b && (b = !0);
            null == A.targetLibraries.h.__keys__[a.__id__] && b && A.targetLibraries.set(a, []);
            return A.targetLibraries.h[a.__id__]
        };
        A.pauseAll = function() {
            for (var a =
                    A.targetLibraries.iterator(); a.hasNext();)
                for (var b = a.next(), c = 0; c < b.length;) {
                    var d = b[c];
                    ++c;
                    d.pause()
                }
        };
        A.resumeAll = function() {
            for (var a = A.targetLibraries.iterator(); a.hasNext();)
                for (var b = a.next(), c = 0; c < b.length;) {
                    var d = b[c];
                    ++c;
                    d.resume()
                }
        };
        A.stop = function(a, b, c, d) {
            null == d && (d = !0);
            null == c && (c = !1);
            if (null != a)
                if (x.__instanceof(a, Pd)) a.stop(null, c, d);
                else if (a = A.getLibrary(a, !1), null != a) {
                if ("string" == typeof b) {
                    var e = {};
                    z.setField(e, b, null);
                    b = e
                } else if (b instanceof Array && null == b.__enum__) {
                    var e = {},
                        f = 0;
                    for (b = x.__cast(b, Array); f < b.length;) {
                        var l = b[f];
                        ++f;
                        z.setField(e, l, null)
                    }
                    b = e
                }
                for (e = a.length - 1; 0 <= e;) a[e].stop(b, c, d), e--
            }
        };
        A.timer = function(a, b) {
            return A.tween(new Rd(0), a, new Rd(1), !1, b)
        };
        A.tween = function(a, b, c, d, e) {
            null == d && (d = !0);
            if (null != a) {
                if (0 < b) {
                    null == e && (e = A.defaultActuator);
                    a = O.createInstance(e, [a, b, c]);
                    b = A.getLibrary(a.target);
                    if (d) {
                        for (d = b.length - 1; 0 <= d;) b[d].stop(a.properties, !1, !1), d--;
                        b = A.getLibrary(a.target)
                    }
                    b.push(a);
                    a.move();
                    return a
                }
                return A.apply(a, c, e)
            }
            return null
        };
        A.unload =
            function(a) {
                var b = a.target;
                null != A.targetLibraries.h.__keys__[b.__id__] && (u.remove(A.targetLibraries.h[b.__id__], a), 0 == A.targetLibraries.h[b.__id__].length && A.targetLibraries.remove(b))
            };
        var Rd = function(a) {
            this.progress = a
        };
        g["motion._Actuate.TweenTimer"] = Rd;
        Rd.__name__ = ["motion", "_Actuate", "TweenTimer"];
        Rd.prototype = {
            __class__: Rd
        };
        var ld = function() {};
        g["motion.IComponentPath"] = ld;
        ld.__name__ = ["motion", "IComponentPath"];
        ld.prototype = {
            __class__: ld
        };
        var mf = function(a, b, c) {
            this.filterIndex = -1;
            la.call(this,
                a, b, c);
            if (x.__instanceof(c.filter, Yf))
                for (this.filterClass = c.filter, 0 == a.get_filters().length && a.set_filters([O.createInstance(this.filterClass, [])]), b = 0, a = a.get_filters(); b < a.length;) c = a[b], ++b, x.__instanceof(c, this.filterClass) && (this.filter = c);
            else this.filterIndex = c.filter, this.filter = a.get_filters()[this.filterIndex]
        };
        g["motion.actuators.FilterActuator"] = mf;
        mf.__name__ = ["motion", "actuators", "FilterActuator"];
        mf.__super__ = la;
        mf.prototype = t(la.prototype, {
            setField_openfl_display_DisplayObject: function(a,
                b, c) {
                Object.prototype.hasOwnProperty.call(a, b) ? a[b] = c : z.setProperty(a, b, c)
            },
            apply: function() {
                for (var a = 0, b = z.fields(this.properties); a < b.length;) {
                    var c = b[a];
                    ++a;
                    "filter" != c && z.setField(this.filter, c, z.field(this.properties, c))
                }
                a = this.getField(this.target, "filters");
                z.setField(a, this.properties.filter, this.filter);
                this.setField_openfl_display_DisplayObject(this.target, "filters", a)
            },
            initialize: function() {
                for (var a, b = 0, c = z.fields(this.properties); b < c.length;) {
                    var d = c[b];
                    ++b;
                    "filter" != d && (a = this.getField(this.filter,
                        d), a = new Eb(this.filter, d, a, z.field(this.properties, d) - a), this.propertyDetails.push(a))
                }
                this.detailsLength = this.propertyDetails.length;
                this.initialized = !0
            },
            update: function(a) {
                la.prototype.update.call(this, a);
                a = this.target.get_filters();
                if (-1 < this.filterIndex) z.setField(a, this.properties.filter, this.filter);
                else
                    for (var b = 0, c = a.length; b < c;) {
                        var d = b++;
                        x.__instanceof(a[d], this.filterClass) && (a[d] = this.filter)
                    }
                this.setField_openfl_display_DisplayObject(this.target, "filters", a)
            },
            __class__: mf
        });
        var nf =
            function(a, b, c) {
                this.currentParameters = [];
                this.tweenProperties = {};
                la.call(this, a, b, c);
                Object.prototype.hasOwnProperty.call(c, "start") || (this.properties.start = []);
                Object.prototype.hasOwnProperty.call(c, "end") || (this.properties.end = this.properties.start);
                a = 0;
                for (b = this.properties.start.length; a < b;) c = a++, this.currentParameters.push(this.properties.start[c])
            };
        g["motion.actuators.MethodActuator"] = nf;
        nf.__name__ = ["motion", "actuators", "MethodActuator"];
        nf.__super__ = la;
        nf.prototype = t(la.prototype, {
            apply: function() {
                this.callMethod(this.target,
                    this.properties.end)
            },
            complete: function(a) {
                null == a && (a = !0);
                for (var b = 0, c = this.properties.start.length; b < c;) {
                    var d = b++;
                    this.currentParameters[d] = z.field(this.tweenProperties, "param" + d)
                }
                this.callMethod(this.target, this.currentParameters);
                la.prototype.complete.call(this, a)
            },
            initialize: function() {
                for (var a, b, c = 0, d = this.properties.start.length; c < d;) {
                    var e = c++;
                    a = "param" + e;
                    b = this.properties.start[e];
                    this.tweenProperties[a] = b;
                    if ("number" == typeof b || (b | 0) === b) a = new Eb(this.tweenProperties, a, b, this.properties.end[e] -
                        b), this.propertyDetails.push(a)
                }
                this.detailsLength = this.propertyDetails.length;
                this.initialized = !0
            },
            update: function(a) {
                la.prototype.update.call(this, a);
                if (this.active && !this.paused) {
                    a = 0;
                    for (var b = this.properties.start.length; a < b;) {
                        var c = a++;
                        this.currentParameters[c] = z.field(this.tweenProperties, "param" + c)
                    }
                    this.callMethod(this.target, this.currentParameters)
                }
            },
            __class__: nf
        });
        var of = function(a, b, c) {
            la.call(this, a, b, c)
        };
        g["motion.actuators.MotionPathActuator"] = of;
        of.__name__ = ["motion", "actuators", "MotionPathActuator"];
        of.__super__ = la;
        of.prototype = t(la.prototype, {
            setField_motion_actuators_MotionPathActuator_T: function(a, b, c) {
                Object.prototype.hasOwnProperty.call(a, b) ? a[b] = c : z.setProperty(a, b, c)
            },
            apply: function() {
                for (var a = 0, b = z.fields(this.properties); a < b.length;) {
                    var c = b[a];
                    ++a;
                    Object.prototype.hasOwnProperty.call(this.target, c) ? z.setField(this.target, c, x.__cast(z.field(this.properties, c), ld).get_end()) : z.setProperty(this.target, c, x.__cast(z.field(this.properties, c), ld).get_end())
                }
            },
            initialize: function() {
                for (var a,
                        b = 0, c = z.fields(this.properties); b < c.length;) {
                    var d = c[b];
                    ++b;
                    a = x.__cast(z.field(this.properties, d), ld);
                    if (null != a) {
                        var e = !0;
                        Object.prototype.hasOwnProperty.call(this.target, d) ? a.start = z.field(this.target, d) : (e = !1, a.start = z.getProperty(this.target, d));
                        a = new Mb(this.target, d, a, e);
                        this.propertyDetails.push(a)
                    }
                }
                this.detailsLength = this.propertyDetails.length;
                this.initialized = !0
            },
            update: function(a) {
                if (!this.paused) {
                    var b, c = (a - this.timeOffset) / this.duration;
                    1 < c && (c = 1);
                    this.initialized || this.initialize();
                    if (this.special) {
                        b = this._reverse ? this._ease.calculate(1 - c) : this._ease.calculate(c);
                        for (var d = 0, e = this.propertyDetails; d < e.length;) {
                            var f = e[d];
                            ++d;
                            this._snapping ? f.isField ? z.setField(f.target, f.propertyName, Math.round(x.__cast(f, Mb).path.calculate(b))) : z.setProperty(f.target, f.propertyName, Math.round(x.__cast(f, Mb).path.calculate(b))) : f.isField ? z.setField(f.target, f.propertyName, x.__cast(f, Mb).path.calculate(b)) : z.setProperty(f.target, f.propertyName, x.__cast(f, Mb).path.calculate(b))
                        }
                    } else
                        for (b = this._ease.calculate(c),
                            d = 0, e = this.propertyDetails; d < e.length;) f = e[d], ++d, f.isField ? z.setField(f.target, f.propertyName, x.__cast(f, Mb).path.calculate(b)) : z.setProperty(f.target, f.propertyName, x.__cast(f, Mb).path.calculate(b));
                    if (1 == c) {
                        if (0 == this._repeat) {
                            this.active = !1;
                            this.toggleVisible && 0 == this.getField(this.target, "alpha") && this.setField_motion_actuators_MotionPathActuator_T(this.target, "visible", !1);
                            this.complete(!0);
                            return
                        }
                        null != this._onRepeat && this.callMethod(this._onRepeat, this._onRepeatParams);
                        this._reflect && (this._reverse = !this._reverse);
                        this.startTime = a;
                        this.timeOffset = this.startTime + this._delay;
                        0 < this._repeat && this._repeat--
                    }
                    this.sendChange && this.change()
                }
            },
            __class__: of
        });
        var Eb = function(a, b, c, d, e) {
            null == e && (e = !0);
            this.target = a;
            this.propertyName = b;
            this.start = c;
            this.change = d;
            this.isField = e
        };
        g["motion.actuators.PropertyDetails"] = Eb;
        Eb.__name__ = ["motion", "actuators", "PropertyDetails"];
        Eb.prototype = {
            __class__: Eb
        };
        var Mb = function(a, b, c, d) {
            null == d && (d = !0);
            Eb.call(this, a, b, 0, 0, d);
            this.path = c
        };
        g["motion.actuators.PropertyPathDetails"] =
            Mb;
        Mb.__name__ = ["motion", "actuators", "PropertyPathDetails"];
        Mb.__super__ = Eb;
        Mb.prototype = t(Eb.prototype, {
            __class__: Mb
        });
        var pf = function(a, b, c) {
            la.call(this, a, b, c)
        };
        g["motion.actuators.TransformActuator"] = pf;
        pf.__name__ = ["motion", "actuators", "TransformActuator"];
        pf.__super__ = la;
        pf.prototype = t(la.prototype, {
            setField_openfl_geom_Transform: function(a, b, c) {
                Object.prototype.hasOwnProperty.call(a, b) ? a[b] = c : z.setProperty(a, b, c)
            },
            setField_motion_actuators_TransformActuator_T: function(a, b, c) {
                Object.prototype.hasOwnProperty.call(a,
                    b) ? a[b] = c : z.setProperty(a, b, c)
            },
            apply: function() {
                this.initialize();
                if (null != this.endColorTransform) {
                    var a = this.getField(this.target, "transform");
                    this.setField_openfl_geom_Transform(a, "colorTransform", this.endColorTransform)
                }
                null != this.endSoundTransform && this.setField_motion_actuators_TransformActuator_T(this.target, "soundTransform", this.endSoundTransform)
            },
            initialize: function() {
                Object.prototype.hasOwnProperty.call(this.properties, "colorValue") && x.__instanceof(this.target, V) && this.initializeColor();
                (Object.prototype.hasOwnProperty.call(this.properties, "soundVolume") || Object.prototype.hasOwnProperty.call(this.properties, "soundPan")) && this.initializeSound();
                this.detailsLength = this.propertyDetails.length;
                this.initialized = !0
            },
            initializeColor: function() {
                this.endColorTransform = new Sd;
                var a = this.properties.colorValue,
                    b = this.properties.colorStrength;
                if (1 > b) {
                    var c;
                    .5 > b ? (c = 1, b *= 2) : (c = 1 - 2 * (b - .5), b = 1);
                    this.endColorTransform.redMultiplier = c;
                    this.endColorTransform.greenMultiplier = c;
                    this.endColorTransform.blueMultiplier =
                        c;
                    this.endColorTransform.redOffset = b * (a >> 16 & 255);
                    this.endColorTransform.greenOffset = b * (a >> 8 & 255);
                    this.endColorTransform.blueOffset = b * (a & 255)
                } else this.endColorTransform.redMultiplier = 0, this.endColorTransform.greenMultiplier = 0, this.endColorTransform.blueMultiplier = 0, this.endColorTransform.redOffset = a >> 16 & 255, this.endColorTransform.greenOffset = a >> 8 & 255, this.endColorTransform.blueOffset = a & 255;
                a = "redMultiplier greenMultiplier blueMultiplier redOffset greenOffset blueOffset".split(" ");
                Object.prototype.hasOwnProperty.call(this.properties,
                    "colorAlpha") ? (this.endColorTransform.alphaMultiplier = this.properties.colorAlpha, a.push("alphaMultiplier")) : this.endColorTransform.alphaMultiplier = this.getField(this.target, "alpha");
                c = this.getField(this.target, "transform");
                c = this.getField(c, "colorTransform");
                this.tweenColorTransform = new Sd;
                for (var d, b = 0; b < a.length;) {
                    var e = a[b];
                    ++b;
                    d = this.getField(c, e);
                    d = new Eb(this.tweenColorTransform, e, d, this.getField(this.endColorTransform, e) - d);
                    this.propertyDetails.push(d)
                }
            },
            initializeSound: function() {
                null == this.getField(this.target,
                    "soundTransform") && this.setField_motion_actuators_TransformActuator_T(this.target, "soundTransform", new Gc);
                var a = this.getField(this.target, "soundTransform");
                this.endSoundTransform = this.getField(this.target, "soundTransform");
                this.tweenSoundTransform = new Gc;
                Object.prototype.hasOwnProperty.call(this.properties, "soundVolume") && (this.endSoundTransform.volume = this.properties.soundVolume, this.propertyDetails.push(new Eb(this.tweenSoundTransform, "volume", a.volume, this.endSoundTransform.volume - a.volume)));
                Object.prototype.hasOwnProperty.call(this.properties, "soundPan") && (this.endSoundTransform.pan = this.properties.soundPan, this.propertyDetails.push(new Eb(this.tweenSoundTransform, "pan", a.pan, this.endSoundTransform.pan - a.pan)))
            },
            update: function(a) {
                la.prototype.update.call(this, a);
                null != this.endColorTransform && (a = this.getField(this.target, "transform"), this.setField_openfl_geom_Transform(a, "colorTransform", this.tweenColorTransform));
                null != this.endSoundTransform && this.setField_motion_actuators_TransformActuator_T(this.target,
                    "soundTransform", this.tweenSoundTransform)
            },
            __class__: pf
        });
        var Bc = function() {};
        g["motion.easing.Bounce"] = Bc;
        Bc.__name__ = ["motion", "easing", "Bounce"];
        Bc.__properties__ = {
            get_easeOut: "get_easeOut"
        };
        Bc.get_easeOut = function() {
            return new Jc
        };
        var Jc = function() {};
        g["motion.easing.BounceEaseOut"] = Jc;
        Jc.__name__ = ["motion", "easing", "BounceEaseOut"];
        Jc.__interfaces__ = [tb];
        Jc._ease = function(a, b, c, d) {
            return .36363636363636365 > (a /= d) ? 7.5625 * c * a * a + b : .7272727272727273 > a ? c * (7.5625 * (a -= .5454545454545454) * a + .75) + b : .9090909090909091 >
                a ? c * (7.5625 * (a -= .8181818181818182) * a + .9375) + b : c * (7.5625 * (a -= .9545454545454546) * a + .984375) + b
        };
        Jc.prototype = {
            calculate: function(a) {
                return Jc._ease(a, 0, 1, 1)
            },
            __class__: Jc
        };
        var qf = function() {};
        g["motion.easing.Cubic"] = qf;
        qf.__name__ = ["motion", "easing", "Cubic"];
        qf.__properties__ = {
            get_easeInOut: "get_easeInOut"
        };
        qf.get_easeInOut = function() {
            return new Td
        };
        var Td = function() {};
        g["motion.easing.CubicEaseInOut"] = Td;
        Td.__name__ = ["motion", "easing", "CubicEaseInOut"];
        Td.__interfaces__ = [tb];
        Td.prototype = {
            calculate: function(a) {
                return 1 >
                    (a /= .5) ? .5 * a * a * a : .5 * ((a -= 2) * a * a + 2)
            },
            __class__: Td
        };
        var qb = function() {};
        g["motion.easing.Linear"] = qb;
        qb.__name__ = ["motion", "easing", "Linear"];
        qb.__properties__ = {
            get_easeNone: "get_easeNone"
        };
        qb.get_easeNone = function() {
            return new Ud
        };
        var Ud = function() {};
        g["motion.easing.LinearEaseNone"] = Ud;
        Ud.__name__ = ["motion", "easing", "LinearEaseNone"];
        Ud.__interfaces__ = [tb];
        Ud.prototype = {
            calculate: function(a) {
                return a
            },
            __class__: Ud
        };
        var na = function() {};
        g["motion.easing.Quad"] = na;
        na.__name__ = ["motion", "easing", "Quad"];
        na.__properties__ = {
            get_easeOut: "get_easeOut",
            get_easeInOut: "get_easeInOut",
            get_easeIn: "get_easeIn"
        };
        na.get_easeIn = function() {
            return new Vd
        };
        na.get_easeInOut = function() {
            return new Wd
        };
        na.get_easeOut = function() {
            return new Xd
        };
        var Vd = function() {};
        g["motion.easing.QuadEaseIn"] = Vd;
        Vd.__name__ = ["motion", "easing", "QuadEaseIn"];
        Vd.__interfaces__ = [tb];
        Vd.prototype = {
            calculate: function(a) {
                return a * a
            },
            __class__: Vd
        };
        var Wd = function() {};
        g["motion.easing.QuadEaseInOut"] = Wd;
        Wd.__name__ = ["motion", "easing", "QuadEaseInOut"];
        Wd.__interfaces__ = [tb];
        Wd.prototype = {
            calculate: function(a) {
                return 1 > (a *= 2) ? .5 * a * a : -.5 * ((a - 1) * (a - 3) - 1)
            },
            __class__: Wd
        };
        var Xd = function() {};
        g["motion.easing.QuadEaseOut"] = Xd;
        Xd.__name__ = ["motion", "easing", "QuadEaseOut"];
        Xd.__interfaces__ = [tb];
        Xd.prototype = {
            calculate: function(a) {
                return -a * (a - 2)
            },
            __class__: Xd
        };
        var bd = function() {};
        g["motion.easing.Quart"] = bd;
        bd.__name__ = ["motion", "easing", "Quart"];
        bd.__properties__ = {
            get_easeOut: "get_easeOut",
            get_easeIn: "get_easeIn"
        };
        bd.get_easeIn = function() {
            return new Yd
        };
        bd.get_easeOut = function() {
            return new Zd
        };
        var Yd = function() {};
        g["motion.easing.QuartEaseIn"] = Yd;
        Yd.__name__ = ["motion", "easing", "QuartEaseIn"];
        Yd.__interfaces__ = [tb];
        Yd.prototype = {
            calculate: function(a) {
                return a * a * a * a
            },
            __class__: Yd
        };
        var Zd = function() {};
        g["motion.easing.QuartEaseOut"] = Zd;
        Zd.__name__ = ["motion", "easing", "QuartEaseOut"];
        Zd.__interfaces__ = [tb];
        Zd.prototype = {
            calculate: function(a) {
                return -(--a * a * a * a - 1)
            },
            __class__: Zd
        };
        var Qb = function() {};
        g["motion.easing.Quint"] = Qb;
        Qb.__name__ = ["motion", "easing",
            "Quint"
        ];
        Qb.__properties__ = {
            get_easeInOut: "get_easeInOut"
        };
        Qb.get_easeInOut = function() {
            return new $d
        };
        var $d = function() {};
        g["motion.easing.QuintEaseInOut"] = $d;
        $d.__name__ = ["motion", "easing", "QuintEaseInOut"];
        $d.__interfaces__ = [tb];
        $d.prototype = {
            calculate: function(a) {
                return 1 > (a *= 2) ? .5 * a * a * a * a * a : .5 * ((a -= 2) * a * a * a * a + 2)
            },
            __class__: $d
        };
        var rf = function() {};
        g["openfl.IAssetCache"] = rf;
        rf.__name__ = ["openfl", "IAssetCache"];
        rf.prototype = {
            __class__: rf
        };
        var ae = function() {
            this.__enabled = !0;
            this.bitmapData = new pa;
            this.font = new pa;
            this.sound = new pa
        };
        g["openfl.AssetCache"] = ae;
        ae.__name__ = ["openfl", "AssetCache"];
        ae.__interfaces__ = [rf];
        ae.prototype = {
            getBitmapData: function(a) {
                return this.bitmapData.get(a)
            },
            getFont: function(a) {
                return this.font.get(a)
            },
            getSound: function(a) {
                return this.sound.get(a)
            },
            hasBitmapData: function(a) {
                return this.bitmapData.exists(a)
            },
            hasFont: function(a) {
                return this.font.exists(a)
            },
            hasSound: function(a) {
                return this.sound.exists(a)
            },
            setBitmapData: function(a, b) {
                this.bitmapData.set(a, b)
            },
            get_enabled: function() {
                return this.__enabled
            },
            __class__: ae,
            __properties__: {
                get_enabled: "get_enabled"
            }
        };
        var Y = function() {};
        g["openfl.Assets"] = Y;
        Y.__name__ = ["openfl", "Assets"];
        Y.exists = function(a, b) {
            return H.exists(a, b)
        };
        Y.getBitmapData = function(a, b) {
            null == b && (b = !0);
            if (b && Y.cache.get_enabled() && Y.cache.hasBitmapData(a)) {
                var c = Y.cache.getBitmapData(a);
                if (Y.isValidBitmapData(c)) return c
            }
            c = H.getImage(a, !1);
            return null != c ? (c = Aa.fromImage(c), b && Y.cache.get_enabled() && Y.cache.setBitmapData(a, c), c) : null
        };
        Y.getFont = function(a, b) {
            null == b && (b = !0);
            if (b &&
                Y.cache.get_enabled() && Y.cache.hasFont(a)) return Y.cache.getFont(a);
            var c = H.getFont(a, !1);
            return null != c ? c : new Vc
        };
        Y.getSound = function(a, b) {
            null == b && (b = !0);
            if (b && Y.cache.get_enabled() && Y.cache.hasSound(a)) {
                var c = Y.cache.getSound(a);
                if (Y.isValidSound(c)) return c
            }
            c = H.getPath(a);
            return null != c ? new lc(new Dc(c)) : null
        };
        Y.getText = function(a) {
            return H.getText(a)
        };
        Y.isValidBitmapData = function(a) {
            return null != a
        };
        Y.isValidSound = function(a) {
            return !0
        };
        var be = function() {
            y.call(this);
            this.__currentFrame = 0;
            this.__currentLabels = [];
            this.__totalFrames = 0;
            this.enabled = !0
        };
        g["openfl.display.MovieClip"] = be;
        be.__name__ = ["openfl", "display", "MovieClip"];
        be.__super__ = y;
        be.prototype = t(y.prototype, {
            __class__: be
        });
        var Wb = function() {
            U.call(this);
            this.applicationDomain = Kc.currentDomain;
            this.bytesTotal = this.bytesLoaded = 0;
            this.childAllowsParent = !0;
            this.parameters = {}
        };
        g["openfl.display.LoaderInfo"] = Wb;
        Wb.__name__ = ["openfl", "display", "LoaderInfo"];
        Wb.create = function(a) {
            var b = new Wb;
            b.uncaughtErrorEvents = new ce;
            null != a ? b.loader = a : b.url = Wb.__rootURL;
            return b
        };
        Wb.__super__ = U;
        Wb.prototype = t(U.prototype, {
            __class__: Wb
        });
        var Kc = function(a) {
            this.parentDomain = null != a ? a : Kc.currentDomain
        };
        g["openfl.system.ApplicationDomain"] = Kc;
        Kc.__name__ = ["openfl", "system", "ApplicationDomain"];
        Kc.prototype = {
            __class__: Kc
        };
        var ce = function(a) {
            U.call(this, a)
        };
        g["openfl.events.UncaughtErrorEvents"] = ce;
        ce.__name__ = ["openfl", "events", "UncaughtErrorEvents"];
        ce.__super__ = U;
        ce.prototype = t(U.prototype, {
            __class__: ce
        });
        var da = function(a, b, c, d, e, f) {
            null == f && (f = 0);
            null == e && (e = 0);
            null == d && (d = 1);
            null == c && (c = 0);
            null == b && (b = 0);
            null == a && (a = 1);
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.tx = e;
            this.ty = f;
            this.__array = new Float32Array([a, b, c, d, e, f, 0, 0, 1])
        };
        g["openfl.geom.Matrix"] = da;
        da.__name__ = ["openfl", "geom", "Matrix"];
        da.prototype = {
            clone: function() {
                return new da(this.a, this.b, this.c, this.d, this.tx, this.ty)
            },
            concat: function(a) {
                var b = this.a * a.a + this.b * a.c;
                this.b = this.a * a.b + this.b * a.d;
                this.a = b;
                b = this.c * a.a + this.d * a.c;
                this.d = this.c * a.b + this.d * a.d;
                this.c = b;
                b = this.tx * a.a + this.ty * a.c + a.tx;
                this.ty = this.tx * a.b + this.ty * a.d + a.ty;
                this.tx = b
            },
            createGradientBox: function(a, b, c, d, e) {
                null == e && (e = 0);
                null == d && (d = 0);
                null == c && (c = 0);
                this.a = a / 1638.4;
                this.d = b / 1638.4;
                if (0 != c) {
                    var f = Math.cos(c);
                    c = Math.sin(c);
                    this.b = c * this.d;
                    this.c = -c * this.a;
                    this.a *= f;
                    this.d *= f
                } else this.c = this.b = 0;
                this.tx = d + a / 2;
                this.ty = e + b / 2
            },
            identity: function() {
                this.a = 1;
                this.c = this.b = 0;
                this.d = 1;
                this.ty = this.tx = 0
            },
            invert: function() {
                var a = this.a * this.d - this.b * this.c;
                if (0 == a) this.a = this.b = this.c = this.d = 0, this.tx = -this.tx, this.ty = -this.ty;
                else {
                    var a = 1 / a,
                        b = this.d * a;
                    this.d = this.a * a;
                    this.a = b;
                    this.b *= -a;
                    this.c *= -a;
                    a = -this.a * this.tx - this.c * this.ty;
                    this.ty = -this.b * this.tx - this.d * this.ty;
                    this.tx = a
                }
                return this
            },
            mult: function(a) {
                var b = new da;
                b.a = this.a * a.a + this.b * a.c;
                b.b = this.a * a.b + this.b * a.d;
                b.c = this.c * a.a + this.d * a.c;
                b.d = this.c * a.b + this.d * a.d;
                b.tx = this.tx * a.a + this.ty * a.c + a.tx;
                b.ty = this.tx * a.b + this.ty * a.d + a.ty;
                return b
            },
            rotate: function(a) {
                var b = Math.cos(a);
                a = Math.sin(a);
                var c = this.a * b - this.b * a;
                this.b = this.a * a + this.b * b;
                this.a = c;
                c = this.c * b - this.d *
                    a;
                this.d = this.c * a + this.d * b;
                this.c = c;
                c = this.tx * b - this.ty * a;
                this.ty = this.tx * a + this.ty * b;
                this.tx = c
            },
            scale: function(a, b) {
                this.a *= a;
                this.b *= b;
                this.c *= a;
                this.d *= b;
                this.tx *= a;
                this.ty *= b
            },
            to3DString: function(a) {
                null == a && (a = !1);
                return a ? "matrix3d(" + this.a + ", " + this.b + ", 0, 0, " + this.c + ", " + this.d + ", 0, 0, 0, 0, 1, 0, " + (this.tx | 0) + ", " + (this.ty | 0) + ", 0, 1)" : "matrix3d(" + this.a + ", " + this.b + ", 0, 0, " + this.c + ", " + this.d + ", 0, 0, 0, 0, 1, 0, " + this.tx + ", " + this.ty + ", 0, 1)"
            },
            transformPoint: function(a) {
                return new ja(a.x *
                    this.a + a.y * this.c + this.tx, a.x * this.b + a.y * this.d + this.ty)
            },
            translate: function(a, b) {
                var c = new da;
                c.tx = a;
                c.ty = b;
                this.concat(c)
            },
            toArray: function(a) {
                null == a && (a = !1);
                a ? (this.__array[0] = this.a, this.__array[1] = this.c, this.__array[2] = 0, this.__array[3] = this.b, this.__array[4] = this.d, this.__array[5] = 0, this.__array[6] = this.tx, this.__array[7] = this.ty) : (this.__array[0] = this.a, this.__array[1] = this.b, this.__array[2] = this.tx, this.__array[3] = this.c, this.__array[4] = this.d, this.__array[5] = this.ty, this.__array[6] = 0, this.__array[7] =
                    0);
                this.__array[8] = 1;
                return this.__array
            },
            __translateTransformed: function(a) {
                this.tx = a.x * this.a + a.y * this.c + this.tx;
                this.ty = a.x * this.b + a.y * this.d + this.ty
            },
            __class__: da
        };
        var S = function() {};
        g["openfl.Lib"] = S;
        S.__name__ = ["openfl", "Lib"];
        S.application = null;
        S.embed = Tc.openfl.embed = function(a, b, c, d, e) {
            Nd.embed(a, b, c, d, e)
        };
        S.getTimer = function() {
            return Nd.getTimer()
        };
        S.getURL = function(a, b) {
            null == b && (b = "_blank");
            window.open(a.url, b)
        };
        S.notImplemented = function(a) {
            S.__sentWarnings.exists(a) || (S.__sentWarnings.set(a, !0), console.log("Warning: " + a + " is not implemented"))
        };
        var uc = function() {
            this.length = 0
        };
        g["openfl.VectorData"] = uc;
        uc.__name__ = ["openfl", "VectorData"];
        uc.prototype = {
            __class__: uc
        };
        var ub = function(a, b) {
            this.width = a;
            this.height = b
        };
        g["openfl._internal.renderer.AbstractRenderer"] = ub;
        ub.__name__ = ["openfl", "_internal", "renderer", "AbstractRenderer"];
        ub.prototype = {
            render: function(a) {},
            resize: function(a, b) {},
            __class__: ub
        };
        var Ec = function() {};
        g["openfl._internal.renderer.RenderSession"] = Ec;
        Ec.__name__ = ["openfl",
            "_internal", "renderer", "RenderSession"
        ];
        Ec.prototype = {
            __class__: Ec
        };
        var Pf = function() {};
        g["openfl._internal.renderer.canvas.CanvasBitmap"] = Pf;
        Pf.__name__ = ["openfl", "_internal", "renderer", "canvas", "CanvasBitmap"];
        Pf.render = function(a, b) {
            if (a.__renderable && !(0 >= a.__worldAlpha)) {
                var c = b.context;
                if (null != a.bitmapData && a.bitmapData.__isValid) {
                    null != a.__mask && b.maskManager.pushMask(a.__mask);
                    a.bitmapData.__sync();
                    c.globalAlpha = a.__worldAlpha;
                    var d = a.__worldTransform,
                        e = a.get_scrollRect();
                    b.roundPixels ? c.setTransform(d.a,
                        d.b, d.c, d.d, d.tx | 0, d.ty | 0) : c.setTransform(d.a, d.b, d.c, d.d, d.tx, d.ty);
                    a.smoothing || (c.mozImageSmoothingEnabled = !1, c.webkitImageSmoothingEnabled = !1, c.imageSmoothingEnabled = !1);
                    null == e ? c.drawImage(a.bitmapData.__image.get_src(), 0, 0) : c.drawImage(a.bitmapData.__image.get_src(), e.x, e.y, e.width, e.height, e.x, e.y, e.width, e.height);
                    a.smoothing || (c.mozImageSmoothingEnabled = !0, c.webkitImageSmoothingEnabled = !0, c.imageSmoothingEnabled = !0);
                    null != a.__mask && b.maskManager.popMask()
                }
            }
        };
        var h = function() {};
        g["openfl._internal.renderer.canvas.CanvasGraphics"] =
            h;
        h.__name__ = ["openfl", "_internal", "renderer", "canvas", "CanvasGraphics"];
        h.bitmapFill = null;
        h.bitmapRepeat = null;
        h.bounds = null;
        h.fillCommands = null;
        h.graphics = null;
        h.hasFill = null;
        h.hasStroke = null;
        h.inversePendingMatrix = null;
        h.pendingMatrix = null;
        h.strokeCommands = null;
        h.context = null;
        h.createBitmapFill = function(a, b) {
            a.__sync();
            return h.context.createPattern(a.__image.get_src(), b ? "repeat" : "no-repeat")
        };
        h.createTempPatternCanvas = function(a, b, c, d) {
            var e = window.document.createElement("canvas"),
                f = e.getContext("2d");
            e.width = c;
            e.height = d;
            f.fillStyle = f.createPattern(a.__image.get_src(), b ? "repeat" : "no-repeat");
            f.beginPath();
            f.moveTo(0, 0);
            f.lineTo(0, d);
            f.lineTo(c, d);
            f.lineTo(c, 0);
            f.lineTo(0, 0);
            f.closePath();
            f.fill();
            return e
        };
        h.endFill = function() {
            h.context.beginPath();
            h.playCommands(h.fillCommands, !1);
            h.fillCommands = []
        };
        h.endStroke = function() {
            h.context.beginPath();
            h.playCommands(h.strokeCommands, !0);
            h.context.closePath();
            h.strokeCommands = []
        };
        h.closePath = function() {
            null != h.context.strokeStyle && (h.context.closePath(),
                h.context.stroke(), h.context.beginPath())
        };
        h.drawRoundRect = function(a, b, c, d, e, f) {
            -1 == f && (f = e);
            e *= .5;
            f *= .5;
            e > c / 2 && (e = c / 2);
            f > d / 2 && (f = d / 2);
            c = a + c;
            d = b + d;
            var l = -e + e * h.SIN45,
                g = -e + e * h.TAN22,
                k = -f + f * h.SIN45,
                n = -f + f * h.TAN22;
            h.context.moveTo(c, d - f);
            h.context.quadraticCurveTo(c, d + n, c + l, d + k);
            h.context.quadraticCurveTo(c + g, d, c - e, d);
            h.context.lineTo(a + e, d);
            h.context.quadraticCurveTo(a - g, d, a - l, d + k);
            h.context.quadraticCurveTo(a, d + n, a, d - f);
            h.context.lineTo(a, b + f);
            h.context.quadraticCurveTo(a, b - n, a - l, b - k);
            h.context.quadraticCurveTo(a -
                g, b, a + e, b);
            h.context.lineTo(c - e, b);
            h.context.quadraticCurveTo(c + g, b, c + l, b - k);
            h.context.quadraticCurveTo(c, b - n, c, b + f);
            h.context.lineTo(c, d - f)
        };
        h.normalizeUVT = function(a, b) {
            null == b && (b = !1);
            for (var c = Math.NEGATIVE_INFINITY, d = Math.NEGATIVE_INFINITY, e = a.length, f = 1, l = e + 1; f < l;) d = f++, b && 0 == d % 3 || (d = a.data[d - 1], c < d && (c = d));
            f = new uc;
            f.data = [];
            f.length = 0;
            f.fixed = !1;
            l = 1;
            for (e += 1; l < e;)
                if (d = l++, !b || 0 != d % 3) {
                    if (!f.fixed) {
                        f.length++;
                        if (f.data.length < f.length) {
                            var g;
                            g = Array(f.data.length + 10);
                            ab.blit(f.data, 0, g, 0, f.data.length);
                            f.data = g
                        }
                        f.data[f.length - 1] = a.data[d - 1] / c
                    }
                    f.length
                }
            return {
                max: c,
                uvt: f
            }
        };
        h.playCommands = function(a, b) {
            null == b && (b = !1);
            h.bounds = h.graphics.__bounds;
            for (var c = h.bounds.x, d = h.bounds.y, e = 0, f = 0, l = !1, g = 0, k = 0, n = 0; n < a.length;) {
                var q = a[n];
                ++n;
                switch (q[1]) {
                    case 3:
                        h.context.bezierCurveTo(q[2] - c, q[3] - d, q[4] - c, q[5] - d, q[6] - c, q[7] - d);
                        break;
                    case 4:
                        h.context.quadraticCurveTo(q[2] - c, q[3] - d, q[4] - c, q[5] - d);
                        break;
                    case 5:
                        var m = q[4],
                            p = q[3],
                            q = q[2];
                        h.context.moveTo(q - c + m, p - d);
                        h.context.arc(q - c, p - d, m, 0, 2 * Math.PI, !0);
                        break;
                    case 6:
                        var p = q[5],
                            r = q[4],
                            m = q[3],
                            q = q[2],
                            q = q - c,
                            m = m - d,
                            t = r / 2 * .5522848,
                            x = p / 2 * .5522848,
                            w = q + r,
                            u = m + p,
                            r = q + r / 2,
                            p = m + p / 2;
                        h.context.moveTo(q, p);
                        h.context.bezierCurveTo(q, p - x, r - t, m, r, m);
                        h.context.bezierCurveTo(r + t, m, w, p - x, w, p);
                        h.context.bezierCurveTo(w, p + x, r + t, u, r, u);
                        h.context.bezierCurveTo(r - t, u, q, p + x, q, p);
                        break;
                    case 8:
                        h.drawRoundRect(q[2] - c, q[3] - d, q[4], q[5], q[6], q[7]);
                        break;
                    case 15:
                        f = q[3];
                        e = q[2];
                        h.context.lineTo(e - c, f - d);
                        break;
                    case 16:
                        k = q[3];
                        g = q[2];
                        h.context.moveTo(g - c, k - d);
                        e = g;
                        f = k;
                        l = !0;
                        break;
                    case 12:
                        t = q[9];
                        x = q[8];
                        w = q[7];
                        m = q[4];
                        p = q[3];
                        q = q[2];
                        b && h.hasStroke && (h.context.closePath(), h.context.stroke(), h.context.beginPath());
                        h.context.moveTo(e - c, f - d);
                        if (null == q) h.hasStroke = !1;
                        else {
                            h.context.lineWidth = q;
                            h.context.lineJoin = null == x ? "round" : v.string(x).toLowerCase();
                            if (null == w) h.context.lineCap = "round";
                            else switch (w[1]) {
                                case 0:
                                    h.context.lineCap = "butt";
                                    break;
                                default:
                                    h.context.lineCap = v.string(w).toLowerCase()
                            }
                            h.context.miterLimit = null == t ? 3 : t;
                            1 == m || null == m ? h.context.strokeStyle = null == p ? "#000000" : "#" + M.hex(p & 16777215,
                                6) : (q = (p & 16711680) >>> 16, t = (p & 65280) >>> 8, x = p & 255, h.context.strokeStyle = null == p ? "#000000" : "rgba(" + q + ", " + t + ", " + x + ", " + m + ")");
                            h.hasStroke = !0
                        }
                        break;
                    case 14:
                        m = q[9];
                        p = q[8];
                        t = q[7];
                        x = q[6];
                        w = q[5];
                        u = q[4];
                        r = q[3];
                        q = q[2];
                        b && h.hasStroke && h.closePath();
                        h.context.moveTo(e - c, f - d);
                        h.context.strokeStyle = h.createGradientPattern(q, r, u, w, x, t, p, m);
                        h.hasStroke = !0;
                        break;
                    case 13:
                        m = q[4];
                        q = q[2];
                        b && h.hasStroke && h.closePath();
                        h.context.moveTo(e - c, f - d);
                        h.context.strokeStyle = h.createBitmapFill(q, m);
                        h.hasStroke = !0;
                        break;
                    case 0:
                        m =
                            q[3];
                        h.context.fillStyle = h.createBitmapFill(q[2], !0);
                        h.hasFill = !0;
                        null != m ? (h.pendingMatrix = m, h.inversePendingMatrix = new da(m.a, m.b, m.c, m.d, m.tx, m.ty), h.inversePendingMatrix.invert()) : (h.pendingMatrix = null, h.inversePendingMatrix = null);
                        break;
                    case 1:
                        m = q[3];
                        q = q[2];
                        .005 > m ? h.hasFill = !1 : (h.context.fillStyle = 1 == m ? "#" + M.hex(q, 6) : "rgba(" + ((q & 16711680) >>> 16) + ", " + ((q & 65280) >>> 8) + ", " + (q & 255) + ", " + m + ")", h.bitmapFill = null, h.hasFill = !0);
                        break;
                    case 2:
                        h.context.fillStyle = h.createGradientPattern(q[2], q[3], q[4], q[5],
                            q[6], q[7], q[8], q[9]);
                        h.bitmapFill = null;
                        h.hasFill = !0;
                        break;
                    case 7:
                        m = q[5];
                        p = q[4];
                        t = q[3];
                        q = q[2];
                        x = !1;
                        if (null != h.bitmapFill) {
                            var md = w = 0,
                                z = r = 0,
                                u = !0;
                            null != h.pendingMatrix ? 0 != h.pendingMatrix.b || 0 != h.pendingMatrix.c ? u = !1 : (r = h.inversePendingMatrix.transformPoint(new ja(q, t)), md = h.inversePendingMatrix.transformPoint(new ja(q + p, t + m)), w = r.y, z = r.x, r = md.y, md = md.x) : (w = t, z = q, r = t + m, md = q + p);
                            u && 0 <= w && 0 <= z && md <= h.bitmapFill.width && r <= h.bitmapFill.height && (x = !0, h.context.drawImage(h.bitmapFill.__image.get_src(), z, w, md -
                                z, r - w, q - c, t - d, p, m))
                        }
                        x || h.context.rect(q - c, t - d, p, m)
                }
            }
            b && h.hasStroke && (h.hasFill && l && h.context.lineTo(g - c, k - d), h.context.stroke());
            b || !h.hasFill && null == h.bitmapFill || (h.context.translate(-h.bounds.x, -h.bounds.y), null != h.pendingMatrix ? (h.context.transform(h.pendingMatrix.a, h.pendingMatrix.b, h.pendingMatrix.c, h.pendingMatrix.d, h.pendingMatrix.tx, h.pendingMatrix.ty), h.context.fill(), h.context.transform(h.inversePendingMatrix.a, h.inversePendingMatrix.b, h.inversePendingMatrix.c, h.inversePendingMatrix.d,
                h.inversePendingMatrix.tx, h.inversePendingMatrix.ty)) : h.context.fill(), h.context.translate(h.bounds.x, h.bounds.y), h.context.closePath())
        };
        h.createGradientPattern = function(a, b, c, d, e, f, l, g) {
            f = null;
            switch (a[1]) {
                case 0:
                    null == e && (e = new da);
                    f = e.transformPoint(new ja(1638.4, 0));
                    f = h.context.createRadialGradient(e.tx, e.ty, 0, e.tx, e.ty, (f.x - e.tx) / 2);
                    break;
                case 1:
                    e = null != e ? new da(e.a, e.b, e.c, e.d, e.tx, e.ty) : new da, f = e.transformPoint(new ja(-819.2, 0)), e = e.transformPoint(new ja(819.2, 0)), f = h.context.createLinearGradient(f.x,
                        f.y, e.x, e.y)
            }
            e = 0;
            for (a = b.length; e < a;) {
                var k = e++,
                    m = b[k];
                l = c[k];
                g = (m & 16711680) >>> 16;
                var q = (m & 65280) >>> 8,
                    m = m & 255,
                    k = d[k] / 255;
                0 > k && (k = 0);
                1 < k && (k = 1);
                f.addColorStop(k, "rgba(" + g + ", " + q + ", " + m + ", " + l + ")")
            }
            return f
        };
        h.render = function(a, b) {
            if (a.__dirty) {
                h.graphics = a;
                h.bounds = a.__bounds;
                if (a.__visible && 0 != a.__commands.length && null != h.bounds && 0 != h.bounds.width && 0 != h.bounds.height) {
                    null == a.__canvas && (a.__canvas = window.document.createElement("canvas"), a.__context = a.__canvas.getContext("2d"));
                    h.context = a.__context;
                    a.__canvas.width = Math.ceil(h.bounds.width);
                    a.__canvas.height = Math.ceil(h.bounds.height);
                    h.fillCommands = [];
                    h.strokeCommands = [];
                    h.hasFill = !1;
                    h.hasStroke = !1;
                    h.bitmapFill = null;
                    h.bitmapRepeat = !1;
                    var c = 0,
                        d = a.__commands;
                    try {
                        for (; c < d.length;) {
                            var e = d[c];
                            ++c;
                            switch (e[1]) {
                                case 3:
                                case 4:
                                case 15:
                                case 16:
                                    h.fillCommands.push(e);
                                    h.strokeCommands.push(e);
                                    break;
                                case 11:
                                    h.endFill();
                                    h.endStroke();
                                    h.hasFill = !1;
                                    h.bitmapFill = null;
                                    break;
                                case 12:
                                case 14:
                                case 13:
                                    h.strokeCommands.push(e);
                                    break;
                                case 0:
                                case 1:
                                case 2:
                                    h.endFill();
                                    h.endStroke();
                                    h.fillCommands.push(e);
                                    h.strokeCommands.push(e);
                                    break;
                                case 5:
                                case 6:
                                case 7:
                                case 8:
                                    h.fillCommands.push(e);
                                    h.strokeCommands.push(e);
                                    break;
                                case 10:
                                    var f = e[5],
                                        l = e[4],
                                        g = e[3],
                                        k = e[2];
                                    h.endFill();
                                    h.endStroke();
                                    var m = k,
                                        q = g,
                                        n = l,
                                        p = null,
                                        r = null == h.bitmapFill;
                                    if (r && null != n) throw "__break__";
                                    if (!r) {
                                        if (null == l) {
                                            var t;
                                            t = new uc;
                                            t.data = [];
                                            t.length = 0;
                                            t.fixed = !1;
                                            for (var l = t, x = 0, w = m.length / 2 | 0; x < w;) {
                                                var v = x++;
                                                if (!l.fixed) {
                                                    l.length++;
                                                    if (l.data.length < l.length) {
                                                        var u;
                                                        u = Array(l.data.length + 10);
                                                        ab.blit(l.data,
                                                            0, u, 0, l.data.length);
                                                        l.data = u
                                                    }
                                                    l.data[l.length - 1] = m.data[2 * v] / h.bitmapFill.width
                                                }
                                                l.length;
                                                if (!l.fixed) {
                                                    l.length++;
                                                    if (l.data.length < l.length) {
                                                        var z;
                                                        z = Array(l.data.length + 10);
                                                        ab.blit(l.data, 0, z, 0, l.data.length);
                                                        l.data = z
                                                    }
                                                    l.data[l.length - 1] = m.data[2 * v + 1] / h.bitmapFill.height
                                                }
                                                l.length
                                            }
                                        }
                                        var A = h.normalizeUVT(l, l.length != m.length),
                                            y = A.max,
                                            n = A.uvt,
                                            p = 1 < y ? h.createTempPatternCanvas(h.bitmapFill, h.bitmapRepeat, h.bounds.width | 0, h.bounds.height | 0) : h.createTempPatternCanvas(h.bitmapFill, h.bitmapRepeat, h.bitmapFill.width,
                                                h.bitmapFill.height)
                                    }
                                    for (var x = 0, F = q.length, D, C, G, I, B, J, K, M, P, H, L, Q, R, O, N, X, Z, U, V, W, aa, ba, ea, ga, ja, ka, la, ma; x < F;) {
                                        D = x;
                                        C = x + 1;
                                        G = x + 2;
                                        I = 2 * q.data[D];
                                        B = 2 * q.data[D] + 1;
                                        J = 2 * q.data[C];
                                        K = 2 * q.data[C] + 1;
                                        M = 2 * q.data[G];
                                        P = 2 * q.data[G] + 1;
                                        H = m.data[I];
                                        L = m.data[B];
                                        Q = m.data[J];
                                        R = m.data[K];
                                        O = m.data[M];
                                        N = m.data[P];
                                        switch (f[1]) {
                                            case 2:
                                                if (!(0 > (Q - H) * (N - L) - (R - L) * (O - H))) {
                                                    x += 3;
                                                    continue
                                                }
                                                break;
                                            case 0:
                                                if (0 > (Q - H) * (N - L) - (R - L) * (O - H)) {
                                                    x += 3;
                                                    continue
                                                }
                                        }
                                        r ? (h.context.beginPath(), h.context.moveTo(H, L), h.context.lineTo(Q, R), h.context.lineTo(O,
                                            N), h.context.closePath(), h.context.fill()) : (h.context.save(), h.context.beginPath(), h.context.moveTo(H, L), h.context.lineTo(Q, R), h.context.lineTo(O, N), h.context.closePath(), h.context.clip(), X = n.data[I] * p.width, U = n.data[J] * p.width, W = n.data[M] * p.width, Z = n.data[B] * p.height, V = n.data[K] * p.height, aa = n.data[P] * p.height, ba = X * (aa - V) - U * aa + W * V + (U - W) * Z, 0 != ba && (ea = -(Z * (O - Q) - V * O + aa * Q + (V - aa) * H) / ba, ga = (V * N + Z * (R - N) - aa * R + (aa - V) * L) / ba, ja = (X * (O - Q) - U * O + W * Q + (U - W) * H) / ba, ka = -(U * N + X * (R - N) - W * R + (W - U) * L) / ba, la = (X * (aa * Q - V * O) + Z *
                                            (U * O - W * Q) + (W * V - U * aa) * H) / ba, ma = (X * (aa * R - V * N) + Z * (U * N - W * R) + (W * V - U * aa) * L) / ba, h.context.transform(ea, ga, ja, ka, la, ma), h.context.drawImage(p, 0, 0), h.context.restore()));
                                        x += 3
                                    }
                                    break;
                                case 9:
                                    var ia = e[6],
                                        ca = e[5],
                                        Y = e[3],
                                        ha = e[2],
                                        m = 0 < (ca & 1),
                                        q = 0 < (ca & 2),
                                        n = 0 < (ca & 16),
                                        T = 0 < (ca & 4),
                                        p = 0 < (ca & 8),
                                        x = 0 < (ca & 32),
                                        pa = 0 < (ca & 64),
                                        qa = 0 < (ca & 65536);
                                    n && (q = m = !1);
                                    var ra = 0,
                                        sa = 0,
                                        ta = 0,
                                        oa = 0,
                                        da = 3;
                                    x && (da = pa ? 8 : 6);
                                    m && (ra = da, da++);
                                    q && (sa = da, da++);
                                    n && (oa = da, da += 4);
                                    T && (da += 3);
                                    p && (ta = da, da++);
                                    var ua = Y.length;
                                    0 <= ia && ua > ia && (ua = ia);
                                    var T = 0,
                                        fa = null,
                                        na = null,
                                        xa = -1,
                                        ya;
                                    ha.__bitmap.__sync();
                                    ya = ha.__bitmap.__image.get_src();
                                    qa && (h.context.globalCompositeOperation = "lighter");
                                    for (; T < ua;) {
                                        var va;
                                        va = x ? -1 : Y[T + 2] | 0;
                                        x || va == xa ? x && (fa = ha.__rectTile, fa.setTo(Y[T + 2], Y[T + 3], Y[T + 4], Y[T + 5]), na = ha.__point, pa ? (na.x = Y[T + 6], na.y = Y[T + 7]) : (na.x = 0, na.y = 0)) : (fa = ha.__tileRects[va], na = ha.__centerPoints[va], xa = va);
                                        if (null != fa && 0 < fa.width && 0 < fa.height && null != na) {
                                            h.context.save();
                                            h.context.translate(Y[T], Y[T + 1]);
                                            q && h.context.rotate(Y[T + sa]);
                                            var wa = 1;
                                            m && (wa = Y[T + ra]);
                                            n && h.context.transform(Y[T +
                                                oa], Y[T + oa + 1], Y[T + oa + 2], Y[T + oa + 3], 0, 0);
                                            p && (h.context.globalAlpha = Y[T + ta]);
                                            h.context.drawImage(ya, fa.x, fa.y, fa.width, fa.height, -na.x * wa, -na.y * wa, fa.width * wa, fa.height * wa);
                                            h.context.restore()
                                        }
                                        T += da
                                    }
                                    qa && (h.context.globalCompositeOperation = "source-over");
                                    break;
                                default:
                                    S.notImplemented("CanvasGraphics")
                            }
                        }
                    } catch (za) {
                        if ("__break__" != za) throw za;
                    }
                    0 < h.fillCommands.length && h.endFill();
                    0 < h.strokeCommands.length && h.endStroke();
                    a.__bitmap = Aa.fromCanvas(a.__canvas)
                } else a.__canvas = null, a.__context = null, a.__bitmap =
                    null;
                a.set___dirty(!1)
            }
        };
        h.renderMask = function(a, b) {
            if (0 != a.__commands.length)
                for (var c = b.context, d = 0, e = a.__commands; d < e.length;) {
                    var f = e[d];
                    ++d;
                    switch (f[1]) {
                        case 3:
                            c.bezierCurveTo(f[2] - 0, f[4] - 0, f[3] - 0, f[5] - 0, f[6] - 0, f[7] - 0);
                            break;
                        case 4:
                            c.quadraticCurveTo(f[2] - 0, f[3] - 0, f[4] - 0, f[5] - 0);
                            break;
                        case 5:
                            c.arc(f[2] - 0, f[3] - 0, f[4], 0, 2 * Math.PI, !0);
                            break;
                        case 6:
                            var l = f[5],
                                g = f[4],
                                k = f[3],
                                f = f[2],
                                f = f - 0,
                                k = k - 0,
                                m = g / 2 * .5522848,
                                q = l / 2 * .5522848,
                                n = f + g,
                                p = k + l,
                                g = f + g / 2,
                                l = k + l / 2;
                            c.moveTo(f, l);
                            c.bezierCurveTo(f, l - q, g - m, k, g, k);
                            c.bezierCurveTo(g + m, k, n, l - q, n, l);
                            c.bezierCurveTo(n, l + q, g + m, p, g, p);
                            c.bezierCurveTo(g - m, p, f, l + q, f, l);
                            break;
                        case 7:
                            c.rect(f[2] - 0, f[3] - 0, f[4], f[5]);
                            break;
                        case 8:
                            h.drawRoundRect(f[2] - 0, f[3] - 0, f[4], f[5], f[6], f[7]);
                            break;
                        case 15:
                            c.lineTo(f[2] - 0, f[3] - 0);
                            break;
                        case 16:
                            c.moveTo(f[2] - 0, f[3] - 0)
                    }
                }
        };
        var de = function(a, b, c) {
            ub.call(this, a, b);
            this.context = c;
            this.renderSession = new Ec;
            this.renderSession.context = c;
            this.renderSession.roundPixels = !0;
            this.renderSession.renderer = this;
            this.renderSession.maskManager = new sf(this.renderSession)
        };
        g["openfl._internal.renderer.canvas.CanvasRenderer"] = de;
        de.__name__ = ["openfl", "_internal", "renderer", "canvas", "CanvasRenderer"];
        de.__super__ = ub;
        de.prototype = t(ub.prototype, {
            render: function(a) {
                this.context.setTransform(1, 0, 0, 1, 0, 0);
                this.context.globalAlpha = 1;
                !a.__transparent && a.__clearBeforeRender ? (this.context.fillStyle = a.__colorString, this.context.fillRect(0, 0, a.stageWidth, a.stageHeight)) : a.__transparent && a.__clearBeforeRender && this.context.clearRect(0, 0, a.stageWidth, a.stageHeight);
                a.__renderCanvas(this.renderSession)
            },
            __class__: de
        });
        var Jf = function() {};
        g["openfl._internal.renderer.canvas.CanvasShape"] = Jf;
        Jf.__name__ = ["openfl", "_internal", "renderer", "canvas", "CanvasShape"];
        Jf.render = function(a, b) {
            if (a.__renderable && !(0 >= a.__worldAlpha)) {
                var c = a.__graphics;
                if (null != c && (h.render(c, b), null != c.__canvas)) {
                    null != a.__mask && b.maskManager.pushMask(a.__mask);
                    var d = b.context,
                        e = a.get_scrollRect();
                    d.globalAlpha = a.__worldAlpha;
                    var f = a.__worldTransform;
                    b.roundPixels ? d.setTransform(f.a, f.b, f.c, f.d, f.tx | 0, f.ty | 0) : d.setTransform(f.a,
                        f.b, f.c, f.d, f.tx, f.ty);
                    null == e ? d.drawImage(c.__canvas, c.__bounds.x, c.__bounds.y) : d.drawImage(c.__canvas, e.x - c.__bounds.x, e.y - c.__bounds.y, e.width, e.height, c.__bounds.x + e.x, c.__bounds.y + e.y, e.width, e.height);
                    null != a.__mask && b.maskManager.popMask()
                }
            }
        };
        var ga = function() {};
        g["openfl._internal.renderer.canvas.CanvasTextField"] = ga;
        ga.__name__ = ["openfl", "_internal", "renderer", "canvas", "CanvasTextField"];
        ga.context = null;
        ga.render = function(a, b) {
            if (a.__renderable && !(0 >= a.__worldAlpha) && (ga.update(a), null !=
                    a.__canvas)) {
                var c = b.context;
                c.globalAlpha = a.__worldAlpha;
                var d = a.__worldTransform,
                    e = a.get_scrollRect();
                b.roundPixels ? c.setTransform(d.a, d.b, d.c, d.d, d.tx | 0, d.ty | 0) : c.setTransform(d.a, d.b, d.c, d.d, d.tx, d.ty);
                null == e ? c.drawImage(a.__canvas, 0, 0) : c.drawImage(a.__canvas, e.x, e.y, e.width, e.height, e.x, e.y, e.width, e.height)
            }
        };
        ga.renderText = function(a, b, c, d) {
            ga.context.font = a.__getFont(c);
            ga.context.textBaseline = "top";
            ga.context.fillStyle = "#" + M.hex(c.color, 6);
            b = b.split("\n");
            for (var e = 0, f = 0; f < b.length;) {
                var l =
                    b[f];
                ++f;
                switch (c.align[1]) {
                    case 3:
                        ga.context.textAlign = "center";
                        ga.context.fillText(l, a.__width / 2, 2 + e, a.__width - 4);
                        break;
                    case 1:
                        ga.context.textAlign = "end";
                        ga.context.fillText(l, a.__width - 2, 2 + e, a.__width - 4);
                        break;
                    default:
                        ga.context.textAlign = "start", ga.context.fillText(l, 2 + d, 2 + e, a.__width - 4)
                }
                e += a.get_textHeight()
            }
        };
        ga.update = function(a) {
            if (a.__dirty)
                if (!(null != a.__text && "" != a.__text || a.background || a.border) || (0 >= a.get_width() || 0 >= a.get_height()) && a.autoSize != wa.LEFT) a.__canvas = null, a.__context = null,
                    a.__dirty = !1;
                else {
                    null == a.__canvas && (a.__canvas = window.document.createElement("canvas"), a.__context = a.__canvas.getContext("2d"));
                    ga.context = a.__context;
                    if (null != a.__text && "" != a.__text) {
                        var b = a.get_text();
                        if (a.displayAsPassword) {
                            for (var b = b.length, c = "", d = 0; d < b;) d++, c += "*";
                            b = c
                        }
                        for (var c = a.__measureText(), e = d = 0; e < c.length;) {
                            var f = c[e];
                            ++e;
                            d += f
                        }
                        a.autoSize == wa.LEFT && (a.__width = d + 4);
                        a.__canvas.width = Math.ceil(a.__width);
                        a.__canvas.height = Math.ceil(a.__height);
                        if (a.border || a.background) a.__context.rect(.5,
                            .5, a.__width - 1, a.__height - 1), a.background && (ga.context.fillStyle = "#" + M.hex(a.backgroundColor, 6), ga.context.fill()), a.border && (ga.context.lineWidth = 1, ga.context.strokeStyle = "#" + M.hex(a.borderColor, 6), ga.context.stroke());
                        a.__hasFocus && a.__selectionStart == a.__cursorPosition && a.__showCursor ? (d = a.__getTextWidth(b.substring(0, a.__cursorPosition)), ga.context.fillStyle = "#" + M.hex(a.__textFormat.color, 6), ga.context.fillRect(d, 5, 1, a.__textFormat.size - 5)) : a.__hasFocus && 0 < Math.abs(a.__selectionStart - a.__cursorPosition) &&
                            !a.__isKeyDown && (e = v["int"](Math.min(a.__selectionStart, a.__cursorPosition)), f = v["int"](Math.max(a.__selectionStart, a.__cursorPosition)), d = a.__getTextWidth(b.substring(0, e)), e = a.__getTextWidth(b.substring(e, f)), ga.context.fillStyle = "#" + M.hex(a.__textFormat.color, 6), ga.context.fillRect(d, 5, e, a.__textFormat.size - 5));
                        if (null == a.__ranges) ga.renderText(a, b, a.__textFormat, 0);
                        else
                            for (var f = e = 0, l = a.__ranges.length; f < l;) {
                                var g = f++,
                                    d = a.__ranges[g];
                                ga.renderText(a, b.substring(d.start, d.end), d.format, e);
                                e +=
                                    c[g]
                            }
                    } else if (a.autoSize == wa.LEFT && (a.__width = 4), a.__canvas.width = Math.ceil(a.__width), a.__canvas.height = Math.ceil(a.__height), a.border || a.background) a.border ? ga.context.rect(.5, .5, a.__width - 1, a.__height - 1) : a.__context.rect(0, 0, a.__width, a.__height), a.background && (ga.context.fillStyle = "#" + M.hex(a.backgroundColor, 6), ga.context.fill()), a.border && (ga.context.lineWidth = 1, ga.context.lineCap = "square", ga.context.strokeStyle = "#" + M.hex(a.borderColor, 6), ga.context.stroke());
                    a.__dirty = !1;
                    return !0
                }
            return !1
        };
        var sf = function(a) {
            this.renderSession = a
        };
        g["openfl._internal.renderer.canvas.MaskManager"] = sf;
        sf.__name__ = ["openfl", "_internal", "renderer", "canvas", "MaskManager"];
        sf.prototype = {
            pushMask: function(a) {
                var b = this.renderSession.context;
                b.save();
                var c = a.__getTransform();
                b.setTransform(c.a, c.c, c.b, c.d, c.tx, c.ty);
                b.beginPath();
                a.__renderMask(this.renderSession);
                b.clip()
            },
            pushRect: function(a, b) {
                var c = this.renderSession.context;
                c.save();
                c.setTransform(b.a, b.c, b.b, b.d, b.tx, b.ty);
                c.beginPath();
                c.rect(a.x, a.y,
                    a.width, a.height);
                c.clip()
            },
            popMask: function() {
                this.renderSession.context.restore()
            },
            __class__: sf
        };
        var ee = function() {};
        g["openfl._internal.renderer.dom.DOMBitmap"] = ee;
        ee.__name__ = ["openfl", "_internal", "renderer", "dom", "DOMBitmap"];
        ee.renderCanvas = function(a, b) {
            null != a.__image && (b.element.removeChild(a.__image), a.__image = null);
            null == a.__canvas && (a.__canvas = window.document.createElement("canvas"), a.__context = a.__canvas.getContext("2d"), a.smoothing || (a.__context.mozImageSmoothingEnabled = !1, a.__context.webkitImageSmoothingEnabled = !1, a.__context.imageSmoothingEnabled = !1), eb.initializeElement(a, a.__canvas, b));
            a.bitmapData.__sync();
            a.__canvas.width = a.bitmapData.width;
            a.__canvas.height = a.bitmapData.height;
            a.__context.globalAlpha = a.__worldAlpha;
            a.__context.drawImage(a.bitmapData.__image.buffer.__srcCanvas, 0, 0);
            eb.applyStyle(a, b, !0, !1, !0)
        };
        ee.renderImage = function(a, b) {
            null != a.__canvas && (b.element.removeChild(a.__canvas), a.__canvas = null);
            null == a.__image && (a.__image = window.document.createElement("img"), a.__image.src = a.bitmapData.__image.buffer.__srcImage.src,
                eb.initializeElement(a, a.__image, b));
            eb.applyStyle(a, b, !0, !0, !0)
        };
        var eb = function(a, b, c) {
            ub.call(this, a, b);
            this.element = c;
            this.renderSession = new Ec;
            this.renderSession.element = c;
            this.renderSession.roundPixels = !0;
            a = window.getComputedStyle(document.documentElement, "");
            a = (Array.prototype.slice.call(a).join("").match(/-(moz|webkit|ms)-/) || "" === a.OLink && ["", "o"])[1];
            "WebKit|Moz|MS|O".match(new RegExp("(" + a + ")", "i"));
            a[0].toUpperCase();
            a.substr(1);
            this.renderSession.vendorPrefix = a;
            this.renderSession.transformProperty =
                "webkit" == a ? "-webkit-transform" : "transform";
            this.renderSession.transformOriginProperty = "webkit" == a ? "-webkit-transform-origin" : "transform-origin";
            this.renderSession.renderer = this
        };
        g["openfl._internal.renderer.dom.DOMRenderer"] = eb;
        eb.__name__ = ["openfl", "_internal", "renderer", "dom", "DOMRenderer"];
        eb.applyStyle = function(a, b, c, d, e) {
            var f = a.__style;
            c && a.__worldTransformChanged && f.setProperty(b.transformProperty, a.__worldTransform.to3DString(b.roundPixels), null);
            a.__worldZ != ++b.z && (a.__worldZ = b.z, f.setProperty("z-index",
                null == a.__worldZ ? "null" : "" + a.__worldZ, null));
            d && a.__worldAlphaChanged && (1 > a.__worldAlpha ? f.setProperty("opacity", null == a.__worldAlpha ? "null" : "" + a.__worldAlpha, null) : f.removeProperty("opacity"));
            e && a.__worldClipChanged && (null == a.__worldClip ? f.removeProperty("clip") : (a = a.__worldClip.transform(a.__worldTransform.clone().invert()), f.setProperty("clip", "rect(" + a.y + "px, " + a.get_right() + "px, " + a.get_bottom() + "px, " + a.x + "px)", null)))
        };
        eb.initializeElement = function(a, b, c) {
            var d = a.__style = b.style;
            d.setProperty("position",
                "absolute", null);
            d.setProperty("top", "0", null);
            d.setProperty("left", "0", null);
            d.setProperty(c.transformOriginProperty, "0 0 0", null);
            c.element.appendChild(b);
            a.__worldAlphaChanged = !0;
            a.__worldClipChanged = !0;
            a.__worldTransformChanged = !0;
            a.__worldVisibleChanged = !0;
            a.__worldZ = -1
        };
        eb.__super__ = ub;
        eb.prototype = t(ub.prototype, {
            render: function(a) {
                this.element.style.background = a.__colorString;
                this.renderSession.z = 1;
                a.__renderDOM(this.renderSession)
            },
            __class__: eb
        });
        var Kf = function() {};
        g["openfl._internal.renderer.dom.DOMShape"] =
            Kf;
        Kf.__name__ = ["openfl", "_internal", "renderer", "dom", "DOMShape"];
        Kf.render = function(a, b) {
            var c = a.__graphics;
            if (null != a.stage && a.__worldVisible && a.__renderable && null != c) {
                if (c.__dirty || a.__worldAlphaChanged || null == a.__canvas && null != c.__canvas) h.render(c, b), null != c.__canvas ? (null == a.__canvas && (a.__canvas = window.document.createElement("canvas"), a.__context = a.__canvas.getContext("2d"), eb.initializeElement(a, a.__canvas, b)), a.__canvas.width = c.__canvas.width, a.__canvas.height = c.__canvas.height, a.__context.globalAlpha =
                    a.__worldAlpha, a.__context.drawImage(c.__canvas, 0, 0)) : null != a.__canvas && (b.element.removeChild(a.__canvas), a.__canvas = null, a.__style = null);
                if (null != a.__canvas) {
                    if (a.__worldTransformChanged || c.__transformDirty) {
                        c.__transformDirty = !1;
                        var d = new da;
                        d.translate(c.__bounds.x, c.__bounds.y);
                        d = d.mult(a.__worldTransform);
                        a.__style.setProperty(b.transformProperty, b.roundPixels ? "matrix3d(" + d.a + ", " + d.b + ", 0, 0, " + d.c + ", " + d.d + ", 0, 0, 0, 0, 1, 0, " + (d.tx | 0) + ", " + (d.ty | 0) + ", 0, 1)" : "matrix3d(" + d.a + ", " + d.b + ", 0, 0, " +
                            d.c + ", " + d.d + ", 0, 0, 0, 0, 1, 0, " + d.tx + ", " + d.ty + ", 0, 1)", null)
                    }
                    eb.applyStyle(a, b, !1, !1, !0)
                }
            } else null != a.__canvas && (b.element.removeChild(a.__canvas), a.__canvas = null, a.__style = null)
        };
        var Lf = function() {};
        g["openfl._internal.renderer.dom.DOMTextField"] = Lf;
        Lf.__name__ = ["openfl", "_internal", "renderer", "dom", "DOMTextField"];
        Lf.render = function(a, b) {
            if (null != a.stage && a.__worldVisible && a.__renderable) {
                if (a.__dirty || null == a.__div)
                    if ("" != a.__text || a.background || a.border) {
                        null == a.__div && (a.__div = window.document.createElement("div"),
                            eb.initializeElement(a, a.__div, b), a.__style.setProperty("cursor", "inherit", null));
                        var c = a.__style;
                        a.__div.innerHTML = a.__text;
                        a.background ? c.setProperty("background-color", "#" + M.hex(a.backgroundColor, 6), null) : c.removeProperty("background-color");
                        a.border ? c.setProperty("border", "solid 1px #" + M.hex(a.borderColor, 6), null) : c.removeProperty("border");
                        c.setProperty("font", a.__getFont(a.__textFormat), null);
                        c.setProperty("color", "#" + M.hex(a.__textFormat.color, 6), null);
                        a.autoSize != wa.NONE ? c.setProperty("width",
                            "auto", null) : c.setProperty("width", a.__width + "px", null);
                        c.setProperty("height", a.__height + "px", null);
                        switch (a.__textFormat.align[1]) {
                            case 3:
                                c.setProperty("text-align", "center", null);
                                break;
                            case 1:
                                c.setProperty("text-align", "right", null);
                                break;
                            default:
                                c.setProperty("text-align", "left", null)
                        }
                        a.__dirty = !1
                    } else null != a.__div && (b.element.removeChild(a.__div), a.__div = null);
                null != a.__div && eb.applyStyle(a, b, !0, !0, !1)
            } else null != a.__div && (b.element.removeChild(a.__div), a.__div = null, a.__style = null)
        };
        var Qf =
            function() {};
        g["openfl._internal.renderer.opengl.GLBitmap"] = Qf;
        Qf.__name__ = ["openfl", "_internal", "renderer", "opengl", "GLBitmap"];
        Qf.render = function(a, b) {
            !a.__renderable || 0 >= a.__worldAlpha || b.spriteBatch.render(a)
        };
        var ha = function(a, b, c, d, e, f) {
            null == f && (f = !1);
            null == e && (e = !1);
            null == d && (d = !1);
            null == b && (b = 600);
            null == a && (a = 800);
            ub.call(this, a, b);
            this.transparent = d;
            this.preserveDrawingBuffer = f;
            this.width = a;
            this.height = b;
            this.options = {
                alpha: d,
                antialias: e,
                premultipliedAlpha: d,
                stencil: !0,
                preserveDrawingBuffer: f
            };
            this._glContextId = ha.glContextId++;
            this.gl = c;
            ha.glContexts[this._glContextId] = c;
            null == ha.blendModesWebGL && (ha.blendModesWebGL = new fd, ha.blendModesWebGL.set(G.NORMAL, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.ADD, [c.SRC_ALPHA, c.DST_ALPHA]), ha.blendModesWebGL.set(G.MULTIPLY, [c.DST_COLOR, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.SCREEN, [c.SRC_ALPHA, c.ONE]), ha.blendModesWebGL.set(G.ALPHA, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.DARKEN, [c.ONE, c.ONE_MINUS_SRC_ALPHA]),
                ha.blendModesWebGL.set(G.DIFFERENCE, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.ERASE, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.HARDLIGHT, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.INVERT, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.LAYER, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.LIGHTEN, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.OVERLAY, [c.ONE, c.ONE_MINUS_SRC_ALPHA]), ha.blendModesWebGL.set(G.SUBTRACT, [c.ONE, c.ONE_MINUS_SRC_ALPHA]));
            this.projection = new ja;
            this.projection.x = this.width / 2;
            this.projection.y = -this.height / 2;
            this.offset = new ja(0, 0);
            this.resize(this.width, this.height);
            this.contextLost = !1;
            this.shaderManager = new tf(c);
            this.spriteBatch = new uf(c);
            this.maskManager = new vf(c);
            this.filterManager = new wf(c, this.transparent);
            this.stencilManager = new xf(c);
            this.blendModeManager = new yf(c);
            this.renderSession = new Ec;
            this.renderSession.gl = this.gl;
            this.renderSession.drawCount = 0;
            this.renderSession.shaderManager = this.shaderManager;
            this.renderSession.maskManager =
                this.maskManager;
            this.renderSession.filterManager = this.filterManager;
            this.renderSession.blendModeManager = this.blendModeManager;
            this.renderSession.spriteBatch = this.spriteBatch;
            this.renderSession.stencilManager = this.stencilManager;
            this.renderSession.renderer = this;
            c.useProgram(this.shaderManager.defaultShader.program);
            c.disable(c.DEPTH_TEST);
            c.disable(c.CULL_FACE);
            c.enable(c.BLEND);
            c.colorMask(!0, !0, !0, this.transparent)
        };
        g["openfl._internal.renderer.opengl.GLRenderer"] = ha;
        ha.__name__ = ["openfl", "_internal",
            "renderer", "opengl", "GLRenderer"
        ];
        ha.__super__ = ub;
        ha.prototype = t(ub.prototype, {
            render: function(a) {
                if (!this.contextLost) {
                    var b = this.gl;
                    b.viewport(0, 0, this.width, this.height);
                    b.bindFramebuffer(b.FRAMEBUFFER, null);
                    this.transparent ? b.clearColor(0, 0, 0, 0) : b.clearColor(a.__colorSplit[0] | 0, a.__colorSplit[1] | 0, a.__colorSplit[2] | 0, 1);
                    b.clear(b.COLOR_BUFFER_BIT);
                    this.renderDisplayObject(a, this.projection)
                }
            },
            renderDisplayObject: function(a, b, c) {
                this.renderSession.blendModeManager.setBlendMode(G.NORMAL);
                this.renderSession.drawCount =
                    0;
                this.renderSession.currentBlendMode = null;
                this.renderSession.projection = b;
                this.renderSession.offset = this.offset;
                this.spriteBatch.begin(this.renderSession);
                this.filterManager.begin(this.renderSession, c);
                a.__renderGL(this.renderSession);
                this.spriteBatch.end()
            },
            resize: function(a, b) {
                ub.prototype.resize.call(this, a, b);
                this.gl.viewport(0, 0, a, b);
                this.projection.x = a / 2;
                this.projection.y = -b / 2
            },
            __class__: ha
        });
        var Mf = function() {};
        g["openfl._internal.renderer.opengl.GLTextField"] = Mf;
        Mf.__name__ = ["openfl", "_internal",
            "renderer", "opengl", "GLTextField"
        ];
        Mf.render = function(a, b) {
            if (a.__renderable && !(0 >= a.__worldAlpha)) {
                var c = b.gl,
                    d = ga.update(a);
                null == a.__texture && (a.__texture = c.createTexture(), c.bindTexture(c.TEXTURE_2D, a.__texture), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_WRAP_S, c.CLAMP_TO_EDGE), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_WRAP_T, c.CLAMP_TO_EDGE), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_MAG_FILTER, c.LINEAR), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_MIN_FILTER, c.LINEAR), d = !0);
                d && (c.bindTexture(c.TEXTURE_2D, a.__texture),
                    c.texImage2D(c.TEXTURE_2D, 0, c.RGBA, c.RGBA, c.UNSIGNED_BYTE, a.__canvas), c.bindTexture(c.TEXTURE_2D, null))
            }
        };
        var Q = function(a) {
            this._UID = Q.__UID++;
            this.gl = a;
            this.program = null;
            this.attributes = []
        };
        g["openfl._internal.renderer.opengl.shaders.AbstractShader"] = Q;
        Q.__name__ = "openfl _internal renderer opengl shaders AbstractShader".split(" ");
        Q.compileProgram = function(a, b, c) {
            c = Q.CompileFragmentShader(a, c);
            b = Q.CompileVertexShader(a, b);
            var d = a.createProgram();
            null != c && null != b && (a.attachShader(d, b), a.attachShader(d,
                c), a.linkProgram(d), 0 == a.getProgramParameter(d, a.LINK_STATUS) && console.log("Could not initialize shaders"));
            return d
        };
        Q.CompileVertexShader = function(a, b) {
            return Q._CompileShader(a, b, a.VERTEX_SHADER)
        };
        Q.CompileFragmentShader = function(a, b) {
            return Q._CompileShader(a, b, a.FRAGMENT_SHADER)
        };
        Q._CompileShader = function(a, b, c) {
            b = b.join("\n");
            c = a.createShader(c);
            a.shaderSource(c, b);
            a.compileShader(c);
            return 0 == a.getShaderParameter(c, a.COMPILE_STATUS) ? (console.log(a.getShaderInfoLog(c)), null) : c
        };
        Q.prototype = {
            init: function() {
                var a = this.gl,
                    b = Q.compileProgram(a, this.vertexSrc, this.fragmentSrc);
                a.useProgram(b);
                this.program = b
            },
            __class__: Q
        };
        var fe = function(a) {
            Q.call(this, a);
            this.fragmentSrc = ["precision mediump float;", "varying vec4 vColor;", "void main(void) {", "   gl_FragColor = vColor;", "}"];
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "uniform mat3 translationMatrix;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "uniform vec3 tint;", "uniform float alpha;", "uniform vec3 color;", "varying vec4 vColor;",
                "void main(void) {", "   vec3 v = translationMatrix * vec3(aVertexPosition , 1.0);", "   v -= offsetVector.xyx;", "   gl_Position = vec4( v.x / projectionVector.x -1.0, v.y / -projectionVector.y + 1.0 , 0.0, 1.0);", "   vColor = vec4(color * alpha * tint, alpha);", "}"
            ];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.ComplexPrimitiveShader"] = fe;
        fe.__name__ = "openfl _internal renderer opengl shaders ComplexPrimitiveShader".split(" ");
        fe.__super__ = Q;
        fe.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                var a = this.gl;
                this.projectionVector = a.getUniformLocation(this.program, "projectionVector");
                this.offsetVector = a.getUniformLocation(this.program, "offsetVector");
                this.tintColor = a.getUniformLocation(this.program, "tint");
                this.color = a.getUniformLocation(this.program, "color");
                this.aVertexPosition = a.getAttribLocation(this.program, "aVertexPosition");
                this.attributes = [this.aVertexPosition];
                this.translationMatrix = a.getUniformLocation(this.program, "translationMatrix");
                this.alpha = a.getUniformLocation(this.program,
                    "alpha")
            },
            __class__: fe
        });
        var Lc = function(a) {
            Q.call(this, a);
            this.fragmentSrc = ["precision lowp float;", "varying vec2 vTextureCoord;", "varying vec4 vColor;", "uniform sampler2D uSampler;", "void main(void) {", "   gl_FragColor = texture2D(uSampler, vTextureCoord) * vColor ;", "}"];
            this.textureCount = 0;
            this.attributes = [];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.DefaultShader"] = Lc;
        Lc.__name__ = "openfl _internal renderer opengl shaders DefaultShader".split(" ");
        Lc.__super__ = Q;
        Lc.prototype = t(Q.prototype, {
            init: function() {
                null == this.vertexSrc && (this.vertexSrc = Lc.defaultVertexSrc);
                Q.prototype.init.call(this);
                var a = this.gl;
                this.uSampler = a.getUniformLocation(this.program, "uSampler");
                this.projectionVector = a.getUniformLocation(this.program, "projectionVector");
                this.offsetVector = a.getUniformLocation(this.program, "offsetVector");
                this.dimensions = a.getUniformLocation(this.program, "dimensions");
                this.aVertexPosition = a.getAttribLocation(this.program, "aVertexPosition");
                this.aTextureCoord = a.getAttribLocation(this.program,
                    "aTextureCoord");
                this.colorAttribute = a.getAttribLocation(this.program, "aColor"); - 1 == this.colorAttribute && (this.colorAttribute = 2);
                this.attributes = [this.aVertexPosition, this.aTextureCoord, this.colorAttribute];
                if (null != this.uniforms)
                    for (var b = this.uniforms.keys(); b.hasNext();) {
                        var c = b.next();
                        this.uniforms.get(c).uniformLocation = a.getUniformLocation(this.program, c)
                    }
                this.initUniforms()
            },
            initSampler2D: function(a) {
                if (null != a.value && null != a.value.baseTexture && null != a.value.baseTexture.hasLoaded) {
                    var b = this.gl;
                    b.activeTexture(z.field(b, "TEXTURE" + this.textureCount));
                    b.bindTexture(b.TEXTURE_2D, a.value.baseTexture._glTextures[ha.glContextId]);
                    if (null != a.textureData) {
                        var c = a.textureData,
                            d;
                        d = 0 != c.magFilter ? c.magFilter : b.LINEAR;
                        var e;
                        e = 0 != c.minFilter ? c.minFilter : b.LINEAR;
                        var f;
                        f = 0 != c.wrapS ? c.wrapS : b.CLAMP_TO_EDGE;
                        var l;
                        l = 0 != c.wrapT ? c.wrapT : b.CLAMP_TO_EDGE;
                        var g;
                        g = 0 != c.luminance ? b.LUMINANCE : b.RGBA;
                        c.repeat && (l = f = b.REPEAT);
                        b.pixelStorei(b.UNPACK_FLIP_Y_WEBGL, c.flip);
                        0 != c.width ? b.texImage2D(b.TEXTURE_2D, 0, g, 0 !=
                            c.width ? c.width : 512, 0 != c.height ? c.height : 2, 0 != c.border ? c.border : 0, g, b.UNSIGNED_BYTE, null) : b.texImage2D(b.TEXTURE_2D, 0, g, b.RGBA, b.UNSIGNED_BYTE, a.value.baseTexture.source);
                        b.texParameteri(b.TEXTURE_2D, b.TEXTURE_MAG_FILTER, d);
                        b.texParameteri(b.TEXTURE_2D, b.TEXTURE_MIN_FILTER, e);
                        b.texParameteri(b.TEXTURE_2D, b.TEXTURE_WRAP_S, f);
                        b.texParameteri(b.TEXTURE_2D, b.TEXTURE_WRAP_T, l)
                    }
                    b.uniform1i(a.uniformLocation, this.textureCount);
                    a._init = !0;
                    this.textureCount++
                }
            },
            initUniforms: function() {
                this.textureCount = 1;
                var a = this.gl,
                    b;
                if (null != this.uniforms)
                    for (var c = this.uniforms.keys(); c.hasNext();) {
                        b = c.next();
                        b = this.uniforms.get(b);
                        var d = b.type;
                        "sampler2D" == d ? (b._init = !1, null != b.value && this.initSampler2D(b)) : "mat2" == d || "mat3" == d || "mat4" == d ? (b.glMatrix = !0, b.glValueLength = 1, "mat2" == d ? b.glFunc = r(a, a.uniformMatrix2fv) : "mat3" == d ? b.glFunc = r(a, a.uniformMatrix3fv) : "mat4" == d && (b.glFunc = r(a, a.uniformMatrix4fv))) : (b.glFunc = z.field(a, "uniform" + d), b.glValueLength = "2f" == d || "2i" == d ? 2 : "3f" == d || "3i" == d ? 3 : "4f" == d || "4i" == d ? 4 : 1)
                    }
            },
            __class__: Lc
        });
        var ge = function(a) {
            Q.call(this, a);
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "attribute vec2 aTextureCoord;", "attribute vec4 aColor;", "uniform mat3 translationMatrix;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "varying vec2 vPos;", "varying vec4 vColor;", "void main(void) {", "   vec3 v = vec3(aVertexPosition , 1.0);", "   v -= offsetVector.xyx;", "   gl_Position = vec4( v.x / projectionVector.x -1.0, v.y / -projectionVector.y + 1.0 , 0.0, 1.0);", "   vPos = aTextureCoord;",
                "   vColor = aColor;", "}"
            ];
            this.fragmentSrc = ["precision mediump float;", "uniform sampler2D sampler;", "uniform vec3 color;", "uniform bool useTexture;", "uniform float alpha;", "varying vec2 vPos;", "varying vec4 vColor;", "vec4 tmp;", "void main(void) {", "   if(useTexture) {", "       tmp = texture2D(sampler, vPos);", "   } else {", "       tmp = vec4(color, 1.);", "   }", "   float a = tmp.a * vColor.a * alpha;", "   gl_FragColor = vec4(vec3((tmp.rgb * vColor.rgb) * a), a);", "}"];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.DrawTrianglesShader"] =
            ge;
        ge.__name__ = "openfl _internal renderer opengl shaders DrawTrianglesShader".split(" ");
        ge.__super__ = Q;
        ge.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                this.translationMatrix = this.gl.getUniformLocation(this.program, "translationMatrix");
                this.projectionVector = this.gl.getUniformLocation(this.program, "projectionVector");
                this.offsetVector = this.gl.getUniformLocation(this.program, "offsetVector");
                this.sampler = this.gl.getUniformLocation(this.program, "sampler");
                this.alpha = this.gl.getUniformLocation(this.program,
                    "alpha");
                this.color = this.gl.getUniformLocation(this.program, "color");
                this.useTexture = this.gl.getUniformLocation(this.program, "useTexture");
                this.aVertexPosition = this.gl.getAttribLocation(this.program, "aVertexPosition");
                this.aTextureCoord = this.gl.getAttribLocation(this.program, "aTextureCoord");
                this.colorAttribute = this.gl.getAttribLocation(this.program, "aColor");
                this.attributes = [this.aVertexPosition, this.aTextureCoord, this.colorAttribute]
            },
            __class__: ge
        });
        var he = function(a) {
            Q.call(this, a);
            this.fragmentSrc = ["precision lowp float;", "varying vec2 vTextureCoord;", "varying float vColor;", "uniform sampler2D uSampler;", "void main(void) {", "   gl_FragColor = texture2D(uSampler, vTextureCoord) * vColor ;", "}"];
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "attribute vec2 aPositionCoord;", "attribute vec2 aScale;", "attribute float aRotation;", "attribute vec2 aTextureCoord;", "attribute float aColor;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "uniform mat3 uMatrix;", "varying vec2 vTextureCoord;",
                "varying float vColor;", "const vec2 center = vec2(-1.0, 1.0);", "void main(void) {", "   vec2 v;", "   vec2 sv = aVertexPosition * aScale;", "   v.x = (sv.x) * cos(aRotation) - (sv.y) * sin(aRotation);", "   v.y = (sv.x) * sin(aRotation) + (sv.y) * cos(aRotation);", "   v = ( uMatrix * vec3(v + aPositionCoord , 1.0) ).xy ;", "   gl_Position = vec4( ( v / projectionVector) + center , 0.0, 1.0);", "   vTextureCoord = aTextureCoord;", "   vColor = aColor;", "}"
            ];
            this.textureCount = 0;
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.FastShader"] =
            he;
        he.__name__ = "openfl _internal renderer opengl shaders FastShader".split(" ");
        he.__super__ = Q;
        he.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                var a = this.gl;
                this.uSampler = a.getUniformLocation(this.program, "uSampler");
                this.projectionVector = a.getUniformLocation(this.program, "projectionVector");
                this.offsetVector = a.getUniformLocation(this.program, "offsetVector");
                this.dimensions = a.getUniformLocation(this.program, "dimensions");
                this.uMatrix = a.getUniformLocation(this.program, "uMatrix");
                this.aVertexPosition = a.getAttribLocation(this.program, "aVertexPosition");
                this.aPositionCoord = a.getAttribLocation(this.program, "aPositionCoord");
                this.aScale = a.getAttribLocation(this.program, "aScale");
                this.aRotation = a.getAttribLocation(this.program, "aRotation");
                this.aTextureCoord = a.getAttribLocation(this.program, "aTextureCoord");
                this.colorAttribute = a.getAttribLocation(this.program, "aColor"); - 1 == this.colorAttribute && (this.colorAttribute = 2);
                this.attributes = [this.aVertexPosition, this.aPositionCoord, this.aScale,
                    this.aRotation, this.aTextureCoord, this.colorAttribute
                ]
            },
            __class__: he
        });
        var ie = function(a) {
            Q.call(this, a);
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "uniform mat3 translationMatrix;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "void main(void) {", "   vec3 v = translationMatrix * vec3(aVertexPosition , 1.0);", "   v -= offsetVector.xyx;", "   gl_Position = vec4( v.x / projectionVector.x -1.0, v.y / -projectionVector.y + 1.0 , 0.0, 1.0);", "}"];
            this.fragmentSrc = ["precision mediump float;",
                "uniform vec3 color;", "uniform float alpha;", "void main(void) {", "   gl_FragColor = vec4((color * alpha), alpha);", "}"
            ];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.FillShader"] = ie;
        ie.__name__ = "openfl _internal renderer opengl shaders FillShader".split(" ");
        ie.__super__ = Q;
        ie.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                this.translationMatrix = this.gl.getUniformLocation(this.program, "translationMatrix");
                this.projectionVector = this.gl.getUniformLocation(this.program,
                    "projectionVector");
                this.offsetVector = this.gl.getUniformLocation(this.program, "offsetVector");
                this.color = this.gl.getUniformLocation(this.program, "color");
                this.alpha = this.gl.getUniformLocation(this.program, "alpha");
                this.aVertexPosition = this.gl.getAttribLocation(this.program, "aVertexPosition");
                this.attributes = [this.aVertexPosition]
            },
            __class__: ie
        });
        var je = function(a) {
            Q.call(this, a);
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "uniform mat3 translationMatrix;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;",
                "uniform mat3 patternMatrix;", "varying vec2 vPos;", "void main(void) {", "   vec3 v = translationMatrix * vec3(aVertexPosition , 1.0);", "   v -= offsetVector.xyx;", "   gl_Position = vec4( v.x / projectionVector.x -1.0, v.y / -projectionVector.y + 1.0 , 0.0, 1.0);", "   vPos = (patternMatrix * vec3(aVertexPosition, 1)).xy;", "}"
            ];
            this.fragmentSrc = ["precision mediump float;", "uniform float alpha;", "uniform vec2 patternTL;", "uniform vec2 patternBR;", "uniform sampler2D sampler;", "varying vec2 vPos;", "void main(void) {",
                "   vec2 pos = mix(patternTL, patternBR, vPos);", "   vec4 tcol = texture2D(sampler, pos);", "   gl_FragColor = vec4(tcol.rgb * alpha, tcol.a * alpha);", "}"
            ];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.PatternFillShader"] = je;
        je.__name__ = "openfl _internal renderer opengl shaders PatternFillShader".split(" ");
        je.__super__ = Q;
        je.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                this.translationMatrix = this.gl.getUniformLocation(this.program, "translationMatrix");
                this.projectionVector =
                    this.gl.getUniformLocation(this.program, "projectionVector");
                this.offsetVector = this.gl.getUniformLocation(this.program, "offsetVector");
                this.patternMatrix = this.gl.getUniformLocation(this.program, "patternMatrix");
                this.patternTL = this.gl.getUniformLocation(this.program, "patternTL");
                this.patternBR = this.gl.getUniformLocation(this.program, "patternBR");
                this.sampler = this.gl.getUniformLocation(this.program, "sampler");
                this.alpha = this.gl.getUniformLocation(this.program, "alpha");
                this.aVertexPosition = this.gl.getAttribLocation(this.program,
                    "aVertexPosition");
                this.attributes = [this.aVertexPosition]
            },
            __class__: je
        });
        var ke = function(a) {
            Q.call(this, a);
            this.fragmentSrc = ["precision mediump float;", "varying vec4 vColor;", "void main(void) {", "   gl_FragColor = vColor;", "}"];
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "attribute vec4 aColor;", "uniform mat3 translationMatrix;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "uniform float alpha;", "uniform vec3 tint;", "varying vec4 vColor;", "void main(void) {", "   vec3 v = translationMatrix * vec3(aVertexPosition , 1.0);",
                "   v -= offsetVector.xyx;", "   gl_Position = vec4( v.x / projectionVector.x -1.0, v.y / -projectionVector.y + 1.0 , 0.0, 1.0);", "   vColor = aColor;", "}"
            ];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.PrimitiveShader"] = ke;
        ke.__name__ = "openfl _internal renderer opengl shaders PrimitiveShader".split(" ");
        ke.__super__ = Q;
        ke.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                var a = this.gl;
                this.projectionVector = a.getUniformLocation(this.program, "projectionVector");
                this.offsetVector =
                    a.getUniformLocation(this.program, "offsetVector");
                this.tintColor = a.getUniformLocation(this.program, "tint");
                this.aVertexPosition = a.getAttribLocation(this.program, "aVertexPosition");
                this.colorAttribute = a.getAttribLocation(this.program, "aColor");
                this.attributes = [this.aVertexPosition, this.colorAttribute];
                this.translationMatrix = a.getUniformLocation(this.program, "translationMatrix");
                this.alpha = a.getUniformLocation(this.program, "alpha")
            },
            __class__: ke
        });
        var le = function(a) {
            Q.call(this, a);
            this.fragmentSrc = ["precision mediump float;", "varying vec2 vTextureCoord;", "uniform float alpha;", "uniform sampler2D uSampler;", "void main(void) {", "   gl_FragColor = texture2D(uSampler, vec2(vTextureCoord.x, vTextureCoord.y));", "}"];
            this.vertexSrc = ["attribute vec2 aVertexPosition;", "attribute vec2 aTextureCoord;", "uniform mat3 translationMatrix;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "varying vec2 vTextureCoord;", "void main(void) {", "   vec3 v = translationMatrix * vec3(aVertexPosition , 1.0);",
                "   v -= offsetVector.xyx;", "   gl_Position = vec4( v.x / projectionVector.x -1.0, v.y / -projectionVector.y + 1.0 , 0.0, 1.0);", "   vTextureCoord = aTextureCoord;", "}"
            ];
            this.init()
        };
        g["openfl._internal.renderer.opengl.shaders.StripShader"] = le;
        le.__name__ = "openfl _internal renderer opengl shaders StripShader".split(" ");
        le.__super__ = Q;
        le.prototype = t(Q.prototype, {
            init: function() {
                Q.prototype.init.call(this);
                var a = this.gl;
                this.uSampler = a.getUniformLocation(this.program, "uSampler");
                this.projectionVector =
                    a.getUniformLocation(this.program, "projectionVector");
                this.offsetVector = a.getUniformLocation(this.program, "offsetVector");
                this.colorAttribute = a.getAttribLocation(this.program, "aColor");
                this.aVertexPosition = a.getAttribLocation(this.program, "aVertexPosition");
                this.aTextureCoord = a.getAttribLocation(this.program, "aTextureCoord");
                this.attributes = [this.aVertexPosition, this.aTextureCoord];
                this.translationMatrix = a.getUniformLocation(this.program, "translationMatrix");
                this.alpha = a.getUniformLocation(this.program,
                    "alpha")
            },
            __class__: le
        });
        var yf = function(a) {
            this.gl = a;
            this.currentBlendMode = null
        };
        g["openfl._internal.renderer.opengl.utils.BlendModeManager"] = yf;
        yf.__name__ = "openfl _internal renderer opengl utils BlendModeManager".split(" ");
        yf.prototype = {
            setBlendMode: function(a) {
                null == a && (a = G.NORMAL);
                if (this.currentBlendMode == a) return !1;
                this.currentBlendMode = a;
                a = ha.blendModesWebGL.get(this.currentBlendMode);
                this.gl.blendFunc(a[0], a[1]);
                return !0
            },
            __class__: yf
        };
        var Ya = function() {
            this.type = T.Polygon;
            this.points = [];
            this.isRemovable = !0;
            this.fillIndex = 0;
            this.line = new nd;
            this.fill = Ja.None
        };
        g["openfl._internal.renderer.opengl.utils.DrawPath"] = Ya;
        Ya.__name__ = "openfl _internal renderer opengl utils DrawPath".split(" ");
        Ya.getStack = function(a, b) {
            return k.build(a, b)
        };
        Ya.prototype = {
            update: function(a, b, c) {
                this.updateLine(a);
                this.fill = b;
                this.fillIndex = c
            },
            updateLine: function(a) {
                this.line.width = a.width;
                this.line.color = a.color & 16777215;
                this.line.alpha = null == a.alpha ? 1 : a.alpha;
                this.line.scaleMode = null == a.scaleMode ? Ta.NORMAL :
                    a.scaleMode;
                this.line.caps = null == a.caps ? vb.ROUND : a.caps;
                this.line.joints = null == a.joints ? wb.ROUND : a.joints;
                this.line.miterLimit = a.miterLimit
            },
            __class__: Ya
        };
        var k = function() {};
        g["openfl._internal.renderer.opengl.utils.PathBuiler"] = k;
        k.__name__ = "openfl _internal renderer opengl utils PathBuiler".split(" ");
        k.__currentPath = null;
        k.__drawPaths = null;
        k.__line = null;
        k.__fill = null;
        k.closePath = function() {
            var a = k.__currentPath.points.length;
            if (!(0 >= a) && k.__currentPath.type == T.Polygon && k.__currentPath.fill != Ja.None) {
                var b =
                    k.__currentPath.points[0],
                    c = k.__currentPath.points[1],
                    d = k.__currentPath.points[a - 1];
                if (b != k.__currentPath.points[a - 2] || c != d) k.__currentPath.points.push(b), k.__currentPath.points.push(c)
            }
        };
        k.endFill = function() {
            k.__fill = Ja.None;
            k.__fillIndex++
        };
        k.moveTo = function(a, b) {
            k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath();
            k.__currentPath = new Ya;
            k.__currentPath.update(k.__line, k.__fill, k.__fillIndex);
            k.__currentPath.type = T.Polygon;
            k.__currentPath.points.push(a);
            k.__currentPath.points.push(b);
            k.__drawPaths.push(k.__currentPath)
        };
        k.build = function(a, b) {
            var c = null,
                d = a.__bounds;
            k.__drawPaths = [];
            k.__currentPath = new Ya;
            k.__line = new nd;
            k.__fill = Ja.None;
            k.__fillIndex = 0;
            c = a.__glStack[ha.glContextId];
            null == c && (c = a.__glStack[ha.glContextId] = new zf(b));
            if (a.__visible && 0 != a.__commands.length && null != d && 0 != d.width && 0 != d.height) {
                for (var d = 0, e = a.__commands; d < e.length;) {
                    var f = e[d];
                    ++d;
                    switch (f[1]) {
                        case 0:
                            var l = f[5],
                                g = f[4],
                                h = f[3],
                                f = f[2];
                            k.endFill();
                            k.__fill = null != f ? Ja.Texture(f,
                                h, g, l) : Ja.None;
                            0 == k.__currentPath.points.length && (k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath(), k.__currentPath = new Ya, k.__currentPath.update(k.__line, k.__fill, k.__fillIndex), k.__currentPath.points = [], k.__currentPath.type = T.Polygon, k.__drawPaths.push(k.__currentPath));
                            break;
                        case 1:
                            l = f[3];
                            f = f[2];
                            k.endFill();
                            k.__fill = 0 < l ? Ja.Color(f & 16777215, l) : Ja.None;
                            0 == k.__currentPath.points.length && (k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() :
                                k.closePath(), k.__currentPath = new Ya, k.__currentPath.update(k.__line, k.__fill, k.__fillIndex), k.__currentPath.points = [], k.__currentPath.type = T.Polygon, k.__drawPaths.push(k.__currentPath));
                            break;
                        case 3:
                            var l = f[7],
                                g = f[6],
                                h = f[5],
                                m = f[4],
                                q = f[3],
                                f = f[2];
                            0 == k.__currentPath.points.length && k.moveTo(0, 0);
                            for (var n = 0, p = 0, r = 0, t = 0, x = 0, w = k.__currentPath.points, v = w[w.length - 2], u = w[w.length - 1], z = 0, A = n = 0, y = 1; 21 > y;) A = y++/20,n=1-A,p=n*n,r=p*n,t=A*A,x=t*A,z=r*v+3*p*A*f+3*n*t*m+x*g,n=r*u+3*p*A*q+3*n*t*h+x*l,w.push(z),w.push(n);
                            break;
                        case 4:
                            l = f[5];
                            g = f[4];
                            h = f[3];
                            f = f[2];
                            0 == k.__currentPath.points.length && k.moveTo(0, 0);
                            u = z = 0;
                            m = k.__currentPath.points;
                            q = m[m.length - 2];
                            w = m[m.length - 1];
                            y = u = z = 0;
                            for (v = 1; 21 > v;) y = v++/20,z=q+(f-q)*y,u=w+(h-w)*y,z+=(f+(g-f)*y-z)*y,u+=(h+(l-h)*y-u)*y,m.push(z),m.push(u);break;case 5:l=f[4];g=f[3];f=f[2];k.__currentPath.isRemovable&&0==k.__currentPath.points.length?k.__drawPaths.pop():k.closePath();k.__currentPath=new Ya;k.__currentPath.update(k.__line,k.__fill,k.__fillIndex);k.__currentPath.type=T.Circle;
                            k.__currentPath.points = [f, g, l];
                            k.__drawPaths.push(k.__currentPath);
                            break;
                        case 6:
                            l = f[5];
                            g = f[4];
                            h = f[3];
                            f = f[2];
                            k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath();
                            k.__currentPath = new Ya;
                            k.__currentPath.update(k.__line, k.__fill, k.__fillIndex);
                            k.__currentPath.type = T.Ellipse;
                            k.__currentPath.points = [f, h, g, l];
                            k.__drawPaths.push(k.__currentPath);
                            break;
                        case 7:
                            l = f[5];
                            g = f[4];
                            h = f[3];
                            f = f[2];
                            k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() :
                                k.closePath();
                            k.__currentPath = new Ya;
                            k.__currentPath.update(k.__line, k.__fill, k.__fillIndex);
                            k.__currentPath.type = T.Rectangle(!1);
                            k.__currentPath.points = [f, h, g, l];
                            k.__drawPaths.push(k.__currentPath);
                            break;
                        case 8:
                            l = f[7];
                            g = f[6];
                            h = f[5];
                            m = f[4];
                            q = f[3];
                            f = f[2]; - 1 == l && (l = g);
                            g *= .5;
                            l *= .5;
                            g > m / 2 && (g = m / 2);
                            l > h / 2 && (l = h / 2);
                            k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath();
                            k.__currentPath = new Ya;
                            k.__currentPath.update(k.__line, k.__fill, k.__fillIndex);
                            k.__currentPath.type =
                                T.Rectangle(!0);
                            k.__currentPath.points = [f, q, m, h, g, l];
                            k.__drawPaths.push(k.__currentPath);
                            break;
                        case 11:
                            k.endFill();
                            break;
                        case 12:
                            l = f[9];
                            g = f[8];
                            h = f[7];
                            m = f[6];
                            q = f[4];
                            w = f[3];
                            f = f[2];
                            k.__line = new nd;
                            k.__line.width = null == f || f == Math.NaN || 0 > f ? 0 : 0 == f ? 1 : f;
                            k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath();
                            k.__line.color = w;
                            k.__line.alpha = q;
                            k.__line.scaleMode = m;
                            k.__line.caps = h;
                            k.__line.joints = g;
                            k.__line.miterLimit = l;
                            k.__currentPath = new Ya;
                            k.__currentPath.update(k.__line,
                                k.__fill, k.__fillIndex);
                            k.__currentPath.points = [];
                            k.__currentPath.type = T.Polygon;
                            k.__drawPaths.push(k.__currentPath);
                            break;
                        case 15:
                            l = f[3];
                            k.__currentPath.points.push(f[2]);
                            k.__currentPath.points.push(l);
                            break;
                        case 16:
                            k.moveTo(f[2], f[3]);
                            break;
                        case 10:
                            l = f[7];
                            g = f[6];
                            h = f[5];
                            q = f[4];
                            m = f[3];
                            f = f[2];
                            switch (k.__fill[1]) {
                                case 1:
                                    w = !0;
                                    break;
                                default:
                                    w = !1
                            }
                            if (w && null != q) continue;
                            k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath();
                            k.__currentPath = new Ya;
                            k.__currentPath.update(k.__line,
                                k.__fill, k.__fillIndex);
                            if (null == q) switch (q = new uc, q.data = [], q.length = 0, q.fixed = !1, w = k.__fill, w[1]) {
                                case 2:
                                    for (w = w[2], v = 0, u = f.length / 2 | 0; v < u;) z = v++, q.fixed || (q.length++, q.data.length < q.length && (y = Array(q.data.length + 10), ab.blit(q.data, 0, y, 0, q.data.length), q.data = y), q.data[q.length - 1] = f.data[2 * z] / w.width), q.length, q.fixed || (q.length++, q.data.length < q.length && (y = Array(q.data.length + 10), ab.blit(q.data, 0, y, 0, q.data.length), q.data = y), q.data[q.length - 1] = f.data[2 * z + 1] / w.height), q.length
                            }
                            k.__currentPath.type =
                                T.DrawTriangles(f, m, q, h, g, l);
                            k.__currentPath.isRemovable = !1;
                            k.__drawPaths.push(k.__currentPath);
                            break;
                        case 9:
                            l = f[6], g = f[5], h = f[4], m = f[3], f = f[2], k.__currentPath.isRemovable && 0 == k.__currentPath.points.length ? k.__drawPaths.pop() : k.closePath(), k.__fillIndex++, k.__currentPath = new Ya, k.__currentPath.update(k.__line, k.__fill, k.__fillIndex), k.__currentPath.type = T.DrawTiles(f, m, h, g, l), k.__currentPath.isRemovable = !1, k.__drawPaths.push(k.__currentPath)
                    }
                }
                k.closePath()
            }
            a.__drawPaths = k.__drawPaths;
            return c
        };
        var nd =
            function() {
                this.color = this.width = 0;
                this.alpha = 1;
                this.scaleMode = Ta.NORMAL;
                this.caps = vb.ROUND;
                this.joints = wb.ROUND;
                this.miterLimit = 3
            };
        g["openfl._internal.renderer.opengl.utils.LineStyle"] = nd;
        nd.__name__ = "openfl _internal renderer opengl utils LineStyle".split(" ");
        nd.prototype = {
            __class__: nd
        };
        var Ja = g["openfl._internal.renderer.opengl.utils.FillType"] = {
            __ename__: "openfl _internal renderer opengl utils FillType".split(" "),
            __constructs__: ["None", "Color", "Texture", "Gradient"]
        };
        Ja.None = ["None", 0];
        Ja.None.toString =
            p;
        Ja.None.__enum__ = Ja;
        Ja.Color = function(a, b) {
            var c = ["Color", 1, a, b];
            c.__enum__ = Ja;
            c.toString = p;
            return c
        };
        Ja.Texture = function(a, b, c, d) {
            a = ["Texture", 2, a, b, c, d];
            a.__enum__ = Ja;
            a.toString = p;
            return a
        };
        Ja.Gradient = ["Gradient", 3];
        Ja.Gradient.toString = p;
        Ja.Gradient.__enum__ = Ja;
        var wf = function(a, b) {
            this.transparent = b;
            this.filterStack = [];
            this.offsetY = this.offsetX = 0;
            this.setContext(a)
        };
        g["openfl._internal.renderer.opengl.utils.FilterManager"] = wf;
        wf.__name__ = "openfl _internal renderer opengl utils FilterManager".split(" ");
        wf.prototype = {
            begin: function(a, b) {
                this.renderSession = a;
                this.defaultShader = a.shaderManager.defaultShader;
                var c = a.projection;
                this.width = 2 * c.x | 0;
                this.height = 2 * -c.y | 0;
                this.buffer = b
            },
            initShaderBuffers: function() {
                var a = this.gl;
                this.vertexBuffer = a.createBuffer();
                this.uvBuffer = a.createBuffer();
                this.colorBuffer = a.createBuffer();
                this.indexBuffer = a.createBuffer();
                this.vertexArray = new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]);
                a.bindBuffer(a.ARRAY_BUFFER, this.vertexBuffer);
                a.bufferData(a.ARRAY_BUFFER, this.vertexArray, a.STATIC_DRAW);
                this.uvArray = new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]);
                a.bindBuffer(a.ARRAY_BUFFER, this.uvBuffer);
                a.bufferData(a.ARRAY_BUFFER, this.uvArray, a.STATIC_DRAW);
                this.colorArray = new Float32Array([1, 16777215, 1, 16777215, 1, 16777215, 1, 16777215]);
                a.bindBuffer(a.ARRAY_BUFFER, this.colorBuffer);
                a.bufferData(a.ARRAY_BUFFER, this.colorArray, a.STATIC_DRAW);
                a.bindBuffer(a.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
                a.bufferData(a.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 1, 3, 2]), a.STATIC_DRAW)
            },
            setContext: function(a) {
                this.gl =
                    a;
                this.texturePool = [];
                this.initShaderBuffers()
            },
            __class__: wf
        };
        var Af = function(a, b, c, d) {
            null == d && (d = !0);
            this.gl = a;
            this.frameBuffer = a.createFramebuffer();
            this.texture = a.createTexture();
            a.bindTexture(a.TEXTURE_2D, this.texture);
            a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, d ? a.LINEAR : a.NEAREST);
            a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, d ? a.LINEAR : a.NEAREST);
            a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_S, a.CLAMP_TO_EDGE);
            a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_T, a.CLAMP_TO_EDGE);
            a.bindFramebuffer(a.FRAMEBUFFER,
                this.frameBuffer);
            a.framebufferTexture2D(a.FRAMEBUFFER, a.COLOR_ATTACHMENT0, a.TEXTURE_2D, this.texture, 0);
            this.renderBuffer = a.createRenderbuffer();
            a.bindRenderbuffer(a.RENDERBUFFER, this.renderBuffer);
            a.framebufferRenderbuffer(a.FRAMEBUFFER, a.DEPTH_STENCIL_ATTACHMENT, a.RENDERBUFFER, this.renderBuffer);
            this.resize(b, c)
        };
        g["openfl._internal.renderer.opengl.utils.FilterTexture"] = Af;
        Af.__name__ = "openfl _internal renderer opengl utils FilterTexture".split(" ");
        Af.prototype = {
            clear: function() {
                var a = this.gl;
                a.clearColor(0, 0, 0, 0);
                a.clear(a.COLOR_BUFFER_BIT)
            },
            resize: function(a, b) {
                if (this.width != a || this.height != b) {
                    this.width = a;
                    this.height = b;
                    var c = this.gl;
                    c.bindTexture(c.TEXTURE_2D, this.texture);
                    c.texImage2D(c.TEXTURE_2D, 0, c.RGBA, a, b, 0, c.RGBA, c.UNSIGNED_BYTE, null);
                    c.bindRenderbuffer(c.RENDERBUFFER, this.renderBuffer);
                    c.renderbufferStorage(c.RENDERBUFFER, c.DEPTH_STENCIL, a, b)
                }
            },
            __class__: Af
        };
        var za = function(a, b, c, d) {
            null == d && (d = 0);
            null == c && (c = 0);
            null == b && (b = 0);
            null == a && (a = 0);
            this.x = a;
            this.y = b;
            this.width = c;
            this.height = d
        };
        g["openfl.geom.Rectangle"] = za;
        za.__name__ = ["openfl", "geom", "Rectangle"];
        za.prototype = {
            copyFrom: function(a) {
                this.x = a.x;
                this.y = a.y;
                this.width = a.width;
                this.height = a.height
            },
            intersects: function(a) {
                var b;
                b = this.x < a.x ? a.x : this.x;
                if ((this.get_right() > a.get_right() ? a.get_right() : this.get_right()) <= b) return !1;
                b = this.y < a.y ? a.y : this.y;
                return (this.get_bottom() > a.get_bottom() ? a.get_bottom() : this.get_bottom()) > b
            },
            setTo: function(a, b, c, d) {
                this.x = a;
                this.y = b;
                this.width = c;
                this.height = d
            },
            transform: function(a) {
                var b =
                    a.a * this.x + a.c * this.y,
                    c = b,
                    d = a.b * this.x + a.d * this.y,
                    e = b,
                    f = a.a * (this.x + this.width) + a.c * this.y,
                    l = a.b * (this.x + this.width) + a.d * this.y;
                f < b && (b = f);
                l < d && (d = l);
                f > c && (c = f);
                l > e && (e = l);
                f = a.a * (this.x + this.width) + a.c * (this.y + this.height);
                l = a.b * (this.x + this.width) + a.d * (this.y + this.height);
                f < b && (b = f);
                l < d && (d = l);
                f > c && (c = f);
                l > e && (e = l);
                f = a.a * this.x + a.c * (this.y + this.height);
                l = a.b * this.x + a.d * (this.y + this.height);
                f < b && (b = f);
                l < d && (d = l);
                f > c && (c = f);
                l > e && (e = l);
                return new za(b + a.tx, d + a.ty, c - b, e - d)
            },
            __expand: function(a, b, c, d) {
                if (0 ==
                    this.width && 0 == this.height) this.x = a, this.y = b, this.width = c, this.height = d;
                else {
                    var e = this.get_right(),
                        f = this.get_bottom();
                    this.x > a && (this.x = a, this.width = e - a);
                    this.y > b && (this.y = b, this.height = f - b);
                    e < a + c && (this.width = a + c - this.x);
                    f < b + d && (this.height = b + d - this.y)
                }
            },
            __toLimeRectangle: function() {
                return new Ac(this.x, this.y, this.width, this.height)
            },
            get_bottom: function() {
                return this.y + this.height
            },
            get_left: function() {
                return this.x
            },
            get_right: function() {
                return this.x + this.width
            },
            get_top: function() {
                return this.y
            },
            __class__: za,
            __properties__: {
                get_top: "get_top",
                get_right: "get_right",
                get_left: "get_left",
                get_bottom: "get_bottom"
            }
        };
        var F = function() {};
        g["openfl._internal.renderer.opengl.utils.GraphicsRenderer"] = F;
        F.__name__ = "openfl _internal renderer opengl utils GraphicsRenderer".split(" ");
        F.buildCircle = function(a, b, c) {
            null == c && (c = !1);
            var d = a.points,
                e = d[0],
                f = d[1],
                l = d[2],
                d = 3 == d.length ? l : d[3];
            a.type == T.Ellipse && (l /= 2, d /= 2, e += l, f += d);
            c && (e -= F.objectBounds.x, f -= F.objectBounds.y);
            c = 2 * Math.PI / 40;
            b = F.prepareBucket(a,
                b);
            if (null != b) {
                var g = b.verts,
                    h = b.indices,
                    k = g.length / 2 | 0;
                h.push(k);
                for (var q = 0; 41 > q;) {
                    var m = q++;
                    g.push(e);
                    g.push(f);
                    g.push(e + Math.sin(c * m) * l);
                    g.push(f + Math.cos(c * m) * d);
                    h.push(k++);
                    h.push(k++)
                }
                h.push(k - 1)
            }
            if (0 < a.line.width) {
                g = a.points;
                a.points = [];
                for (h = 0; 41 > h;) k = h++, a.points.push(e + Math.sin(c * k) * l), a.points.push(f + Math.cos(c * k) * d);
                F.buildLine(a, b.line);
                a.points = g
            }
        };
        F.buildComplexPoly = function(a, b, c) {
            null == c && (c = !1);
            if (!(6 > a.points.length)) {
                var d = a.points.slice();
                if (c)
                    for (var e = 0, f = d.length / 2 | 0; e < f;) {
                        var l =
                            e++;
                        d[2 * l] -= F.objectBounds.x;
                        d[2 * l + 1] -= F.objectBounds.y
                    }
                e = F.prepareBucket(a, b);
                e.drawMode = b.gl.TRIANGLE_FAN;
                e.verts = d;
                b = e.indices;
                d = d.length / 2 | 0;
                for (f = 0; f < d;) l = f++, b.push(l);
                0 < a.line.width && F.buildLine(a, e.line, c)
            }
        };
        F.buildLine = function(a, b, c) {
            null == c && (c = !1);
            var d = a.points;
            if (0 != d.length) {
                if (c) {
                    c = 0;
                    for (var e = d.length / 2 | 0; c < e;) {
                        var f = c++;
                        d[2 * f] -= F.objectBounds.x;
                        d[2 * f + 1] -= F.objectBounds.y
                    }
                }
                if (0 < a.line.width % 2)
                    for (c = 0, e = d.length; c < e;) f = c++, d[f] += .5;
                e = new ja(d[0], d[1]);
                f = new ja(d[d.length - 2 | 0], d[d.length -
                    1 | 0]);
                e.x == f.x && e.y == f.y && (d = d.slice(), d.pop(), d.pop(), f = new ja(d[d.length - 2 | 0], d[d.length - 1 | 0]), c = f.x + .5 * (e.x - f.x), e = f.y + .5 * (e.y - f.y), d.unshift(e), d.unshift(c), d.push(c), d.push(e));
                c = b.verts;
                b = b.indices;
                var l = d.length / 2 | 0,
                    e = d.length,
                    f = c.length / 6 | 0,
                    g = a.line.width / 2,
                    h = F.hex2rgb(a.line.color);
                a = a.line.alpha;
                var k = h[0] * a,
                    q = h[1] * a,
                    h = h[2] * a,
                    m, n, p, r, t, x, w, v, u, z, y, A, D, C;
                p = d[0];
                r = d[1];
                t = d[2];
                x = d[3];
                v = -(r - x);
                u = p - t;
                n = Math.sqrt(Math.abs(v * v + u * u));
                v = v / n * g;
                u = u / n * g;
                c.push(p - v);
                c.push(r - u);
                c.push(k);
                c.push(q);
                c.push(h);
                c.push(a);
                c.push(p + v);
                c.push(r + u);
                c.push(k);
                c.push(q);
                c.push(h);
                c.push(a);
                for (var G = 1, I = l - 1; G < I;) u = G++, p = d[2 * (u - 1)], r = d[2 * (u - 1) + 1], t = d[2 * u], x = d[2 * u + 1], m = d[2 * (u + 1)], w = d[2 * (u + 1) + 1], v = -(r - x), u = p - t, n = Math.sqrt(Math.abs(v * v + u * u)), v /= n, u /= n, v *= g, u *= g, z = -(x - w), y = t - m, n = Math.sqrt(Math.abs(z * z + y * y)), z /= n, y /= n, z *= g, y *= g, n = -u + r - (-u + x), A = -v + t - (-v + p), p = (-v + p) * (-u + x) - (-v + t) * (-u + r), r = -y + w - (-y + x), D = -z + t - (-z + m), w = (-z + m) * (-y + x) - (-z + t) * (-y + w), C = n * D - r * A, .1 > Math.abs(C) ? (c.push(t - v), c.push(x - u), c.push(k), c.push(q), c.push(h),
                    c.push(a), c.push(t + v), c.push(x + u), c.push(k), c.push(q), c.push(h), c.push(a)) : (m = (A * w - D * p) / C, n = (r * p - n * w) / C, A = (m - t) * (m - t) + (n - x) + (n - x), 19600 < A ? (v -= z, u -= y, n = Math.sqrt(Math.abs(v * v + u * u)), v /= n, u /= n, v *= g, u *= g, c.push(t - v), c.push(x - u), c.push(k), c.push(q), c.push(h), c.push(a), c.push(t + v), c.push(x + u), c.push(k), c.push(q), c.push(h), c.push(a), c.push(t - v), c.push(x - u), c.push(k), c.push(q), c.push(h), c.push(a), e++) : (c.push(m), c.push(n), c.push(k), c.push(q), c.push(h), c.push(a), c.push(t - (m - t)), c.push(x - (n - x)), c.push(k), c.push(q),
                    c.push(h), c.push(a)));
                p = d[2 * (l - 2)];
                r = d[2 * (l - 2) + 1];
                t = d[2 * (l - 1)];
                x = d[2 * (l - 1) + 1];
                v = -(r - x);
                u = p - t;
                n = Math.sqrt(Math.abs(v * v + u * u));
                Math.isFinite(n) || console.log(v * v + u * u);
                v /= n;
                u /= n;
                v *= g;
                u *= g;
                c.push(t - v);
                c.push(x - u);
                c.push(k);
                c.push(q);
                c.push(h);
                c.push(a);
                c.push(t + v);
                c.push(x + u);
                c.push(k);
                c.push(q);
                c.push(h);
                c.push(a);
                b.push(f);
                for (d = 0; d < e;) d++, b.push(f++);
                b.push(f - 1)
            }
        };
        F.buildRectangle = function(a, b, c) {
            null == c && (c = !1);
            var d = a.points,
                e = d[0],
                f = d[1],
                l = d[2],
                d = d[3];
            c && (e -= F.objectBounds.x, f -= F.objectBounds.y);
            b = F.prepareBucket(a, b);
            if (null != b) {
                c = b.verts;
                var g = b.indices,
                    h = c.length / 2 | 0;
                c.push(e);
                c.push(f);
                c.push(e + l);
                c.push(f);
                c.push(e);
                c.push(f + d);
                c.push(e + l);
                c.push(f + d);
                g.push(h);
                g.push(h);
                g.push(h + 1);
                g.push(h + 2);
                g.push(h + 3);
                g.push(h + 3)
            }
            0 < a.line.width && (c = a.points, a.points = [e, f, e + l, f, e + l, f + d, e, f + d, e, f], F.buildLine(a, b.line), a.points = c)
        };
        F.buildRoundedRectangle = function(a, b, c) {
            null == c && (c = !1);
            var d = a.points.slice(),
                e = d[0],
                f = d[1],
                l = d[2],
                g = d[3],
                d = d[4];
            c && (e -= F.objectBounds.x, f -= F.objectBounds.y);
            c = [];
            c.push(e);
            c.push(f + d);
            c = c.concat(F.quadraticBezierCurve(e, f + g - d, e, f + g, e + d, f + g));
            c = c.concat(F.quadraticBezierCurve(e + l - d, f + g, e + l, f + g, e + l, f + g - d));
            c = c.concat(F.quadraticBezierCurve(e + l, f + d, e + l, f, e + l - d, f));
            c = c.concat(F.quadraticBezierCurve(e + d, f, e, f, e, f + d));
            b = F.prepareBucket(a, b);
            if (null != b) {
                e = b.verts;
                f = b.indices;
                l = e.length / 2;
                g = Mc.triangulate(c);
                for (d = 0; d < g.length;) f.push(g[d] + l | 0), f.push(g[d] + l | 0), f.push(g[d + 1] + l | 0), f.push(g[d + 2] + l | 0), f.push(g[d + 2] + l | 0), d += 3;
                for (d = 0; d < c.length;) e.push(c[d]), e.push(c[++d]), d++
            }
            0 <
                a.line.width && (e = a.points, a.points = c, F.buildLine(a, b.line), a.points = e)
        };
        F.buildDrawTriangles = function(a, b, c, d) {
            null == d && (d = !1);
            var e = a.type.slice(2),
                f = e[0],
                g = e[1],
                h = e[2],
                k = e[3],
                e = e[4],
                m, q, n, p, r;
            d ? (m = 1, n = q = 0, p = 1, b = r = 0) : (m = b.__worldTransform.a, q = b.__worldTransform.b, n = b.__worldTransform.c, p = b.__worldTransform.d, r = b.__worldTransform.tx, b = b.__worldTransform.ty);
            var t = null != e && 0 < e.length;
            c = F.prepareBucket(a, c);
            c.rawVerts = !0;
            c.glLength = g.length;
            c.stride = 8;
            a = c.glLength * c.stride;
            null == c.glVerts || c.glVerts.length <
                a ? (a = new Float32Array(a), c.glVerts = a) : a = c.glVerts;
            for (var v = 0, u = 0, x = 0, w = 0, z = c = 0, y = 0, A = 0, C = 0, D = 0, G = 0, I = 0, B = 0, H = [1, 1, 1, 1], w = H, L = 0, J = g.length / 3 | 0; L < J;) {
                u = L++;
                w = g.data[3 * u];
                c = g.data[3 * u + 1];
                z = g.data[3 * u + 2];
                v = 2 * w;
                u = 2 * c;
                x = 2 * z;
                y = f.data[v];
                A = f.data[v + 1];
                C = f.data[u];
                D = f.data[u + 1];
                G = f.data[x];
                I = f.data[x + 1];
                d && (y -= F.objectBounds.x, A -= F.objectBounds.y, C -= F.objectBounds.x, D -= F.objectBounds.y, G -= F.objectBounds.x, I -= F.objectBounds.y);
                switch (k[1]) {
                    case 2:
                        if (!(0 > (C - y) * (I - A) - (D - A) * (G - y))) continue;
                        break;
                    case 0:
                        if (0 >
                            (C - y) * (I - A) - (D - A) * (G - y)) continue
                }
                a[B++] = m * y + n * A + r;
                a[B++] = q * y + p * A + b;
                a[B++] = h.data[v];
                a[B++] = h.data[v + 1];
                t ? (w = F.hex2rgba(e.data[w]), a[B++] = w[0], a[B++] = w[1], a[B++] = w[2], a[B++] = w[3]) : (a[B++] = H[0], a[B++] = H[1], a[B++] = H[2], a[B++] = H[3]);
                a[B++] = m * C + n * D + r;
                a[B++] = q * C + p * D + b;
                a[B++] = h.data[u];
                a[B++] = h.data[u + 1];
                t ? (w = F.hex2rgba(e.data[c]), a[B++] = w[0], a[B++] = w[1], a[B++] = w[2], a[B++] = w[3]) : (a[B++] = H[0], a[B++] = H[1], a[B++] = H[2], a[B++] = H[3]);
                a[B++] = m * G + n * I + r;
                a[B++] = q * G + p * I + b;
                a[B++] = h.data[x];
                a[B++] = h.data[x + 1];
                t ? (w = F.hex2rgba(e.data[z]),
                    a[B++] = w[0], a[B++] = w[1], a[B++] = w[2], a[B++] = w[3]) : (a[B++] = H[0], a[B++] = H[1], a[B++] = H[2], a[B++] = H[3])
            }
        };
        F.quadraticBezierCurve = function(a, b, c, d, e, f) {
            for (var g, h, k, m, q = [], n = 0, p = 0; 21 > p;) n = p++/20,g=a+(c-a)*n,h=b+(d-b)*n,k=c+(e-c)*n,m=d+(f-d)*n,g+=(k-g)*n,h+=(m-h)*n,q.push(g),q.push(h);return q};F.render=function(a,b){var c=a.__graphics,d=b.spriteBatch,e=c.__dirty;if(!(0>=c.__commands.length))if(e&&F.updateGraphics(a,b.gl,a.cacheAsBitmap),a.cacheAsBitmap){if(e){var e=b.gl,f=c.__bounds,g=c.__cachedTexture,
            h = Math.floor(f.width + .5), f = Math.floor(f.height + .5);
            null == g && (g = new Af(e, h, f, !1), c.__cachedTexture = g);
            g.resize(h, f);
            e.bindFramebuffer(e.FRAMEBUFFER, g.frameBuffer);
            e.viewport(0, 0, h, f);
            g.clear();
            F.renderGraphics(a, b, new ja(h / 2, -f / 2), !0);
            e.bindFramebuffer(e.FRAMEBUFFER, null);
            e.viewport(0, 0, b.renderer.width, b.renderer.height)
        }
        d.drawing || d.begin(b);
        d.renderCachedGraphics(a)
    } else F.renderGraphics(a, b, b.projection, !1)
};
F.renderGraphics = function(a, b, c, d) {
    null == d && (d = !1);
    var e = b.gl,
        f = b.offset,
        g = a.__graphics.__glStack[ha.glContextId],
        h, k;
    k = d ? da.__identity : a.__worldTransform;
    for (var m = b.spriteBatch.drawing, q = 0, n = g.buckets.length; q < n;) {
        var p = q++,
            m = b.spriteBatch.drawing;
        h = g.buckets[p];
        switch (h.mode[1]) {
            case 1:
            case 2:
                m && !d && b.spriteBatch.end();
                b.stencilManager.pushBucket(h, b, c, k.toArray(!0));
                m = F.prepareShader(h, b, a, c, k.toArray(!1));
                F.renderFill(h, m, b);
                b.stencilManager.popBucket(a, h, b);
                break;
            case 5:
                m && !d && b.spriteBatch.end();
                m = F.prepareShader(h, b, a, c, null);
                F.renderDrawTriangles(h, m, b);
                break;
            case 6:
                m || b.spriteBatch.begin(b), F.renderDrawTiles(a,
                    h, b)
        }
        p = 0;
        for (h = h.data; p < h.length;) {
            var r = h[p];
            ++p;
            null != r.line && 0 < r.line.verts.length && ((m = b.spriteBatch.drawing) && !d && b.spriteBatch.end(), m = b.shaderManager.primitiveShader, b.shaderManager.setShader(m), e.uniformMatrix3fv(m.translationMatrix, !1, k.toArray(!0)), e.uniform2f(m.projectionVector, c.x, -c.y), e.uniform2f(m.offsetVector, -f.x, -f.y), e.uniform1f(m.alpha, a.__worldAlpha), e.bindBuffer(e.ARRAY_BUFFER, r.line.vertsBuffer), e.vertexAttribPointer(m.aVertexPosition, 2, e.FLOAT, !1, 24, 0), e.vertexAttribPointer(m.colorAttribute,
                4, e.FLOAT, !1, 24, 8), e.bindBuffer(e.ELEMENT_ARRAY_BUFFER, r.line.indexBuffer), e.drawElements(e.TRIANGLE_STRIP, r.line.indices.length, e.UNSIGNED_SHORT, 0))
        }(m = b.spriteBatch.drawing) || d || b.spriteBatch.begin(b)
    }
};
F.updateGraphics = function(a, b, c) {
    null == c && (c = !1);
    var d = a.__graphics;
    F.objectPosition.setTo(a.get_x(), a.get_y());
    null != d.__bounds && F.objectBounds.copyFrom(d.__bounds);
    var e = null;
    d.__dirty && (e = Ya.getStack(d, b));
    d.set___dirty(!1);
    b = 0;
    for (var f = e.buckets; b < f.length;) {
        var g = f[b];
        ++b;
        g.reset();
        F.bucketPool.push(g)
    }
    e.reset();
    b = e.lastIndex;
    for (f = d.__drawPaths.length; b < f;) {
        var g = b++,
            g = d.__drawPaths[g],
            h = g.type;
        switch (h[1]) {
            case 0:
                F.buildComplexPoly(g, e, c);
                break;
            case 1:
                h[2] ? F.buildRoundedRectangle(g, e, c) : F.buildRectangle(g, e, c);
                break;
            case 2:
            case 3:
                F.buildCircle(g, e, c);
                break;
            case 4:
                F.buildDrawTriangles(g, a, e, c);
                break;
            case 5:
                F.prepareBucket(g, e)
        }
        e.lastIndex++
    }
    e.upload()
};
F.prepareBucket = function(a, b) {
    var c = null,
        c = a.fill;
    switch (c[1]) {
        case 1:
            var d = c[3],
                e = c[2],
                c = F.switchBucket(a.fillIndex, b, ma.Fill);
            c.color = null == e ? [0, 0, 0] : [(e >>
                16 & 255) / 255, (e >> 8 & 255) / 255, (e & 255) / 255];
            c.alpha = d;
            c.uploadTileBuffer = !0;
            break;
        case 2:
            var f = c[5],
                g = c[4],
                e = c[3],
                d = c[2],
                c = F.switchBucket(a.fillIndex, b, ma.PatternFill);
            c.bitmap = d;
            c.textureRepeat = g;
            c.textureSmooth = f;
            c.texture = d.getTexture(b.gl);
            c.uploadTileBuffer = !0;
            f = c.textureMatrix;
            f.identity();
            e = null == e ? new da : new da(e.a, e.b, e.c, e.d, e.tx, e.ty);
            e = e.invert();
            e.__translateTransformed(new ja(-F.objectPosition.x, -F.objectPosition.y));
            var g = e.tx / d.width,
                h = e.ty / d.height;
            f.concat(e);
            c.textureTL.x = g;
            c.textureTL.y =
                h;
            c.textureBR.x = g + 1;
            c.textureBR.y = h + 1;
            f.scale(1 / d.width, 1 / d.height);
            c.textureMatrix = f;
            break;
        default:
            c = F.switchBucket(a.fillIndex, b, ma.Line), c.uploadTileBuffer = !1
    }
    switch (a.type[1]) {
        case 4:
            c.mode = ma.DrawTriangles;
            c.uploadTileBuffer = !1;
            break;
        case 5:
            c.mode = ma.DrawTiles, c.uploadTileBuffer = !1
    }
    c.graphicType = a.type;
    return c.getData()
};
F.getBucket = function(a, b) {
    var c = F.bucketPool.pop();
    null == c && (c = new Bf(a.gl));
    c.mode = b;
    a.buckets.push(c);
    return c
};
F.switchBucket = function(a, b, c) {
    var d;
    0 == b.buckets.length ? d =
        F.getBucket(b, c) : (d = b.buckets[b.buckets.length - 1], d.fillIndex != a && (d = F.getBucket(b, c)));
    d.dirty = !0;
    d.fillIndex = a;
    return d
};
F.prepareShader = function(a, b, c, d, e) {
    var f = b.gl,
        g = b.offset,
        h = null;
    switch (a.mode[1]) {
        case 1:
            h = b.shaderManager.fillShader;
            break;
        case 2:
            h = b.shaderManager.patternFillShader;
            break;
        case 5:
            h = b.shaderManager.drawTrianglesShader;
            break;
        default:
            h = null
    }
    if (null == h) return null;
    b.shaderManager.setShader(h);
    f.uniform2f(h.projectionVector, d.x, -d.y);
    f.uniform2f(h.offsetVector, -g.x, -g.y);
    f.uniform1f(h.alpha,
        c.__worldAlpha * a.alpha);
    switch (a.mode[1]) {
        case 1:
            f.uniformMatrix3fv(h.translationMatrix, !1, e);
            f.uniform3fv(h.color, new Float32Array(a.color));
            break;
        case 2:
            f.uniformMatrix3fv(h.translationMatrix, !1, e);
            f.uniform1i(h.sampler, 0);
            f.uniform2f(h.patternTL, a.textureTL.x, a.textureTL.y);
            f.uniform2f(h.patternBR, a.textureBR.x, a.textureBR.y);
            f.uniformMatrix3fv(h.patternMatrix, !1, a.textureMatrix.toArray(!1));
            break;
        case 5:
            null != a.texture ? (f.uniform1i(h.useTexture, 1), f.uniform1i(h.sampler, 0)) : (f.uniform1i(h.useTexture,
                0), f.uniform3fv(h.color, new Float32Array(a.color)))
    }
    return h
};
F.renderFill = function(a, b, c) {
    c = c.gl;
    a.mode == ma.PatternFill && null != a.texture && F.bindTexture(c, a);
    c.bindBuffer(c.ARRAY_BUFFER, a.tileBuffer);
    c.vertexAttribPointer(b.aVertexPosition, 4, c.SHORT, !1, 0, 0);
    c.drawArrays(c.TRIANGLE_STRIP, 0, 4)
};
F.renderDrawTriangles = function(a, b, c) {
    c = c.gl;
    for (var d = 0, e = a.data; d < e.length;) {
        var f = e[d];
        ++d;
        f.destroyed || (null != a.texture && F.bindTexture(c, a), F.bindDrawTrianglesBuffer(c, b, f), c.drawArrays(c.TRIANGLES, f.glStart,
            f.glLength))
    }
};
F.renderDrawTiles = function(a, b, c) {
    b = b.graphicType.slice(2);
    c.spriteBatch.renderTiles(a, b[0], b[1], b[2], b[3], b[4])
};
F.bindDrawTrianglesBuffer = function(a, b, c) {
    a.bindBuffer(a.ARRAY_BUFFER, c.vertsBuffer);
    c = 4 * c.stride;
    a.vertexAttribPointer(b.aVertexPosition, 2, a.FLOAT, !1, c, 0);
    a.vertexAttribPointer(b.aTextureCoord, 2, a.FLOAT, !1, c, 8);
    a.vertexAttribPointer(b.colorAttribute, 4, a.FLOAT, !1, c, 16)
};
F.bindTexture = function(a, b) {
    a.bindTexture(a.TEXTURE_2D, b.texture);
    b.textureRepeat && b.bitmap.__image.get_powerOfTwo() ?
        (a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_S, a.REPEAT), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_T, a.REPEAT)) : (a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_S, a.CLAMP_TO_EDGE), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_T, a.CLAMP_TO_EDGE));
    b.textureSmooth ? (a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, a.LINEAR), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, a.LINEAR)) : (a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, a.NEAREST), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, a.NEAREST))
};
F.hex2rgb = function(a) {
    return null == a ? [0, 0, 0] : [(a >> 16 & 255) / 255, (a >> 8 & 255) / 255, (a & 255) / 255]
};
F.hex2rgba = function(a) {
    return null == a ? [1, 1, 1, 1] : [(a >> 16 & 255) / 255, (a >> 8 & 255) / 255, (a & 255) / 255, (a >> 24 & 255) / 255]
};
var zf = function(a) {
    this.lastIndex = 0;
    this.gl = a;
    this.buckets = [];
    this.lastIndex = 0
};
g["openfl._internal.renderer.opengl.utils.GLStack"] = zf;
zf.__name__ = "openfl _internal renderer opengl utils GLStack".split(" ");
zf.prototype = {
    reset: function() {
        this.buckets = [];
        this.lastIndex = 0
    },
    upload: function() {
        for (var a =
                0, b = this.buckets; a < b.length;) {
            var c = b[a];
            ++a;
            c.dirty && c.upload()
        }
    },
    __class__: zf
};
var Bf = function(a) {
    this.textureSmooth = this.uploadTileBuffer = !0;
    this.textureRepeat = !1;
    this.data = [];
    this.fillIndex = 0;
    this.gl = a;
    this.color = [0, 0, 0];
    this.lastIndex = 0;
    this.alpha = 1;
    this.dirty = !0;
    this.mode = ma.Fill;
    this.textureMatrix = new da;
    this.textureTL = new ja;
    this.textureBR = new ja(1, 1)
};
g["openfl._internal.renderer.opengl.utils.GLBucket"] = Bf;
Bf.__name__ = "openfl _internal renderer opengl utils GLBucket".split(" ");
Bf.prototype = {
    getData: function() {
        for (var a = null, b = !1, c = 0, d = this.data; c < d.length;) {
            var e = d[c];
            ++c;
            if (e.destroyed) {
                a = e;
                b = !0;
                break
            }
        }
        null == a && (a = new me(this.gl));
        a.destroyed = !1;
        a.parent = this;
        b && u.remove(this.data, a);
        this.data.push(a);
        return a
    },
    reset: function() {
        for (var a = 0, b = this.data; a < b.length;) {
            var c = b[a];
            ++a;
            c.destroy()
        }
        this.fillIndex = 0;
        this.uploadTileBuffer = !0;
        this.graphicType = T.Polygon
    },
    upload: function() {
        this.uploadTileBuffer && (null == this.tileBuffer && (this.tileBuffer = this.gl.createBuffer(), this.tile = [0, 0, 0, 0,
            4096, 0, 1, 0, 0, 4096, 0, 1, 4096, 4096, 1, 1
        ], this.glTile = new Int16Array(this.tile)), this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.tileBuffer), this.gl.bufferData(this.gl.ARRAY_BUFFER, this.glTile, this.gl.STATIC_DRAW), this.uploadTileBuffer = !1);
        for (var a = 0, b = this.data; a < b.length;) {
            var c = b[a];
            ++a;
            c.destroyed || c.upload()
        }
        this.dirty = !1
    },
    __class__: Bf
};
var me = function(a, b) {
    null == b && (b = !0);
    this.rawIndices = this.destroyed = !1;
    this.stride = 0;
    this.rawVerts = !1;
    this.glLength = this.glStart = this.lastVertsSize = 0;
    this.gl = a;
    this.drawMode =
        a.TRIANGLE_STRIP;
    this.verts = [];
    this.vertsBuffer = a.createBuffer();
    this.indices = [];
    this.indexBuffer = a.createBuffer();
    b && (this.line = new me(a, !1))
};
g["openfl._internal.renderer.opengl.utils.GLBucketData"] = me;
me.__name__ = "openfl _internal renderer opengl utils GLBucketData".split(" ");
me.prototype = {
    destroy: function() {
        this.destroyed = !0;
        this.verts = [];
        this.indices = [];
        this.stride = this.glStart = this.glLength = 0;
        this.rawIndices = this.rawVerts = !1;
        null != this.line && this.line.destroy()
    },
    upload: function() {
        if (this.rawVerts &&
            null != this.glVerts && 0 < this.glVerts.length || 0 < this.verts.length)
            if (this.rawVerts || (this.glVerts = new Float32Array(this.verts)), this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.vertsBuffer), this.glVerts.length <= this.lastVertsSize) {
                var a = 4 * this.glLength * this.stride;
                0 < this.glLength && this.lastVertsSize > a ? (a = this.glVerts.subarray(0, a), this.gl.bufferSubData(this.gl.ARRAY_BUFFER, 0, a)) : this.gl.bufferSubData(this.gl.ARRAY_BUFFER, 0, this.glVerts)
            } else this.gl.bufferData(this.gl.ARRAY_BUFFER, this.glVerts, this.gl.STREAM_DRAW),
                this.lastVertsSize = this.glVerts.length;
        0 == this.glLength && (this.rawIndices && null != this.glIndices && 0 < this.glIndices.length || 0 < this.indices.length) && (this.rawIndices || (this.glIndices = new Uint16Array(this.indices)), this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer), this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, this.glIndices, this.gl.STREAM_DRAW));
        null != this.line && this.line.upload()
    },
    __class__: me
};
var ma = g["openfl._internal.renderer.opengl.utils.BucketMode"] = {
    __ename__: "openfl _internal renderer opengl utils BucketMode".split(" "),
    __constructs__: "None Fill PatternFill Line PatternLine DrawTriangles DrawTiles".split(" ")
};
ma.None = ["None", 0];
ma.None.toString = p;
ma.None.__enum__ = ma;
ma.Fill = ["Fill", 1];
ma.Fill.toString = p;
ma.Fill.__enum__ = ma;
ma.PatternFill = ["PatternFill", 2];
ma.PatternFill.toString = p;
ma.PatternFill.__enum__ = ma;
ma.Line = ["Line", 3];
ma.Line.toString = p;
ma.Line.__enum__ = ma;
ma.PatternLine = ["PatternLine", 4];
ma.PatternLine.toString = p;
ma.PatternLine.__enum__ = ma;
ma.DrawTriangles = ["DrawTriangles", 5];
ma.DrawTriangles.toString =
    p;
ma.DrawTriangles.__enum__ = ma;
ma.DrawTiles = ["DrawTiles", 6];
ma.DrawTiles.toString = p;
ma.DrawTiles.__enum__ = ma;
var fg = function() {};
g["openfl._internal.renderer.opengl.utils.GLGraphicsData"] = fg;
fg.__name__ = "openfl _internal renderer opengl utils GLGraphicsData".split(" ");
var Mc = function() {};
g["openfl._internal.renderer.opengl.utils.PolyK"] = Mc;
Mc.__name__ = "openfl _internal renderer opengl utils PolyK".split(" ");
Mc.triangulate = function(a) {
    var b = !0,
        c = a.length >> 1;
    if (3 > c) return [];
    var d = [],
        e;
    e = [];
    for (var f =
            0; f < c;) {
        var g = f++;
        e.push(g)
    }
    for (var f = 0, g = c, h = !1; 3 < g;) {
        var k = e[f % g],
            m = e[(f + 1) % g],
            q = e[(f + 2) % g],
            n = a[2 * k],
            p = a[2 * k + 1],
            r = a[2 * m],
            t = a[2 * m + 1],
            u = a[2 * q],
            v = a[2 * q + 1],
            h = !1;
        if (Mc._convex(n, p, r, t, u, v, b))
            for (var h = !0, x = 0; x < g;) {
                var w = x++,
                    w = e[w];
                if (w != k && w != m && w != q && Mc._PointInTriangle(a[2 * w], a[2 * w + 1], n, p, r, t, u, v)) {
                    h = !1;
                    break
                }
            }
        if (h) d.push(k), d.push(m), d.push(q), e.splice((f + 1) % g, 1), g--, f = 0;
        else if (f++ > 3 * g)
            if (b) {
                d = [];
                b = [];
                for (e = 0; e < c;) f = e++, b.push(f);
                e = b;
                f = 0;
                g = c;
                b = !1
            } else return console.log("Warning: shape too complex to fill"), []
    }
    d.push(e[0]);
    d.push(e[1]);
    d.push(e[2]);
    return d
};
Mc._PointInTriangle = function(a, b, c, d, e, f, g, h) {
    g = g - c | 0;
    h = h - d | 0;
    e = e - c | 0;
    f = f - d | 0;
    a = a - c | 0;
    c = b - d | 0;
    b = g * g + h * h;
    d = g * e + h * f;
    g = g * a + h * c;
    h = e * e + f * f;
    e = e * a + f * c;
    f = 1 / (b * h - d * d);
    h = (h * g - d * e) * f;
    g = (b * e - d * g) * f;
    return 0 <= h && 0 <= g && 1 > h + g
};
Mc._convex = function(a, b, c, d, e, f, g) {
    return 0 <= (b - d) * (e - c) + (c - a) * (f - d) == g
};
var T = g["openfl._internal.renderer.opengl.utils.GraphicType"] = {
    __ename__: "openfl _internal renderer opengl utils GraphicType".split(" "),
    __constructs__: "Polygon Rectangle Circle Ellipse DrawTriangles DrawTiles".split(" ")
};
T.Polygon = ["Polygon", 0];
T.Polygon.toString = p;
T.Polygon.__enum__ = T;
T.Rectangle = function(a) {
    a = ["Rectangle", 1, a];
    a.__enum__ = T;
    a.toString = p;
    return a
};
T.Circle = ["Circle", 2];
T.Circle.toString = p;
T.Circle.__enum__ = T;
T.Ellipse = ["Ellipse", 3];
T.Ellipse.toString = p;
T.Ellipse.__enum__ = T;
T.DrawTriangles = function(a, b, c, d, e, f) {
    a = ["DrawTriangles", 4, a, b, c, d, e, f];
    a.__enum__ = T;
    a.toString = p;
    return a
};
T.DrawTiles = function(a, b, c, d, e) {
    a = ["DrawTiles", 5, a, b, c, d, e];
    a.__enum__ = T;
    a.toString = p;
    return a
};
var vf = function(a) {
    this.maskStack = [];
    this.maskPosition = 0;
    this.setContext(a);
    this.reverse = !1;
    this.count = 0
};
g["openfl._internal.renderer.opengl.utils.MaskManager"] = vf;
vf.__name__ = "openfl _internal renderer opengl utils MaskManager".split(" ");
vf.prototype = {
    setContext: function(a) {
        this.gl = a
    },
    __class__: vf
};
var tf = function(a) {
    this.maxAttibs = 10;
    this.attribState = [];
    this.tempAttribState = [];
    this.shaderMap = [];
    for (var b = 0, c = this.maxAttibs; b < c;) {
        var d = b++;
        this.attribState[d] = !1
    }
    this.setContext(a)
};
g["openfl._internal.renderer.opengl.utils.ShaderManager"] =
    tf;
tf.__name__ = "openfl _internal renderer opengl utils ShaderManager".split(" ");
tf.prototype = {
    setAttribs: function(a) {
        for (var b = 0, c = this.tempAttribState.length; b < c;) {
            var d = b++;
            this.tempAttribState[d] = !1
        }
        b = 0;
        for (c = a.length; b < c;) d = b++, this.tempAttribState[a[d]] = !0;
        a = this.gl;
        b = 0;
        for (c = this.attribState.length; b < c;) d = b++, this.attribState[d] != this.tempAttribState[d] && (this.attribState[d] = this.tempAttribState[d], this.tempAttribState[d] ? a.enableVertexAttribArray(d) : a.disableVertexAttribArray(d))
    },
    setContext: function(a) {
        this.gl =
            a;
        this.primitiveShader = new ke(a);
        this.complexPrimitiveShader = new fe(a);
        this.defaultShader = new Lc(a);
        this.fastShader = new he(a);
        this.stripShader = new le(a);
        this.fillShader = new ie(a);
        this.patternFillShader = new je(a);
        this.drawTrianglesShader = new ge(a);
        this.setShader(this.defaultShader)
    },
    setShader: function(a) {
        if (this._currentId == a._UID) return !1;
        this._currentId = a._UID;
        this.currentShader = a;
        this.gl.useProgram(a.program);
        this.setAttribs(a.attributes);
        return !0
    },
    __class__: tf
};
var uf = function(a) {
    this.states = [];
    this.vertSize = 6;
    this.size = Math.floor(Math.pow(2, 16) / this.vertSize);
    var b = 6 * this.size;
    this.vertices = new Float32Array(4 * this.size * this.vertSize);
    this.indices = new Uint16Array(b);
    for (var c = this.lastIndexCount = 0, d = 0; c < b;) this.indices[c] = d, this.indices[c + 1] = d + 1, this.indices[c + 2] = d + 2, this.indices[c + 3] = d, this.indices[c + 4] = d + 2, this.indices[c + 5] = d + 3, c += 6, d += 4;
    this.drawing = !1;
    this.currentBatchSize = 0;
    this.currentBaseTexture = null;
    this.setContext(a);
    this.dirty = !0;
    this.currentState = new ne
};
g["openfl._internal.renderer.opengl.utils.SpriteBatch"] =
    uf;
uf.__name__ = "openfl _internal renderer opengl utils SpriteBatch".split(" ");
uf.prototype = {
    begin: function(a) {
        this.renderSession = a;
        this.shader = a.shaderManager.defaultShader;
        this.drawing = !0;
        this.start()
    },
    end: function() {
        this.flush();
        this.drawing = !1
    },
    flush: function() {
        if (0 != this.currentBatchSize) {
            var a = this.gl;
            this.renderSession.shaderManager.setShader(this.renderSession.shaderManager.defaultShader);
            if (this.dirty) {
                this.dirty = !1;
                a.activeTexture(a.TEXTURE0);
                a.bindBuffer(a.ARRAY_BUFFER, this.vertexBuffer);
                a.bindBuffer(a.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
                var b = this.renderSession.projection;
                a.uniform2f(this.shader.projectionVector, b.x, b.y);
                b = 4 * this.vertSize;
                a.vertexAttribPointer(this.shader.aVertexPosition, 2, a.FLOAT, !1, b, 0);
                a.vertexAttribPointer(this.shader.aTextureCoord, 2, a.FLOAT, !1, b, 8);
                a.vertexAttribPointer(this.shader.colorAttribute, 2, a.FLOAT, !1, b, 16)
            }
            this.currentBatchSize > .5 * this.size ? a.bufferSubData(a.ARRAY_BUFFER, 0, this.vertices) : (b = this.vertices.subarray(0, 4 * this.currentBatchSize * this.vertSize),
                a.bufferSubData(a.ARRAY_BUFFER, 0, b));
            var c = b = 0;
            this.currentState.texture = null;
            this.currentState.textureSmooth = !0;
            this.currentState.blendMode = this.renderSession.blendModeManager.currentBlendMode;
            for (var d = this.currentBatchSize, e = 0; e < d;) {
                var f = e++,
                    a = this.states[f];
                if (this.currentState.texture != a.texture || this.currentState.blendMode != a.blendMode) this.renderBatch(this.currentState, b, c), c = f, b = 0, this.currentState.texture = a.texture, this.currentState.textureSmooth = a.textureSmooth, this.currentState.blendMode =
                    a.blendMode, this.renderSession.blendModeManager.setBlendMode(this.currentState.blendMode);
                b++
            }
            this.renderBatch(this.currentState, b, c);
            this.currentBatchSize = 0
        }
    },
    render: function(a) {
        var b = a.bitmapData,
            c = b.getTexture(this.gl);
        if (null != b) {
            this.currentBatchSize >= this.size && (this.flush(), this.currentState.texture = c);
            var d = b.__uvData;
            null != d && (this.fillVertices(4 * this.currentBatchSize * this.vertSize, 0, 0, b.width, b.height, 16777215, a.__worldAlpha, d, a.__worldTransform), this.setState(this.currentBatchSize, c, null,
                a.blendMode), this.currentBatchSize++)
        }
    },
    renderCachedGraphics: function(a) {
        var b = a.__graphics.__cachedTexture;
        if (null != b) {
            this.currentBatchSize >= this.size && (this.flush(), this.currentBaseTexture = b.texture);
            var c = a.__worldAlpha,
                d = new Xc;
            d.x0 = 0;
            d.y0 = 1;
            d.x1 = 1;
            d.y1 = 1;
            d.x2 = 1;
            d.y2 = 0;
            d.x3 = 0;
            d.y3 = 0;
            var e = 4 * this.currentBatchSize * this.vertSize,
                f = a.__worldTransform.clone();
            f.__translateTransformed(new ja(a.__graphics.__bounds.x, a.__graphics.__bounds.y));
            this.fillVertices(e, 0, 0, b.width, b.height, 16777215, c, d, f);
            this.setState(this.currentBatchSize, b.texture, null, a.blendMode);
            this.currentBatchSize++
        }
    },
    renderTiles: function(a, b, c, d, e, f) {
        null == f && (f = -1);
        null == e && (e = 0);
        null == d && (d = !1);
        var g = b.__bitmap.getTexture(this.gl);
        if (null != g) {
            var h = 0 < (e & 1),
                k = 0 < (e & 2),
                m = 0 < (e & 16),
                n = 0 < (e & 4),
                p = 0 < (e & 8),
                r = 0 < (e & 32),
                t = 0 < (e & 64);
            switch (e & 983040) {
                case 65536:
                    e = G.ADD;
                    break;
                case 131072:
                    e = G.MULTIPLY;
                    break;
                case 262144:
                    e = G.SCREEN;
                    break;
                default:
                    e = G.NORMAL
            }
            m && (k = h = !1);
            var u = 0,
                w = 0,
                v = 0,
                x = 0,
                z = 0,
                y = 3;
            r && (y = t ? 8 : 6);
            h && (u = y, y++);
            k && (w = y, y++);
            m && (z =
                y, y += 4);
            n && (v = y, y += 3);
            p && (x = y, y++);
            var A = c.length;
            0 <= f && A > f && (A = f);
            f = 0;
            var B = -1,
                C = b.__rectTile,
                B = b.__rectUV,
                D = b.__point,
                F = 0,
                H = 0,
                I = 1,
                L = 16777215,
                J = 1,
                K = 0,
                M = 1,
                P = K = J = M = K = 0,
                Q = H = F = 0,
                R = 0,
                O = new da;
            a = a.__worldTransform;
            for (var N = new Xc, H = 0; f < A;) this.currentBatchSize >= this.size && (this.flush(), this.currentBaseTexture = g), F = c[f], H = c[f + 1], r ? (C.x = c[f + 2], C.y = c[f + 3], C.width = c[f + 4], C.height = c[f + 5], t ? (D.x = c[f + 6], D.y = c[f + 7]) : (D.x = 0, D.y = 0), B.setTo(C.get_left() / b.__bitmap.width, C.get_top() / b.__bitmap.height, C.get_right() /
                b.__bitmap.width, C.get_bottom() / b.__bitmap.height)) : (B = (null == c[f + 2] ? 0 : c[f + 2]) | 0, C = b.__tileRects[B], D = b.__centerPoints[B], B = b.__tileUVs[B]), null != C && 0 < C.width && 0 < C.height && null != D && (I = 1, L = 16777215, M = J = 1, K = 0, O.identity(), p && (I = c[f + x]), n && (L = (255 * c[f + v] | 0) << 16 | (255 * c[f + v + 1] | 0) << 8 | 255 * c[f + v + 2] | 0), h && (J = c[f + u]), k && (K = c[f + w], M = Math.cos(K), K = Math.sin(K)), m ? (M = c[f + z], J = c[f + z + 1], K = c[f + z + 2], P = c[f + z + 3]) : (M *= J, J *= K, K = -J, P = M), Q = D.x * M + D.y * K, R = D.x * J + D.y * P, F -= Q, H -= R, O.a = M * a.a + J * a.c, O.b = M * a.b + J * a.d, O.c = K * a.a + P * a.c,
                O.d = K * a.b + P * a.d, O.tx = F * a.a + H * a.c, O.ty = F * a.b + H * a.d, N.x0 = B.x, N.y0 = B.y, N.x1 = B.width, N.y1 = B.y, N.x2 = B.width, N.y2 = B.height, N.x3 = B.x, N.y3 = B.height, H = 4 * this.currentBatchSize * this.vertSize, this.fillVertices(H, 0, 0, C.width, C.height, L, I, N, O), this.setState(this.currentBatchSize, g, d, e), this.currentBatchSize++), f += y
        }
    },
    fillVertices: function(a, b, c, d, e, f, g, h, k) {
        var m;
        m = d * (1 - b);
        b = d * -b;
        d = e * (1 - c);
        c = e * -c;
        e = k.a;
        var n = k.b,
            p = k.c,
            r = k.d,
            t = k.tx;
        k = k.ty;
        this.vertices[a++] = e * b + p * c + t;
        this.vertices[a++] = r * c + n * b + k;
        this.vertices[a++] =
            h.x0;
        this.vertices[a++] = h.y0;
        this.vertices[a++] = g;
        this.vertices[a++] = f;
        this.vertices[a++] = e * m + p * c + t;
        this.vertices[a++] = r * c + n * m + k;
        this.vertices[a++] = h.x1;
        this.vertices[a++] = h.y1;
        this.vertices[a++] = g;
        this.vertices[a++] = f;
        this.vertices[a++] = e * m + p * d + t;
        this.vertices[a++] = r * d + n * m + k;
        this.vertices[a++] = h.x2;
        this.vertices[a++] = h.y2;
        this.vertices[a++] = g;
        this.vertices[a++] = f;
        this.vertices[a++] = e * b + p * d + t;
        this.vertices[a++] = r * d + n * b + k;
        this.vertices[a++] = h.x3;
        this.vertices[a++] = h.y3;
        this.vertices[a++] = g;
        this.vertices[a++] =
            f
    },
    setState: function(a, b, c, d) {
        null == c && (c = !0);
        a = this.states[this.currentBatchSize];
        null == a && (a = this.states[this.currentBatchSize] = new ne);
        a.texture = b;
        a.textureSmooth = c;
        a.blendMode = d
    },
    renderBatch: function(a, b, c) {
        0 != b && (this.gl.bindTexture(this.gl.TEXTURE_2D, a.texture), a.textureSmooth ? (this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MAG_FILTER, this.gl.LINEAR), this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.LINEAR)) : (this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MAG_FILTER,
            this.gl.NEAREST), this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.NEAREST)), this.gl.drawElements(this.gl.TRIANGLES, 6 * b, this.gl.UNSIGNED_SHORT, 12 * c), this.renderSession.drawCount++)
    },
    setContext: function(a) {
        this.gl = a;
        this.vertexBuffer = a.createBuffer();
        this.indexBuffer = a.createBuffer();
        a.bindBuffer(a.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
        a.bufferData(a.ELEMENT_ARRAY_BUFFER, this.indices, a.STATIC_DRAW);
        a.bindBuffer(a.ARRAY_BUFFER, this.vertexBuffer);
        a.bufferData(a.ARRAY_BUFFER,
            this.vertices, a.DYNAMIC_DRAW);
        this.currentBlendMode = null
    },
    start: function() {
        this.dirty = !0
    },
    __class__: uf
};
var ne = function() {
    this.textureSmooth = !0
};
g["openfl._internal.renderer.opengl.utils._SpriteBatch.State"] = ne;
ne.__name__ = "openfl _internal renderer opengl utils _SpriteBatch State".split(" ");
ne.prototype = {
    __class__: ne
};
var xf = function(a) {
    this.stencilStack = [];
    this.bucketStack = [];
    this.setContext(a);
    this.reverse = !0;
    this.count = 0
};
g["openfl._internal.renderer.opengl.utils.StencilManager"] = xf;
xf.__name__ =
    "openfl _internal renderer opengl utils StencilManager".split(" ");
xf.prototype = {
    prepareGraphics: function(a, b, c, d) {
        var e = b.offset,
            f = b.shaderManager.fillShader;
        b.shaderManager.setShader(f);
        this.gl.uniformMatrix3fv(f.translationMatrix, !1, d);
        this.gl.uniform2f(f.projectionVector, c.x, -c.y);
        this.gl.uniform2f(f.offsetVector, -e.x, -e.y);
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, a.vertsBuffer);
        this.gl.vertexAttribPointer(f.aVertexPosition, 2, this.gl.FLOAT, !1, 8, 0);
        this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER,
            a.indexBuffer)
    },
    pushBucket: function(a, b, c, d) {
        0 == this.bucketStack.length && (this.gl.enable(this.gl.STENCIL_TEST), this.gl.clear(this.gl.STENCIL_BUFFER_BIT), this.gl.stencilMask(255));
        this.bucketStack.push(a);
        this.gl.colorMask(!1, !1, !1, !1);
        this.gl.stencilFunc(this.gl.NEVER, 1, 255);
        this.gl.stencilOp(this.gl.INVERT, this.gl.KEEP, this.gl.KEEP);
        this.gl.clear(this.gl.STENCIL_BUFFER_BIT);
        var e = 0;
        for (a = a.data; e < a.length;) {
            var f = a[e];
            ++e;
            f.destroyed || (this.prepareGraphics(f, b, c, d), this.gl.drawElements(f.drawMode,
                f.glIndices.length, this.gl.UNSIGNED_SHORT, 0))
        }
        this.gl.colorMask(!0, !0, !0, !0);
        this.gl.stencilOp(this.gl.KEEP, this.gl.KEEP, this.gl.KEEP);
        this.gl.stencilFunc(this.gl.EQUAL, 255, 255)
    },
    popBucket: function(a, b, c) {
        this.bucketStack.pop();
        0 == this.bucketStack.length && this.gl.disable(this.gl.STENCIL_TEST)
    },
    setContext: function(a) {
        this.gl = a
    },
    __class__: xf
};
var rd = function() {
    this.__mouseOutStack = [];
    Xa.call(this);
    S.application = this
};
g["openfl.display.Application"] = rd;
rd.__name__ = ["openfl", "display", "Application"];
rd.__super__ = Xa;
rd.prototype = t(Xa.prototype, {
    convertKeyCode: function(a) {
        switch (a) {
            case 8:
                return 8;
            case 9:
                return 9;
            case 13:
                return 13;
            case 27:
                return 27;
            case 32:
                return 32;
            case 39:
                return 222;
            case 44:
                return 188;
            case 45:
                return 189;
            case 46:
                return 190;
            case 47:
                return 191;
            case 48:
                return 48;
            case 49:
                return 49;
            case 50:
                return 50;
            case 51:
                return 51;
            case 52:
                return 52;
            case 53:
                return 53;
            case 54:
                return 54;
            case 55:
                return 55;
            case 56:
                return 56;
            case 57:
                return 57;
            case 59:
                return 186;
            case 61:
                return 187;
            case 91:
                return 219;
            case 92:
                return 220;
            case 93:
                return 221;
            case 96:
                return 192;
            case 97:
                return 65;
            case 98:
                return 66;
            case 99:
                return 67;
            case 100:
                return 68;
            case 101:
                return 69;
            case 102:
                return 70;
            case 103:
                return 71;
            case 104:
                return 72;
            case 105:
                return 73;
            case 106:
                return 74;
            case 107:
                return 75;
            case 108:
                return 76;
            case 109:
                return 77;
            case 110:
                return 78;
            case 111:
                return 79;
            case 112:
                return 80;
            case 113:
                return 81;
            case 114:
                return 82;
            case 115:
                return 83;
            case 116:
                return 84;
            case 117:
                return 85;
            case 118:
                return 86;
            case 119:
                return 87;
            case 120:
                return 88;
            case 121:
                return 89;
            case 122:
                return 90;
            case 127:
                return 46;
            case 1073741881:
                return 20;
            case 1073741882:
                return 112;
            case 1073741883:
                return 113;
            case 1073741884:
                return 114;
            case 1073741885:
                return 115;
            case 1073741886:
                return 116;
            case 1073741887:
                return 117;
            case 1073741888:
                return 118;
            case 1073741889:
                return 119;
            case 1073741890:
                return 120;
            case 1073741891:
                return 121;
            case 1073741892:
                return 122;
            case 1073741893:
                return 123;
            case 1073741897:
                return 45;
            case 1073741898:
                return 36;
            case 1073741899:
                return 33;
            case 1073741901:
                return 35;
            case 1073741902:
                return 34;
            case 1073741903:
                return 39;
            case 1073741904:
                return 37;
            case 1073741905:
                return 40;
            case 1073741906:
                return 38;
            case 1073741908:
                return 111;
            case 1073741909:
                return 106;
            case 1073741910:
                return 109;
            case 1073741911:
                return 107;
            case 1073741912:
                return 108;
            case 1073741913:
                return 97;
            case 1073741914:
                return 98;
            case 1073741915:
                return 99;
            case 1073741916:
                return 100;
            case 1073741917:
                return 101;
            case 1073741918:
                return 102;
            case 1073741919:
                return 103;
            case 1073741920:
                return 104;
            case 1073741921:
                return 105;
            case 1073741922:
                return 96;
            case 1073741923:
                return 110;
            case 1073741928:
                return 124;
            case 1073741929:
                return 125;
            case 1073741930:
                return 126;
            case 1073742048:
                return 17;
            case 1073742049:
                return 16;
            case 1073742050:
                return 18;
            case 1073742052:
                return 17;
            case 1073742053:
                return 16;
            case 1073742054:
                return 18;
            default:
                return a
        }
    },
    create: function(a) {
        Xa.prototype.create.call(this, a);
        this.stage = new oe(this.windows[0].__width, this.windows[0].__height, a.background);
        this.stage.addChild(S.current);
        this.stage.align = ka.TOP_LEFT;
        this.stage.scaleMode = Oa.NO_SCALE
    },
    onKey: function(a) {
        var b = [];
        null == this.stage.__focus ? this.stage.__getInteractive(b) : this.stage.__focus.__getInteractive(b);
        0 < b.length && (b.reverse(), this.stage.__fireEvent(a, b))
    },
    onKeyDown: function(a, b) {
        var c = this.convertKeyCode(a);
        this.onKey(new Tb(Tb.KEY_DOWN, !0, !1, c, c, null, ob.get_ctrlKey(b), ob.get_altKey(b), ob.get_shiftKey(b), ob.get_metaKey(b)))
    },
    onKeyUp: function(a, b) {
        var c = this.convertKeyCode(a);
        this.onKey(new Tb(Tb.KEY_UP, !0, !1, c, c, null, ob.get_ctrlKey(b), ob.get_altKey(b), ob.get_shiftKey(b), ob.get_metaKey(b)))
    },
    onMouse: function(a, b, c, d) {
        if (!(2 < d)) {
            this.stage.__mouseX = b;
            this.stage.__mouseY = c;
            var e = [],
                f = null,
                g = new ja(b, c);
            this.stage.__hitTest(b, c, !1, e, !0) ? f = e[e.length - 1] : (f = this.stage, e = [this.stage]);
            this.stage.__fireEvent(D.__create(a, d, f == this.stage ? g : f.globalToLocal(g), f), e);
            switch (a) {
                case D.MOUSE_UP:
                    b = D.CLICK;
                    break;
                case D.MIDDLE_MOUSE_UP:
                    b = D.MIDDLE_CLICK;
                    break;
                case D.RIGHT_MOUSE_UP:
                    b = D.RIGHT_CLICK;
                    break;
                default:
                    b = null
            }
            null != b && (this.stage.__fireEvent(D.__create(b, d, f == this.stage ? g : f.globalToLocal(g), f),
                e), a == D.MOUSE_UP && x.__cast(f, $a).doubleClickEnabled && (a = S.getTimer(), 500 > a - this.__lastClickTime ? (this.stage.__fireEvent(D.__create(D.DOUBLE_CLICK, d, f == this.stage ? g : f.globalToLocal(g), f), e), this.__lastClickTime = 0) : this.__lastClickTime = a));
            x.__instanceof(f, y) ? (d = f, d.buttonMode && d.useHandCursor ? Sb.set_cursor(J.POINTER) : Sb.set_cursor(J.ARROW)) : x.__instanceof(f, pe) ? f.useHandCursor ? Sb.set_cursor(J.POINTER) : Sb.set_cursor(J.ARROW) : x.__instanceof(f, Na) ? f.type == Rb.INPUT ? Sb.set_cursor(J.TEXT) : Sb.set_cursor(J.ARROW) :
                Sb.set_cursor(J.ARROW);
            d = 0;
            for (f = this.__mouseOutStack; d < f.length;) a = f[d], ++d, -1 == u.indexOf(e, a, 0) && (u.remove(this.__mouseOutStack, a), b = a.globalToLocal(g), a.dispatchEvent(new D(D.MOUSE_OUT, !1, !1, b.x, b.y, a)));
            for (d = 0; d < e.length;) f = e[d], ++d, -1 == u.indexOf(this.__mouseOutStack, f, 0) && (f.hasEventListener(D.MOUSE_OVER) && (a = f.globalToLocal(g), f.dispatchEvent(new D(D.MOUSE_OVER, !1, !1, a.x, a.y, f))), f.hasEventListener(D.MOUSE_OUT) && this.__mouseOutStack.push(f));
            null != this.stage.__dragObject && this.stage.__drag(g)
        }
    },
    onMouseDown: function(a, b, c) {
        var d;
        switch (c) {
            case 1:
                d = D.MIDDLE_MOUSE_DOWN;
                break;
            case 2:
                d = D.RIGHT_MOUSE_DOWN;
                break;
            default:
                d = D.MOUSE_DOWN
        }
        this.onMouse(d, a, b, c)
    },
    onMouseMove: function(a, b, c) {
        this.onMouse(D.MOUSE_MOVE, a, b, 0)
    },
    onMouseUp: function(a, b, c) {
        var d;
        switch (c) {
            case 1:
                d = D.MIDDLE_MOUSE_UP;
                break;
            case 2:
                d = D.RIGHT_MOUSE_UP;
                break;
            default:
                d = D.MOUSE_UP
        }
        this.onMouse(d, a, b, c)
    },
    onTouch: function(a, b, c, d) {
        var e = new ja(b, c);
        this.stage.__mouseX = e.x;
        this.stage.__mouseY = e.y;
        var f = [],
            g;
        switch (a) {
            case "touchBegin":
                g =
                    D.MOUSE_DOWN;
                break;
            case "touchMove":
                g = D.MOUSE_MOVE;
                break;
            case "touchEnd":
                g = D.MOUSE_UP;
                break;
            default:
                g = null
        }
        if (this.stage.__hitTest(b, c, !1, f, !0)) {
            c = f[f.length - 1];
            var h = c.globalToLocal(e);
            b = Cc.__create(a, null, h, c);
            b.touchPointID = d;
            b.isPrimaryTouchPoint = !0;
            d = D.__create(g, 0, h, c);
            d.buttonDown = "touchEnd" != a;
            this.stage.__fireEvent(b, f);
            this.stage.__fireEvent(d, f)
        } else f = Cc.__create(a, null, e, this.stage), f.touchPointID = d, f.isPrimaryTouchPoint = !0, d = D.__create(g, 0, e, this.stage), d.buttonDown = "touchEnd" != a, this.stage.__fireEvent(f, [this.stage]), this.stage.__fireEvent(d, [this.stage]);
        "touchMove" == a && null != this.stage.__dragObject && this.stage.__drag(e)
    },
    onTouchMove: function(a, b, c) {
        this.onTouch("touchMove", a, b, c)
    },
    onTouchEnd: function(a, b, c) {
        this.onTouch("touchEnd", a, b, c)
    },
    onTouchStart: function(a, b, c) {
        this.onTouch("touchBegin", a, b, c)
    },
    onWindowActivate: function() {
        var a = new w(w.ACTIVATE);
        this.stage.__broadcast(a, !0)
    },
    onWindowDeactivate: function() {
        var a = new w(w.DEACTIVATE);
        this.stage.__broadcast(a, !0)
    },
    onWindowResize: function(a, b) {
        this.stage.stageWidth =
            a;
        this.stage.stageHeight = b;
        var c = new w(w.RESIZE);
        this.stage.__broadcast(c, !1)
    },
    render: function(a) {
        this.stage.__render(a)
    },
    __class__: rd
});
var Zb = function(a, b, c) {
    null == c && (c = !1);
    Ha.call(this);
    this.bitmapData = a;
    this.pixelSnapping = b;
    this.smoothing = c;
    null == b && (this.pixelSnapping = Fb.AUTO)
};
g["openfl.display.Bitmap"] = Zb;
Zb.__name__ = ["openfl", "display", "Bitmap"];
Zb.__super__ = Ha;
Zb.prototype = t(Ha.prototype, {
    __getBounds: function(a, b) {
        if (null != this.bitmapData) {
            var c = new za(0, 0, this.bitmapData.width, this.bitmapData.height),
                c = c.transform(this.__worldTransform);
            a.__expand(c.x, c.y, c.width, c.height)
        }
    },
    __hitTest: function(a, b, c, d, e) {
        if (!this.get_visible() || null == this.bitmapData) return !1;
        a = this.globalToLocal(new ja(a, b));
        return 0 < a.x && 0 < a.y && a.x <= this.bitmapData.width && a.y <= this.bitmapData.height ? (null == d || e || d.push(this), !0) : !1
    },
    __renderCanvas: function(a) {
        Pf.render(this, a)
    },
    __renderDOM: function(a) {
        null != this.stage && this.__worldVisible && this.__renderable && null != this.bitmapData && this.bitmapData.__isValid ? null != this.bitmapData.__image.buffer.__srcImage ?
            ee.renderImage(this, a) : ee.renderCanvas(this, a) : (null != this.__image && (a.element.removeChild(this.__image), this.__style = this.__image = null), null != this.__canvas && (a.element.removeChild(this.__canvas), this.__style = this.__canvas = null))
    },
    __renderGL: function(a) {
        Qf.render(this, a)
    },
    __renderMask: function(a) {
        a.context.rect(0, 0, this.get_width(), this.get_height())
    },
    get_height: function() {
        return null != this.bitmapData ? this.bitmapData.height * this.get_scaleY() : 0
    },
    get_width: function() {
        return null != this.bitmapData ? this.bitmapData.width *
            this.get_scaleX() : 0
    },
    __class__: Zb
});
var Xc = function() {
    this.x0 = this.x1 = this.x2 = this.x3 = this.y0 = this.y1 = this.y2 = this.y3 = 0
};
g["openfl.display.TextureUvs"] = Xc;
Xc.__name__ = ["openfl", "display", "TextureUvs"];
Xc.prototype = {
    __class__: Xc
};
var G = g["openfl.display.BlendMode"] = {
    __ename__: ["openfl", "display", "BlendMode"],
    __constructs__: "ADD ALPHA DARKEN DIFFERENCE ERASE HARDLIGHT INVERT LAYER LIGHTEN MULTIPLY NORMAL OVERLAY SCREEN SUBTRACT".split(" ")
};
G.ADD = ["ADD", 0];
G.ADD.toString = p;
G.ADD.__enum__ = G;
G.ALPHA = ["ALPHA", 1];
G.ALPHA.toString = p;
G.ALPHA.__enum__ = G;
G.DARKEN = ["DARKEN", 2];
G.DARKEN.toString = p;
G.DARKEN.__enum__ = G;
G.DIFFERENCE = ["DIFFERENCE", 3];
G.DIFFERENCE.toString = p;
G.DIFFERENCE.__enum__ = G;
G.ERASE = ["ERASE", 4];
G.ERASE.toString = p;
G.ERASE.__enum__ = G;
G.HARDLIGHT = ["HARDLIGHT", 5];
G.HARDLIGHT.toString = p;
G.HARDLIGHT.__enum__ = G;
G.INVERT = ["INVERT", 6];
G.INVERT.toString = p;
G.INVERT.__enum__ = G;
G.LAYER = ["LAYER", 7];
G.LAYER.toString = p;
G.LAYER.__enum__ = G;
G.LIGHTEN = ["LIGHTEN", 8];
G.LIGHTEN.toString = p;
G.LIGHTEN.__enum__ =
    G;
G.MULTIPLY = ["MULTIPLY", 9];
G.MULTIPLY.toString = p;
G.MULTIPLY.__enum__ = G;
G.NORMAL = ["NORMAL", 10];
G.NORMAL.toString = p;
G.NORMAL.__enum__ = G;
G.OVERLAY = ["OVERLAY", 11];
G.OVERLAY.toString = p;
G.OVERLAY.__enum__ = G;
G.SCREEN = ["SCREEN", 12];
G.SCREEN.toString = p;
G.SCREEN.__enum__ = G;
G.SUBTRACT = ["SUBTRACT", 13];
G.SUBTRACT.toString = p;
G.SUBTRACT.__enum__ = G;
var vb = g["openfl.display.CapsStyle"] = {
    __ename__: ["openfl", "display", "CapsStyle"],
    __constructs__: ["NONE", "ROUND", "SQUARE"]
};
vb.NONE = ["NONE", 0];
vb.NONE.toString = p;
vb.NONE.__enum__ =
    vb;
vb.ROUND = ["ROUND", 1];
vb.ROUND.toString = p;
vb.ROUND.__enum__ = vb;
vb.SQUARE = ["SQUARE", 2];
vb.SQUARE.toString = p;
vb.SQUARE.__enum__ = vb;
var Cf = function() {};
g["openfl.display.FrameLabel"] = Cf;
Cf.__name__ = ["openfl", "display", "FrameLabel"];
Cf.__super__ = U;
Cf.prototype = t(U.prototype, {
    __class__: Cf
});
var Xb = g["openfl.display.GradientType"] = {
    __ename__: ["openfl", "display", "GradientType"],
    __constructs__: ["RADIAL", "LINEAR"]
};
Xb.RADIAL = ["RADIAL", 0];
Xb.RADIAL.toString = p;
Xb.RADIAL.__enum__ = Xb;
Xb.LINEAR = ["LINEAR", 1];
Xb.LINEAR.toString = p;
Xb.LINEAR.__enum__ = Xb;
var Ke = function() {
    this.__visible = !0;
    this.__glStack = [];
    this.__dirty = !0;
    this.__commands = [];
    this.__commands = [];
    this.__positionY = this.__positionX = this.__halfStrokeWidth = 0;
    this.__hardware = !0;
    this.moveTo(0, 0);
    this.renderY = this.renderX = 0;
    this.renderWidth = S.current.stage.stageWidth;
    this.renderHeight = S.current.stage.stageHeight
};
g["openfl.display.Graphics"] = Ke;
Ke.__name__ = ["openfl", "display", "Graphics"];
Ke.prototype = {
    beginFill: function(a, b) {
        null == b && (b = 1);
        null == a &&
            (a = 0);
        this.__commands.push(R.BeginFill(a & 16777215, b));
        0 < b && (this.__visible = !0)
    },
    beginGradientFill: function(a, b, c, d, e, f, g, h) {
        this.__commands.push(R.BeginGradientFill(a, b, c, d, e, f, g, h));
        this.__hardware = !1;
        for (a = 0; a < c.length;)
            if (b = c[a], ++a, 0 < b) {
                this.__visible = !0;
                break
            }
    },
    clear: function() {
        this.__commands = [];
        this.__halfStrokeWidth = 0;
        null != this.__bounds && (this.set___dirty(!0), this.__transformDirty = !0, this.__bounds = null);
        this.__visible = !1;
        this.__hardware = !0;
        this.moveTo(0, 0)
    },
    drawRect: function(a, b, c, d) {
        0 >=
            c || 0 >= d || (this.__inflateBounds(a - this.__halfStrokeWidth, b - this.__halfStrokeWidth), this.__inflateBounds(a + c + this.__halfStrokeWidth, b + d + this.__halfStrokeWidth), this.__commands.push(R.DrawRect(a, b, c, d)), this.set___dirty(!0))
    },
    drawTiles: function(a, b, c, d, e) {
        null == e && (e = -1);
        null == d && (d = 0);
        null == c && (c = !1);
        this.__inflateBounds(this.renderX, this.renderY);
        this.__inflateBounds(this.renderWidth, this.renderHeight);
        this.__commands.push(R.DrawTiles(a, b, c, d, e));
        this.set___dirty(!0);
        this.__visible = !0
    },
    endFill: function() {
        this.__commands.push(R.EndFill)
    },
    lineStyle: function(a, b, c, d, e, f, g, h) {
        this.__halfStrokeWidth = a > this.__halfStrokeWidth ? a / 2 : this.__halfStrokeWidth;
        this.__commands.push(R.LineStyle(a, b, c, d, e, f, g, h));
        null != a && (this.__visible = !0)
    },
    moveTo: function(a, b) {
        this.__positionX = a;
        this.__positionY = b;
        this.__commands.push(R.MoveTo(a, b))
    },
    __getBounds: function(a, b) {
        if (null != this.__bounds) {
            var c = this.__bounds.transform(b);
            a.__expand(c.x, c.y, c.width, c.height)
        }
    },
    __hitTest: function(a, b, c, d) {
        if (null == this.__bounds) return !1;
        c = this.__bounds.transform(d);
        return a >
            c.x && b > c.y && a <= c.get_right() && b <= c.get_bottom()
    },
    __inflateBounds: function(a, b) {
        null == this.__bounds ? (this.__bounds = new za(a, b, 0, 0), this.__transformDirty = !0) : (a < this.__bounds.x && (this.__bounds.width += this.__bounds.x - a, this.__bounds.x = a, this.__transformDirty = !0), b < this.__bounds.y && (this.__bounds.height += this.__bounds.y - b, this.__bounds.y = b, this.__transformDirty = !0), a > this.__bounds.x + this.__bounds.width && (this.__bounds.width = a - this.__bounds.x), b > this.__bounds.y + this.__bounds.height && (this.__bounds.height =
            b - this.__bounds.y))
    },
    set___dirty: function(a) {
        a && null != this.__owner && this.__owner.__setRenderDirty();
        return this.__dirty = a
    },
    __class__: Ke,
    __properties__: {
        set___dirty: "set___dirty"
    }
};
var R = g["openfl.display.DrawCommand"] = {
    __ename__: ["openfl", "display", "DrawCommand"],
    __constructs__: "BeginBitmapFill BeginFill BeginGradientFill CubicCurveTo CurveTo DrawCircle DrawEllipse DrawRect DrawRoundRect DrawTiles DrawTriangles EndFill LineStyle LineBitmapStyle LineGradientStyle LineTo MoveTo DrawPathC OverrideMatrix".split(" ")
};
R.BeginBitmapFill = function(a, b, c, d) {
    a = ["BeginBitmapFill", 0, a, b, c, d];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.BeginFill = function(a, b) {
    var c = ["BeginFill", 1, a, b];
    c.__enum__ = R;
    c.toString = p;
    return c
};
R.BeginGradientFill = function(a, b, c, d, e, f, g, h) {
    a = ["BeginGradientFill", 2, a, b, c, d, e, f, g, h];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.CubicCurveTo = function(a, b, c, d, e, f) {
    a = ["CubicCurveTo", 3, a, b, c, d, e, f];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.CurveTo = function(a, b, c, d) {
    a = ["CurveTo", 4, a, b, c, d];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.DrawCircle = function(a, b, c) {
    a = ["DrawCircle", 5, a, b, c];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.DrawEllipse = function(a, b, c, d) {
    a = ["DrawEllipse", 6, a, b, c, d];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.DrawRect = function(a, b, c, d) {
    a = ["DrawRect", 7, a, b, c, d];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.DrawRoundRect = function(a, b, c, d, e, f) {
    a = ["DrawRoundRect", 8, a, b, c, d, e, f];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.DrawTiles = function(a, b, c, d, e) {
    a = ["DrawTiles", 9, a, b, c, d, e];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.DrawTriangles = function(a,
    b, c, d, e, f) {
    a = ["DrawTriangles", 10, a, b, c, d, e, f];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.EndFill = ["EndFill", 11];
R.EndFill.toString = p;
R.EndFill.__enum__ = R;
R.LineStyle = function(a, b, c, d, e, f, g, h) {
    a = ["LineStyle", 12, a, b, c, d, e, f, g, h];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.LineBitmapStyle = function(a, b, c, d) {
    a = ["LineBitmapStyle", 13, a, b, c, d];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.LineGradientStyle = function(a, b, c, d, e, f, g, h) {
    a = ["LineGradientStyle", 14, a, b, c, d, e, f, g, h];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.LineTo = function(a,
    b) {
    var c = ["LineTo", 15, a, b];
    c.__enum__ = R;
    c.toString = p;
    return c
};
R.MoveTo = function(a, b) {
    var c = ["MoveTo", 16, a, b];
    c.__enum__ = R;
    c.toString = p;
    return c
};
R.DrawPathC = function(a, b, c) {
    a = ["DrawPathC", 17, a, b, c];
    a.__enum__ = R;
    a.toString = p;
    return a
};
R.OverrideMatrix = function(a) {
    a = ["OverrideMatrix", 18, a];
    a.__enum__ = R;
    a.toString = p;
    return a
};
var Nc = g["openfl.display.GraphicsPathWinding"] = {
    __ename__: ["openfl", "display", "GraphicsPathWinding"],
    __constructs__: ["EVEN_ODD", "NON_ZERO"]
};
Nc.EVEN_ODD = ["EVEN_ODD", 0];
Nc.EVEN_ODD.toString =
    p;
Nc.EVEN_ODD.__enum__ = Nc;
Nc.NON_ZERO = ["NON_ZERO", 1];
Nc.NON_ZERO.toString = p;
Nc.NON_ZERO.__enum__ = Nc;
var Oc = g["openfl.display.InterpolationMethod"] = {
    __ename__: ["openfl", "display", "InterpolationMethod"],
    __constructs__: ["RGB", "LINEAR_RGB"]
};
Oc.RGB = ["RGB", 0];
Oc.RGB.toString = p;
Oc.RGB.__enum__ = Oc;
Oc.LINEAR_RGB = ["LINEAR_RGB", 1];
Oc.LINEAR_RGB.toString = p;
Oc.LINEAR_RGB.__enum__ = Oc;
var wb = g["openfl.display.JointStyle"] = {
    __ename__: ["openfl", "display", "JointStyle"],
    __constructs__: ["MITER", "ROUND", "BEVEL"]
};
wb.MITER = ["MITER", 0];
wb.MITER.toString = p;
wb.MITER.__enum__ = wb;
wb.ROUND = ["ROUND", 1];
wb.ROUND.toString = p;
wb.ROUND.__enum__ = wb;
wb.BEVEL = ["BEVEL", 2];
wb.BEVEL.toString = p;
wb.BEVEL.__enum__ = wb;
var Ta = g["openfl.display.LineScaleMode"] = {
    __ename__: ["openfl", "display", "LineScaleMode"],
    __constructs__: ["HORIZONTAL", "NONE", "NORMAL", "VERTICAL"]
};
Ta.HORIZONTAL = ["HORIZONTAL", 0];
Ta.HORIZONTAL.toString = p;
Ta.HORIZONTAL.__enum__ = Ta;
Ta.NONE = ["NONE", 1];
Ta.NONE.toString = p;
Ta.NONE.__enum__ = Ta;
Ta.NORMAL = ["NORMAL", 2];
Ta.NORMAL.toString =
    p;
Ta.NORMAL.__enum__ = Ta;
Ta.VERTICAL = ["VERTICAL", 3];
Ta.VERTICAL.toString = p;
Ta.VERTICAL.__enum__ = Ta;
var Df = function() {};
g["openfl.display.Loader"] = Df;
Df.__name__ = ["openfl", "display", "Loader"];
Df.__super__ = y;
Df.prototype = t(y.prototype, {
    __class__: Df
});
var Fb = g["openfl.display.PixelSnapping"] = {
    __ename__: ["openfl", "display", "PixelSnapping"],
    __constructs__: ["NEVER", "AUTO", "ALWAYS"]
};
Fb.NEVER = ["NEVER", 0];
Fb.NEVER.toString = p;
Fb.NEVER.__enum__ = Fb;
Fb.AUTO = ["AUTO", 1];
Fb.AUTO.toString = p;
Fb.AUTO.__enum__ = Fb;
Fb.ALWAYS = ["ALWAYS", 2];
Fb.ALWAYS.toString = p;
Fb.ALWAYS.__enum__ = Fb;
var sd = function(a) {
    Ia.call(this);
    if (null != a && (this.display = a, S.current.addChild(a), x.__instanceof(a, yb))) x.__cast(a, yb).onInit()
};
g["openfl.display.Preloader"] = sd;
sd.__name__ = ["openfl", "display", "Preloader"];
sd.__super__ = Ia;
sd.prototype = t(Ia.prototype, {
    load: function(a, b) {
        var c = [],
            d = null,
            e = this.display;
        1 == z.isFunction(z.field(e, "handleAssets")) && e.handleAssets(a, b);
        for (var e = 0, f = a.length; e < f;) {
            var g = e++,
                d = a[g];
            switch (b[g]) {
                case "MUSIC":
                case "SOUND":
                    d =
                        Ic.withoutExtension(d), u.remove(c, d) || this.total++, c.push(d)
            }
        }
        for (e = 0; e < c.length;) f = c[e], ++e, d = new lc, d.addEventListener(w.COMPLETE, r(this, this.sound_onComplete)), d.addEventListener(Ub.IO_ERROR, r(this, this.sound_onIOError)), d.load(new Dc(f + ".ogg"));
        Ia.prototype.load.call(this, a, b)
    },
    start: function() {
        null != this.display && x.__instanceof(this.display, yb) ? (this.display.addEventListener(w.COMPLETE, r(this, this.display_onComplete)), x.__cast(this.display, yb).onLoaded()) : Ia.prototype.start.call(this)
    },
    update: function(a,
        b) {
        if (null != this.display && x.__instanceof(this.display, yb)) x.__cast(this.display, yb).onUpdate(a, b)
    },
    display_onComplete: function(a) {
        this.display.removeEventListener(w.COMPLETE, r(this, this.display_onComplete));
        S.current.removeChild(this.display);
        S.current.stage.set_focus(null);
        this.display = null;
        Ia.prototype.start.call(this)
    },
    sound_onComplete: function(a) {
        this.loaded++;
        this.update(this.loaded, this.total);
        this.loaded == this.total && this.start()
    },
    sound_onIOError: function(a) {
        this.loaded++;
        this.update(this.loaded,
            this.total);
        this.loaded == this.total && this.start()
    },
    __class__: sd
});
var pe = function() {};
g["openfl.display.SimpleButton"] = pe;
pe.__name__ = ["openfl", "display", "SimpleButton"];
pe.__super__ = Ha;
pe.prototype = t(Ha.prototype, {
    __class__: pe
});
var Nb = g["openfl.display.SpreadMethod"] = {
    __ename__: ["openfl", "display", "SpreadMethod"],
    __constructs__: ["REPEAT", "REFLECT", "PAD"]
};
Nb.REPEAT = ["REPEAT", 0];
Nb.REPEAT.toString = p;
Nb.REPEAT.__enum__ = Nb;
Nb.REFLECT = ["REFLECT", 1];
Nb.REFLECT.toString = p;
Nb.REFLECT.__enum__ = Nb;
Nb.PAD = ["PAD", 2];
Nb.PAD.toString = p;
Nb.PAD.__enum__ = Nb;
var oe = function(a, b, c) {
    this.__mouseX = this.__mouseY = 0;
    y.call(this);
    null == c ? (this.__transparent = !0, this.set_color(0)) : this.set_color(c);
    this.set_name(null);
    this.__mouseY = this.__mouseX = 0;
    this.stageWidth = a;
    this.stageHeight = b;
    this.stage = this;
    this.align = ka.TOP_LEFT;
    this.allowsFullScreen = !1;
    this.set_displayState(Gb.NORMAL);
    this.frameRate = 60;
    this.quality = Za.HIGH;
    this.scaleMode = Oa.NO_SCALE;
    this.__clearBeforeRender = this.stageFocusRect = !0;
    this.__stack = [];
    a = new uc;
    a.data = [];
    a.length = 0;
    a.fixed = !1;
    a = this.stage3Ds = a;
    b = new qe;
    a.fixed || (a.length++, a.data.length < a.length && (c = Array(a.data.length + 10), ab.blit(a.data, 0, c, 0, a.data.length), a.data = c), a.data[a.length - 1] = b);
    a.length
};
g["openfl.display.Stage"] = oe;
oe.__name__ = ["openfl", "display", "Stage"];
oe.__super__ = y;
oe.prototype = t(y.prototype, {
    globalToLocal: function(a) {
        return a
    },
    localToGlobal: function(a) {
        return a
    },
    __drag: function(a) {
        var b = this.__dragObject.parent;
        null != b && (a = b.globalToLocal(a));
        b = a.x + this.__dragOffsetX;
        a = a.y + this.__dragOffsetY;
        null != this.__dragBounds && (b < this.__dragBounds.x ? b = this.__dragBounds.x : b > this.__dragBounds.get_right() && (b = this.__dragBounds.get_right()), a < this.__dragBounds.y ? a = this.__dragBounds.y : a > this.__dragBounds.get_bottom() && (a = this.__dragBounds.get_bottom()));
        this.__dragObject.set_x(b);
        this.__dragObject.set_y(a)
    },
    __fireEvent: function(a, b) {
        var c = b.length;
        if (0 == c) a.eventPhase = La.AT_TARGET, a.target.__broadcast(a, !1);
        else {
            a.eventPhase = La.CAPTURING_PHASE;
            a.target = b[b.length - 1];
            for (var d =
                    0, e = c - 1; d < e;) {
                var f = d++;
                b[f].__broadcast(a, !1);
                if (a.__isCancelled) return
            }
            a.eventPhase = La.AT_TARGET;
            a.target.__broadcast(a, !1);
            if (!a.__isCancelled && a.bubbles)
                for (a.eventPhase = La.BUBBLING_PHASE, c -= 2; 0 <= c;) {
                    b[c].__broadcast(a, !1);
                    if (a.__isCancelled) break;
                    c--
                }
        }
    },
    __getInteractive: function(a) {
        a.push(this)
    },
    __render: function(a) {
        this.__broadcast(new w(w.ENTER_FRAME), !0);
        this.__invalidated && (this.__invalidated = !1, this.__broadcast(new w(w.RENDER), !0));
        this.__renderable = !0;
        this.__update(!1, !0);
        switch (a[1]) {
            case 0:
                a =
                    a[2];
                null == this.__renderer && (this.__renderer = new ha(this.stageWidth, this.stageHeight, a));
                this.__renderer.render(this);
                break;
            case 1:
                a = a[2];
                null == this.__renderer && (this.__renderer = new de(this.stageWidth, this.stageHeight, a));
                this.__renderer.render(this);
                break;
            case 2:
                a = a[2], null == this.__renderer && (this.__renderer = new eb(this.stageWidth, this.stageHeight, a)), this.__renderer.render(this)
        }
    },
    __update: function(a, b) {
        if (a) 0 < V.__worldTransformDirty && (y.prototype.__update.call(this, !0, b), b && (V.__worldTransformDirty =
            0, this.__dirty = !0));
        else if (0 < V.__worldTransformDirty || this.__dirty || 0 < V.__worldRenderDirty) y.prototype.__update.call(this, !1, b), b && (V.__worldTransformDirty = 0, V.__worldRenderDirty = 0, this.__dirty = !1)
    },
    get_mouseX: function() {
        return this.__mouseX
    },
    get_mouseY: function() {
        return this.__mouseY
    },
    set_color: function(a) {
        this.__colorSplit = [((a & 16711680) >>> 16) / 255, ((a & 65280) >>> 8) / 255, (a & 255) / 255];
        this.__colorString = "#" + M.hex(a, 6);
        return this.__color = a
    },
    set_focus: function(a) {
        if (a != this.__focus) {
            if (null != this.__focus) {
                var b =
                    new Bb(Bb.FOCUS_OUT, !0, !1, a, !1, 0);
                this.__stack = [];
                this.__focus.__getInteractive(this.__stack);
                this.__stack.reverse();
                this.__fireEvent(b, this.__stack)
            }
            null != a && (b = new Bb(Bb.FOCUS_IN, !0, !1, this.__focus, !1, 0), this.__stack = [], a.__getInteractive(this.__stack), this.__stack.reverse(), this.__fireEvent(b, this.__stack));
            this.__focus = a
        }
        return this.__focus
    },
    set_displayState: function(a) {
        return this.displayState = a
    },
    __class__: oe,
    __properties__: t(y.prototype.__properties__, {
        set_focus: "set_focus",
        set_color: "set_color",
        set_displayState: "set_displayState"
    })
});
var qe = function() {
    U.call(this)
};
g["openfl.display.Stage3D"] = qe;
qe.__name__ = ["openfl", "display", "Stage3D"];
qe.__super__ = U;
qe.prototype = t(U.prototype, {
    __class__: qe
});
var ka = g["openfl.display.StageAlign"] = {
    __ename__: ["openfl", "display", "StageAlign"],
    __constructs__: "TOP_RIGHT TOP_LEFT TOP RIGHT LEFT BOTTOM_RIGHT BOTTOM_LEFT BOTTOM".split(" ")
};
ka.TOP_RIGHT = ["TOP_RIGHT", 0];
ka.TOP_RIGHT.toString = p;
ka.TOP_RIGHT.__enum__ = ka;
ka.TOP_LEFT = ["TOP_LEFT", 1];
ka.TOP_LEFT.toString =
    p;
ka.TOP_LEFT.__enum__ = ka;
ka.TOP = ["TOP", 2];
ka.TOP.toString = p;
ka.TOP.__enum__ = ka;
ka.RIGHT = ["RIGHT", 3];
ka.RIGHT.toString = p;
ka.RIGHT.__enum__ = ka;
ka.LEFT = ["LEFT", 4];
ka.LEFT.toString = p;
ka.LEFT.__enum__ = ka;
ka.BOTTOM_RIGHT = ["BOTTOM_RIGHT", 5];
ka.BOTTOM_RIGHT.toString = p;
ka.BOTTOM_RIGHT.__enum__ = ka;
ka.BOTTOM_LEFT = ["BOTTOM_LEFT", 6];
ka.BOTTOM_LEFT.toString = p;
ka.BOTTOM_LEFT.__enum__ = ka;
ka.BOTTOM = ["BOTTOM", 7];
ka.BOTTOM.toString = p;
ka.BOTTOM.__enum__ = ka;
var Gb = g["openfl.display.StageDisplayState"] = {
    __ename__: ["openfl",
        "display", "StageDisplayState"
    ],
    __constructs__: ["NORMAL", "FULL_SCREEN", "FULL_SCREEN_INTERACTIVE"]
};
Gb.NORMAL = ["NORMAL", 0];
Gb.NORMAL.toString = p;
Gb.NORMAL.__enum__ = Gb;
Gb.FULL_SCREEN = ["FULL_SCREEN", 1];
Gb.FULL_SCREEN.toString = p;
Gb.FULL_SCREEN.__enum__ = Gb;
Gb.FULL_SCREEN_INTERACTIVE = ["FULL_SCREEN_INTERACTIVE", 2];
Gb.FULL_SCREEN_INTERACTIVE.toString = p;
Gb.FULL_SCREEN_INTERACTIVE.__enum__ = Gb;
var Za = g["openfl.display.StageQuality"] = {
    __ename__: ["openfl", "display", "StageQuality"],
    __constructs__: ["BEST", "HIGH",
        "MEDIUM", "LOW"
    ]
};
Za.BEST = ["BEST", 0];
Za.BEST.toString = p;
Za.BEST.__enum__ = Za;
Za.HIGH = ["HIGH", 1];
Za.HIGH.toString = p;
Za.HIGH.__enum__ = Za;
Za.MEDIUM = ["MEDIUM", 2];
Za.MEDIUM.toString = p;
Za.MEDIUM.__enum__ = Za;
Za.LOW = ["LOW", 3];
Za.LOW.toString = p;
Za.LOW.__enum__ = Za;
var Oa = g["openfl.display.StageScaleMode"] = {
    __ename__: ["openfl", "display", "StageScaleMode"],
    __constructs__: ["SHOW_ALL", "NO_SCALE", "NO_BORDER", "EXACT_FIT"]
};
Oa.SHOW_ALL = ["SHOW_ALL", 0];
Oa.SHOW_ALL.toString = p;
Oa.SHOW_ALL.__enum__ = Oa;
Oa.NO_SCALE = ["NO_SCALE",
    1
];
Oa.NO_SCALE.toString = p;
Oa.NO_SCALE.__enum__ = Oa;
Oa.NO_BORDER = ["NO_BORDER", 2];
Oa.NO_BORDER.toString = p;
Oa.NO_BORDER.__enum__ = Oa;
Oa.EXACT_FIT = ["EXACT_FIT", 3];
Oa.EXACT_FIT.toString = p;
Oa.EXACT_FIT.__enum__ = Oa;
var Ob = g["openfl.display.TriangleCulling"] = {
    __ename__: ["openfl", "display", "TriangleCulling"],
    __constructs__: ["NEGATIVE", "NONE", "POSITIVE"]
};
Ob.NEGATIVE = ["NEGATIVE", 0];
Ob.NEGATIVE.toString = p;
Ob.NEGATIVE.__enum__ = Ob;
Ob.NONE = ["NONE", 1];
Ob.NONE.toString = p;
Ob.NONE.__enum__ = Ob;
Ob.POSITIVE = ["POSITIVE",
    2
];
Ob.POSITIVE.toString = p;
Ob.POSITIVE.__enum__ = Ob;
var re = function(a, b) {
    null == b && (b = 0);
    null == a && (a = "");
    this.message = a;
    this.errorID = b;
    this.name = "Error"
};
g["openfl.errors.Error"] = re;
re.__name__ = ["openfl", "errors", "Error"];
re.prototype = {
    toString: function() {
        return null != this.message ? this.message : "Error"
    },
    __class__: re
};
var w = function(a, b, c) {
    null == c && (c = !1);
    null == b && (b = !1);
    this.type = a;
    this.bubbles = b;
    this.cancelable = c;
    this.eventPhase = La.AT_TARGET
};
g["openfl.events.Event"] = w;
w.__name__ = ["openfl", "events",
    "Event"
];
w.prototype = {
    stopImmediatePropagation: function() {
        this.__isCancelledNow = this.__isCancelled = !0
    },
    __class__: w
};
var Pc = function(a, b, c, d) {
    null == d && (d = "");
    null == c && (c = !1);
    null == b && (b = !1);
    w.call(this, a, b, c);
    this.text = d
};
g["openfl.events.TextEvent"] = Pc;
Pc.__name__ = ["openfl", "events", "TextEvent"];
Pc.__super__ = w;
Pc.prototype = t(w.prototype, {
    __class__: Pc
});
var Vb = function(a, b, c, d, e) {
    null == e && (e = 0);
    null == d && (d = "");
    null == c && (c = !1);
    null == b && (b = !1);
    Pc.call(this, a, b, c, d);
    this.errorID = e
};
g["openfl.events.ErrorEvent"] =
    Vb;
Vb.__name__ = ["openfl", "events", "ErrorEvent"];
Vb.__super__ = Pc;
Vb.prototype = t(Pc.prototype, {
    __class__: Vb
});
var ud = function(a, b, c) {
    this.callback = a;
    this.useCapture = b;
    this.priority = c
};
g["openfl.events._EventDispatcher.Listener"] = ud;
ud.__name__ = ["openfl", "events", "_EventDispatcher", "Listener"];
ud.prototype = {
    match: function(a, b) {
        return z.compareMethods(this.callback, a) && this.useCapture == b
    },
    __class__: ud
};
var La = g["openfl.events.EventPhase"] = {
    __ename__: ["openfl", "events", "EventPhase"],
    __constructs__: ["CAPTURING_PHASE",
        "AT_TARGET", "BUBBLING_PHASE"
    ]
};
La.CAPTURING_PHASE = ["CAPTURING_PHASE", 0];
La.CAPTURING_PHASE.toString = p;
La.CAPTURING_PHASE.__enum__ = La;
La.AT_TARGET = ["AT_TARGET", 1];
La.AT_TARGET.toString = p;
La.AT_TARGET.__enum__ = La;
La.BUBBLING_PHASE = ["BUBBLING_PHASE", 2];
La.BUBBLING_PHASE.toString = p;
La.BUBBLING_PHASE.__enum__ = La;
var Bb = function(a, b, c, d, e, f) {
    null == f && (f = 0);
    null == e && (e = !1);
    null == c && (c = !1);
    null == b && (b = !1);
    w.call(this, a, b, c);
    this.keyCode = f;
    this.shiftKey = e;
    this.relatedObject = d
};
g["openfl.events.FocusEvent"] =
    Bb;
Bb.__name__ = ["openfl", "events", "FocusEvent"];
Bb.__super__ = w;
Bb.prototype = t(w.prototype, {
    __class__: Bb
});
var Qc = function(a, b, c, d) {
    null == d && (d = 0);
    null == c && (c = !1);
    null == b && (b = !1);
    this.status = d;
    w.call(this, a, b, c)
};
g["openfl.events.HTTPStatusEvent"] = Qc;
Qc.__name__ = ["openfl", "events", "HTTPStatusEvent"];
Qc.__super__ = w;
Qc.prototype = t(w.prototype, {
    __class__: Qc
});
var Ub = function(a, b, c, d, e) {
    null == e && (e = 0);
    null == d && (d = "");
    null == c && (c = !1);
    null == b && (b = !0);
    Vb.call(this, a, b, c, d, e)
};
g["openfl.events.IOErrorEvent"] =
    Ub;
Ub.__name__ = ["openfl", "events", "IOErrorEvent"];
Ub.__super__ = Vb;
Ub.prototype = t(Vb.prototype, {
    __class__: Ub
});
var Tb = function(a, b, c, d, e, f, g, h, k, m, n) {
    null == n && (n = !1);
    null == m && (m = !1);
    null == k && (k = !1);
    null == h && (h = !1);
    null == g && (g = !1);
    null == e && (e = 0);
    null == d && (d = 0);
    null == c && (c = !1);
    null == b && (b = !1);
    w.call(this, a, b, c);
    this.charCode = d;
    this.keyCode = e;
    this.keyLocation = null != f ? f : 0;
    this.ctrlKey = g;
    this.altKey = h;
    this.shiftKey = k;
    this.controlKey = m;
    this.commandKey = n
};
g["openfl.events.KeyboardEvent"] = Tb;
Tb.__name__ = ["openfl",
    "events", "KeyboardEvent"
];
Tb.__super__ = w;
Tb.prototype = t(w.prototype, {
    __class__: Tb
});
var D = function(a, b, c, d, e, f, g, h, k, m, n, p, r) {
    null == r && (r = 0);
    null == p && (p = !1);
    null == n && (n = 0);
    null == m && (m = !1);
    null == k && (k = !1);
    null == h && (h = !1);
    null == g && (g = !1);
    null == e && (e = 0);
    null == d && (d = 0);
    null == c && (c = !1);
    null == b && (b = !0);
    w.call(this, a, b, c);
    this.shiftKey = k;
    this.altKey = h;
    this.ctrlKey = g;
    this.bubbles = b;
    this.relatedObject = f;
    this.delta = n;
    this.localX = d;
    this.localY = e;
    this.buttonDown = m;
    this.commandKey = p;
    this.clickCount = r
};
g["openfl.events.MouseEvent"] =
    D;
D.__name__ = ["openfl", "events", "MouseEvent"];
D.__create = function(a, b, c, d) {
    switch (a) {
        case D.MOUSE_DOWN:
        case D.MIDDLE_MOUSE_DOWN:
        case D.RIGHT_MOUSE_DOWN:
            D.__buttonDown[b] = !0;
            break;
        case D.MOUSE_UP:
        case D.MIDDLE_MOUSE_UP:
        case D.RIGHT_MOUSE_UP:
            D.__buttonDown[b] = !1
    }
    a = new D(a, !0, !1, c.x, c.y, null, !1, !1, !1, D.__buttonDown[b], 2);
    a.stageX = S.current.stage.get_mouseX();
    a.stageY = S.current.stage.get_mouseY();
    a.target = d;
    return a
};
D.__super__ = w;
D.prototype = t(w.prototype, {
    __class__: D
});
var Rc = function(a, b, c, d, e) {
    null ==
        e && (e = 0);
    null == d && (d = 0);
    null == c && (c = !1);
    null == b && (b = !1);
    w.call(this, a, b, c);
    this.bytesLoaded = d;
    this.bytesTotal = e
};
g["openfl.events.ProgressEvent"] = Rc;
Rc.__name__ = ["openfl", "events", "ProgressEvent"];
Rc.__super__ = w;
Rc.prototype = t(w.prototype, {
    __class__: Rc
});
var Sc = function(a, b, c, d, e) {
    null == e && (e = 0);
    null == d && (d = "");
    null == c && (c = !1);
    null == b && (b = !1);
    Vb.call(this, a, b, c, d, e)
};
g["openfl.events.SecurityErrorEvent"] = Sc;
Sc.__name__ = ["openfl", "events", "SecurityErrorEvent"];
Sc.__super__ = Vb;
Sc.prototype = t(Vb.prototype, {
    __class__: Sc
});
var xb = function(a, b, c) {
    null == c && (c = !1);
    null == b && (b = !1);
    w.call(this, a, b, c)
};
g["openfl.events.TimerEvent"] = xb;
xb.__name__ = ["openfl", "events", "TimerEvent"];
xb.__super__ = w;
xb.prototype = t(w.prototype, {
    __class__: xb
});
var Cc = function(a, b, c, d, e, f, g, h, k, m, n, p, r, t, u) {
    null == t && (t = !1);
    null == r && (r = 0);
    null == p && (p = !1);
    null == n && (n = !1);
    null == m && (m = !1);
    null == k && (k = !1);
    null == g && (g = 1);
    null == f && (f = 1);
    null == e && (e = 0);
    null == d && (d = 0);
    null == c && (c = !1);
    null == b && (b = !0);
    w.call(this, a, b, c);
    this.shiftKey = n;
    this.altKey =
        m;
    this.ctrlKey = k;
    this.bubbles = b;
    this.relatedObject = h;
    this.delta = r;
    this.localX = d;
    this.localY = e;
    this.sizeX = f;
    this.sizeY = g;
    this.buttonDown = p;
    this.commandKey = t;
    this.pressure = 1;
    this.touchPointID = 0;
    this.isPrimaryTouchPoint = !0
};
g["openfl.events.TouchEvent"] = Cc;
Cc.__name__ = ["openfl", "events", "TouchEvent"];
Cc.__create = function(a, b, c, d) {
    a = new Cc(a, !0, !1, c.x, c.y, null, null, null, !1, !1, !1, !1, 0, null, 0);
    a.stageX = S.current.stage.get_mouseX();
    a.stageY = S.current.stage.get_mouseY();
    a.target = d;
    return a
};
Cc.__super__ =
    w;
Cc.prototype = t(w.prototype, {
    __class__: Cc
});
var gg = function() {};
g["openfl.filters.BitmapFilter"] = gg;
gg.__name__ = ["openfl", "filters", "BitmapFilter"];
var Sd = function(a, b, c, d, e, f, g, h) {
    null == h && (h = 0);
    null == g && (g = 0);
    null == f && (f = 0);
    null == e && (e = 0);
    null == d && (d = 1);
    null == c && (c = 1);
    null == b && (b = 1);
    null == a && (a = 1);
    this.redMultiplier = a;
    this.greenMultiplier = b;
    this.blueMultiplier = c;
    this.alphaMultiplier = d;
    this.redOffset = e;
    this.greenOffset = f;
    this.blueOffset = g;
    this.alphaOffset = h
};
g["openfl.geom.ColorTransform"] = Sd;
Sd.__name__ = ["openfl", "geom", "ColorTransform"];
Sd.prototype = {
    __class__: Sd
};
var hg = function() {};
g["openfl.geom.Transform"] = hg;
hg.__name__ = ["openfl", "geom", "Transform"];
var ig = function() {};
g["openfl.media.ID3Info"] = ig;
ig.__name__ = ["openfl", "media", "ID3Info"];
var lc = function(a, b) {
    U.call(this, this);
    this.bytesTotal = this.bytesLoaded = 0;
    this.id3 = null;
    this.isBuffering = !1;
    this.length = 0;
    this.url = null;
    null != a && this.load(a, b)
};
g["openfl.media.Sound"] = lc;
lc.__name__ = ["openfl", "media", "Sound"];
lc.__super__ = U;
lc.prototype = t(U.prototype, {
    load: function(a, b) {
        this.url = a.url;
        this.__soundID = Ic.withoutExtension(a.url);
        lc.__registeredSounds.exists(this.__soundID) ? this.dispatchEvent(new w(w.COMPLETE)) : (lc.__registeredSounds.set(this.__soundID, !0), createjs.Sound.addEventListener("fileload", r(this, this.SoundJS_onFileLoad)), createjs.Sound.addEventListener("fileerror", r(this, this.SoundJS_onFileError)), createjs.Sound.registerSound(this.url, this.__soundID))
    },
    play: function(a, b, c) {
        null == b && (b = 0);
        null == a && (a = 0);
        null == c && (c = new Gc(1, 0));
        a = createjs.Sound.play(this.__soundID,
            "any", 0, a | 0, b, c.volume, c.pan);
        return new se(a)
    },
    SoundJS_onFileLoad: function(a) {
        a.id == this.__soundID && (createjs.Sound.removeEventListener("fileload", r(this, this.SoundJS_onFileLoad)), createjs.Sound.removeEventListener("fileerror", r(this, this.SoundJS_onFileError)), this.dispatchEvent(new w(w.COMPLETE)))
    },
    SoundJS_onFileError: function(a) {
        a.id == this.__soundID && (createjs.Sound.removeEventListener("fileload", r(this, this.SoundJS_onFileLoad)), createjs.Sound.removeEventListener("fileerror", r(this, this.SoundJS_onFileError)),
            this.dispatchEvent(new Ub(Ub.IO_ERROR)))
    },
    __class__: lc
});
var se = function(a) {
    U.call(this, this);
    null != a && (this.__soundInstance = a, this.__soundInstance.addEventListener("complete", r(this, this.source_onComplete)), this.__isValid = !0)
};
g["openfl.media.SoundChannel"] = se;
se.__name__ = ["openfl", "media", "SoundChannel"];
se.__super__ = U;
se.prototype = t(U.prototype, {
    stop: function() {
        this.__isValid && this.__soundInstance.stop()
    },
    get_position: function() {
        return this.__isValid ? this.__soundInstance.getPosition() : 0
    },
    source_onComplete: function() {
        this.dispatchEvent(new w(w.SOUND_COMPLETE))
    },
    __class__: se,
    __properties__: {
        get_position: "get_position"
    }
});
var jg = function() {};
g["openfl.media.SoundLoaderContext"] = jg;
jg.__name__ = ["openfl", "media", "SoundLoaderContext"];
var Gc = function(a, b) {
    null == b && (b = 0);
    null == a && (a = 1);
    this.volume = a;
    this.pan = b;
    this.rightToRight = this.rightToLeft = this.leftToRight = this.leftToLeft = 0
};
g["openfl.media.SoundTransform"] = Gc;
Gc.__name__ = ["openfl", "media", "SoundTransform"];
Gc.prototype = {
    __class__: Gc
};
var rb = function() {
    U.call(this)
};
g["openfl.net.SharedObject"] = rb;
rb.__name__ = ["openfl", "net", "SharedObject"];
rb.getLocal = function(a, b, c) {
    null == b && (b = window.location.href);
    c = new rb;
    c.__key = b + ":" + a;
    a = null;
    try {
        a = rb.__getLocalStorage().getItem(c.__key)
    } catch (d) {}
    c.data = {};
    null != a && "" != a && (a = new cb(a), a.setResolver({
        resolveEnum: O.resolveEnum,
        resolveClass: rb.resolveClass
    }), c.data = a.unserialize());
    null == c.data && (c.data = {});
    return c
};
rb.__getLocalStorage = function() {
    var a = Of.getLocalStorage();
    if (null == a) throw new re("SharedObject not supported");
    return a
};
rb.resolveClass = function(a) {
    return null !=
        a ? O.resolveClass(M.replace(M.replace(a, "jeash.", "flash."), "browser.", "flash.")) : null
};
rb.__super__ = U;
rb.prototype = t(U.prototype, {
    flush: function(a) {
        a = Cb.run(this.data);
        try {
            rb.__getLocalStorage().removeItem(this.__key), rb.__getLocalStorage().setItem(this.__key, a)
        } catch (b) {
            return mc.PENDING
        }
        return mc.FLUSHED
    },
    __class__: rb
});
var mc = g["openfl.net.SharedObjectFlushStatus"] = {
    __ename__: ["openfl", "net", "SharedObjectFlushStatus"],
    __constructs__: ["FLUSHED", "PENDING"]
};
mc.FLUSHED = ["FLUSHED", 0];
mc.FLUSHED.toString =
    p;
mc.FLUSHED.__enum__ = mc;
mc.PENDING = ["PENDING", 1];
mc.PENDING.toString = p;
mc.PENDING.__enum__ = mc;
var Jd = function(a) {
    U.call(this);
    this.bytesTotal = this.bytesLoaded = 0;
    this.set_dataFormat(pb.TEXT);
    null != a && this.load(a)
};
g["openfl.net.URLLoader"] = Jd;
Jd.__name__ = ["openfl", "net", "URLLoader"];
Jd.__super__ = U;
Jd.prototype = t(U.prototype, {
    getData: function() {
        return null
    },
    load: function(a) {
        this.requestUrl(a.url, a.method, a.data, a.formatRequestHeaders())
    },
    registerEvents: function(a) {
        var b = this;
        "undefined" != typeof XMLHttpRequestProgressEvent &&
            a.addEventListener("progress", r(this, this.onProgress), !1);
        a.onreadystatechange = function() {
            if (4 == a.readyState) {
                var c;
                try {
                    c = a.status
                } catch (d) {
                    c = null
                }
                void 0 == c && (c = null);
                if (null != c) b.onStatus(c);
                if (null != c && 200 <= c && 400 > c) b.onData(a.response);
                else if (null == c) b.onError("Failed to connect or resolve host");
                else if (12029 == c) b.onError("Failed to connect to host");
                else if (12007 == c) b.onError("Unknown host");
                else if (0 == c) b.onError("Unable to make request (may be blocked due to cross-domain permissions)"), b.onSecurityError("Unable to make request (may be blocked due to cross-domain permissions)");
                else b.onError("Http Error #" + a.status)
            }
        }
    },
    requestUrl: function(a, b, c, d) {
        var e = new XMLHttpRequest;
        this.registerEvents(e);
        var f = "";
        if (x.__instanceof(c, fb)) switch (this.dataFormat[1]) {
            case 0:
                f = c.data.buffer;
                break;
            default:
                f = c.readUTFBytes(c.length)
        } else if (x.__instanceof(c, Zc))
            for (var g = 0, h = z.fields(c); g < h.length;) {
                var k = h[g];
                ++g;
                0 != f.length && (f += "&");
                f += encodeURIComponent(k) + "=" + M.urlEncode(z.field(c, k))
            } else null != c && (f = c.toString());
        try {
            if ("GET" == b && null != f && "" != f) {
                var m = 1 >= a.split("?").length;
                e.open(b,
                    a + (m ? "?" : "&") + v.string(f), !0);
                f = ""
            } else e.open(b, a, !0)
        } catch (n) {
            this.onError(n.toString());
            return
        }
        switch (this.dataFormat[1]) {
            case 0:
                e.responseType = "arraybuffer"
        }
        for (a = 0; a < d.length;) b = d[a], ++a, e.setRequestHeader(b.name, b.value);
        e.send(f);
        this.onOpen();
        this.getData = function() {
            return null != e.response ? e.response : e.responseText
        }
    },
    onData: function(a) {
        a = this.getData();
        switch (this.dataFormat[1]) {
            case 0:
                this.data = fb.__ofBuffer(a);
                break;
            default:
                this.data = v.string(a)
        }
        a = new w(w.COMPLETE);
        a.currentTarget = this;
        this.dispatchEvent(a)
    },
    onError: function(a) {
        var b = new Ub(Ub.IO_ERROR);
        b.text = a;
        b.currentTarget = this;
        this.dispatchEvent(b)
    },
    onOpen: function() {
        var a = new w(w.OPEN);
        a.currentTarget = this;
        this.dispatchEvent(a)
    },
    onProgress: function(a) {
        var b = new Rc(Rc.PROGRESS);
        b.currentTarget = this;
        b.bytesLoaded = a.loaded;
        b.bytesTotal = a.total;
        this.dispatchEvent(b)
    },
    onSecurityError: function(a) {
        var b = new Sc(Sc.SECURITY_ERROR);
        b.text = a;
        b.currentTarget = this;
        this.dispatchEvent(b)
    },
    onStatus: function(a) {
        a = new Qc(Qc.HTTP_STATUS, !1, !1, a);
        a.currentTarget = this;
        this.dispatchEvent(a)
    },
    set_dataFormat: function(a) {
        a != pb.BINARY || z.hasField(window, "ArrayBuffer") ? this.dataFormat = a : this.dataFormat = pb.TEXT;
        return this.dataFormat
    },
    __class__: Jd,
    __properties__: {
        set_dataFormat: "set_dataFormat"
    }
});
var pb = g["openfl.net.URLLoaderDataFormat"] = {
    __ename__: ["openfl", "net", "URLLoaderDataFormat"],
    __constructs__: ["BINARY", "TEXT", "VARIABLES"]
};
pb.BINARY = ["BINARY", 0];
pb.BINARY.toString = p;
pb.BINARY.__enum__ = pb;
pb.TEXT = ["TEXT", 1];
pb.TEXT.toString = p;
pb.TEXT.__enum__ =
    pb;
pb.VARIABLES = ["VARIABLES", 2];
pb.VARIABLES.toString = p;
pb.VARIABLES.__enum__ = pb;
var Dc = function(a) {
    null != a && (this.url = a);
    this.requestHeaders = [];
    this.method = $c.GET;
    this.contentType = null
};
g["openfl.net.URLRequest"] = Dc;
Dc.__name__ = ["openfl", "net", "URLRequest"];
Dc.prototype = {
    formatRequestHeaders: function() {
        var a = this.requestHeaders;
        null == a && (a = []);
        if (this.method == $c.GET || null == this.data) return a;
        if ("string" == typeof this.data || x.__instanceof(this.data, fb)) a = a.slice(), a.push(new Ef("Content-Type", null !=
            this.contentType ? this.contentType : "application/x-www-form-urlencoded"));
        return a
    },
    __class__: Dc
};
var Ef = function(a, b) {
    null == b && (b = "");
    null == a && (a = "");
    this.name = a;
    this.value = b
};
g["openfl.net.URLRequestHeader"] = Ef;
Ef.__name__ = ["openfl", "net", "URLRequestHeader"];
Ef.prototype = {
    __class__: Ef
};
var $c = function() {};
g["openfl.net.URLRequestMethod"] = $c;
$c.__name__ = ["openfl", "net", "URLRequestMethod"];
var Zc = function(a) {
    null != a && this.decode(a)
};
g["openfl.net.URLVariables"] = Zc;
Zc.__name__ = ["openfl", "net", "URLVariables"];
Zc.prototype = {
    decode: function(a) {
        for (var b = z.fields(this), c = 0; c < b.length;) {
            var d = b[c];
            ++c;
            z.deleteField(this, d)
        }
        a = a.split(";").join("&").split("&");
        for (b = 0; b < a.length;) c = a[b], ++b, d = c.indexOf("="), 0 < d ? z.setField(this, M.urlDecode(u.substr(c, 0, d)), M.urlDecode(u.substr(c, d + 1, null))) : 0 != d && z.setField(this, decodeURIComponent(c.split("+").join(" ")), "")
    },
    __class__: Zc
};
var Vc = function(a) {
    Ib.call(this, a)
};
g["openfl.text.Font"] = Vc;
Vc.__name__ = ["openfl", "text", "Font"];
Vc.__super__ = id;
Vc.prototype = t(id.prototype, {
    __class__: Vc
});
var Ab = g["openfl.text.GridFitType"] = {
    __ename__: ["openfl", "text", "GridFitType"],
    __constructs__: ["NONE", "PIXEL", "SUBPIXEL"]
};
Ab.NONE = ["NONE", 0];
Ab.NONE.toString = p;
Ab.NONE.__enum__ = Ab;
Ab.PIXEL = ["PIXEL", 1];
Ab.PIXEL.toString = p;
Ab.PIXEL.__enum__ = Ab;
Ab.SUBPIXEL = ["SUBPIXEL", 2];
Ab.SUBPIXEL.toString = p;
Ab.SUBPIXEL.__enum__ = Ab;
var Rf = function() {};
g["openfl.text.TextFormatRange"] = Rf;
Rf.__name__ = ["openfl", "text", "TextFormatRange"];
Rf.prototype = {
    __class__: Rf
};
var wa = g["openfl.text.TextFieldAutoSize"] = {
    __ename__: ["openfl", "text", "TextFieldAutoSize"],
    __constructs__: ["CENTER", "LEFT", "NONE", "RIGHT"]
};
wa.CENTER = ["CENTER", 0];
wa.CENTER.toString = p;
wa.CENTER.__enum__ = wa;
wa.LEFT = ["LEFT", 1];
wa.LEFT.toString = p;
wa.LEFT.__enum__ = wa;
wa.NONE = ["NONE", 2];
wa.NONE.toString = p;
wa.NONE.__enum__ = wa;
wa.RIGHT = ["RIGHT", 3];
wa.RIGHT.toString = p;
wa.RIGHT.__enum__ = wa;
var Rb = g["openfl.text.TextFieldType"] = {
    __ename__: ["openfl", "text", "TextFieldType"],
    __constructs__: ["DYNAMIC", "INPUT"]
};
Rb.DYNAMIC = ["DYNAMIC", 0];
Rb.DYNAMIC.toString =
    p;
Rb.DYNAMIC.__enum__ = Rb;
Rb.INPUT = ["INPUT", 1];
Rb.INPUT.toString = p;
Rb.INPUT.__enum__ = Rb;
var cd = function(a, b, c, d, e, f, g, h, k, m, n, p, r) {
    this.font = a;
    this.size = b;
    this.color = c;
    this.bold = d;
    this.italic = e;
    this.underline = f;
    this.url = g;
    this.target = h;
    this.align = k;
    this.leftMargin = m;
    this.rightMargin = n;
    this.indent = p;
    this.leading = r
};
g["openfl.text.TextFormat"] = cd;
cd.__name__ = ["openfl", "text", "TextFormat"];
cd.prototype = {
    clone: function() {
        var a = new cd(this.font, this.size, this.color, this.bold, this.italic, this.underline,
            this.url, this.target);
        a.align = this.align;
        a.leftMargin = this.leftMargin;
        a.rightMargin = this.rightMargin;
        a.indent = this.indent;
        a.leading = this.leading;
        a.blockIndent = this.blockIndent;
        a.bullet = this.bullet;
        a.kerning = this.kerning;
        a.letterSpacing = this.letterSpacing;
        a.tabStops = this.tabStops;
        return a
    },
    __merge: function(a) {
        null != a.font && (this.font = a.font);
        null != a.size && (this.size = a.size);
        null != a.color && (this.color = a.color);
        null != a.bold && (this.bold = a.bold);
        null != a.italic && (this.italic = a.italic);
        null != a.underline &&
            (this.underline = a.underline);
        null != a.url && (this.url = a.url);
        null != a.target && (this.target = a.target);
        null != a.align && (this.align = a.align);
        null != a.leftMargin && (this.leftMargin = a.leftMargin);
        null != a.rightMargin && (this.rightMargin = a.rightMargin);
        null != a.indent && (this.indent = a.indent);
        null != a.leading && (this.leading = a.leading);
        null != a.blockIndent && (this.blockIndent = a.blockIndent);
        null != a.bullet && (this.bullet = a.bullet);
        null != a.kerning && (this.kerning = a.kerning);
        null != a.letterSpacing && (this.letterSpacing = a.letterSpacing);
        null != a.tabStops && (this.tabStops = a.tabStops)
    },
    __class__: cd
};
var Ea = g["openfl.text.TextFormatAlign"] = {
    __ename__: ["openfl", "text", "TextFormatAlign"],
    __constructs__: ["LEFT", "RIGHT", "JUSTIFY", "CENTER"]
};
Ea.LEFT = ["LEFT", 0];
Ea.LEFT.toString = p;
Ea.LEFT.__enum__ = Ea;
Ea.RIGHT = ["RIGHT", 1];
Ea.RIGHT.toString = p;
Ea.RIGHT.__enum__ = Ea;
Ea.JUSTIFY = ["JUSTIFY", 2];
Ea.JUSTIFY.toString = p;
Ea.JUSTIFY.__enum__ = Ea;
Ea.CENTER = ["CENTER", 3];
Ea.CENTER.toString = p;
Ea.CENTER.__enum__ = Ea;
var te = function(a, b) {
    null == b && (b = 0);
    if (Math.isNaN(a) ||
        0 > a) throw new re("The delay specified is negative or not a finite number");
    U.call(this);
    this.__delay = a;
    this.set_repeatCount(b);
    this.running = !1;
    this.currentCount = 0
};
g["openfl.utils.Timer"] = te;
te.__name__ = ["openfl", "utils", "Timer"];
te.__super__ = U;
te.prototype = t(U.prototype, {
    reset: function() {
        this.running && this.stop();
        this.currentCount = 0
    },
    start: function() {
        this.running || (this.running = !0, this.__timerID = window.setInterval(r(this, this.timer_onTimer), this.__delay | 0))
    },
    stop: function() {
        this.running = !1;
        null !=
            this.__timerID && (window.clearInterval(this.__timerID), this.__timerID = null)
    },
    set_repeatCount: function(a) {
        this.running && 0 != a && a <= this.currentCount && this.stop();
        return this.repeatCount = a
    },
    timer_onTimer: function() {
        this.currentCount++;
        0 < this.repeatCount && this.currentCount >= this.repeatCount ? (this.stop(), this.dispatchEvent(new xb(xb.TIMER)), this.dispatchEvent(new xb(xb.TIMER_COMPLETE))) : this.dispatchEvent(new xb(xb.TIMER))
    },
    __class__: te,
    __properties__: {
        set_repeatCount: "set_repeatCount"
    }
});
var Ff = function() {
    y.call(this)
};
g["scenes.Achievements"] = Ff;
Ff.__name__ = ["scenes", "Achievements"];
Ff.__super__ = Qa;
Ff.prototype = t(Qa.prototype, {
    init: function() {
        this.createTilelayer();
        this.createUi()
    },
    createTilelayer: function() {
        this.tilelayerManager = aa.get_instance();
        var a = m.formatAsset("assets/images/%25p%25/spritelists/ui.html"),
            b = m.formatAsset("assets/images/%25p%25/spritelists/ui-2.html");
        this.tilelayerManager.create("ui", a, b, this)
    },
    createUi: function() {
        this.uiLayer = new dd;
        this.addChild(this.uiLayer);
        this.createMenu();
        this.createHidePanels();
        var a = m.formatAsset("assets/images/%25p%25/buttons/btn_back.html");
        this.btnExit = new xa(a);
        this.btnExit.addEventListener("complete", r(this, this.exit));
        this.btnExit.set_x(70);
        this.btnExit.set_y(120);
        this.btnExit.setSoundEffect("click");
        this.addChild(this.btnExit);
        ba.animate(this.btnExit, {
            dir: 4
        })
    },
    createMenu: function() {
        this.menu = new od;
        this.menu.downBorder = 0;
        this.addChild(this.menu);
        this.uiLayer.add(this.menu);
        var a = {
                x: 360,
                y: 270
            },
            b = {
                x: 0,
                y: 200
            },
            c = this.createItems(),
            d = c.length * b.y,
            d = m.get_instance().nativeHeight -
            a.y + .5 * b.y - 150 - d;
        0 < d && (d = 0);
        this.menu.upBorder = d;
        this.menu.buildItems(c, a, b)
    },
    createItems: function() {
        for (var a = [], b = m.get_instance().getConfig("awards").awards, c = b.length, d = aa.get_instance().get("ui"), e, f = 0; f < c;) e = f++, e = new ue(d, e, b[e]), a.push(e);
        return a
    },
    createHidePanels: function() {
        var a = new y;
        a.get_graphics().beginFill(14409696);
        a.get_graphics().drawRect(-360, 0, 720, 175);
        a.get_graphics().endFill();
        a.set_x(360);
        a.set_y(0);
        a.mouseEnabled = !0;
        a.addEventListener(D.MOUSE_UP, r(this, this.onStopEvent));
        this.addChild(a);
        a = new y;
        a.get_graphics().beginFill(14409696);
        a.get_graphics().drawRect(-360, 0, 720, 140);
        a.get_graphics().endFill();
        a.set_x(360);
        a.set_y(1140);
        a.mouseEnabled = !0;
        a.addEventListener(D.MOUSE_UP, r(this, this.onStopEvent));
        this.addChild(a)
    },
    onStopEvent: function(a) {
        a.stopImmediatePropagation();
        this.menu.onMouseUp(a)
    },
    exit: function(a) {
        sa.instance.showScene("Menu")
    },
    update: function(a, b) {
        this.menu.update(a);
        this.tilelayerManager.update()
    },
    free: function() {
        N.get_instance().clear();
        ba.stopTween(this.btnExit);
        this.btnExit = null;
        this.tilelayerManager.free();
        this.tilelayerManager = null;
        this.uiLayer.free();
        this.uiLayer = null;
        this.menu.free();
        this.menu = null;
        P.clearPool()
    },
    __class__: Ff
});
var Gf = function() {
    y.call(this)
};
g["scenes.Leaderboard"] = Gf;
Gf.__name__ = ["scenes", "Leaderboard"];
Gf.__super__ = Qa;
Gf.prototype = t(Qa.prototype, {
    init: function() {
        this.createUi()
    },
    createUi: function() {
        var a = new qa;
        a.set_size(70);
        a.set_fieldWidth(600);
        a.set_align("center");
        a.set_x(60);
        a.set_y(17);
        a.set_text("Scores");
        this.addChild(a);
        ba.animate(a, {
            dir: 2,
            delay: .15
        });
        a = m.formatAsset("assets/images/%25p%25/buttons/btn_back.html");
        this.btnExit = new xa(a);
        this.btnExit.addEventListener("complete", r(this, this.exit));
        this.btnExit.set_x(70);
        this.btnExit.set_y(120);
        this.btnExit.setSoundEffect("click");
        this.addChild(this.btnExit);
        ba.animate(this.btnExit, {
            dir: 4
        })
    },
    exit: function(a) {
        sa.instance.showScene("Menu")
    },
    free: function() {
        ba.stopTween(this.btnExit);
        this.btnExit = null
    },
    __class__: Gf
});
var Pa = function() {
    null != Pa.instance && console.log("Presend old instance");
    Pa.instance = this;
    y.call(this)
};
g["scenes.LevelBuilder"] = Pa;
Pa.__name__ = ["scenes", "LevelBuilder"];
Pa.__interfaces__ = [dc];
Pa.instance = null;
Pa.__super__ = Qa;
Pa.prototype = t(Qa.prototype, {
    init: function() {
        this.timeMultiplier = 1;
        B.get_instance().score = 0;
        B.get_instance().additionalButtonId = "";
        this.initLayers();
        this.levelManager = new fa;
        this.createTilelayers();
        this.signToNotifications();
        this.createUi();
        this.initEntityEngine();
        this.levelManager.build();
        this.tilelayerManager.update();
        ia.get_instance().levelStarted(1);
        N.get_instance().signToNotify("softgames", this)
    },
    start: function() {
        N.get_instance().postNotify("start")
    },
    initLayers: function() {
        this.layersManager = new Ne(this);
        this.layersManager.addLayer("background");
        this.layersManager.addLayer("tilelayer");
        this.layersManager.addLayer("foreground");
        this.layersManager.addLayer("debug");
        this.layersManager.addLayer("ui")
    },
    createTilelayers: function() {
        this.tilelayerManager = aa.get_instance();
        var a = this.layersManager.getLayer("tilelayer"),
            b = m.formatAsset("assets/images/%25p%25/spritelists/main.html"),
            c = m.formatAsset("assets/images/%25p%25/spritelists/main-2.html");
        this.tilelayerManager.create("main", b, c, a);
        this.tilelayerManager.createGroup("bgGroup", "main");
        this.tilelayerManager.createGroup("pathGroup", "main");
        this.tilelayerManager.createGroup("topWallsGroup", "main");
        this.tilelayerManager.createGroup("coinsGroup", "main");
        this.tilelayerManager.createGroup("heroGroup", "main");
        this.tilelayerManager.createGroup("heroTail", "main");
        this.tilelayerManager.createGroup("bottomWallsGroup", "main");
        this.tilelayerManager.createGroup("effectsGroup",
            "main")
    },
    signToNotifications: function() {
        N.get_instance().signToNotify("levelEvent", this)
    },
    initEntityEngine: function() {
        this.entityEngine = new n;
        this.entityEngine.addCleaner(Ad);
        this.entityEngine.addSystem(ve, "PathSystem");
        this.entityEngine.addSystem(we);
        this.entityEngine.addSystem(xe);
        this.entityEngine.addSystem(pd);
        this.entityEngine.addSystem(ye);
        this.entityEngine.addSystem(ze);
        this.entityEngine.addSystem(Ae);
        this.entityEngine.addSystem(Be);
        this.entityEngine.addSystem(Ce);
        this.entityEngine.addSystem(De);
        this.entityEngine.addSystem(Ee);
        this.entityEngine.activate()
    },
    createUi: function() {
        this.createButtons();
        this.createFields()
    },
    createButtons: function() {},
    createFields: function() {
        var a = this.layersManager.getLayer("ui"),
            b = B.get_instance().getCoins();
        this.coinsPanel = new qc("assets/images/%25p%25/coins_ui.html", 14, 40);
        this.coinsPanel.label.set_text("" + b);
        this.coinsPanel.set_x(25);
        this.coinsPanel.set_y(100);
        a.addChild(this.coinsPanel);
        ba.animate(this.coinsPanel, {
            dir: 2
        });
        this.scorePanel = new Gd;
        this.scorePanel.set_x(360);
        this.scorePanel.set_y(110);
        a.addChild(this.scorePanel);
        ba.animate(this.scorePanel, {
            dir: 2
        })
    },
    updateCoins: function(a) {
        this.coinsPanel.animate(a)
    },
    updateScore: function(a) {
        this.scorePanel.update(a)
    },
    receiveNotify: function(a, b, c) {
        "lose" == c.id ? this.lose() : "loseForce" == c.id ? this.lose(!0) : "changeCoins" == c.id && this.updateCoins(v.parseInt(c.value));
        "softgames" == a && ("pause" == c.id ? this.sgPause() : "resume" == c.id && this.sgResume())
    },
    sgPause: function() {
        this.paused = !0;
        A.pauseAll();
        L.get_instance().pauseMusic(!0);
        L.get_instance().pauseSfx(!0)
    },
    sgResume: function() {
        this.paused = !1;
        A.resumeAll();
        L.get_instance().pauseMusic(!1);
        L.get_instance().pauseSfx(!1)
    },
    lose: function(a) {
        null == a && (a = !1);
        if (0 == a) this.showReviveMenu();
        else if (1 != this.showedResultMenu && 1 != this.paused)
            if (this.showedResultMenu = !0, this.saveData(), 0 == a) A.timer(.8).onComplete(r(this, this.showLose));
            else this.showLose()
    },
    showReviveMenu: function() {
        null == this.reviveMenu && (this.reviveMenu = new kd, this.addChild(this.reviveMenu));
        this.reviveMenu.show()
    },
    saveData: function() {
        var a = B.get_instance().score;
        this.saveScore(a);
        ia.get_instance().levelFinished(1, a);
        L.get_instance().pauseMusic(true);
        SG_Hooks.gameOver(1, a, function() {
            L.get_instance().pauseMusic(false);
        })
        //ia.get_instance().gameOver(1, a)
    },
    saveScore: function(a) {
        a > B.get_instance().bestScore && (B.get_instance().bestScore = a, B.get_instance().newRecord = !0, Ba.get_instance().save("highscore", "" + a));
        B.get_instance().saveScore(a)
    },
    showLose: function() {
        this.exit()
    },
    restart: function(a) {
        Pa.instance = null;
        sa.instance.showScene("LevelBuilder")
    },
    pause: function(a) {
        1 != this.paused && (this.paused = !0)
    },
    resume: function() {
        this.paused = !1
    },
    exit: function() {
        Pa.instance = null;
        sa.instance.showScene("Menu")
    },
    update: function(a, b) {
        1 != this.paused && (a *= this.timeMultiplier, this.entityEngine.update(a), this.tilelayerManager.update())
    },
    free: function() {
        P.clearPool();
        this.entityEngine.free();
        this.entityEngine = null;
        this.layersManager.free();
        this.layersManager = null;
        this.levelManager.free();
        this.levelManager = null;
        this.tilelayerManager.free();
        this.tilelayerManager = null;
        L.get_instance().stopSfx();
        N.get_instance().postNotify("clearAll");
        N.get_instance().clear()
    },
    __class__: Pa
});
var Fe = function() {
    y.call(this);
    this.active = !0;
    this.animList = []
};
g["scenes.Menu"] = Fe;
Fe.__name__ = ["scenes", "Menu"];
Fe.__interfaces__ = [dc];
Fe.__super__ = Qa;
Fe.prototype = t(Qa.prototype, {
    init: function() {
        N.get_instance().signToNotify("prize", this);
        this.createMenu();
        1 == B.get_instance().newRecord && this.showRecord()
    },
    createMenu: function() {
        this.converter = new Od;
        var a = m.formatAsset("assets/images/%25p%25/spritelists/shop.html"),
            b = m.formatAsset("assets/images/%25p%25/spritelists/shop-2.html");
        this.heroPanel = this.converter.getSprite("hero_podlog", a, b);
        this.heroPanel.set_x(360);
        this.heroPanel.set_y(1E3);
        this.addChild(this.heroPanel);
        a = B.get_instance().getHero();
        this.showHero(a, .35, .7);
        a = new qa;
        a.set_color(14804194);
        a.set_size(150);
        a.set_fieldWidth(600);
        a.set_fieldHeight(200);
        a.set_align("center");
        a.set_x(60);
        a.set_y(60);
        a.set_text("TIP TAP 2");
        a.mouseEnabled = !1;
        this.addChild(a);
        ba.animate(a, {
            dir: 2
        });
        this.addScoreField();
        a = B.get_instance().getCoins();
        this.coinsPanel = new qc("assets/images/%25p%25/coins_ui.html", 14, 40);
        this.coinsPanel.update(a);
        this.coinsPanel.set_x(360);
        this.coinsPanel.set_y(550);
        this.addChild(this.coinsPanel);
        ba.animate(this.coinsPanel, {
            dir: 2,
            delay: .3
        });
        ia.get_instance().isEnabledIncentiviseButton() && (b = m.formatAsset("assets/images/%25p%25/buttons/btn_plus.html"), b = new xa(b), b.addEventListener("complete", r(this, this.buyCoins)), b.setSoundEffect("click"), b.set_y(-3), this.coinsPanel.addButton(b, 55));
        b = m.formatAsset("assets/images/%25p%25/buttons/btn_play.html");
        b = new xa(b);
        b.onlyFirstClick = !0;
        b.addEventListener("complete", r(this, this.startGame));
        b.set_x(610);
        b.set_y(810);
        b.setSoundEffect("click");
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 2,
            delay: .3
        });
        b = this.createAdditionalButton();
        b.set_x(110);
        b.set_y(810);
        b.setSoundEffect("click");
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 2,
            delay: .3
        });
        a = [];
        0 == Ka.isIE && (b = new Ge, b.set_y(1024), b.setSoundEffect("click"), this.addChild(b), this.animList.push(b), a.push(b), ba.animate(b, {
            dir: 2,
            delay: .35
        }));
        b = m.formatAsset("assets/images/%25p%25/buttons/btn_hero.html");
        b = new xa(b);
        b.onlyFirstClick = !0;
        b.addEventListener("complete", r(this, this.showShop));
        b.set_y(1024);
        b.setSoundEffect("click");
        this.addChild(b);
        this.animList.push(b);
        a.push(b);
        ba.animate(b, {
            dir: 2,
            delay: .35
        });
        b = m.formatAsset("assets/images/%25p%25/buttons/btn_moreGames.html");
        b = new xa(b);
        b.addEventListener(D.CLICK, r(this, this.showMoreGames));
        b.set_y(1024);
        b.setSoundEffect("click");
        this.addChild(b);
        this.animList.push(b);
        a.push(b);
        ba.animate(b, {
            dir: 2,
            delay: .35
        });
        this.addStatFields();
        C.alignToCenter(a, 360, 160);
        this.prizeMenu = new jd;
        this.addChild(this.prizeMenu)
    },
    addStatFields: function() {
        var a = Da.get_instance().getPhrase("label3").toUpperCase(),
            b = new qa;   
        b.setSystemFont();
        b.set_color(14804194);
        b.set_size(33);
        b.set_fieldWidth(300);
        b.set_fieldHeight(75);
        b.set_align("left");
        b.set_x(10);
        b.set_y(1100);
        b.set_text(a);
        b.mouseEnabled = !1;
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 1
        });
        a = 0;
        null != K.get_instance().get("plays") && (a = v.parseInt("" + v.string(K.get_instance().get("plays"))));
        b = new qa;
        b.set_color(14804194);
        b.set_size(30);
        b.set_fieldWidth(300);
        b.set_fieldHeight(50);
        b.set_align("left");
        b.set_x(75);
        b.set_y(1176);
        b.set_text("" + a);
        b.mouseEnabled = !1;
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 1
        });
        a = Da.get_instance().getPhrase("label4").toUpperCase();
        b = new qa;
        b.setSystemFont();
        b.set_color(14804194);
        b.set_size(33);
        b.set_fieldWidth(400);
        b.set_fieldHeight(75);
        b.set_align("center");
        b.set_x(160);
        b.set_y(1100);
        b.set_text(a);
        b.mouseEnabled = !1;
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 1
        });
        a = B.get_instance().getTodayBest();
        b = new qa;
        b.set_color(14804194);
        b.set_size(30);
        b.set_fieldWidth(300);
        b.set_fieldHeight(50);
        b.set_align("center");
        b.set_x(210);
        b.set_y(1176);
        b.set_text("" + a);
        b.mouseEnabled = !1;
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 1
        });
        a = Da.get_instance().getPhrase("label5").toUpperCase();
        b = new qa;
        b.setSystemFont();
        b.set_color(14804194);
        b.set_size(33);
        b.set_fieldWidth(300);
        b.set_fieldHeight(75);
        b.set_align("right");
        b.set_x(430);
        b.set_y(1100);
        b.set_text(a);
        b.mouseEnabled = !1;
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 1
        });
        a = B.get_instance().getAverageScore();
        b = new qa;
        b.set_color(14804194);
        b.set_size(30);
        b.set_fieldWidth(300);
        b.set_fieldHeight(50);
        b.set_align("right");
        b.set_x(370);
        b.set_y(1176);
        b.set_text("" + a);
        b.mouseEnabled = !1;
        this.addChild(b);
        this.animList.push(b);
        ba.animate(b, {
            dir: 1
        })
    },
    addScoreField: function() {
        var a = B.get_instance().score,
            b = B.get_instance().getBestScore(),
            a = new yd(a, b);
        a.set_x(360);
        a.set_y(430);
        this.addChild(a);
        ba.animateAlpha(a, {
            delay: .15
        })
    },
    createAdditionalButton: function() {
        "" == B.get_instance().additionalButtonId &&
            (B.get_instance().additionalButtonId = this.getAdditionalButtonId());
        var a = B.get_instance().additionalButtonId,
            b;
        b = null;
        if ("gift" == a) {
            b = m.formatAsset("assets/images/%25p%25/buttons/btn_gift2.html");
            var a = m.formatAsset("assets/images/%25p%25/buttons/btn_gift.html"),
                c = B.get_instance().getGiftTimeout(),
                c = new He("giftCoins", c);
            c.set_name("gift");
            c.swapMode(b, a);
            c.addEventListener("complete", r(this, this.showGift));
            return c
        }
        "hero" == a ? (a = B.get_instance().getCoins(), b = 200 <= a ? m.formatAsset("assets/images/%25p%25/buttons/btn_buy.html") :
            m.formatAsset("assets/images/%25p%25/buttons/btn_buy2.html"), b = new qd(b), b.set_name("hero"), b.addEventListener("complete", r(this, this.showNewHero)), c = new qa, c.set_color(14804194), c.set_size(38), c.set_fieldWidth(140), c.set_fieldHeight(46), c.set_align("center"), c.set_y(18), b.setLabel(c), this.updateBuyHeroButton(b, a, !0)) : "video" == a && (b = m.formatAsset("assets/images/%25p%25/buttons/btn_video.html"), b = new qd(b), b.set_name("video"), b.addEventListener("complete", r(this, this.showVideoAds)), a = new qa, a.set_color(14804194),
            a.set_size(46), a.set_fieldWidth(100), a.set_fieldHeight(46), a.set_align("left"), a.set_x(-12), a.set_y(12), a.set_text("100"), b.setLabel(a));
        return b
    },
    getAdditionalButtonId: function() {
        var a = [];
        0 == B.get_instance().checkAllHeroEnabled() && a.push("hero");
        a.push("gift");
        ia.get_instance().isEnabledIncentiviseButton() && a.push("video");
        var a = C.shuffle(a),
            b = Math.floor((a.length - 1 + 1) * Math.random()),
            b = a[b],
            c = null;
        for (null != K.get_instance().get("menuAddButton") && (c = K.get_instance().get("menuAddButton")); b == c;) b =
            Math.floor((a.length - 1 + 1) * Math.random()), b = a[b];
        K.get_instance().save("menuAddButton", b);
        return b
    },
    startGame: function(a) {
        1 == sa.instance.firstPlay && (sa.instance.firstPlay = !1, Ba.get_instance().save("play"));
        sa.instance.showScene("LevelBuilder");
        K.get_instance().increaseValue("plays")
    },
    showMoreGames: function(a) {
        sa.instance.moreGames("Menu_more_games")
    },
    showGift: function(a) {
        B.get_instance().completeGiftTimeout();
        a = B.get_instance().getGiftTimeout();
        var b = this.getAnimObjByName("gift");
        b.setTimeout(a);
        b.complete();
        a = this.randomGift();
        this.prizeMenu.showPrize("coins", a)
    },
    getAnimObjByName: function(a) {
        for (var b = 0, c = this.animList.length; b < c;) {
            var d = b++;
            if (this.animList[d].get_name() == a) return this.animList[d]
        }
        return null
    },
    showShop: function(a) {
        sa.instance.showScene("Shop")
    },
    showVideoAds: function(a) {
        L.get_instance().pauseMusic(true);
        ia.get_instance().triggerIncentivise(r(this, this.onCompleteVideo));
        Ba.get_instance().save("watchVideoAds")
    },
    onCompleteVideo: function(a) {
        0 != a && (this.prizeMenu.showPrize("coins", 100), this.getAnimObjByName("video").setEnabled(!1))
        L.get_instance().pauseMusic(false);
    },
    showNewHero: function(a) {
        a = this.randomHero();
        this.prizeMenu.showPrize("hero", a)
    },
    randomHero: function() {
        var a = this.initHeroList(),
            a = C.shuffle(a),
            b = Math.floor((a.length - 1 + 1) * Math.random());
        return a[b]
    },
    initHeroList: function() {
        for (var a = [], b, c = 0; 16 > c;) b = c++ + 1, 0 == B.get_instance().checkHero(b) && a.push(b);
        return a
    },
    receiveNotify: function(a, b, c) {
        this.onPrize(c.id, c.value)
    },
    onPrize: function(a, b) {
        "coins" == a ? this.takeCoins(b) : this.takeHero(b)
    },
    takeCoins: function(a) {
        this.changeCoins(a, 2)
    },
    changeCoins: function(a,
        b) {
        null == b && (b = 0);
        B.get_instance().changeCoins(a);
        var c = B.get_instance().getCoins();
        this.coinsPanel.update(c);
        0 != b && ba.animateAlpha(this.coinsPanel, {
            delay: b
        });
        var d = this.getAnimObjByName("hero");
        null != d && this.updateBuyHeroButton(d, c)
    },
    updateBuyHeroButton: function(a, b, c) {
        null == c && (c = !1);
        if (200 <= b) {
            if (0 == a.isEnabled() || 1 == c) c = m.formatAsset("assets/images/%25p%25/buttons/btn_buy.html"), a.createGraphFrom(c), a.setEnabled(!0), a.label.set_text("200"), a.label.set_align("left"), a.label.set_x(-12)
        } else {
            if (1 == a.isEnabled() ||
                1 == c) c = m.formatAsset("assets/images/%25p%25/buttons/btn_buy2.html"), a.createGraphFrom(c), a.setEnabled(!1), a.label.set_align("center"), a.label.set_x(-70);
            a.label.set_text(b + "/200")
        }
    },
    takeHero: function(a) {
        B.get_instance().buyHero(a);
        this.changeCoins(-200, 2);
        (200 > B.get_instance().getCoins() || 1 == B.get_instance().checkAllHeroEnabled()) && this.getAnimObjByName("hero").setEnabled(!1);
        this.showHero(a, 2, 2.35)
    },
    showHero: function(a, b, c) {
        ba.animate(this.heroPanel, {
            dir: 1,
            delay: b,
            ease: na.get_easeOut()
        });
        null != this.hero &&
            this.heroPanel.removeChild(this.hero);
        b = m.formatAsset("assets/images/%25p%25/spritelists/shop.html");
        var d = m.formatAsset("assets/images/%25p%25/spritelists/shop-2.html");
        this.hero = this.converter.getSprite("hero_" + a + "_1", b, d);
        this.hero.set_x(0);
        this.hero.set_y(-260);
        this.heroPanel.addChild(this.hero);
        ba.animate(this.hero, {
            dir: 2,
            delay: c,
            ease: Bc.get_easeOut()
        })
    },
    buyCoins: function(a) {
        L.get_instance().pauseMusic(true);
        ia.get_instance().triggerIncentivise(r(this, this.buyResult));
        Ba.get_instance().save("buyCoins")
    },
    buyResult: function(a) {
        1 == a && this.prizeMenu.showPrize("coins",
            100)
        L.get_instance().pauseMusic(true);
    },
    randomGift: function() {
        var a = -1;
        null != K.get_instance().get("gift") && (a = K.get_instance().get("gift"));
        for (var b, c; !(b = C.randomRangeIntExclude(10, 60, a), c = b % 5, b -= c, b != a && 10 <= b););
        K.get_instance().save("gift", b);
        return b
    },
    showRecord: function() {
        B.get_instance().newRecord = !1;
        this.prizeMenu.showPrize("record")
    },
    free: function() {
        for (var a = 0, b = this.animList; a < b.length;) {
            var c = b[a];
            ++a;
            ba.stopTween(c)
        }
        this.animList = [];
        this.animList = null;
        this.prizeMenu.free();
        this.converter = this.hero = this.heroPanel = this.prizeMenu =
            null;
        this.coinsPanel.free();
        this.coinsPanel = null;
        N.get_instance().clear()
    },
    __class__: Fe
});
var Ie = function() {
    y.call(this)
};
g["scenes.Shop"] = Ie;
Ie.__name__ = ["scenes", "Shop"];
Ie.__interfaces__ = [dc];
Ie.__super__ = Qa;
Ie.prototype = t(Qa.prototype, {
    init: function() {
        this.createTilelayer();
        this.createUi();
        N.get_instance().signToNotify("selectShopItem", this)
    },
    createTilelayer: function() {
        this.tilelayerManager = aa.get_instance();
        var a = m.formatAsset("assets/images/%25p%25/spritelists/shop.html"),
            b = m.formatAsset("assets/images/%25p%25/spritelists/shop-2.html");
        this.tilelayerManager.create("shop", a, b, this)
    },
    createUi: function() {
        this.uiLayer = new dd;
        this.addChild(this.uiLayer);
        this.createMenu();
        this.createHidePanels();
        var a = m.formatAsset("assets/images/%25p%25/buttons/btn_back.html");
        this.btnExit = new xa(a);
        this.btnExit.addEventListener("complete", r(this, this.exit));
        this.btnExit.set_x(70);
        this.btnExit.set_y(600);
        this.btnExit.setSoundEffect("click");
        this.addChild(this.btnExit);
        ba.animate(this.btnExit, {
            dir: 4
        })
    },
    createMenu: function() {
        this.menu = new od;
        this.menu.downBorder =
            0;
        this.addChild(this.menu);
        this.uiLayer.add(this.menu);
        var a = {
                x: 360,
                y: 490
            },
            b = {
                x: 285,
                y: 300
            },
            c = this.createItems(),
            d = c.length / 2 * b.y,
            d = m.get_instance().nativeHeight - a.y + .5 * b.y - 2400 - d;
        0 < d && (d = 0);
        this.menu.upBorder = d;
        this.menu.buildItems(c, a, b, 1)
    },
    createItems: function() {
        for (var a = [], b = aa.get_instance().get("shop"), c, d, e = 0; 16 > e;) d = e++, c = !1, d += 1, 1 == B.get_instance().checkHero(d) && (c = !0), c = new Je(b, d, c), this.uiLayer.add(c), a.push(c);
        return a
    },
    createHidePanels: function() {
        var a = m.formatAsset("assets/images/%25p%25/top_panel.html"),
            a = ta.buildSprite(a);
        a.set_x(360);
        a.set_y(57);
        a.mouseEnabled = !0;
        a.addEventListener(D.MOUSE_UP, r(this, this.onStopEvent));
        this.addChild(a);
        a = m.formatAsset("assets/images/%25p%25/bottom_panel.html");
        a = ta.buildSprite(a);
        a.set_x(360);
        a.set_y(1224);
        a.mouseEnabled = !0;
        a.addEventListener(D.MOUSE_UP, r(this, this.onStopEvent));
        this.addChild(a)
    },
    onStopEvent: function(a) {
        a.stopImmediatePropagation();
        this.menu.onMouseUp(a)
    },
    exit: function(a) {
        sa.instance.showScene("Menu")
    },
    update: function(a, b) {
        this.menu.update(a);
        this.tilelayerManager.update()
    },
    receiveNotify: function(a, b, c) {
        this.selectItem(c.id)
    },
    selectItem: function(a) {
        B.get_instance().setHero(a);
        Ba.get_instance().save("selectHero", "" + a);
        this.exit()
    },
    free: function() {
        N.get_instance().clear();
        ba.stopTween(this.btnExit);
        this.btnExit = null;
        this.tilelayerManager.free();
        this.tilelayerManager = null;
        this.uiLayer.free();
        this.uiLayer = null;
        this.menu.free();
        this.menu = null;
        P.clearPool()
    },
    __class__: Ie
});
var Hf = function() {
    y.call(this)
};
g["scenes.Test"] = Hf;
Hf.__name__ = ["scenes", "Test"];
Hf.__super__ = Qa;
Hf.prototype =
    t(Qa.prototype, {
        init: function() {
            var a = new y;
            this.addChild(a);
            var b = new da;
            b.createGradientBox(m.get_instance().scaledWidth, m.get_instance().scaledHeight, Math.PI / 2, 0, 0);
            a.get_graphics().clear();
            a.get_graphics().beginGradientFill(Xb.LINEAR, [4671039, 13404180], [1, 1], [70, 255], b);
            a.get_graphics().drawRect(0, 0, m.get_instance().scaledWidth, m.get_instance().scaledHeight);
            a.get_graphics().endFill()
        },
        update: function(a, b) {},
        free: function() {
            Qa.prototype.free.call(this)
        },
        __class__: Hf
    });
var Be = function() {};
g["systems.BackgroundSystem"] =
    Be;
Be.__name__ = ["systems", "BackgroundSystem"];
Be.__super__ = Z;
Be.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.tiles = [];
        this.newTilesOffset = this.offset = this.counter = 0;
        this.prevTileId = -1;
        this.logicId = 0;
        n.get_instance().eventManager.addListener(this, "game")
    },
    activate: function() {
        this.createTiles(8, 50, 670, 50, 1200)
    },
    createTiles: function(a, b, c, d, e) {
        for (var f = aa.get_instance().get("main"), g = aa.get_instance().getGroup("bgGroup", "main"), h = 0; h < a;) h++, this.createTile(f, g, b, c, d, e)
    },
    createTile: function(a, b, c, d, e, f) {
        var g = C.randomRangeIntExclude(1, 4, this.prevTileId, -1, 30);
        this.prevTileId = g;
        a = P.create(a, "bg_tile" + g);
        b.addChild(a);
        b = this.getPosForTile(a, c, d, e, f);
        a.x = b.x;
        a.y = b.y;
        this.tiles.push(a)
    },
    getPosForTile: function(a, b, c, d, e) {
        var f = a.size.width * a._scaleX;
        a = a.size.height * a._scaleY;
        var g = {
                x: 0,
                y: 0
            },
            h = !1,
            k = new za;
        k.width = f;
        k.height = a;
        for (var m; 0 == h;) g.x = C.randTo(b, c), g.y = C.randTo(d, e), k.x = g.x - f / 2, k.y = g.y - a / 2, m = this.getMinDistTo(g.x, g.y), -1 != m && 80 > m || (h = this.checkPosInTiles(k));
        return g
    },
    getMinDistTo: function(a, b) {
        for (var c = -1, d = this.tiles.length, e, f = 0; f < d;)
            if (e = f++, e = this.tiles[e], e = C.calcDistOfDots(a, b, e.x, e.y), -1 == c || e < c) c = e;
        return c
    },
    checkPosInTiles: function(a) {
        for (var b = this.tiles.length, c, d = new za, e = 0; e < b;)
            if (c = e++, c = this.tiles[c], d.x = c.x - c.size.width * c._scaleX / 2, d.y = c.y - c.size.height * c._scaleY / 2, d.width = c.size.width * c._scaleX, d.height = c.size.height * c._scaleY, 1 == d.intersects(a)) return !1;
        return !0
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        if ("completePath" ==
            a.id && null == a.revive) this.onCompletePath(a.offset)
    },
    onCompletePath: function(a) {
        this.updateThemeCounter();
        this.updateCameraOfset(a);
        this.updateCreateNewTiles(a)
    },
    updateThemeCounter: function() {
        this.counter++;
        10 == this.counter && (this.counter = 0, this.changeTheme())
    },
    changeTheme: function() {
        B.get_instance().nextThemeId();
        sa.instance.showBg();
        var a = B.get_instance().getThemeId();
        n.get_instance().eventManager.sendEvent("game", {
            id: "changeTheme",
            theme: a
        });
        this.updateBalanceLogic()
    },
    updateBalanceLogic: function() {
        this.logicId +=
            1;
        switch (this.logicId) {
            case 1:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: 2
                });
                break;
            case 2:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: 1
                });
                break;
            case 3:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changePathSize",
                    size: 2
                });
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: -1
                });
                break;
            case 4:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: 2
                });
                break;
            case 5:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: 1
                });
                break;
            case 6:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changePathSize",
                    size: 3
                });
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: -1
                });
                break;
            case 7:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: 2
                });
                break;
            case 8:
                n.get_instance().eventManager.sendEvent("game", {
                    id: "changeWallStrength",
                    strength: 1
                })
        }
    },
    updateCameraOfset: function(a) {
        this.offset += a
    },
    update: function(a) {
        0 != this.offset && this.updateCamera()
    },
    updateCamera: function() {
        var a = 4.2;
        0 < this.offset + a ? (a = -this.offset, this.offset = 0) : this.offset += a;
        this.updateTiles(.55 * a);
        this.clearTiles()
    },
    updateTiles: function(a) {
        for (var b = this.tiles.length, c = 0; c < b;) {
            var d = c++;
            this.tiles[d].y += a
        }
    },
    clearTiles: function() {
        for (var a = this.tiles.length, b, c, d = 0, e = 0; e < a;) {
            e++;
            if (d >= this.tiles.length) break;
            c = this.tiles[d];
            b = c.y - c.size.height * c._scaleY / 2;
            1300 < b ? (c.destroyToCache(), this.tiles.splice(d, 1)) : d++
        }
    },
    updateCreateNewTiles: function(a) {
        this.newTilesOffset += .55 * Math.abs(a);
        100 < this.newTilesOffset && (this.newTilesOffset = 0, this.createNewTiles())
    },
    createNewTiles: function() {
        var a = 1 + Math.floor(2 * Math.random()),
            a = v["int"](C.clamp(a, 0, 30 - this.tiles.length));
        this.createTiles(a, 50, 670, -450, 100)
    },
    __class__: Be
});
var ze = function() {};
g["systems.CameraSystem"] = ze;
ze.__name__ = ["systems", "CameraSystem"];
ze.__super__ = Z;
ze.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.offset = 0;
        var a = aa.get_instance();
        this.pathGroup = a.getGroup("pathGroup", "main");
        this.topWallsGroup =
            a.getGroup("topWallsGroup", "main");
        this.coinsGroup = a.getGroup("coinsGroup", "main");
        this.heroGroup = a.getGroup("heroGroup", "main");
        this.heroTail = a.getGroup("heroTail", "main");
        this.bottomWallsGroup = a.getGroup("bottomWallsGroup", "main");
        this.effectsGroup = a.getGroup("effectsGroup", "main");
        this.foreground = Pa.instance.layersManager.getLayer("foreground");
        n.get_instance().eventManager.addListener(this, "game")
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        "completePath" == a.id && this.updateCamera(a.offset)
    },
    updateCamera: function(a) {
        this.offset += a
    },
    update: function(a) {
        0 != this.offset && this.moveCamera()
    },
    moveCamera: function() {
        var a = 4.2;
        0 < this.offset + a ? (a = -this.offset, this.offset = 0) : this.offset += a;
        this.pathGroup.y += a;
        this.topWallsGroup.y += a;
        this.coinsGroup.y += a;
        this.heroGroup.y += a;
        this.heroTail.y += a;
        this.bottomWallsGroup.y += a;
        this.effectsGroup.y += a;
        var b = this.foreground;
        b.set_y(b.get_y() + a)
    },
    free: function() {
        Z.prototype.free.call(this);
        this.effectsGroup = this.bottomWallsGroup = this.heroGroup = this.coinsGroup =
            this.topWallsGroup = this.pathGroup = null
    },
    __class__: ze
});
var Ae = function() {};
g["systems.CoinsSystem"] = Ae;
Ae.__name__ = ["systems", "CoinsSystem"];
Ae.__super__ = Z;
Ae.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.prevCount = -1;
        this.addRequiredComponentClass(Jb);
        this.generator = new Le(.7);
        n.get_instance().eventManager.addListener(this, "game")
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        if ("createCoin" == a.id) this.checkCreateCoin(a.pathEntity);
        else if ("showCoin" ==
            a.id) this.showCoins(a.pathEntity, a.animated);
        else if ("collide" == a.id) this.onCollide(a.target, a.targetId);
        else "hideWalls" == a.id && this.clearOldCoin(a.pathEntity, a.pathId)
    },
    checkCreateCoin: function(a) {
        1 == this.generator.check() && this.createCoins(a)
    },
    createCoins: function(a) {
        var b = C.randomRangeIntExclude(1, 3, this.prevCount, -1, 30);
        this.prevCount = b;
        a = n.get_instance().getComponentIn(a, ca);
        for (var c = 50 * b, d = a.length - 18; c > d;) --b, c = 50 * b;
        c = C.randTo(60, d - c);
        for (d = 0; d < b;) {
            var e = d++;
            this.createCoin(a, c, 50, e)
        }
    },
    createCoin: function(a,
        b, c, d) {
        b += c * d;
        d = fa.get_instance().calcPosOnPath(a.startX, a.startY, b, a.direction);
        c = n.get_instance().createEntity();
        var e = n.get_instance().getComponent(Jb, !0);
        e.graph = this.createGraph(d.x, d.y, a.direction);
        n.get_instance().addComponent(c, e);
        d = n.get_instance().getComponent(Kb, !0);
        d.id = "coin";
        d.active = !0;
        d.path = a.id;
        d.strength = 1;
        d.length = b;
        n.get_instance().addComponent(c, d);
        n.get_instance().saveEntity(c);
        a.items.push(c)
    },
    createGraph: function(a, b, c) {
        var d = aa.get_instance().get("main"),
            e = aa.get_instance().getGroup("coinsGroup",
                "main"),
            d = P.create(d, "coin");
        d.referenceX = 25;
        4 == c && (d.referenceX *= -1);
        d.referenceY = -10;
        d.x = a;
        d.y = b;
        d.alpha = 0;
        e.addChild(d);
        return d
    },
    showCoins: function(a, b) {
        var c = this.getCoins(a),
            d = c.length;
        if (0 != d)
            for (var e = 0; e < d;) {
                var f = e++;
                this.showGraph(c[f], b)
            }
    },
    getCoins: function(a) {
        a = n.get_instance().getComponentIn(a, ca);
        for (var b = a.items.length, c, d = [], e = 0; e < b;) c = e++, c = a.items[c], null != n.get_instance().getComponentIn(c, Jb) && d.push(c);
        return d
    },
    showGraph: function(a, b) {
        var c = n.get_instance().getComponentIn(a,
            Jb);
        if (1 == b) {
            var d = c.graph.y;
            c.graph.y -= 70;
            A.tween(c.graph, .2, {
                alpha: 1,
                y: d
            }).ease(na.get_easeIn())
        } else c.graph.alpha = 1
    },
    onCollide: function(a, b) {
        "coin" == b && this.takeCoin(a)
    },
    takeCoin: function(a) {
        var b = n.get_instance().getComponentIn(a, Kb);
        b.active = !1;
        b = n.get_instance().getSystem("PathSystem").getPathEntityById(b.path);
        b = n.get_instance().getComponentIn(b, ca);
        u.remove(b.items, a);
        L.get_instance().playSound("coin");
        this.animateCoin(a)
    },
    animateCoin: function(a) {
        N.get_instance().postNotify("incomeCoin");
        var b = n.get_instance().getComponentIn(a, Jb);
        null != b && null != b.graph && (A.stop(b.graph, null, !1, !1), this.showBlowEffect(b.graph.x + b.graph.referenceX, b.graph.y + b.graph.referenceY));
        this.completeAnimate(a)
    },
    showBlowEffect: function(a, b) {
        for (var c = aa.get_instance().get("main"), d = aa.get_instance().getGroup("effectsGroup", "main"), e = 0, f; 360 > e;) f = C.randTo(22, 35), e += f, this.createBlowEntity(a, b, e, c, d)
    },
    createBlowEntity: function(a, b, c, d, e) {
        var f = n.get_instance().createEntity();
        d = P.create(d, "coins_particle");
        d.x =
            a;
        d.y = b;
        d.set_scaleX(0);
        d.set_scaleY(0);
        e.addChild(d);
        b = this.calcParticleSpeed(c, 2.5);
        a = new ec(1, 0);
        c = C.toRad(c);
        Math.cos(c);
        Math.sin(c);
        e = a.x;
        var g = a.y;
        a.x = e * Math.cos(c) - g * Math.sin(c);
        a.y = e * Math.sin(c) + g * Math.cos(c);
        a;
        c = Math.sqrt(a.x * a.x + a.y * a.y);
        0 < c && (a.x /= c, a.y /= c, a);
        a;
        a.x *= b;
        a.y *= b;
        a;
        a;
        c = n.get_instance().getComponent(yc, !0);
        c.graph = d;
        c.velocityX = a.x;
        c.velocityY = a.y;
        c.maxLifeTime = C.randTo(.5, .8, 2);
        c.lifeTime = c.maxLifeTime;
        c.scale = C.randTo(3, 4, 2);
        n.get_instance().addComponent(f, c);
        n.get_instance().saveEntity(f)
    },
    calcParticleSpeed: function(a, b) {
        var c = C.randTo(.8, 1, 2);
        return b * c
    },
    completeAnimate: function(a) {
        var b = n.get_instance().getComponentIn(a, Jb);
        null != b && null != b.graph && (b.graph.destroyToCache(), b.graph = null);
        n.get_instance().destroyEntity(a)
    },
    clearOldCoin: function(a, b) {
        for (var c = this.getCoins(a), d = c.length, e, f = 0; f < d;) e = f++, e = c[e], e = n.get_instance().getComponentIn(e, Jb), e.graph.destroyToCache(), e.graph = null
    },
    free: function() {
        this.destroyEntitys(!0, !1);
        Z.prototype.free.call(this)
    },
    __class__: Ae
});
var we = function() {};
g["systems.CollisionSystem"] = we;
we.__name__ = ["systems", "CollisionSystem"];
we.__super__ = Z;
we.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.pathId = 0;
        this.addRequiredComponentClass(Kb)
    },
    process: function(a, b) {
        var c = n.get_instance().getEntityByTag("hero"),
            d = n.get_instance().getComponentIn(c, Sa);
        if (0 != d.active) {
            var e = n.get_instance().getComponentIn(a, Kb);
            if (0 != e.active && e.path == d.path && ("wall" != e.id || n.get_instance().getComponentIn(a, mb).position == d.direction) && (c = n.get_instance().getComponentIn(c,
                    bb), d = C.calcDistOfDots(d.startX, d.startY, c.x, c.y), 25 >= Math.abs(e.length - d))) this.onCollide(a, e)
        }
    },
    onCollide: function(a, b) {
        -1 != b.strength && --b.strength;
        var c = {
            id: "collide",
            target: a,
            targetId: b.id
        };
        n.get_instance().eventManager.sendEvent("game", c)
    },
    __class__: we
});
var Ce = function() {};
g["systems.GravitySystem"] = Ce;
Ce.__name__ = ["systems", "GravitySystem"];
Ce.__super__ = Z;
Ce.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.addRequiredComponentClass(fc);
        this.addRequiredComponentClass(bb);
        this.addRequiredComponentClass(gc)
    },
    process: function(a, b) {
        var c = n.get_instance().getComponentIn(a, fc),
            d = n.get_instance().getComponentIn(a, gc),
            e = n.get_instance().getComponentIn(a, bb);
        d.x *= .99;
        d.y *= .99;
        d.y += .6;
        e.x += d.x;
        e.y += d.y;
        c.graph.x = e.x;
        c.graph.y = e.y; - 1 != c.lifeTime && (c.lifeTime -= b, 0 >= c.lifeTime && (c.graph.destroyToCache(), c.graph = null, n.get_instance().destroyEntity(a)))
    },
    __class__: Ce
});
var pd = function() {};
g["systems.HeroSystem"] = pd;
pd.__name__ = ["systems", "HeroSystem"];
pd.__interfaces__ = [dc];
pd.__super__ =
    Z;
pd.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.working = !1;
        this.heroId = B.get_instance().getHero();
        this.speed = 8.3;
        this.addRequiredComponentClass(Sa);
        n.get_instance().eventManager.addListener(this, "game");
        N.get_instance().signToNotify("revive", this);
        this.tutorial = !1;
        1 == $b.checkNeed() && (this.tutorial = !0, this.tutorialManager = new $b)
    },
    process: function(a, b) {
        0 != this.working && 1 != this.animationWorking && this.move(a)
    },
    move: function(a) {
        var b = n.get_instance().getComponentIn(a, Sa),
            c;
        c = 3 == b.pathDirection ? fa.get_instance().vectorLeft : fa.get_instance().vectorRight;
        var d;
        d = Math.sqrt(c.x * c.x + c.y * c.y);
        0 < d && (c.x /= d, c.y /= d, c);
        c;
        d = c.x * this.speed;
        c = c.y * this.speed;
        2 == b.direction && (d *= -1, c *= -1);
        var e = n.get_instance().getComponentIn(a, bb);
        e.x += d;
        e.y += c;
        b.graph.x = e.x;
        b.graph.y = e.y;
        this.checkFall(b, e) && this.fall(a, b);
        1 == this.tutorial && 2 == this.tutorialManager.step && this.tutorialManager.update({
            hero: b,
            position: e,
            system: this
        })
    },
    checkFall: function(a, b) {
        var c = 40;
        0 == a.active && (c = 60);
        var d;
        if (1 ==
            a.fall) {
            if (d = C.calcDistOfDots(a.fallX, a.fallY, b.x, b.y), d > c) return !0
        } else d = C.calcDistOfDots(a.startX, a.startY, b.x, b.y), 2 == a.direction ? 5 >= d && this.setFall(a, b) : d >= a.pathLength - 5 && this.setFall(a, b);
        return !1
    },
    setFall: function(a, b) {
        a.fall = !0;
        a.fallX = b.x;
        a.fallY = b.y;
        L.get_instance().playSound("fall")
    },
    fall: function(a, b) {
        this.working = !1;
        N.get_instance().postNotify("levelEvent", this, {
            id: "lose"
        });
        this.updateGraphIndex(a, b);
        this.addRigidBody(a, b);
        n.get_instance().eventManager.sendEvent("game", {
            id: "controllOff"
        })
    },
    updateGraphIndex: function(a, b) {
        var c = aa.get_instance().getGroup("heroGroup", "main");
        c.removeChild(b.graph);
        c = aa.get_instance().getGroup("pathGroup", "main");
        c.addChild(b.graph);
        var d = n.get_instance().getSystem("PathSystem"),
            e = d.getPathEntityById(b.path + 1);
        if (-1 != e) {
            var f = n.get_instance().getComponentIn(a, bb),
                f = C.calcDistOfDots(b.startX, b.startY, f.x, f.y),
                d = d.getPathEntityById(b.path),
                d = n.get_instance().getComponentIn(d, ca);
            f < d.connectionLength ? (e = c.getChildIndex(d.tiles[d.tiles.length - 1]), c.setChildIndex(b.graph,
                e)) : (e = n.get_instance().getComponentIn(e, ca), e = c.getChildIndex(e.tiles[0]), c.setChildIndex(b.graph, e - 1))
        } else c.setChildIndex(b.graph, 0)
    },
    addRigidBody: function(a, b) {
        var c = new ec(1, 0);
        3 == b.pathDirection && (c.x = -1);
        2 == b.direction && (c.x *= -1);
        var d;
        d = Math.sqrt(c.x * c.x + c.y * c.y);
        0 < d && (c.x /= d, c.y /= d, c);
        c;
        c.x *= 5;
        c.y *= 5;
        c;
        c;
        d = n.get_instance().getComponent(fc, !0);
        d.lifeTime = -1;
        d.graph = b.graph;
        n.get_instance().addComponent(a, d);
        d = n.get_instance().getComponent(gc, !0);
        d.x = c.x;
        d.y = c.y;
        n.get_instance().addComponent(a,
            d);
        n.get_instance().saveEntity(a)
    },
    delRigidBody: function(a) {
        var b = n.get_instance().getComponentIn(a, fc);
        n.get_instance().delComponent(a, b);
        b = n.get_instance().getComponentIn(a, gc);
        n.get_instance().delComponent(a, b);
        n.get_instance().changedEntity(a)
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        if ("createHero" == a.id) this.createHero(a.pathEntity);
        else if ("showHero" == a.id) this.showHero();
        else if ("collide" == a.id) this.onCollide(a.targetId);
        else if ("tap" == a.id) this.onTap();
        else if ("changeTheme" ==
            a.id) this.onChangeTheme()
    },
    createHero: function(a) {
        var b = n.get_instance().createEntity();
        n.get_instance().addTag(b, "hero");
        a = n.get_instance().getComponentIn(a, ca);
        var c = fa.get_instance().calcPosOnPath(a.startX, a.startY, 30, a.direction),
            d = n.get_instance().getComponent(bb, !0);
        d.x = c.x;
        d.y = c.y;
        n.get_instance().addComponent(b, d);
        c = n.get_instance().getComponent(Sa, !0);
        c.path = a.id;
        c.pathLength = a.length;
        c.pathOffset = 0;
        c.startX = a.startX;
        c.startY = a.startY;
        c.active = !1;
        c.direction = 1;
        c.pathDirection = a.direction;
        c.graph = this.createGraph(d.x, d.y);
        n.get_instance().addComponent(b, c);
        n.get_instance().saveEntity(b);
        1 == this.tutorial && 0 == this.tutorialManager.step && this.tutorialManager.update()
    },
    createGraph: function(a, b) {
        var c = aa.get_instance().get("main"),
            d = aa.get_instance().getGroup("heroGroup", "main"),
            c = P.create(c, "hero_" + this.heroId + "_2");
        c.referenceY = -11;
        c.x = a;
        c.y = b;
        c.alpha = 0;
        d.addChild(c);
        return c
    },
    showHero: function() {
        var a = n.get_instance().getEntityByTag("hero"),
            a = n.get_instance().getComponentIn(a, Sa),
            b = a.graph.y;
        a.graph.y -= 80;
        A.tween(a.graph, .3, {
            alpha: 1,
            y: b
        }).ease(na.get_easeIn()).onComplete(r(this, this.completeShow))
    },
    completeShow: function() {
        this.working = !0;
        var a = n.get_instance().getEntityByTag("hero");
        n.get_instance().getComponentIn(a, Sa).active = !0
    },
    onTap: function() {
        1 == this.tutorial && 3 == this.tutorialManager.step && this.tutorialManager.update({
            system: this
        });
        1 == this.working && (1 == this.animationWorking && this.completeAnimNormal(), this.changeDirection())
    },
    changeDirection: function() {
        var a = n.get_instance().getEntityByTag("hero"),
            b = n.get_instance().getComponentIn(a, Sa);
        if (0 != b.active) {
            this.nextPathDirection(b);
            var c = n.get_instance().getSystem("PathSystem"),
                d = b.path + 1;
            1 == this.checkNextPath(a, b, d, c) ? (this.setNewPath(b, d, c), this.notifyAboutNewPath(b, c)) : this.breakHero(a, b);
            this.updateGraph(b)
        }
    },
    nextPathDirection: function(a) {
        a.direction = 1;
        a.pathDirection = 3 == a.pathDirection ? 4 : 3
    },
    updateGraph: function(a) {
        3 == a.pathDirection ? 1 == a.direction ? a.graph.set_tile("hero_" + this.heroId + "_2") : a.graph.set_tile("hero_" + this.heroId + "_1") : 1 == a.direction ?
            a.graph.set_tile("hero_" + this.heroId + "_4") : a.graph.set_tile("hero_" + this.heroId + "_3")
    },
    checkNextPath: function(a, b, c, d) {
        c = d.getPathEntityById(c);
        return null == n.get_instance().getComponentIn(c, ca) ? !1 : 1 == this.checkSwitchPath(a, b, d) ? !0 : !1
    },
    checkSwitchPath: function(a, b, c) {
        var d = c.getPathEntityById(b.path),
            d = n.get_instance().getComponentIn(d, ca);
        a = n.get_instance().getComponentIn(a, bb);
        a = C.calcDistOfDots(a.x, a.y, b.startX, b.startY) - d.connectionLength;
        c = c.getPathEntityById(b.path + 1);
        c = n.get_instance().getComponentIn(c,
            ca);
        return Math.abs(a) <= c.radius + 4 ? (b.pathOffset = a, !0) : !1
    },
    setNewPath: function(a, b, c) {
        var d = 3;
        3 == a.pathDirection && (d = 4);
        var e = c.getPathEntityById(a.path);
        n.get_instance().getComponentIn(e, ca);
        c = c.getPathEntityById(b);
        c = n.get_instance().getComponentIn(c, ca);
        d = fa.get_instance().calcPosOnPath(c.startX, c.startY, a.pathOffset, d);
        a.startX = d.x;
        a.startY = d.y;
        a.path = b;
        a.pathLength = c.length
    },
    notifyAboutNewPath: function(a, b) {
        N.get_instance().postNotify("completePath");
        var c = a.path - 1,
            d = b.getPathEntityById(c),
            e =
            n.get_instance().getComponentIn(d, ca),
            f = b.getPathEntityById(a.path),
            e = {
                id: "completePath",
                offset: n.get_instance().getComponentIn(f, ca).connectionY - e.connectionY
            };
        n.get_instance().eventManager.sendEvent("game", e);
        e = {
            id: "hideWalls",
            pathEntity: d,
            pathId: c
        };
        n.get_instance().eventManager.sendEvent("game", e)
    },
    breakHero: function(a, b) {
        b.active = !1;
        var c = n.get_instance().getComponentIn(a, bb);
        this.setFall(b, c)
    },
    onCollide: function(a) {
        "wall" == a && this.animateCollide()
    },
    animateCollide: function() {
        this.animationWorking = !0;
        var a = n.get_instance().getEntityByTag("hero"),
            a = n.get_instance().getComponentIn(a, Sa);
        a.active = !1;
        A.tween(a.graph, .04, {
            scaleX: .5,
            scaleY: .5
        }).ease(na.get_easeOut()).onComplete(r(this, this.completeAnimSmall))
    },
    completeAnimSmall: function() {
        this.swapDir();
        var a = n.get_instance().getEntityByTag("hero"),
            a = n.get_instance().getComponentIn(a, Sa);
        A.tween(a.graph, .05, {
            scaleX: 1,
            scaleY: 1
        }).ease(na.get_easeIn()).onComplete(r(this, this.completeAnimNormal))
    },
    completeAnimNormal: function() {
        this.animationWorking = !1;
        var a = n.get_instance().getEntityByTag("hero"),
            a = n.get_instance().getComponentIn(a, Sa);
        a.active = !0;
        a.graph.set_scaleX(1);
        a.graph.set_scaleY(1);
        A.stop(a.graph, null, !1, !1)
    },
    swapDir: function() {
        var a = n.get_instance().getEntityByTag("hero"),
            a = n.get_instance().getComponentIn(a, Sa);
        a.direction = 1 == a.direction ? 2 : 1;
        this.updateGraph(a);
        1 == this.tutorial && 1 == this.tutorialManager.step && this.tutorialManager.update({
            dir: a.direction
        })
    },
    receiveNotify: function(a, b, c) {
        this.revive()
    },
    revive: function() {
        L.get_instance().playSound("revive");
        var a = n.get_instance().getEntityByTag("hero"),
            b = n.get_instance().getComponentIn(a, Sa);
        b.fall = !1;
        b.pathOffset = 0;
        this.delRigidBody(a);
        var c = n.get_instance().getSystem("PathSystem"),
            d = c.getPathEntityById(b.path),
            e = n.get_instance().getComponentIn(d, ca),
            f = b.path + 1,
            g = c.getPathEntityById(f); - 1 == g && (g = c.createNextPath(e.connectionX, e.connectionY, f, b.pathDirection));
        c = n.get_instance().getComponentIn(g, ca);
        b.startX = c.startX;
        b.startY = c.startY;
        b.path = f;
        b.pathLength = c.length;
        b.direction = 1;
        b.pathDirection = c.direction;
        b.graph.parent.removeChild(b.graph);
        aa.get_instance().getGroup("heroGroup", "main").addChild(b.graph);
        g = fa.get_instance().calcPosOnPath(c.startX, c.startY, 30, c.direction);
        a = n.get_instance().getComponentIn(a, bb);
        a.x = g.x;
        a.y = g.y;
        b.graph.x = a.x;
        b.graph.y = a.y;
        b = {
            id: "completePath",
            revive: !0,
            offset: c.connectionY - e.connectionY
        };
        n.get_instance().eventManager.sendEvent("game", b);
        b = {
            id: "hideWalls",
            pathEntity: d,
            pathId: f - 1
        };
        n.get_instance().eventManager.sendEvent("game", b);
        this.showHero();
        n.get_instance().eventManager.sendEvent("game", {
            id: "controllOn"
        })
    },
    onChangeTheme: function() {
        11 != this.speed && (this.speed *= 1.015, 11 < this.speed && (this.speed = 11))
    },
    free: function() {
        Z.prototype.free.call(this);
        null != this.tutorialManager && (this.tutorialManager = null)
    },
    __class__: pd
});
var ye = function() {};
g["systems.InputSystem"] = ye;
ye.__name__ = ["systems", "InputSystem"];
ye.__super__ = Z;
ye.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.addControls();
        this.working = !0;
        n.get_instance().eventManager.addListener(this, "game")
    },
    receiveEvent: function(a,
        b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        "controllOff" == a.id ? this.working = !1 : "controllOn" == a.id && (this.working = !0)
    },
    addControls: function() {
        S.current.stage.addEventListener(D.MOUSE_DOWN, r(this, this.onMouseUp))
    },
    delControls: function() {
        S.current.stage.removeEventListener(D.MOUSE_DOWN, r(this, this.onMouseUp))
    },
    onMouseUp: function(a) {
        0 != this.working && 1 != Pa.instance.paused && (n.get_instance().eventManager.sendEvent("game", {
            id: "tap"
        }), L.get_instance().playSound("click"))
    },
    free: function() {
        Z.prototype.free.call(this);
        this.delControls()
    },
    __class__: ye
});
var De = function() {};
g["systems.ParticleSystem"] = De;
De.__name__ = ["systems", "ParticleSystem"];
De.__super__ = Z;
De.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.addRequiredComponentClass(yc)
    },
    process: function(a, b) {
        var c = n.get_instance().getComponentIn(a, yc);
        0 >= c.lifeTime ? this.destroyParticle(a, c) : this.updateParticle(a, c, b)
    },
    destroyParticle: function(a, b) {
        b.graph.destroyToCache();
        b.graph = null;
        n.get_instance().destroyEntity(a)
    },
    updateParticle: function(a,
        b, c) {
        b.lifeTime -= c;
        0 > b.lifeTime && (b.lifeTime = 0);
        b.graph.x += b.velocityX;
        b.graph.y += b.velocityY;
        a = C.toPercent(b.lifeTime, b.maxLifeTime);
        b.graph.alpha = a;
        a *= b.scale;
        b.graph.set_scaleX(a);
        b.graph.set_scaleY(a)
    },
    free: function() {
        Z.prototype.free.call(this)
    },
    __class__: De
});
var ve = function() {};
g["systems.PathSystem"] = ve;
ve.__name__ = ["systems", "PathSystem"];
ve.__super__ = Z;
ve.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.working = !1;
        this.first = !0;
        this.themeId = B.get_instance().getThemeId();
        this.prevPathLength = -1;
        this.sizeId = 1;
        this.switchRadius();
        this.addRequiredComponentClass(ca);
        n.get_instance().eventManager.addListener(this, "game")
    },
    activate: function() {
        this.createStartPath()
    },
    createStartPath: function() {
        var a = this.createPath(485, 850, 0, 3),
            b = {
                id: "createHero",
                pathEntity: a
            };
        n.get_instance().eventManager.sendEvent("game", b);
        b = {
            id: "createWalls",
            pathEntity: a
        };
        n.get_instance().eventManager.sendEvent("game", b);
        this.showPath(a, !1);
        b = {
            id: "showHero"
        };
        n.get_instance().eventManager.sendEvent("game",
            b)
    },
    createPath: function(a, b, c, d) {
        var e = n.get_instance().createEntity(),
            f = n.get_instance().getComponent(ca, !0);
        f.theme = this.themeId;
        f.active = !1;
        f.id = c;
        f.direction = d;
        f.size = this.sizeId;
        f.radius = this.pathRadius;
        d = {
            x: a,
            y: b
        };
        0 != c && (c = this.getPathEntityById(c - 1), c = n.get_instance().getComponentIn(c, ca).radius, d = fa.get_instance().calcPosOnPath(a, b, c, f.direction));
        f.startX = d.x;
        f.startY = d.y;
        f.length = this.calcPathLength(f.startX, f.startY, f.direction, 2 * f.radius - 4);
        a = fa.get_instance().calcPosOnPath(f.startX, f.startY,
            f.length, f.direction);
        f.endX = a.x;
        f.endY = a.y;
        f.connectionLength = this.calcConnectionLength(f);
        a = fa.get_instance().calcPosOnPath(f.startX, f.startY, f.connectionLength, f.direction);
        f.connectionX = a.x;
        f.connectionY = a.y;
        f.items = [];
        f.tiles = [];
        this.createGraph(f);
        n.get_instance().addComponent(e, f);
        n.get_instance().saveEntity(e);
        return e
    },
    calcPathLength: function(a, b, c, d) {
        b = 0;
        3 == c ? (c = fa.get_instance().angleLeftRadians, b = 40) : (c = fa.get_instance().angleRightRadians, b = 680);
        a = (b - a) / Math.cos(c);
        a = C.randomRangeFloatExclude(180,
            a, this.prevPathLength, 30, 20);
        a -= a % d;
        180 > a && (a += d);
        return this.prevPathLength = a
    },
    calcConnectionLength: function(a) {
        return C.randTo(90, a.length - 90)
    },
    createGraph: function(a) {
        for (var b = 2 * a.radius - 4, c = v["int"](Math.floor(a.length / b)), d = aa.get_instance().get("main"), e = aa.get_instance().getGroup("pathGroup", "main"), f = 0; f < c;) {
            var g = f++;
            this.createPathTile(a, b, g, d, e)
        }
    },
    createPathTile: function(a, b, c, d, e) {
        b = b / 2 + b * c;
        0 == c && (b -= 2);
        c = fa.get_instance().calcPosOnPath(a.startX, a.startY, b, a.direction);
        c.y += 92;
        d = P.create(d,
            "wall_" + this.themeId + "_" + this.sizeId);
        d.x = c.x;
        d.y = c.y;
        d.alpha = 0;
        e.addChildAt(d, 0);
        a.tiles.push(d)
    },
    showPath: function(a, b) {
        null == b && (b = !0);
        for (var c = n.get_instance().getComponentIn(a, ca), d = c.tiles.length, e = aa.get_instance().get("main"), f = 0; f < d;) {
            var g = f++;
            this.showTile(a, c, g, d, e, b)
        }
    },
    showTile: function(a, b, c, d, e, f) {
        b = b.tiles[c];
        if (1 == f) {
            e = .03 * c;
            var g = b.y;
            b.y += 60;
            b.set_scaleX(.5);
            b.set_scaleY(.5);
            if (c == d - 1) A.tween(b, .2, {
                alpha: 1,
                scaleX: 1,
                scaleY: 1,
                y: g
            }).ease(na.get_easeOut()).delay(e).onComplete(r(this,
                this.completeShow), [a, f]);
            else A.tween(b, .2, {
                alpha: 1,
                scaleX: 1,
                scaleY: 1,
                y: g
            }).ease(na.get_easeOut()).delay(e)
        } else b.alpha = 1, c == d - 1 && this.completeShow(a, f)
    },
    completeShow: function(a, b) {
        var c = {
            id: "showWall",
            pos: 1,
            pathEntity: a,
            animated: b
        };
        n.get_instance().eventManager.sendEvent("game", c);
        c = {
            id: "showCoin",
            pathEntity: a,
            animated: b
        };
        n.get_instance().eventManager.sendEvent("game", c)
    },
    getPathEntityById: function(a) {
        for (var b, c, d = 0, e = this.countEntitys; d < e;)
            if (b = d++, b = this.entityList[b], 1 != this.isEntityDisabled(b) &&
                (c = n.get_instance().getComponentIn(b, ca), c.id == a)) return b;
        return -1
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        if ("collide" == a.id) this.onCollide(a.target);
        else "changeTheme" == a.id ? this.changeTheme(a.theme) : "hidePath" == a.id ? this.hidePath(a.pathEntity) : "changePathSize" == a.id && this.changePathSize(a.size)
    },
    onCollide: function(a) {
        if (null != n.get_instance().getComponentIn(a, mb)) {
            a = n.get_instance().getEntityByTag("hero");
            a = n.get_instance().getComponentIn(a, Sa);
            a = this.getPathEntityById(a.path);
            var b = n.get_instance().getComponentIn(a, ca);
            0 == b.active && this.activatePath(a, b)
        }
    },
    activatePath: function(a, b) {
        b.active = !0;
        var c = {
            id: "showWall",
            pos: 2,
            pathEntity: a,
            animated: !0
        };
        n.get_instance().eventManager.sendEvent("game", c);
        var c = b.id + 1,
            d = 3;
        3 == b.direction && (d = 4);
        this.createNextPath(b.connectionX, b.connectionY, c, d)
    },
    createNextPath: function(a, b, c, d) {
        a = this.createPath(a, b, c, d);
        b = {
            id: "createWalls",
            pathEntity: a
        };
        n.get_instance().eventManager.sendEvent("game", b);
        this.showPath(a, !0);
        return a
    },
    changePathSize: function(a) {
        this.sizeId =
            a;
        this.switchRadius()
    },
    switchRadius: function() {
        switch (this.sizeId) {
            case 1:
                this.pathRadius = 34;
                break;
            case 2:
                this.pathRadius = 24;
                break;
            case 3:
                this.pathRadius = 14
        }
    },
    changeTheme: function(a) {
        this.themeId = a
    },
    hidePath: function(a) {
        for (var b = n.get_instance().getComponentIn(a, ca), c = b.tiles.length, d = 0; d < c;) {
            var e = d++;
            this.hideTile(a, b.tiles[e], e, c)
        }
    },
    hideTile: function(a, b, c, d) {
        var e = .03 * c,
            f = b.y + 60;
        if (c == d - 1) A.tween(b, .2, {
            alpha: 0,
            scaleX: .5,
            scaleY: .5,
            y: f
        }).ease(na.get_easeOut()).delay(e).onComplete(r(this, this.completeHide), [a]);
        else A.tween(b, .2, {
            alpha: 0,
            scaleX: .5,
            scaleY: .5,
            y: f
        }).ease(na.get_easeOut()).delay(e)
    },
    completeHide: function(a) {
        for (var b = n.get_instance().getComponentIn(a, ca), c = b.tiles.length, d = 0; d < c;) {
            var e = d++;
            b.tiles[e].destroyToCache()
        }
        b.tiles = [];
        b.items = [];
        n.get_instance().destroyEntity(a)
    },
    __class__: ve
});
var Ee = function() {};
g["systems.TailSystem"] = Ee;
Ee.__name__ = ["systems", "TailSystem"];
Ee.__super__ = Z;
Ee.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.working = !1;
        this.counter =
            0;
        n.get_instance().eventManager.addListener(this, "game")
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        "showHero" == a.id && this.startEmiter()
    },
    startEmiter: function() {
        var a = n.get_instance().getEntityByTag("hero");
        this.targetPos = n.get_instance().getComponentIn(a, bb);
        this.working = !0
    },
    update: function(a) {
        0 != this.working && (this.counter++, 3 == this.counter && (this.counter = 0, this.createParticle()))
    },
    createParticle: function() {
        var a = aa.get_instance().get("main"),
            b = aa.get_instance().getGroup("heroTail",
                "main"),
            c = n.get_instance().createEntity(),
            a = P.create(a, "tail_particle");
        a.x = this.targetPos.x;
        a.y = this.targetPos.y;
        b.addChild(a);
        b = n.get_instance().getComponent(yc, !0);
        b.graph = a;
        b.velocityX = 0;
        b.velocityY = 0;
        b.maxLifeTime = .4;
        b.lifeTime = b.maxLifeTime;
        b.scale = 2;
        n.get_instance().addComponent(c, b);
        n.get_instance().saveEntity(c)
    },
    process: function(a, b) {},
    free: function() {
        Z.prototype.free.call(this)
    },
    __class__: Ee
});
var xe = function() {};
g["systems.WallSystem"] = xe;
xe.__name__ = ["systems", "WallSystem"];
xe.__super__ =
    Z;
xe.prototype = t(Z.prototype, {
    init: function() {
        Z.prototype.init.call(this);
        this.counter = 0;
        this.strength = -1;
        this.addRequiredComponentClass(mb);
        n.get_instance().eventManager.addListener(this, "game");
        this.bestScore = B.get_instance().getBestScore()
    },
    receiveEvent: function(a, b) {
        this.onGameEvent(b)
    },
    onGameEvent: function(a) {
        if ("createWalls" == a.id) this.createWalls(a.pathEntity);
        else if ("showWall" == a.id) this.showWall(a.pathEntity, a.pos, a.animated);
        else if ("collide" == a.id) this.onCollide(a.target, a.targetId);
        else "hideWalls" ==
            a.id ? this.hideWalls(a.pathEntity, a.pathId) : "changeWallStrength" == a.id && this.changeWallStrength(a.strength)
    },
    createWalls: function(a) {
        var b = n.get_instance().getComponentIn(a, ca),
            c = this.calcTopWallLength(b),
            d = this.calcBottomWallLength(b);
        this.createWall(b, 1, c);
        this.createWall(b, 2, d);
        a = {
            id: "createCoin",
            pathEntity: a
        };
        n.get_instance().eventManager.sendEvent("game", a)
    },
    calcTopWallLength: function(a) {
        return a.length - 6
    },
    calcBottomWallLength: function(a) {
        a = a.connectionLength - 90;
        18 > a && (a = 18);
        return C.randTo(18,
            a)
    },
    createWall: function(a, b, c) {
        var d = n.get_instance().createEntity(),
            e = n.get_instance().getComponent(mb, !0);
        e.position = b;
        e.graph = this.createGraph(e, a, c);
        n.get_instance().addComponent(d, e);
        b = n.get_instance().getComponent(Kb, !0);
        b.id = "wall";
        b.active = !1;
        b.path = a.id;
        b.strength = this.strength;
        b.length = c;
        n.get_instance().addComponent(d, b);
        n.get_instance().saveEntity(d);
        a.items.push(d)
    },
    createGraph: function(a, b, c) {
        var d = {
            x: b.startX,
            y: b.startY
        };
        0 != c && (d = fa.get_instance().calcPosOnPath(b.startX, b.startY, c,
            b.direction));
        a.x = d.x;
        a.y = d.y;
        c = aa.get_instance().get("main");
        d = this.getTileName(b);
        c = P.create(c, d);
        b = this.getWallOffset(a, b, this.strength);
        c.x = a.x + b.x;
        c.y = a.y + b.y;
        c.alpha = 0;
        c.set_scaleX(1);
        c.set_scaleY(1);
        (1 == a.position ? aa.get_instance().getGroup("topWallsGroup", "main") : aa.get_instance().getGroup("bottomWallsGroup", "main")).addChild(c);
        return c
    },
    getTileName: function(a) {
        var b = "pere_" + a.theme + "a";
        4 == a.direction && (b = "pere_" + a.theme + "b");
        b += "_" + a.size;
        1 == this.strength && (b += "_s");
        return b
    },
    showWall: function(a,
        b, c) {
        a = n.get_instance().getComponentIn(a, ca);
        var d = this.getWallEntity(a, b);
        n.get_instance().getComponentIn(d, Kb).active = !0;
        d = n.get_instance().getComponentIn(d, mb);
        this.showGraph(d.graph, c);
        1 == b && 0 != this.bestScore && a.id == this.bestScore && this.addBestScore(d.graph.x, d.graph.y)
    },
    getWallEntity: function(a, b) {
        for (var c = a.items.length, d, e, f = 0; f < c;)
            if (d = f++, d = a.items[d], null != n.get_instance().getComponentIn(d, mb) && (e = n.get_instance().getComponentIn(d, mb), e.position == b)) return d;
        return -1
    },
    showGraph: function(a,
        b) {
        if (1 == b) {
            var c = a.y;
            a.y += 30;
            A.tween(a, .3, {
                alpha: 1,
                y: c
            }).ease(na.get_easeOut())
        } else a.alpha = 1
    },
    onCollide: function(a, b) {
        if ("wall" == b) {
            L.get_instance().playSound("collide");
            var c = n.get_instance().getComponentIn(a, mb),
                d = n.get_instance().getComponentIn(a, Kb),
                e = n.get_instance().getSystem("PathSystem").getPathEntityById(d.path),
                e = n.get_instance().getComponentIn(e, ca);
            0 == d.strength ? (c.graph.visible = !1, d.active = !1, u.remove(e.items, a), this.animateBlow(c, e.theme)) : 1 == d.strength && (this.changeWallGraph(c, e,
                d.strength), this.animateBlow(c, e.theme))
        }
    },
    getWallOffset: function(a, b, c) {
        a = {
            x: 0,
            y: 0
        };
        1 == c ? 3 == b.direction ? 1 == b.size ? (a.x = 7, a.y = -14) : 2 == b.size ? (a.x = 9, a.y = -10) : 3 == b.size && (a.x = 9, a.y = -12) : 1 == b.size ? (a.x = -10, a.y = -14) : 2 == b.size ? (a.x = -9, a.y = -11) : 3 == b.size && (a.x = -9, a.y = -12) : (a.x = 3 == b.direction ? 9 : -9, a.y = -24);
        return a
    },
    changeWallGraph: function(a, b, c) {
        b = this.getWallOffset(a, b, c);
        c = a.graph._tile;
        a.graph.set_tile(c + "_s");
        a.graph.x = a.x + b.x;
        a.graph.y = a.y + b.y
    },
    hideWalls: function(a, b) {
        var c = n.get_instance().getComponentIn(a,
            ca); - 1 != this.getWallEntity(c, 2) ? this.hideWall(a, 2) : this.hideWall(a, 1)
    },
    hideWall: function(a, b) {
        var c = n.get_instance().getComponentIn(a, ca),
            d = this.getWallEntity(c, b);
        1 == b && 0 != this.bestScore && c.id == this.bestScore && this.hideBestScore(); - 1 != d ? (c = n.get_instance().getComponentIn(d, mb), A.tween(c.graph, .15, {
            alpha: 0
        }).ease(na.get_easeOut()).onComplete(r(this, this.completeHide), [d, a, b])) : this.completeHide(-1, a, b)
    },
    completeHide: function(a, b, c) {
        if (-1 != a) {
            var d = n.get_instance().getComponentIn(a, mb);
            d.graph.destroyToCache();
            d.graph = null;
            n.get_instance().destroyEntity(a)
        }
        2 == c ? this.hideWall(b, 1) : this.completeHideWalls(b)
    },
    completeHideWalls: function(a) {
        a = {
            id: "hidePath",
            pathEntity: a
        };
        n.get_instance().eventManager.sendEvent("game", a)
    },
    addBestScore: function(a, b) {
        var c = Pa.instance.layersManager.getLayer("foreground"),
            d = m.formatAsset("assets/images/%25p%25/record_2.html");
        this.bestScoreTile = ta.buildSprite(d);
        this.bestScoreTile.set_x(a);
        this.bestScoreTile.set_y(b - 130);
        c.addChild(this.bestScoreTile);
        c = new qa;
        c.setSystemFont();
        c.set_size(25);
        c.set_fieldWidth(140);
        c.set_fieldHeight(40);
        c.set_align("center");
        c.set_x(-70);
        c.set_y(-24);
        d = Da.get_instance().getPhrase("label0").toUpperCase();
        c.set_text(d);
        this.bestScoreTile.addChild(c)
    },
    hideBestScore: function() {
        A.tween(this.bestScoreTile, .3, {
            alpha: 0
        }).ease(na.get_easeIn()).onComplete(r(this, this.completeHideBestScore))
    },
    completeHideBestScore: function() {
        this.bestScoreTile.parent.removeChild(this.bestScoreTile);
        this.bestScoreTile = null
    },
    animateBlow: function(a, b) {
        L.get_instance().playSound("crushing_wall");
        for (var c = "wall_" + b + "_particle", d = 2 + Math.floor(3 * Math.random()), e = aa.get_instance().get("main"), f = aa.get_instance().getGroup("effectsGroup", "main"), g = 0; g < d;) g++, this.createParticle(c, a, e, f)
    },
    createParticle: function(a, b, c, d) {
        var e = n.get_instance().createEntity(),
            f = b.graph.x;
        b = b.graph.y;
        a = P.create(c, a);
        a.x = f;
        a.y = b;
        a.set_scaleX(1);
        a.set_scaleY(1);
        d.addChild(a);
        A.tween(a, 1.7, {
            alpha: 0,
            scaleX: .2,
            scaleY: .2
        }).ease(qb.get_easeNone());
        d = n.get_instance().getComponent(fc, !0);
        d.lifeTime = 2;
        d.graph = a;
        n.get_instance().addComponent(e,
            d);
        d = C.randTo(10, 15, 2);
        a = C.toRad(-135);
        c = C.toRad(-45);
        c = C.randTo(a, c, 2);
        a = new ec(1, 0);
        Math.cos(c);
        Math.sin(c);
        var g = a.x,
            h = a.y;
        a.x = g * Math.cos(c) - h * Math.sin(c);
        a.y = g * Math.sin(c) + h * Math.cos(c);
        a;
        c = Math.sqrt(a.x * a.x + a.y * a.y);
        0 < c && (a.x /= c, a.y /= c, a);
        a;
        a.x *= d;
        a.y *= d;
        a;
        a;
        d = n.get_instance().getComponent(bb, !0);
        d.x = f;
        d.y = b;
        n.get_instance().addComponent(e, d);
        f = n.get_instance().getComponent(gc, !0);
        f.x = a.x;
        f.y = a.y;
        n.get_instance().addComponent(e, f);
        n.get_instance().saveEntity(e)
    },
    changeWallStrength: function(a) {
        this.strength =
            a
    },
    free: function() {
        Z.prototype.free.call(this);
        this.bestScoreTile = null
    },
    __class__: xe
});
var ad = function() {};
g["tjson.TJSON"] = ad;
ad.__name__ = ["tjson", "TJSON"];
ad.parse = function(a, b, c) {
    null == b && (b = "JSON Data");
    return (new If(a, b, c)).doParse()
};
var If = function(a, b, c) {
    null == b && (b = "JSON Data");
    this.json = a;
    this.fileName = b;
    this.currentLine = 1;
    this.lastSymbolQuoted = !1;
    this.pos = 0;
    this.floatRegex = new ra("^-?[0-9]*\\.[0-9]+$", "");
    this.intRegex = new ra("^-?[0-9]+$", "");
    this.strProcessor = null == c ? r(this, this.defaultStringProcessor) :
        c;
    this.cache = []
};
g["tjson.TJSONParser"] = If;
If.__name__ = ["tjson", "TJSONParser"];
If.prototype = {
    doParse: function() {
        try {
            var a = this.getNextSymbol();
            switch (a) {
                case "{":
                    return this.doObject();
                case "[":
                    return this.doArray();
                default:
                    return this.convertSymbolToProperType(a)
            }
        } catch (b) {
            if (x.__instanceof(b, String)) throw this.fileName + " on line " + this.currentLine + ": " + b;
            throw b;
        }
    },
    doObject: function() {
        var a = {},
            b = "",
            c, d = !1;
        for (this.cache.push(a); this.pos < this.json.length;)
            if (c = this.getNextSymbol(), "," != c || this.lastSymbolQuoted) {
                if ("}" ==
                    c && !this.lastSymbolQuoted) return d && null != a.TJ_unserialize && a.TJ_unserialize(), a;
                b = this.getNextSymbol();
                if (":" != b) throw "Expected ':' but got '" + b + "' instead.";
                b = this.getNextSymbol();
                if ("_hxcls" == c) {
                    a = O.resolveClass(b);
                    if (null == a) throw "Invalid class name - " + b;
                    a = O.createEmptyInstance(a);
                    this.cache.pop();
                    this.cache.push(a);
                    d = !0
                } else b = "{" != b || this.lastSymbolQuoted ? "[" != b || this.lastSymbolQuoted ? this.convertSymbolToProperType(b) : this.doArray() : this.doObject(), a[c] = b
            }
        throw "Unexpected end of file. Expected '}'";
    },
    doArray: function() {
        for (var a = [], b; this.pos < this.json.length;)
            if (b = this.getNextSymbol(), "," != b || this.lastSymbolQuoted) {
                if ("]" != b || this.lastSymbolQuoted) b = "{" != b || this.lastSymbolQuoted ? "[" != b || this.lastSymbolQuoted ? this.convertSymbolToProperType(b) : this.doArray() : this.doObject();
                else return a;
                a.push(b)
            }
        throw "Unexpected end of file. Expected ']'";
    },
    convertSymbolToProperType: function(a) {
        return this.lastSymbolQuoted ? M.startsWith(a, ad.OBJECT_REFERENCE_PREFIX) ? (a = v.parseInt(u.substr(a, ad.OBJECT_REFERENCE_PREFIX.length,
            null)), this.cache[a]) : a : this.looksLikeFloat(a) ? v.parseFloat(a) : this.looksLikeInt(a) ? v.parseInt(a) : "true" == a.toLowerCase() ? !0 : "false" == a.toLowerCase() ? !1 : "null" == a.toLowerCase() ? null : a
    },
    looksLikeFloat: function(a) {
        var b;
        if (!(b = this.floatRegex.match(a))) {
            if (a = this.intRegex.match(a)) a = this.intRegex.matched(0), a = 45 == u.cca(a, 0) ? "-2147483648" < a : "2147483647" < a;
            b = a
        }
        return b
    },
    looksLikeInt: function(a) {
        return this.intRegex.match(a)
    },
    getNextSymbol: function() {
        this.lastSymbolQuoted = !1;
        for (var a = "", b = !1, c = "", d = "",
                e = !1, f = !1, g = !1, h = !1; this.pos < this.json.length;)
            if (a = this.json.charAt(this.pos++), "\n" != a || f || this.currentLine++, g) {
                if ("\n" == a || "\r" == a) g = !1, this.pos++
            } else if (h) "*" == a && "/" == this.json.charAt(this.pos) && (h = !1, this.pos++);
        else if (b) {
            if (e) {
                e = !1;
                if ("'" == a || '"' == a) {
                    d += a;
                    continue
                }
                if ("t" == a) {
                    d += "\t";
                    continue
                }
                if ("n" == a) {
                    d += "\n";
                    continue
                }
                if ("\\" == a) {
                    d += "\\";
                    continue
                }
                if ("r" == a) {
                    d += "\r";
                    continue
                }
                if ("/" == a) {
                    d += "http://games.softgames.de/";
                    continue
                }
                if ("u" == a) {
                    for (var k = a = 0; 4 > k;) {
                        k++;
                        if (this.pos >= this.json.length) throw "Unfinished UTF8 character";
                        var m;
                        m = this.pos++;
                        m = u.cca(this.json, m);
                        a <<= 4;
                        if (48 <= m && 57 >= m) a += m - 48;
                        else if (65 <= m && 70 >= m) a += 10 + m - 65;
                        else if (97 <= m && 102 >= m) a += 10 + m - 95;
                        else throw "Not a hex digit";
                    }
                    k = new Ve;
                    k.__b += String.fromCharCode(a);
                    d += k.__b;
                    continue
                }
                throw "Invalid escape sequence '\\" + a + "'";
            }
            if ("\\" == a) e = !0;
            else {
                if (a == c) return d;
                d += a
            }
        } else {
            if ("/" == a)
                if (k = this.json.charAt(this.pos), "/" == k) {
                    g = !0;
                    this.pos++;
                    continue
                } else if ("*" == k) {
                h = !0;
                this.pos++;
                continue
            }
            if (f) {
                if (" " == a || "\n" == a || "\r" == a || "\t" == a || "," == a || ":" == a || "}" == a || "]" ==
                    a) return this.pos--, d;
                d += a
            } else if (" " != a && "\t" != a && "\n" != a && "\r" != a) {
                if ("{" == a || "}" == a || "[" == a || "]" == a || "," == a || ":" == a) return a;
                "'" == a || '"' == a ? (b = !0, c = a, this.lastSymbolQuoted = !0) : (f = !0, d = a)
            }
        }
        if (b) throw "Unexpected end of data. Expected ( " + c + " )";
        return d
    },
    defaultStringProcessor: function(a) {
        return a
    },
    __class__: If
};
var Od = function() {};
g["tools.AtlasConverter"] = Od;
Od.__name__ = ["tools", "AtlasConverter"];
Od.prototype = {
    getSprite: function(a, b, c) {
        b = Y.getText(b);
        c = Y.getBitmapData(c);
        var d = new ja(0, 0),
            e = new Yc(I.parse(b).firstElement()),
            f = new za;
        b = new za;
        a = this.getNodeByName(a, e);
        if (null == a) return null;
        e = !1;
        a.has.resolve("rotated") && "true" == a.att.resolve("rotated") && (e = !0);
        f.x = v.parseFloat(a.att.resolve("x"));
        f.y = v.parseFloat(a.att.resolve("y"));
        f.width = v.parseFloat(a.att.resolve("width"));
        f.height = v.parseFloat(a.att.resolve("height"));
        1 == a.has.resolve("frameX") ? (0 == e ? (b.x = v.parseInt(a.att.resolve("frameX")), b.y = v.parseInt(a.att.resolve("frameY"))) : (b.x = v.parseInt(a.att.resolve("frameY")), b.y = v.parseInt(a.att.resolve("frameX"))),
            b.width = v.parseInt(a.att.resolve("frameWidth")), b.height = v.parseInt(a.att.resolve("frameHeight"))) : (b.width = f.width, b.height = f.height);
        a = new Aa(b.width, b.height, !0, 0);
        d.x = -b.get_left();
        d.y = -b.get_top();
        a.copyPixels(c, f, d);
        1 == e && (c = new Aa(b.width, b.height, !0, 0), d = new da, d.translate(-b.width / 2, -b.height / 2), d.rotate(-Math.PI / 2), d.translate(b.width / 2, b.height / 2), c.draw(a, d), a = c);
        return ta.buildSpriteByData(a)
    },
    getNodeByName: function(a, b) {
        for (var c = b.nodes.resolve("SubTexture").iterator(); c.hasNext();) {
            var d =
                c.next();
            if (d.att.resolve("name") == a) return d
        }
        return null
    },
    __class__: Od
};
var Da = function() {
    Da._instance = this
};
g["tools.Localization"] = Da;
Da.__name__ = ["tools", "Localization"];
Da.__interfaces__ = [oc];
Da.__properties__ = {
    get_instance: "get_instance"
};
Da._instance = null;
Da.get_instance = function() {
    null == Da._instance && (Da._instance = new Da);
    return Da._instance
};
Da.prototype = {
    init: function() {
        var a = C.parseConfig("assets/texts/localization.json"),
            b = z.fields(a);
        this.langCode = "en";
        this.langCode = ia.get_instance().getLangCode(b);
        this.localization = z.field(a, this.langCode)
    },
    getPhrase: function(a) {
        return z.field(this.localization, a)
    },
    __class__: Da
};
var ia = function() {
    ia._instance = this;
    this.init()
};
g["tools.SoftgamesAPI"] = ia;
ia.__name__ = ["tools", "SoftgamesAPI"];
ia.__interfaces__ = [oc];
ia.__properties__ = {
    get_instance: "get_instance"
};
ia._instance = null;
ia.instance = null;
ia.get_instance = function() {
    null == ia._instance && (ia._instance = new ia);
    return ia._instance
};
ia.prototype = {
    init: function() {
        this.apiLink = SG_Hooks
    },
    setOrientationHandler: function(a) {
        this.apiLink.setOrientationHandler(a)
    },
    setResizeHandler: function(a) {
        this.apiLink.setResizeHandler(a)
    },
    start: function() {
        this.apiLink.start()
    },
    levelStarted: function(a) {
        this.apiLink.levelStarted(a)
    },
    levelFinished: function(a, b) {
        this.apiLink.levelFinished(a, b)
    },
    levelUp: function(a, b) {
        this.apiLink.levelUp(a, b)
    },
    gameOver: function(a, b) {
        this.apiLink.gameOver(a, b)
    },
    setPauseHandler: function(a) {
        this.apiLink.setPauseHandler(a)
    },
    setUnpauseHandler: function(a) {
        this.apiLink.setUnpauseHandler(a)
    },
    setStorageItem: function(a, b) {
        this.apiLink.setStorageItem(a,
            b)
    },
    getStorageItem: function(a) {
        return this.apiLink.getStorageItem(a)
    },
    isEnabledIncentiviseButton: function() {
        return this.apiLink.isEnabledIncentiviseButton()
    },
    triggerIncentivise: function(a) {
        this.apiLink.triggerIncentivise(a)
    },
    getLangCode: function(a) {
        return SG.lang; //this.apiLink.getLanguage(a)
    },
    __class__: ia
};
var Ba = function() {
    if (null != Ba._instance) throw "Error: Allready inited. Use instance instead;";
};
g["tools.Statistics"] = Ba;
Ba.__name__ = ["tools", "Statistics"];
Ba.__properties__ = {
    get_instance: "get_instance"
};
Ba._instance = null;
Ba.instance = null;
Ba.get_instance = function() {
    null == Ba._instance && (Ba._instance = new Ba);
    return Ba._instance
};
Ba.prototype = {
    init: function(a, b) {
        null == b && (b = "none");
        zb.get_instance().init(a, b)
    },
    save: function(a, b) {
        null == b && (b = "");
        zb.get_instance().sendEvent(a, b)
    },
    __class__: Ba
};
var ue = function(a, b, c) {
    va.call(this);
    this.init(a, b, c)
};
g["ui.AchievementItem"] = ue;
ue.__name__ = ["ui", "AchievementItem"];
ue.__super__ = va;
ue.prototype = t(va.prototype, {
    init: function(a, b, c) {
        var d = P.create(a, "achievement_bg");
        a.addChild(d);
        this.addTile(d);
        b = 1 == lb.get_instance().isEarned("award" + b) ? "achievement_active" : "achievement_normal";
        b = P.create(a, b);
        b.x = -240;
        a.addChild(b);
        this.addTile(b);
        a = new qa;
        a.set_color(3223856);
        a.set_size(40);
        a.set_fieldWidth(600);
        a.set_align("left");
        a.set_x(-190);
        a.set_y(-60);
        a.set_text(c.title);
        this.addChild(a);
        a = M.replace(c.dsc, "%c%", "" + v.string(c.count));
        b = new qa;
        b.set_color(7105643);
        b.set_size(35);
        b.set_fieldWidth(600);
        b.set_align("left");
        b.set_x(-190);
        b.set_y(-20);
        b.set_text(a);
        this.addChild(b);
        a = new qa;
        a.set_color(6327100);
        a.set_size(35);
        a.set_fieldWidth(600);
        a.set_align("left");
        a.set_x(-190);
        a.set_y(25);
        a.set_text(v.string(c.prize) + " coins");
        this.addChild(a)
    },
    __class__: ue
});
var qd = function(a, b) {
    xa.call(this, a, b)
};
g["ui.AnimatedButton"] = qd;
qd.__name__ = ["ui", "AnimatedButton"];
qd.__super__ = xa;
qd.prototype = t(xa.prototype, {
    init: function() {
        xa.prototype.init.call(this);
        this.animationID = "scale";
        this.setEnabled(!0)
    },
    enabledState: function() {
        xa.prototype.enabledState.call(this);
        "scale" == this.animationID ?
            this.scaleAnim() : this.rotateAnim()
    },
    rotateAnim: function(a) {
        null == a && (a = 1);
        a *= -1;
        A.tween(this, .5, {
            rotation: 15 * a,
            scaleX: 1.1,
            scaleY: 1.1
        }).ease(na.get_easeOut()).repeat(1).reflect().onComplete(r(this, this.rotateAnim), [a])
    },
    scaleAnim: function() {
        A.tween(this, .5, {
            scaleX: 1.1,
            scaleY: 1.1
        }).ease(na.get_easeOut()).repeat().reflect()
    },
    disabledState: function() {
        xa.prototype.disabledState.call(this);
        this.stopAnim()
    },
    stopAnim: function() {
        A.stop(this, null, !1, !1);
        this.set_rotation(0);
        this.set_scaleX(1);
        this.set_scaleY(1)
    },
    __class__: qd
});
var nc = function() {
    va.call(this);
    this.init()
};
g["ui.InertiaTileContainer"] = nc;
nc.__name__ = ["ui", "InertiaTileContainer"];
nc.__super__ = va;
nc.prototype = t(va.prototype, {
    init: function() {
        this.active = !0;
        this.dragNow = this.mouseDown = !1;
        this.decelerationRate = .1;
        this.vertical = this.horizontal = !1;
        this.prevPosition = {
            x: 0,
            y: 0
        };
        this.deltaPosition = {
            x: 0,
            y: 0
        };
        this.velocity = {
            x: 0,
            y: 0
        };
        this.minDistForDrag = 10
    },
    onMouseDown: function(a) {
        0 != this.active && 0 != this.get_visible() && (this.mouseDown = !0, this.dragNow = !1,
            this.prevPosition.x = m.getMouseX(), this.prevPosition.y = m.getMouseY(), this.velocity.x = 0, this.velocity.y = 0)
    },
    onMouseUp: function(a) {
        this.mouseDown = !1;
        if (0 != this.velocity.x || 0 != this.velocity.y) this.onStartInertia()
    },
    onStartInertia: function() {},
    update: function(a) {
        1 == this.mouseDown ? this.updateDrag(a) : 0 != this.velocity.x && 0 != this.velocity.y && this.moveByInertia(a)
    },
    updateDrag: function(a) {
        this.calcDeltaPosition();
        0 != this.dragNow && (this.calcVelocity(a), this.calcPosition())
    },
    calcDeltaPosition: function() {
        var a =
            m.getMouseX(),
            b = m.getMouseY();
        if (0 == this.dragNow)
            if (C.calcDistOfDots(a, b, this.prevPosition.x, this.prevPosition.y) >= this.minDistForDrag) this.dragNow = !0, this.prevPosition.x = a, this.prevPosition.y = b;
            else return;
        this.deltaPosition.x = a - this.prevPosition.x;
        this.deltaPosition.y = b - this.prevPosition.y;
        this.prevPosition.x = a;
        this.prevPosition.y = b
    },
    calcVelocity: function(a) {
        this.velocity.x = C.lerp(this.velocity.x, this.deltaPosition.x / a, 10 * a);
        this.velocity.y = C.lerp(this.velocity.y, this.deltaPosition.y / a, 10 * a)
    },
    calcPosition: function() {
        if (1 ==
            this.horizontal && 0 != this.deltaPosition.x) {
            var a = this.get_x() + this.deltaPosition.x,
                a = C.clamp(a, this.leftBorder, this.rightBorder);
            this.set_x(a)
        }
        1 == this.vertical && 0 != this.deltaPosition.y && (a = this.get_y() + this.deltaPosition.y, a = C.clamp(a, this.upBorder, this.downBorder), this.set_y(a))
    },
    moveByInertia: function(a) {
        if (1 == this.horizontal && 0 != this.velocity.x) {
            this.velocity.x *= Math.pow(this.decelerationRate, a);
            1 > Math.abs(this.velocity.x) && (this.velocity.x = 0);
            var b = this.velocity.x * a,
                b = this.get_x() + b,
                b = C.clamp(b,
                    this.leftBorder, this.rightBorder);
            this.set_x(b)
        }
        1 == this.vertical && 0 != this.velocity.y && (this.velocity.y *= Math.pow(this.decelerationRate, a), 1 > Math.abs(this.velocity.y) && (this.velocity.y = 0), a *= this.velocity.y, a = this.get_y() + a, a = C.clamp(a, this.upBorder, this.downBorder), this.set_y(a))
    },
    free: function() {
        va.prototype.free.call(this);
        this.velocity = this.deltaPosition = this.prevPosition = null
    },
    __class__: nc
});
var qa = function(a) {
    xc.call(this);
    this.set_font("assets/fonts/screengem.ttf")
};
g["ui.Label"] = qa;
qa.__name__ = ["ui", "Label"];
qa.__super__ = xc;
qa.prototype = t(xc.prototype, {
    init: function() {
        xc.prototype.init.call(this);
        this.set_size(18);
        this.set_color(3422005)
    },
    __class__: qa
});
var Je = function(a, b, c) {
    Pb.call(this);
    this.id = b;
    this.purchased = c;
    this.createUi(a);
    0 == this.purchased && (this.manualDisabled = !0)
};
g["ui.ShopItem"] = Je;
Je.__name__ = ["ui", "ShopItem"];
Je.__super__ = Pb;
Je.prototype = t(Pb.prototype, {
    createUi: function(a) {
        this.setHitRect(0, -245, 305, 190);
        this.setSoundEffect("click");
        var b = P.create(a, "hero_podlog");
        a.addChild(b);
        this.setGraph(b);
        this.icon = P.create(a, 1 == this.purchased ? "hero_" + this.id + "_1" : "hero_lock");
        this.icon.x = 0;
        this.icon.y = -255;
        0 == this.purchased && (this.icon.x = 15, this.icon.y = -290);
        a.addChild(this.icon);
        this.addTile(this.icon);
        this.addEventListener("b_complete", r(this, this.onClick))
    },
    onClick: function(a) {
        1 == this.purchased && this.select()
    },
    select: function() {
        var a = this.icon.y;
        A.tween(this.icon, .2, {
            y: a - 120
        }).ease(qf.get_easeInOut());
        A.tween(this.icon, .3, {
            y: a
        }, !1).ease(Bc.get_easeOut()).delay(.2).onComplete(r(this,
            this.completeSelect))
    },
    completeSelect: function() {
        N.get_instance().postNotify("selectShopItem", this, {
            id: this.id
        })
    },
    free: function() {
        Pb.prototype.free.call(this);
        this.icon = null
    },
    __class__: Je
});
var Ge = function(a) {
    null == a && (a = 1);
    var b;
    1 == a ? (a = m.formatAsset("assets/images/%25p%25/buttons/btn_sound_on.html"), b = m.formatAsset("assets/images/%25p%25/buttons/btn_sound_off.html")) : (a = m.formatAsset("assets/images/%25p%25/buttons/btn_sound_on2.html"), b = m.formatAsset("assets/images/%25p%25/buttons/btn_sound_off2.html"));
    wc.call(this,
        a, b);
    1 == L.get_instance().isMuted() && this.setState(Ma.OFF)
};
g["ui.SoundButton"] = Ge;
Ge.__name__ = ["ui", "SoundButton"];
Ge.__super__ = wc;
Ge.prototype = t(wc.prototype, {
    completeAnim: function() {
        wc.prototype.completeAnim.call(this);
        this.state == Ma.ON ? (L.get_instance().mute(!1), K.get_instance().save("soundMuted", !1, !0)) : (L.get_instance().mute(!0), K.get_instance().save("soundMuted", !0, !0))
    },
    __class__: Ge
});
var He = function(a, b) {
    xa.call(this);
    this.id = a;
    this.timeout = b
};
g["ui.TimerButton"] = He;
He.__name__ = ["ui", "TimerButton"];
He.__super__ = xa;
He.prototype = t(xa.prototype, {
    init: function() {
        xa.prototype.init.call(this);
        this.timerField = new qa;
        this.timerField.set_color(14804194);
        this.timerField.mouseEnabled = !1;
        this.timerField.set_size(41);
        this.timerField.set_fieldWidth(150);
        this.timerField.set_align("center");
        this.timerField.set_x(-77);
        this.timerField.set_y(6);
        this.timerField.set_visible(!1);
        this.setLabel(this.timerField);
        this.timer = new te(1E3);
        this.timer.addEventListener(xb.TIMER, r(this, this.updateTimer))
    },
    swapMode: function(a,
        b) {
        this.mode = 2;
        this.normalAsset = a;
        this.activeAsset = b;
        this.initState()
    },
    initState: function() {
        var a = this.getSpendSeconds();
        a >= this.timeout ? this.showReady() : this.showTimer(a)
    },
    showReady: function() {
        2 == this.mode && this.createGraphFrom(this.activeAsset);
        this.setEnabled(!0);
        this.timerField.set_visible(!1);
        this.animate()
    },
    animate: function() {
        this.scaleAnim()
    },
    scaleAnim: function() {
        A.tween(this, .5, {
            scaleX: 1.1,
            scaleY: 1.1
        }).ease(na.get_easeOut()).repeat().reflect()
    },
    showTimer: function(a) {
        null == a && (a = -1);
        2 == this.mode &&
            this.createGraphFrom(this.normalAsset);
        this.setEnabled(!1); - 1 == a && (a = this.getSpendSeconds());
        this.time = this.timeout - a;
        this.timer.start();
        this.timerField.set_text(C.formatTime(this.time, !1));
        this.timerField.set_visible(!0)
    },
    getSpendSeconds: function() {
        var a = (new Date).getTime();
        null == K.get_instance().get(this.id) && (a = this.saveCurrentTime());
        var b = v.parseFloat(K.get_instance().get(this.id)),
            a = a - b;
        return 0 >= a ? 0 : Math.floor(a / 1E3) | 0
    },
    saveCurrentTime: function() {
        var a = (new Date).getTime();
        K.get_instance().save(this.id,
            a);
        return a
    },
    updateTimer: function(a) {
        this.time--;
        this.timerField.set_text(C.formatTime(this.time, !1));
        0 == this.time && this.completeTimer()
    },
    completeTimer: function() {
        this.timer.reset();
        this.timerField.set_visible(!1);
        this.showReady()
    },
    setTimeout: function(a) {
        this.timeout = a
    },
    complete: function() {
        this.stopAnim();
        this.saveCurrentTime();
        0 < this.timeout ? this.showTimer() : this.showReady()
    },
    stopAnim: function() {
        A.stop(this, null, !1, !1);
        this.set_rotation(0);
        this.set_scaleX(1);
        this.set_scaleY(1)
    },
    __class__: He
});
var od =
    function() {
        nc.call(this)
    };
g["ui.VerticalMenu"] = od;
od.__name__ = ["ui", "VerticalMenu"];
od.__super__ = nc;
od.prototype = t(nc.prototype, {
    init: function() {
        nc.prototype.init.call(this);
        this.vertical = !0;
        this.upBorder = 0;
        this.downBorder = 600;
        this.items = []
    },
    buildItems: function(a, b, c, d) {
        null == d && (d = 1);
        0 != this.items.length && this.removeOldItems();
        for (var e = a.length, f, g, h = 0, k = 0, m = 0; m < e;) {
            var n = m++;
            f = this.calcPos(n, b, c, h, k);
            g = a[n];
            1 == x.__instanceof(a[n], P) ? this.initNewTile(a[n], f) : this.initNewObject(a[n], f);
            this.items.push(g);
            h++;
            h == d && (h = 0, k++)
        }
    },
    initNewTile: function(a, b) {
        a.x = b.x;
        a.y = b.y;
        this.addTile(a)
    },
    initNewObject: function(a, b) {
        a.set_x(b.x);
        a.set_y(b.y);
        this.addChild(a)
    },
    removeOldItems: function() {
        for (var a = this.items.length, b, c = 0; c < a;) b = c++, b = this.items[b], 1 == x.__instanceof(b, P) ? this.delTile(b) : this.removeChild(b);
        this.items = []
    },
    calcPos: function(a, b, c, d, e) {
        a = {
            x: 0,
            y: 0
        };
        a.x = b.x + d * c.x;
        a.y = b.y + e * c.y;
        return a
    },
    onStartInertia: function() {
        this.setChildreEnabled(!1);
        A.timer(.02).onComplete(r(this, this.setChildreEnabled), [!0])
    },
    free: function() {
        nc.prototype.free.call(this)
    },
    __class__: od
});
var qg = 0;
Array.prototype.indexOf && (u.indexOf = function(a, b, c) {
    return Array.prototype.indexOf.call(a, b, c)
});
Math.NaN = Number.NaN;
Math.NEGATIVE_INFINITY = Number.NEGATIVE_INFINITY;
Math.POSITIVE_INFINITY = Number.POSITIVE_INFINITY;
g.Math = Math;
Math.isFinite = function(a) {
    return isFinite(a)
};
Math.isNaN = function(a) {
    return isNaN(a)
};
String.prototype.__class__ = g.String = String;
String.__name__ = ["String"];
g.Array = Array;
Array.__name__ = ["Array"];
Date.prototype.__class__ =
    g.Date = Date;
Date.__name__ = ["Date"];
var rg = g.Int = {
        __name__: ["Int"]
    },
    sg = g.Dynamic = {
        __name__: ["Dynamic"]
    },
    Wf = g.Float = Number;
Wf.__name__ = ["Float"];
var Xf = g.Bool = Boolean;
Xf.__ename__ = ["Bool"];
var Yf = g.Class = {
        __name__: ["Class"]
    },
    tg = {};
I.Element = "element";
I.PCData = "pcdata";
I.CData = "cdata";
I.Comment = "comment";
I.DocType = "doctype";
I.ProcessingInstruction = "processingInstruction";
I.Document = "document";
Yb.content = [{
    name: "__ASSET__:bitmap_SoftgamesLogo",
    data: "aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQTVRQUFBRGxDQU1BQUFBYmZraURBQUFDK2xCTVZFVm5Qa0lBQUFCb1AwTm5Qa0puUGtKblBrSm5Qa0puUGtKblBrSm5Qa0puUGtMTXY4Qm5Qa0puUGtKblBrSm5Qa0pvUDBOblBrSm5Qa0puUGtKblBrSm5Qa0puUGtKblBrSm5Qa0puUGtMLy8vOW5Qa0wvLy85blBrTC8vLytKYVd5eW5KNm5qNUZuUGtMLy92L3I1ZVpuUGtKblBrSm5Qa0xCc0xMLy8vLy8vLy8vLy85M1VsYlV5TWxuUGtLa2k0Ny8vLy85L2YzdmdoLy8vLy92Z2lEem5sTGpUeWpxWmkwUVMwY05TVVgxOWZieTh2SVZWbElpYW1jZFkyQWZaV0laWEZnUlQwc1NUa29OU2tjU1VFd1BURWtYVjFRVVUxQUhQamtpYkdrZ1oyUWJZRndMUlVIeGt6MFNVVTBKUVQzdmd5RU5SMEljWVY0WVdWWVVWRkgydEhraGFXWVpYbG9MUXo4a2JteEVjbkFrYldzUlRFZ1BUVXJxNmVydmZoWVZVazRsYjJ3U1VrOEVPVFFHUERjSFFEc0xSME1ETnpJRk96WVdXVlh3Z3g4Q05URHVlQXNrYkduLy9mb0lRejhVUWo0Y1hGbnZnQnJ1ZXcvdWZCTHZnaHovK3ZVZFVFeis4ZU1XVzFkQ2Iyd0RNUzN4dUlNY1RVa05PVFh0ZFFYd2l5enpta1g0dklOR2MzRS9hMm40K2ZyOWhpRGpUU1o4cDZVdlltRCsvdjdtV1N6NTA3QVVSa0x0ZHdnUlBqb0xOVEQ5NHNrWlMwY2hWVkY0UmgvOTZkYzlYbG9uVlZEd1RpUWdXRlh5OVBiNy9QejFzWEk5YUdYMXBsMzBxbVg4MnJzL1pXSHQ3TzN5bTB2em1FTHo3ZWp3aUNZYVNFUnNWeXNiVkZDdVZEYnY3L0Q2emFUeGtEWGlSUjMvOS9ELzlPcmY0T0h6b1hqeW9saUNTeUR5aEI3NXdZekF4Y2JxVGlZSVNrZDZsNVZwUEJ2ejFyMVlXMVhwWHlUVDFkWXJYVm5NemM0REtpZjBoUjJvWFI0bmJtcHJXMHpwWVN0eVlqYmxmUjFxYUdlVFVoNjZ1cnRMU1VYcWoydlBjQnp6NXRrTFZGTlhOeUQ1eDVoNmRuWDNoaDI2WmgzeTNzMGdJU0NHZ29HTWo0OWlSelNvc3JUY2VCN29XaDN6eHFIenZwSkNPellTRlJPVWxwZmJVeXo0dVg0VmFXa3hMU21HWlV1YlhFQytXRFdobkpuT1ZqRzBzckg2aUJ2cWVVMmlwS1VCVEUydHFxbVNvcUxzY1RyK2lScGlob1QwbmxQc2lGdnd0NTdtWlQzd3pMcnlsMmlrd0wvSEZCZXZBQUFBTW5SU1RsTy9BQVFQdkoreUpZVmtRT1VIRnk1TWN4MlNXVGQrS3EyeHFkYXZxcVJjeWRyV1FTRHRTVWhHM2NsSUQ3M0ZRNktUaDJpSHBMOEFBSGhKU1VSQlZIamE3SnU1cXhOUkZNWmRXdjhDQ1dsUzZXdGNqaERGUnFOaW9SZ0xRVVJGY0VXTHZFNVJoQ2N1cUNpaW9oSmNnNDlvd0lBMmlqWSsvQmRzYlFWN1FTdkJ1ODJjM0p4Nzd6ZVRwNm5tbTJTV3pPYU04NXZ2bkhQdlc3STByVVo5YlczVnFwdnJLMVdxdEdqZFhMV3F0cmJlQU5DbG9KeXAxemF0cjFTcDBqL1dwbHA5WmlJb1Y5Y2VyNjlVcWRKLzBlUGE2dEpRMWxldXIxU3Awbi9VeW5vcEtGZFhTRmFxOU4rMWNuVmhLQnUxOVpVcVZacUNhbzFpVU5hdnJtZTlmZkhtL1pNbnZ6ZFVxalJGL2Y3eGNGdzlKVFZpUGUwOUhkV1ZzTTVIZFVBUGVoclFaZjNGTXB1NmtWenJIVXdOZXZUcjEvVnZIdzZ2WjEydEY0QnkyWm9SSW0vdDIxQ3AwdlRGVUVvMFdVd2trd25abEpKY1NrYi9xYzUvK2pQQzVacGxDTXFaVmZuR0Q3NXZlTG1oVXFVcGk2SHNPUkFsbGM0bWUvYmJNenphUVk5OEhQVnczbzBsallaSWJabDY1RHNiZXgxUVdXejFtVDk5emtGYk5aT0dzcEZYZU01OWYvbnk1WWFYRlphVnBxL2Z6aWx2S0NCN0FTaWZqb2V3dlN1OUs1Wkw2WkhPS0NXVUJnNUhaQzRYa3pLay8wSG03RmMrNVc2NXNwR0NrcG44K2xLcllyTFN0TVZPMlRNZkgwb09YZGt0ZXhwSC9kVkVQbzFBS2FWTjBvellLdDNFSUxsNGVhVHp2SWJTL3FOK1Npb2xsRE1aa3crZVg3Sk1WZ0ZzcGVtS25mSkdacFdKbERKM1NzdGtMK1NVVVYxMkZxa25kbXJMTzRyS1VzUTVaWXRJK2tTS1NxMWY3eklxWjJKUUxzdnl5VnVYTGwxNldWbGxwZWxLNXBUNkU3VEpZSjNIRUNtTk1sWjc1ZmpWSXNuZmxETDhCR3Jqc3piTkRFUHByRks5Ui81a2VlV3lDSlJaM2ZYTi9Id0c1UWIxblovZlhhblNWRFgvNDlWRnAxZE9GODgrZXZUb3JCdnVQd3ByUVgvdFVFZzM5S0ErUEt0SGV2Sy9wTjRkSTB3K3ZmRXRxOEdHb2F4bjZlUzhrcVB5MHZ4d3J0OXZ0Mm1ka2hvNWtmdjZjaHVSK05HTWlmaW43RWR4UU9JOXZMWGVDZmlnUXVFZmlkU0h4REhoN2pRMlEzSWRVZkFBOGs1RjdoaGZFNThFaXk4cm0zZ0tMcE5ZQzA2SlJWUitsOENaU2F3OWZlMzFsd3RHWDZ6VTBwa3pKNjJPT3AweU9xYTEwK2k0R1IwL3Z1ZjRubEh0ZCtwMGRvM3FoS2VORy9YbzQwYWp2WGJTekdYbU42cEpTNDliYW1yRmN5eTlaellyMWgvY2VtVFFYYmh4SldOU1Vab2xsdlVRbEkycnppZDN6MmRVenU4ZTl0c0JCQ254cUdFUkFRU0N3cXZsOGJBb0NUYVJ0eFE4cEhpTEVHKy9LS0d6VG80Q3ZyTVNhQ2hLckpMWUpWK3NET1dYVEFwSkRhV2s4cGltMG1ISlRES1ZuVDBkQTZUV3JnQ1VlOTFrcjhMU2ttakdGc1NXNXF2WmJEVno0RHo0ZUthY3RoN3AzdENSdG1aU2ZaeFhYbTBFb0t5NWZISzNrcUhTSXNtaTFKTW5QRWhzUnlTZGgxR1M3a24ydzZmMUFHQmdoRkhMUjRtSXVlSHpGWDVLaFJ1UjhHNXhKK1NGVXZ3c0JQaExXTHc4YWdwRkNubTlmNVVjcndpZWdMMlMrWUJkRTI5VDNzcEI2U001N3BTbkxKUmpUQ29xbFpqSlR0QXBMWWhHSjV3dDVremVWbC9EWm9haCtYMlVSMTZlVkFjMWxvcEpoYVNTeXl0ckVzclZydTZhQmZVR1NYa2pKVmpRTW5rTExNSXZkVXA1blVDbmVJZ2JXWmFjR2NheDVEc0lPeldJUTdHb0VLNGt3dWRrV0VzSnVnaWZUNHFJankzZkZRNUtKWTVjallSUENpYU5VWm92VTluWjMvR0oxQ1F5bFZvYmcycjlUMjBkTEdpYk5GcHcvUWhXQ3loZGE4aXpvVUZTRFhOdGNHL2piOTlVbWtUQ2ZRQWtNbkNXNWhUMFNwNmhjZWZrRDF0bktCOU9QRk5FS0g4amNRbHh2NlF3emZoRkpLNGthcThrdGsrS0dNbWdvYk9uaGk4SVlrdWhmZTNQRENYYlpDU2xGRkJxTVpKS0drbjlaU2FOUHdJaUo0R3lxYVJHV3Y3dndhMjNkVzg0Smg5ZGR1MGlES1ZYNVhrL0hDb3FsWWFhU1NjQzFaVW9VQmd6anhvY2xlSHpZVzhJQ2w4YmVOdVVTRzJKUWxFR2djdUNvcGgvNFJzMGVTS09qeW1qWVh3Y2hwSnRrcUYwU0tyUHNSQ1UxaXd6Sm5WT3FlVVI2VEpKeDZNcThBaWgrTlJ3MTF5Y3RuWXRra28vL1ZyUEVzOG9Id3kxY2lZSlpERWtTei9DYzRybkVoUTllT0U2Q0hncE80OURoMHd4eGdJR1dUSWVsWGtsRnM1azhVbGxiQjV5Wm5USGc1NktSWkdLTWlrb21jbTRVeDZUWlo0eHE5UklXaWdaUzB1a2d6SUFaQ3Y3U2pYL3FiWjFGelNVV3U4OHExemlaWlJQaGthV3ljV0xZdWtFRUVoR0lVbW9hRlBxOFplRkxVcWlSOEEwQ0o3SkphNjRSZ0tCaEpBQXB3L0RPWklPVU5sNGhYQVV4RTU1UWV1TXlDalpLY001cFdnTjhheVNqVkpCNldHWkYzWE1GSEc0ZUIxVVZEb29mM2xaNVpMUjB1dmR1Ym5obklKeUxtZVN5aUJBdkFEQ1haaGJpS2VSRU56RVh3S2NGdjFkdWdqQUF0UXpJTzlSZXlmZ1FxSjJuVTVVUVhVSnJTSks1SjNqcVhxNHJCNHNLWk1QNVFVbmh0S0lFMHFtY3FUMkdnSnlOS1BjcFlsa0JkUEk1clMwN2Y3Q2dxYXkyLzJjRldBWnlwbkgxaWpubElacTZJTXdpV0tySkNaWUJMakFva0Q4U0Y1aGc4b2xsektnU2lOSnFaWUN1TXd6Rk1TZjZaUkJQMHFSeStKSDNodEZvSVRlQkJSakdJY1BzcDFTR3FXc3ZjcFdTdGIrUGFaOTBqZktYWUpJMWlKdzNHNC9ic0ZKTFp1eCs5SGIwRzUycE52dFB1b3FXYXQ4UE9PZzVETFB1VG1uZnJzd1ZiS3d5VXNTVGlKUlE4Vit3MndVcnpOUTJYWnhpUXB2SVVNQThnOUJaWk11U1RVQWlrMG8wV3dFakRsYy94RXN3dndqRWF2Z1Zpb2dBbEFxalZBSm1GVEtvTXdiS1BjS0pzdEQ2UWhqSFZUU3BPbEJxYlU5cDdObGZ0WGlQZTNPRnRkdGcvdG56OTd2ZGdmZHcxenFVVkJ5OVBxbTMxZEdxYUhFVFZ2K0dMKytaWVpFNHJDaDdSR0ZUQ3FsWHVoRTRuRVNSZ2ZLaC9JU0FVaXBFSjhTRGdVVGErNzRRT1R4S2hJSG5zWC9TVFJoc0MvRFZUZWhkQWNJM2tMZVJ3bGxqbVJXZlRYS2lKUlFkcmhOeEREcDVMSkpDV1V6QmFWbFRIUG5nRHFvWnh4ZWFtcmJQZktOVzFyYmcycnkyS2lsdS9pZUhlellQUGptNGxlR2NwTnRvK3dyWlVZcG1TRHNtVUdqSVdBWW9GV0JVTk1sQ0liS1BJOFlLWGxGcUZCSnlKOGxjVWlFTmtxZGxGZWhwRDNXVGdramNpeUsvaHRUVHNsTUJudnpHREdVbWtjTDVhNWN0b1Z5M0NXNVlUSEFvL00xelpxR2tHa0w2dUNJN0pJYXhkV2NWVlMrT2pzWURHeGI1VldHc21HalYwV2tHcFRFdzVXWWx4QklLOFU0RW1nR3dXc3AzbUc3ZEtzajVobEwxcjRXVTFnbUZIZEllTUM3TExaTnVJOGNmcWxLWC9UakV4SzdVNlFyWU53cG1jaDR4d0h1WDdlL005YmxsVHZ4UkxzSmhJTFVCSDE2N1NpRmJzVHpVQnR2djNwbG9CelkrTFZob09TVThsYTczZTVydGZIRGhaL2g4ajRRYmlLVEpVenN6cjRJRnYzeEJTSEo1bHBVRmFKQ0dYb2NNaGtUNDE2bXFkQWN0OWFXYks0VnRTSjVsUlE1TTBNWnFmUDRVTXJPUEIwMTVIMTUyQ1p6S01lY3N0VVVVQVlEMEdiVDV3OWpoM1g3bFFwZmp4elp0dlVQSjVVR3lyVzJONCs2SVcwdEFzOTFhcDBJZXNxYkRDRjNLdHdvV0xEd2lVRkNmeHVDYjBINVVCbUxJQ2o0cUxnb0pkTkcwRytETjVpd1g1YUFFdmQ3NWI0OFhpNXB4QTJVRWFkc1dpZ1ZpUjl0SE1zMVZCbDlidjlYT3VTZ3ZMZE5FYWxtcmhzSTEyWlFMck4xbnVmMnZyVGJzb0dCUUE5eHdVZTBGMncrUmM4SkZYeUFjWUtIMXdmOUNkWWpDK2U2UkdCZmtqc2tOaVZVQ1M5OTZTUVBBNFh6a0dJUk1JblltUWhCZVNvS3BXVnl2L3Bra2xCeVI1NVdVMWQ0V2lKOEhUZkRnNFVnTTdJVHQ0alZ2RDNiM0tKMlVudllScEhhc2d4SzI4ZnVrcnN6N2ZLbTVvc1N4QlRycHdJd0IzWkljbHZjVElaalNkdzlGd2lDUXVDdEFBUnVGbzRoQ0J5R3c5SXlqZ3RSNS9XeStocnM5enJxbEtHLzJmSjZEWXhES1d1dVdjUnFjTFJFNmlrQWtFa2M0N0JNN0RvN2UyZlduZWlLN1dubm9GeTJ3aFpmaCt1czJxaC9aTlFiS09rNUpKSjdpRXNVL0VMN1ViR29sSGltSkVScENBaEh4eFR0aVU3QW9XVlpScTRpR1hqZ2pxckEzYVFvY2d2SkRnWGhsVDE2QkpNeHA1Uk5sTUlsUjZBODRlV1NZMm9wR0hQSmFOTzNQMTZsVi9KU2NXMi9mV2QyZHZhMlhWZ3dFRzVhc2N4Q3VmeXFXZTdqLzZSb1RaeUFtd2dBSjdNV3dnODlvdy9yRjFpNEtCeG1Db3RpNWtnQVFkRi9EN3U0djkxRWFhaEhPQkdvY3dPQkJFQkF5VmpLNHV2T3Y2eWR6MnNiUnhUSG9UMFVTbjlRS1AwRENtM3YxVHZJeVVuK1VlZFFYQW85bEdBSjBUWk9VYUV5Z1JCSWFTK0pDemFZUUZ0YUVwRkRkR21EVHdZTEl3ZmpDSW1DTFJ1RHNReEpuSVB4b1lkU1l6RE91VE03bzMwYVB6MTl0WEsrc2FUWlhYbEpwUDNrL1pnM2J4bktLOHlrc0pTZmR6WWFpTzFrclBZQ3F6RHJhbGtURkRLTTdaM1p3WldldGxDNk0zemk1a1JlZFZDKzhXWXFFalJnTEFvemE1QmlPanUyVHppZ0l6NUNZcEdrYU5taEFNcGhyUElmdkI3MmdlSnM1ZW9VYnlIcVdwZXRHekxKSWx6QUtwbVJVU1B2cDJBTUFrNUtHTkpUNzFDR1FJRE1VTXB5SHFVNWo3U1VuN1h6UE8zaU9nOWxtT0poSnAzR2dqbVFiR2dCc1NVY1RpNUQ1WitUMFNnejZTaDg4dzBMNVNzTVpWc0VMUkovb3FoTkJpa05mVUtxRVJzNGpTclBqZWRKa3JjajRQUDFPa0tTRjdXWWlJZkFNeFFKVWNrbVhydEZSQ2dxd0I4Qm82b0Y4bnBqRUR4TGlxSGtZcDZBU2E1NFBkc0FSRnZQSEsrTFpDZ0JmY2tBek1BM1RNNVB0Z2ZUYlNoZnNWQysrZzVES2FWSGdRVG52L2pxUUk0dUFmY096cHVRY2x3ZVFIVXhXQmhzZkhyOW1JelFDWWFweVUrdWtJd0RlT21mOEtidVJvdkRjT2xXRUZKMlNiNkdURnAxT3E5Qkhib3lPZW1MQnZxRmN0aUJpRWs4bzI1NzdhWXpsUE51YkRJK0hzcDNYblZRdnNaUTZrSlovWkJBaVFicFNPQzZTLzNLNFcyWmd3b2NaV1c2bWpjUklEUWdteXB3UUVUSmlNT3RmODZmSENZVTdiSVJWZkFPRGdhWUl5aS9Gb1pTSzN0MVVNWkllaXJEY2xlUG80c2lKWkNUS25JUlg4eVozOG0wQ1JtYTNjK3dmUjYycjI1UEptMVJUR2N5MWt6R1VMNW1vVFFoNVZzaGxDU3YzUDZ1clVJa0NRbUJLaHp4ZlNXbEkzbHBMY3c4Nm9HY3NCRUVKZ3dTT0FEVXE0a3V6Z2JobW1GU3ZnUkJCazRyS3pFMVlKM1U0RWlIOHFyNUViMTVoS1gwUkJhRDFLdVRZOUlxTkpXeGpld0JvOE9PSVpTVzBBRG15Yk80R1owMW5PWXdBNW4xU0pvRDZXbXJZWXNrUS9tV0NTb05sTzh3bE9yY0JyN0VDNVhDdFhXamE1VktRZWx3QVZhR1lDR2NzRWpiSmx5Tmx3QjFDVUd5QldRa1RBa0IrNWRNb0Q4b1Z2SlVMaVZJc0F0TGFZWEtYb1BVcTBPVG9lUzBxK3lLeGJWemJTZ25ReVJEdzJldFlYUWdoaTlyRWJONzNOSCtGZEZvbmdJbzN6RlFtcER5M1E0bzdaTWVycXUxaXZYV3RlMjlwV2RHUzQzdGE2MUNyNnBvMGd3SzZYbjRlQUF5SGdSdGxKYnVsWW5ZOEYrUEEwaTlBSWRJaTNzSGQyanhYQTB1OEpBZnRYUUI5UGljeEVPZUdjQ0lZa3A5T3NSSlFQbGxOeWluV041RXl2b2RocEtCWk1Ec09CdDdudjVnTC96NlkzTnltalh2czYvdm1xRFNRUG5hNjBwTXFkUUNDQlZhcmVkN3phM1YzWlA5L2NQZDFhM21kcjJlc0dINitXMEF6aS8wS2tJamdmN0FJbVhlUkFiVWhESlRPRXVLNXlMT1dZOUV1SUlZMjBoc1ppV1VNdmNxb1F5SUROM1g0cWVleVNsMlg0TzVFSll0NG1ubmRrTEgwd0xvZnJvVHlQU0dEbSs4elcveGlQTzIwYWpONzNqOU9UenFLSHo5TlFmbCt6R1VIUEtJeTBubHFYNWEzMjd1YkJ3dWwremNaMm11dlBsa3EzbXRSV0Y2eFk4a0dLVGtTTkdPWG56cFFwWFZsSWk5Z1VVRXdrM1krWitVTERmOGNQcERqR0R2RVVMM0NNRWllY2NIaHRJeWFYNWthMGtSVTBaTTJrY0laU3hmTmNCRURrMUZjbjFhTGF2VkliUGN1R3BsektkNU9Ca2F6UTd6SitzWjlQR24yVytlVFgrQkRJUG5SNk1aKzdEUExMOGwxY0hrdlBsZEQrWDdGc28zM256dkl3K2x5R1JDTDRpb2ZycHUzTmFONHdWL1E0UnlicUZVMnR6NjdYb0ZsMityWncxMmtMaENuRHFwVjFkOEVSc2d6WFRLeUk4RUFOUnIwazcyRGVHTFRFelZVcS82ZTFJeElEb0RESUVFSjY2SGxiNDZnWXBBRWtDSnVVdHhDWEhqYWxLV21zbFVPWkdETXM2OWlycFhyUUZ6dkY3THZuUXlHY3hSL3ZMakw3K1lCZitUTnBxMEF6c2VjNjgzT3BUSitNR1FDeGlIL05GUnM5OFBoaU80QXV6Y0hrT21WWVNrM1dCVTNjQWNHMDZ6NTJyZjY2SDg2TDAzMzdCUWZpaGl5ajVUSEZRL2V0N2NXVDNadkpkcXE3U1F5NVZMaTZ1L1hTOUl0Qmt1R2I2UW1HeEdIUTE2VlpPS25oUXNVUElnd2wzUXZVUDVxNEY3Z0pBR3BiaXdRYjBkZWdPNDQ0VG9MUit5VGppSUpuNW9xVElpQ3ZiZzFia01aVitGQTh4azIxSVdPZXZxU2w2WnluVHh4YkxWL3UrZkdrdnB4NCtIN0NEVXcyRy83OFdJWmF6b3QxYUdxMjUwOG5qTWcrZkVvd3dQWXloWi91QndKNUlNNVljZXlnOFlTZ1pILzc3NVFNc2l1YitZNmxTcG5NdmxTb3RielVydi92aUU4aEZLWWdaM2tnUE5kS1Jnb3o3ZFRvTlRDQzdES3gvK2s0am9QTjY2NUFUR29GSWNnZ0RIUnl0SlNDd0tvZVRzYTdBNmhFUEtTSjdKc0x3dVVtZ28wK2x2WEQveTNPMmlnZEtOeTdOVk93aDFkM0xGRFhLUHN5YSt2TEhtdGpaL3JMcjlhN01qbzE0aGxPekZPalBxZjloME9sUHFjcS9wNGVoWTdMNSs0S0I4NjIyR0VuZThJUjRkTlhaMmE3blVHYzFZS21kcVc5c0Y4VXZpak5KNkpsaEJpQnF5U2JMd1pBRDJwbkUzZHFWekxRclBsYUJCdUkxeVFMQnVIb3R3dVR3K0w0a0I4cTdsSkNteHBZd2wwanhPb2lkNjBZcVpaQ2lIT25WcDVmdVUwZUw5NHRoaytqQVZqV2VuRG5Vb1UvdWZqbWFLSnlXL1lhQ2NzWVBhYkRWekxzMjdZTkxMUS9uMld3TEtCRjlwb2RVODJMeVFrcnFRczFRK2VWUWZaSmt1djlLNVZtSVFzRUZDZ0h3RmRGU0lxL21acE16bDRPbzg2dHJIRmpTMEZtOUVEYnpnZEs1MHFmRDMyaU5zQ0NVdDVkZHlKYVYwWHIvc2tLZ1ptSXBYYTExYUtTV0U4dUtMYXZYMllncERHUWFZem8xVk5aR2VuM1R2QUZEMlB6dFdPR3F1cnFXOHBBTmJYanZZcTZQdVpUbzlraVM5UFEyTzJrZ3Z0Qk5ScE14SVlEdWdqNmkvMm5md0R5UXdsNnR5eGw1SUF2aVVhQnovRjRudEtLSDVGUW1sdkNlbDdEZ2cxelp6U05scEtVZU1HTW9IUlhON0FnQ2xWKzNIOUdaS2hYTDBwV2dDUW9rOXRxUEdnV05TYWlabmRISGowUkdNNnZTa3B5eUwwUU02SXRqRkczZUNSR1lEZE96QUltakdYMXFCVTlMMXJyalpIb0Z1endtd3gzRXhocEs5VjFHS0xtNTZOeFJDT1QxOTlhbUQ4dGFZNlNGMzRxRWNPdnplS2hWcExocDNRUG45eW9zTE1aUTNHTXJSbDZqOCthQ2tLTWV6YzV4U05IZlJRTG13ZkxDdU9MQ0tTd20vYkpKMnlENEpyb0FuS0RJNHZBWE1zVENDU29kblFrQ1FYRzJSdk02Y0NDTktBOTVIQkVjV1V0VG5HbTdaU0xZcmxMTEVUclo3bFZDZWpTa05qMU9kN1YySHB1Lzg0Q3psdmVWOW83VTJsTGRPakk1ejBmVmJPN0VhSHpaUWVpMHNwcnBBT2RLSC9adHdMMUwrT0lLU0l4Mzg1YlFhdTNZZVJEZVY1ZkpxODVSQWp3d3RtV1NGTDlhRVIvRzFsZnlFeWQwNDNQRU9RMG5udHFpNFN3UVdvZDZGZWlZWFpJRTFLSVBDQWVHOUZyc3QyZW9nMHZ5TVJGQWFTOG55VUZhcjVsZXZ6TmVpK0d2bGF0RW9ZNkJrS1ZBeWNSWXdnWngvc29mYTcrTnhDQyt5bEFRTHVPdlBIKzJuVk0wdFdGTjV2RU1WOFdXUWZVaWo0UTY1bC9wUnBEb3BWWndFbXI0Um4xQm5rVjl3bkVjS1JjbzlqWWprUGxFRGdWZS9VZUlFRnlXNHc2KzZBQmFHck5qRER6OStFczRGWGxIQ1VGNFZscEx0WkJkTFdReFRyL09kUlFPdTM0Y0dwYTBxci82eDVxQXNScUJnS0Qxa0hrTTdIbHhmcVZER2hJQzZrdFllWjNtVUJPeEM3Wi9HcVZicFJiM3FFZllhUm52UFQrdEtiK0tBYWJWOUFmRkFWTVFFVVBKRFlBb2JhL0lIMWV0bUlPb0tRMWtBQTFzUXFlWlRGcEFQMGppSENONmZZZkJvbWtCV21IcEJLWnZZWFRrelJ4bGtYcjE0Y1lpeGxFYWFwYlE1bStSUVdpSVJpZWVIc3Q5bXVmWEc3bHlxdDZrc2wzZDNXZ1h0eXRaMnQ5YVhkdjUrY256ODlPK2RwZWVubGZOZkU4ekM0TW1KODNWdHhqRUJzRTdKcjN4Y1hnZENReWpxdWFXSjBHY2pvV1FtSFpRV1NKWnZ2OHhRTXBQMnFiT1o1SWhydWF4QU9UUnNkQWJLeklvNzZLZmkxeTZjaFhKczRxVkpkVjlSb29JUEZxNHRQVTJsZ0ttOHNIbXczUktaMHQ1TG11dDdPeHZMaS9kS3BYdUx5NnM3emZWV1FSZ3hrQ3dFN3dUZ2dxb2pkQUVDOG9WRDEvV3ZCMEl1Y091K2hGbFp6UzJWN29kd1JVbjhqY0YvQU9EVFVhSDhtcUdVYTdhNE5VK1E0akUzdmJOa2lnV1VPcFRHVkk1MWczS3U1bSt6L0dMeERKU1BxOWxJR1l0VUNGZytieDd1dVdQRGJVMUVUMjdEUHZ2akNwUWlFYXArNlpYMTM3Z3NTWnVyWE1odExCMFZVQjFMb05iU1Z1MWluUEZhMnpob3JsY0tsTnhLRUZHL3hnOERpOVA2SUNrcUdkRGJ5T0ZDUE1JN3NibmwyM25nS1ZpZE1yMVRyUnZqYmdRRW9MenFGR1I1YklXZG1LSTBQMFZ1dmN5ZHNuZzZ4SWxqeXBtMTVWcXRsb3ZkVjZQQVVobzVTMW03dXgvQm1ENEQ1ZUxKaXRPdC9PaEUvaXVuQ2YrVVhPT2ErMHFxcVdCZ0FaUmVkbFprNW1UbmVZdFBnR2M3V28ydElGS2RNZGF5c1g2OUl0SW9KRys5anlqRFNCUGF6ZGhJdGtocERKL2NxdUtiZ3lsdCs1STdDSVA3ckFKNUhINmpvZzJaZlpXVGxFWWk4K3AxNWthVXJwOWtER1hjam9laFhMdzhZc3pUU1FEbHIxMmgvR0syYk41eTg4b1pLT2RLWHZzM01wS3hmUFRrWmJiTWs5MzA4cHY4SmdnbDdyRllXQWZ1YTJxdWJQelgya0hqWjFqb3pUdGEyN0llb2JieHJHR2RXQ0ljMThEOFBOeVA2YUYrNys4T0Y0ckkzNVNGVERMMXd5TGdiUkx5OG1HUkZSYVIvSHdJeEJoMm9ONFlRb2Z5V3g5VGVpWmxBK1ppUjBUSlVMcFpTc2VqaC9JN0QrV0RTNlk1K1dFbmxObnVsdElzRjVtYld4bWFDcUZrR1NpTi94a1N4MXZoRVYxZ1NnUTdZb1hyVFpmbzBYWFBwSG91N2o3NnVDTFkwVlNwN0R5ZFNRbjl0L3JYZHFFaTdGZlBGWWN3Y01SMkZSc1g2RTBPZnNzOVNyVEFRMitFbGJ5b043ay9UM0x4VzlLMFR6QXJKcURrUkkvYWdEbWNEZm1jb2ZUaXV5eDNRUG43VDZacmxZZlNUVGt5bERhanl1NXI5dTdtOHQxc1ZZZHkxUERtRmJIM1V0MVhYUFRGVXlLTHZhRXNXZjkxYzJ1N3hWOVo4TW5Mck1kcFk3WGMxZWdlSHpTT0NxTDRCcktpWnlsQUN6bkZ4eUlpWmFFWnBsdmZHVFo3d0l2YUNJR08yUUo0UzFZSjNhT0p0TGZETGo4a054bktxN3krMlRtdmVsZjBvS21rNkx6TWR3Y1o2WUR5bStsNUhVcURaUXpsUkdiMmRqWGZ5MUpDNUFhSGtzUzNIbnFhL0lYVnQ1L3RwM3Byd2FSNkZqYWFsWUthM0tEUVVGN1Q2aEhtOXJmMldnWGwyb1lScXdRZ25NempGeUkzNkwwQ2toU3VjRUJKL1pCTGF0a2dFUWtzZ3cxRUlBbXdXV0NtVnF1a1ZaeHFkUHF3WjBOWXFVUWhsSExWbG9nb2kwWHpNSkpwbm5tZjRvbHZUMkNnblA3dWFjcGJTZ09sWDF0NW42RTBXaWthY3hkYnlyVzdFL2xzZGp3L2xYTUk1cXRtdndybGVFQmEyNWUxTWFaLzhRY1NRcWxWZlJJUHFGQnZIcWF3cVV3OVBYaGVWMWNFaDN0T0cxdUx5cG5tVG5hc3hRVWRiSFNSQXEvc0Y4UzdTU0FMTGp2eHVlbEVDcEFGbEc0Z0kwcTl6WmdzRzVJaWJPRWxuTlNqb2xYMUxFaHR3Y1lmYlhBZThvTVFTaXRaOVNvc1pRUWxwM2tja0o5emUxZUg1ZGlrZ2RJMFFQN3VpWmxETHkvVWZyODBQNTkrbXN1WjhkcnNtSU55K2FJNWxGdVpjaE1iSzNhcnZQeUp5NlpXMXhiTTFzWGpoOVVYdVRMTDdMSHVxOVc0VWQ3K2lUV09GYjNiUENsUXltOUcxOUhlMzR2SVZMcFVUNldnNWx2RFdaWkh6cTJRdW1BdGJxR2dPRWxKR3BqQ2RZanNEU2p2Rm9ZVzJDZXcxZ3NJL281U3BnK0xKaFJyakNXd0JwbTJ3U1NoNUtKWFlTbU5vU3lLVWg2ZUMybmZUaXRxSVdtZ3ZIUG5qd2MzYjk2OGZQL2htR21IL01lREJ6Y3YzN3I5TUJNVm9PYnYzN3A4K2RibHgzYm0wWkQ0K05abHMzbmZHNy9SbTlIbWJON3NEelJya1FJSVluMmhRYW16dzZPWUlaNFUwY3ZTUzd1UDFobEtVbmlpaVBLTm5IcWltZVZuMnhXY3RTRVZOaFR5NEhaeWdQQmtVQktoOUJTb2tkTU80TVpDV0RqTFE4cCtRREN1TmlJTXBYUmZMWmZNWkpkRmxHbG5LQzJWazJsN245WkxOZzlVemRyR3EzZCsrdW5MNmxRMTQ2dkNxNUd5ZVFkbHhtMTlOZTVNWURiYXpJem5NN2JsWFRWV0Z1RDJjcUFrZ3JmaXB0UG1hZzdPaWhpYURrUmJFT0d2T2NpWGpyWHp6T1RLOTNhYjZ3VjlFZzRUeHdKaEdFaHdpTmlQZ3lOWkJhdjJBTlR2VjR0aEl4emQ4UjRJbEk0dDRacEZRdW5VWUFNMWp2ZUhHTXB3UWtSQytWa3NuM2xsS0lQRXE1dWpqTzZTbmgyYmp6bzZHc1hka0NjbmVLbEdXellBakQzUnlNVThEMjd1OFlWNU9QRXdBWlJnV3N5dkUzbFdTNlZncmQzTWF2TTZtQWVnNkhRTnc3aCtucGwvSHdtNGtYQWtoV2pFMXkwMmtuQS9nU2xZSFdrY1ZPc25IY3pQRjJFMTlab3NwZ0Z2NUNLZ1ZCWlNNcElHU2lYejZoTTgxa282T1NnejJXd01aZnAvOHM3OU40cnJpdVAvRTc2a0xZNHFJQW1OUk54T2F5ejRnVEtJcGcrMnEyMlloekZxWVcxTFZpVFhMTjJVYlFwWTlncTdiaDNiOFJLRFNlVzZGSUZJTWJnVURKUkhTUXZFSWdrbElXa2owc2NQUGZmTzNUbjN6cGs3ZHpHeDFNZlhhN3c3TzdzN3U4eG56K09lZXk0VTFLbFF4dkdneEhGcncrQnRnRC9wMmdhWDZJcjhYUUtVbHA3QjBsVGVQZFJrcmJVN2RPUDIyUWJPZ21PM2JqN01xZzdxK1hqbWRJUFJEZ2luWnRoSC9FRkdOSmJTME1kZWdjY1NwUVpDZUNSbUdtMElOUmdFR3UzVkUzNEM1T05rMW9lUjltRFVmWTJRcEZEU3R1aG9KeFVzWlIzNjVsZ1N5a2hmNTdIbVhoQ0FLVTJrQW1XbUtIUGI5RTBSZnhzMEJyY2wvMndURXRjc1VOb3RUeFFFM2o1aU41VmpSeURWWTF6cUdLRzhPbnNvYThySm9ZOW56alVVc1hsdTRFc0Zuc1V6RmJ2SGU3dWhZeW9CZFl5S2UwY3h4eVptR09jSTNTQStCSzBsc1NGM3pQUm5OZlUwb1MrUEZzeThCeXJ6SFpsOG5qRDcwN2NYRktsUWZqdkZVaHFIS0RIdktyQ01nWlFDR3VWcTZBZ2xGNjhSRUZzRWt4RWlKaWJyZGhBeGswQnRRSW45TklrTjhVYmxUdHo4SmZIN3RCMUtNc2FmVm9EejhKQTkxZE1ERTdoc1g3ZU1uZFdHUGVuWXlxR0hNMGZQTXN0L3NSUDYrU0RzYk9sYXVYTGwwSEJuTG9CYlRscTNSNGE3NXpwYmh2anVMU09lWHdwV09Ha0g2ZVdOQ2h6NStRUjVtM3lQNUVPQmRqZnZoNTBUdzBQOEVEcmhnRnpIc1h3ait2b0JwTWVZekMzbEUvSWNQWjlGanRoVlg5bngvTHhaSHI2UTh1a0g4RjVHSnFKUGYyS0V2elBIWnJaeGd6M1JrejRhOGoybzVvbWhKS3ZEMWdjb09aVFAvWkxyaFgwdjdYc2hYaEQyV2JDV1grQlE4cEZHc0pJWHR5VjE4ZUkyK0ltMVRmN2lOdjRRdVU4RUs2Skg5ZlFHc3d4UVdqcVFrUXFjZWRJUmhOcTRzUk8zYngxRGR5MjlhRE04UGQrVEdab2V1ait6LzBJdXM5R2I0NVh5blFQVGZlV095ZmIyOXNtT1NuVmhvRE9meDdLSFNBeDM5enNIRjZvVnVYdTVyM3NvVi9JRlpMckN6cTZ1NFdGKzRScU9mdVUvRS9XZEp1Sk5zQ1Bzek1VM1NQSHJJMkZ5Z1IvbUY3Mmg3cjV5cFNZUFlYSElLL3BPMXVvZFR0Z1NIUW44OGlzVFlYb0UyZ2wzNHZHSWwvZVladFFtb2p2Z1J4NXpaNmc4M2hzUmR3eEg3MXkrSFhFYmQ5VS8vWHgrWkNCK0x6WDQ5QWNuOHFVVmpxa1ppSEcwRjZGRUpoSEtsRVY5bEJsYjBudFZvWHdHRk1XVTBhb0RQK2Q2VmRWdTJMRDcxYzlDUHdicStBK2d4MzhwajlGZDRpcTlxeEVvOVd3Wm82UG1PZS9TaVFaR1JRN0NCQzRjODA0djdna3ZQY3djNzRUczYzNEJwVEcveUp4OE1EUmRidGNlV1NoM3QrVERWRlB2QkQ3c1h0QjJyMVhiSmtxaGszenFZS0REcVBIQVk5d3VoZU8xRG9zcVhiNmpSMTlodnJPL1d0TVBvYTkvSkkrdlRwdmhlQzJWRGtXMXZoRTNKZFhpdVcyMTVNc1BsaHpsdWNLdzJwRlF0NDlQNGVTSHl4bnZhQ0JJT05aT0VIU1JUNzh5M1lYbUY3dkVaa01wM3J1QU1tTThSSm16SlF3bFFpbW94SEJTUXNtSFEzNTU1clZsMXZ2di90Z0FwZHdjYll5dVVqS1hFbFBTSWNFUHpsMXZzcHZLNW9mM3poNHpsRzloUk5tVDZiM0NPT1grbzdkeVdiTnZTNTNqdFNhcVNsdmUweGRZajVnczVSWlNkaTlVQnNWcHhOUVNBbit3eWFpK1FEeTdHMWFiYkdvZnlqc2FaMTVwb0ZLZ2gxQ2VLcnFtMWlNQVM1dStlMjBpU1BIbXc2Q2JQUEYwRVYrZVcwTHk5aGRVS0V0RGswMW1EUWI2TjZOVGNoYzZtcWc2dW9PQXVMQzJpWllTeXF6eEVOTENUczVzeGxYVWxaQnlzeGlpWFB2UnV6OWRicjMyNnNVTlM1RWR5c1o3QmgrN01ML0ZudW81Zk9UMnVRK3laNTZjbW5tUS9SUmoxMmYydzBCbFJsOG5mN2hzWUtIYjlSaVowUkJNR0NpYVhBeGNSejlPZndEUU1RZ3NwWWpnd2o0cmxMVXVEVXJtZWQyVDZUc3VocUd4QjBSUVRUQThoWHlnUXBkQzJlZUh5bE81WGUyRVdsK0Z2NnZEQmlWYU92UEhXVmh3WGVmeFo0WVpvZFFuYmVGeVBsTDZLdXJSRk1yTkFPVnpNQzc1MFpsM25scGUvZlMzRnpYSytHOERza0hKNENlanlScUY2VVlEL3V2WWpVdWY1RmpHUU1HVnpPQjBqTTgydWJsLy8rbXNiOXRnWmMzMCtNSjBucHdQZmtzRmQ2Q25FZDl0K2FCazBwZ3RGSXhIN0p2UzNsNW5MWW1TNjhub3dnSmxaU1EyV2d3czRXS3ZBVW9oTzVTd0x4TGNXVGI2U3RPQloxa0NqUGpxRFVNSjBsZWpsSGJ5VzNHZnJLaTZMb0p5ZHRtaFBIUHg2U1dvVG02RGE0blE1ZmVqQzdxZDh6ME56QlU1Q2IxNm1IbG8rbGg0Nlh3bTFtTmpOMmFPUWtocFhyN0E2MFRJaURxR0l4cncxSFp6R1F3Vit2T0tTYkZEeVI0SFNsVFFYVEFmUWx2QWtnVXhFU3MrTVhEbEVVOFAxMDFRMWxhV0hIeENzTGdVU3Z5TTdGQ2lzai9POWtGL2hVVmt5ZytCa25pdklNMTdSU2pWdkN2M1g0RkozajF5N2VhUDV2L3lwc2JRZndxVVV1dXlvTVRUd1M3MzVuRzdxVHk4NWZMK1R6S21MbnlDZlowTlplM0h1YUZrT1dZc2VmR25tekkwN252YVVGOFlMR2J0WG1uSk05eDVlYUIwOHBreFczc1hVRW5GRFZ3aENmQ1EyNWo3MnR0ZFlzaFJaOGVUUW9sRHcyb0FTMVYxQWtPOW9YRnFDVUlwcUZTYTg1QkpXeHFVV00xRG9Wejc5VmVYR2NxWG41cGRMaWp0UENLOE1KUnh1Y2xlQUF1cG5sdFhqT1hlcDg1ZXlpRDdrSUI2NXVoUkxFaW5sdHh0MGM3d1dxWFNRVTBseXAzUTd5NVh5NU1hYVo3WHFLWHNlenozRmQzUW9DOTV4TzNhSWVSVEsrVERGQU8zR09BTWJCVktvajdYaXkxdWZxRGRBR1hEN2lzQ1BsTFJvbko0THdYMXZRMEZ0a29qUEhZZFNreStVdWNWWTBxUU9vbFNoWks3cnp6TDgvVzFtNWNmeWpmZldRWW9yWE1zNkwyNVczUU9KSzJSYXo0eGYrNFQ0enpEVDQ3T0hzNTgrTUh6bDQ1eVEybnNpTUQ4QmRYS2pIZU5qQXd2cUpoMTU3WDlnemIxSEpxZThOemNvNnE2YVZqbU1TaVV2ZTJhQ3JHbHRHZGZDNUI5amFPdzRwUUtSWFZsNThqRVlGazdCQncvUVRGL29wYkNXb2lEZjFsUVZqcDlWaC90TEM3MEdxQ01kdEdoYkU4S29NVFBKNWhTMytYNFZPZEl5Nko2bUJCVlp0VWVJcFRNQ0NXSXRrVkhLRitnVUhJaVpSMTYzVkkrKy83alF2bHlZNnBEK1pmbGdKS0VhcmFsSzFqdTdQN3JEZml2elRkbVRKMGlHYXdVZEQ2emZQYnc0Y2hRT3VhNVAxNVpPWjM3aThVZ0tKWDZDN285UTM4MFZBbWFIQ3ptWFM4b2FxYXVQOERCY1IzSzh1REFvS29oTC9MZ1ZpeFcrK3BTaHg3TGZiSEdXNEk0MGVPNWZXcHFDU29HZ253eE42N21la3FPTmpkZi9PTVUrOXNwYTA1SVBoZUVVak5aSlVmdTU3bmxwalFvV2FxbExDd09ET3FhOEhBOWVNOWRVSFBkZVhndnBlS1VnblExNThaenI1VXdnaTRwb2tINVhWTDMranhkdW5tVFZKTEpaM2ptbFk5UDhqeVBzSlNnang0YnloODJxRHFVUHdFb2x5NFRsSTB2K3lKM2hWVFA0VVltY00xZi9jQkE5aWZuc2lMS1pyNThGemVVSzQ3RlZKRytFcDRTSVBXT0Y2RlNqVG11cjVCWERWMkdEL0dHRlY0WFlIZkdCOXJVVk5HNEcwR01saEozTDVaVUJZNDgxMEl1TC9TODBBK1ZFMzdJRjF0RGZzR2pocUY1OWFUMUEzN0VqcS82cHVYUWRjZ1lWT2dqeTRqTXNKc1pVK0tPQTFHbWg4R25NOUtSQnFXNGswTFpQbEVzNlhLVkxoV2VVMWJkYnZGZXZLTHkraDBUQUNVanRadU1UcmloVUZKRENkS1RQT29Dc1lyekdnMVNibGFoZk8zTngyVHljNDNwTFFubCt6OVpEa3RwYnRGUEVwODR1NE1XclZLdURzOGRQWlZMdGJyRVVKS2wyZy9QY1VONUttTlZ1bUM0SFMxZmw4d3hCb05xaHJKdXBGakNlNjFNU0ovU0sybW5FWUVTdzAybUtjNy91blhsWFJYS3ZCc0xCeDlaYVJDUHVIZkFkMlFXcDE4eGF4QUhrLzhEZDBVNVBuQjhnalkvQmtTRmtxcmJEMW45UzZGbXRwU01RTm5sTWwxYTVudGlFai85Z2FMNGxvcHFEL0RobHVhbHBMR21DaVVkRDlHZ2xJMTVBRWtGeW1kd09DU0djczFIN3oyMVBGQktTOGxyQjlKeGd3djh3ai9pRm1ncE1hVjlUaDlTZVJyOTE0eDY4cnYzTHNSdG1STnJ0TTlaREtXSUtITTVzOFYyZkNWclVYRUVUM3J5cDl6cHE2TUJmZW8zZThoWUZFUzFLTVpqeW8zMnBWQzZydUZzaXVYbUZDaFhLcWV6d2t4K1dyV0pudHpzRHJkcnB6Zkp2ZVl4UTlWZFFVdXJaR3BaRnBSOWRZZkJLYllWVXFHVW9sQm05SzExaDVSdnN4YndrSms0VXNYeGVPUlNIOHZJSjdXVUJFcFN6QVBDcWdFVlN0QmF1QUNVYTVZVHlwY2xsTDhCNHBZc0E1VDI1WS9wWjNybHd2ekpCbnIxbkpnL2ZTVkhseEZscENzZW1aQjVVRVNVbEdoMW9IdXdvRUladllUYldkR2dqSTg3ZENwS3RGUjA1SkVFdWFxVzBaUmlGRXBMMys4RWxHa1RoRjJ2VHgzOUQrUFNOd1dFL3FKRG5yclUzeDQ3QkdYa2QwSnh6ck9nckV6NEJqZllEcVVaSVhkS2hUTHZpUFBIVjhzSkJsenlhTnFvekFRbFZnNlFDU0ljeVJoS05hSlVYZGV2YzBXVzhzdzd5d3ZsZTl1ZmhNbFdBNVNXNXNDNjg0bjlybnJ0RFFnT1haOFJCYkRrNFZtcmQvWHl6TzN4bTJBb2orWHc2NExPMkZLVE9yVVdhUlRka2JLYWQwU3o0N1cwS3lQYkFLVmt5VlVOcUFDRk5XUXBiVkRTMUptam5iS0RidnhsRmVMbVFsdHNLVEVZUmh0ZjloWncxMEVnd1J4VHRrOFc0cURTbDlYajhTQkdvVllnTVdVMmxNUXF1d042TGluNmluT3FGRXE5TkoyS0pIcE0zaXNkby94V1ZJcE8ycnpXNTJpdEFTMC9sQmVYRTBvTUd1ekxTSHh3ZXZhSXZkUnUxZkg1QzZkb1hIcnN3czN6MlluYnNia1pLRVUvbGJKVWVMcWxMSFFYbzZQM2N0UFZ1aFpHMEphd1lHVkJyM0poRWF2K3VPcFNodEhlQmt0cExHTXdRSW52bkp6eGs4b1pyMGFqM0liamswY3NvMDg0WGhwVURpclBNcUNzVld2SzRFUVV2RTdWTjNYMFRaSWhFUkFqVUpwSC85MUhxclVWNWYrTWVXRjNOUlk4bkdWOTNkT055WmlTVk5oSktxV2wvS3FjczRXenRjUS93T1JtQ1NYTWFuNzI2OHNHNVZQTEQ2Vzk3WXcrOWo5ejNwSi81WXV0SDVvN0d1Wm9sdkRjYkhhS3FPYzhONVJYTWlNUXgxL1pybmhRblNVbjRzWU5ZcW5mNy81Z3I1TFJRUk9xeG5tVmFPNmozVkl5SzVScHVZeThHZ1IzNGk3ZVFpVldQekYvanBJZTZpOHBSYkJsTDlTOFFSM0tqc1g0ZVBweVVkb1UzMnA1dXRZWWxJeVplbks1UXdXMVRxTW9uMEg1OUQyV01hcEdicUdsakFaRStGOWxEUkV5UkltV1VrQVpkM25sNGpnS3JRRW8xOHd2SjVSUTBIUG00cnJZZ2QwT2wrM2k3M1lRUlRDNlMveVJWODFRMnV2NUNicWZuTHUreWpKL1M2WjZqcEhQL214V21WNlBuRWNKWTVTWlpRM01WWWZVZThlZHZNNUtLRURRb0VUNGNMNWZxYTJncGwrem9XVEdCbE1VU2lxL1g4ME1LN3VNZE1haXRRTmVzQkJqc3RKM3k4clJCc3ljNk9rWTZFdnM2SHJWR05PMkJKVE1FbFBTS3N4b1FBckQ5eUpPYkE1SmpRQUdRbGtKMk1oU3lsSEs3NE4reElWUUtua2VkV1p6bE9kQktEZHZSaVRYcmwwdUtHRkVCS0VVaUZGRjIzZCtTZnd4N1dHQkVtWHNGWURjMHJXeWFHaklGNnVjUHgwU0szdDZMbnVBcy9lUGw2RHE5UlQ2MDJSaUpMOHJYRkhSaWkwbllPeFJDMTRZTHAvSUhMOGZvU3l2aUh0MG9CMENUYlo0ekFpbGFheklZaWx4djlCZjFJZlc1VkVtelF1dS9oZkhhV2poRmNOZUdGU1NRaFRLb2ZGNHg1VkJJcVJkSEp3a3MwUnNVR3BpVVNFRXF0eFN4UEVuUmllK1dsYStKSmJ5MjRBa1FBbS9HcEpvS2dISEY3NGxwYVI1QU1rRWxNL3UvTXZ5UUlsVmRzTDRJV2F4MXUzY3VyMTE1ODlmMmJtdVZaaFFjUkVTSnRVR0pXMk1TbnVaTXQzY3dRU3VIbHVtQi9pNmZ0UEw0Uk5IaHZKMnRxRnNQbklHVXErM2NpbEJMbE54RU9FZ3FqSVk1SmxqV0Q1RW15WmM5angwRGdlVW9UV0FNdHFkamxNNnFnaHlGRXJhaGRFTHBuVW9rV2dVWFV5QkR6UGd3S3V2NUZmNjhsa3g1ZkNpWGtqdWxJWTdZa3JCa2Jablg0ZURVSlArcm9OQi9kUHZEK011SUl5azJ3bURSaWkvZ1pieVIwSnFtbWNUTmdIaFFpYWppbGZnVVdWU1F2blJNa0dKVlhicldrVjBDQmY0clYrRkgyaENzblgwNTY5QTI1SFIxdTE4bTd6QXJ6Mm1iRHlZMUJjQjJXS0hjdXpJL0lXYzN0enh5dEhaM214RCtYRmtLRzF5dXlKc3NBQnpBcjZ1MFpqcWFTSFZUTGtJWlhGcU1xMUtoaVVxZWpRcE15U1pNYWJVKzNuRWZpZ09IbVoyZHNOVGxlZXpzT1RJSFM2a2VlRTRkUXV0L3RDa012bFNlNktPa1lhZ2JDbjZxckMvR0V1YmNWS290cFI4OHVtYlhEQjZFNkg4dHJDVWtzbzlxcVVVcFR3Z1JGSkx2QW9pK1VWQythelF4ZmVUdGEydlorcmxYMmZxclRRb1ZjV0c4dWxYWHZuNUsxdDMvL3dWRURlV1NiVzJ3c1VBSlg2cFphMm1UYnFUd25KWkoyMVFnbnJtOXA5Q0p5YUtLRTltMXcySTZTRXh5dWE4T2dzV1NCK0tpWkpIM3c1TFFobHdsMXBDcWN5VExpaEZLRXlyZmUzWE5MQWkxSnYvVVNoVHpqdlAxYUZrckpHbEF0Ukh0ZmtyUWdXRnlha1MybXdDWlZldW9wV2hLdDhKMVdKL3dRd2xVdGFucXJyUXFVMHM4OXpwNUtlLzBGSnZ6c1BTL2hPTWZSV1lEdVdQT0kvZitBNWMyN01ITGkvdWVmSDVlSHFJc3FLUFVzdURIU1c1Uk5vMWt1aTEvRnFDeVgvOExsUC9laU5USC80NldXV25VcVpvSGNkeDYzYXdsOXhZZ3ExTVZlT1dzcUUxbktCOGRaVWR5b013Z1F1SEtxTVdQNzNablhsRVJDbGV5RkxOd0djUDZTcDA5SHRZWUsxWnltNGR5amltSE9yUW9FeU5LUXY2SkpGeTZOcUtCK2dVY1phRTByWk1nUXdwY2VDMUJoTk90TUtraGJ4bWkzVW9WeGFyYURWZDdZbW1pNHRwVURJVlNxb09YcHVJWTB4WWQ0R3FUZWZ5SWZsb3NtNHdsVm9KcFRDUzlWcjA3d2dYTmg0T3FkY05ZRk5KSFVvY29ZeUk1T3U2SnFCOC9kUGYveXhMaysyWmV1TnRIS1lVVVA0R0FZditrVGUyZ3FIY3pVSGR3QjNZZFFxenJmZ0FrNlUwZHRLMkxDVjhpcVI2U1BaVmFQN2NGZVhrUEhVcnF4bGVNNDhvNTBSRWlmaVpjd1BCd0NUdFFEWG9CU0hUYTI4b2xCaFRkaEVveFZ0SEtLbktuaFZLbWxwa3JqdE9hdDlDTDZFdytXRUhVd1VscEFTdnVrMTVIOXB4TUwxNFlLRFlYVkFxRlpnL05CbGJXTHdMb1dUbVNjNVlNS3psM2ZMREZmS2ZYbWtMZzFDdGZHS1pKV0phc2t5RDhrVWhoUEtieUNSQ3FWbktaeUQxeXMwa1hFUkFHU0VKVUw2YmdQTEQzeDlzemxCMnBxVHdyN2NUVlhhN0pHUW80Y09PY3VmMTZWMXdDNExMVjlhSkszRFJIVjBqbEtiUW0xRWs5ZHNmekZ5M3pCUGhPbmozMGhXbU5CelluMkZmVi9IOUgrQThTbHVjRy9xWU8wWDFkZnJFaDIwVVNueElvMUN5ekRJN0ZJRVNOakVLSlQ0S25VUzEzNEU3MUt1WExLR1NVS0pqdmhDRVlkQ0dkQkVvcFJxRlV2N0pENlRzWGUzeVhkYmc4bjU0N3VudUsvekl3b0Z2ZmdNdEpjYVRhWlpTZEpTTW9Gd3JGQm5LTDhkUW92djZoeWVBc3AxQWVYRzd4QXQrSXdrUVh3RnRsUnZXYlgwYTcxSmtodExVV2Q1YVFYd3FzMWRQejVaSWg0L0Fnc3l5RFRFdm1yMTVJcE5qaUNoNU1jK3hsS1haR1YySzJmUDdheW1PVnBzWDZBMG1KWlRZNFEyenNzTlBDS1V4KzJxSDB2UGFxbjI2cG56OVJIWFJSeXkwbFJpdmxLMlFvSktsUTRsN2xwM1E5Y2JSNGhZWGx3NGxpb1g1bFJXNlg2MTdKRkJSc3l3aXBsdktiM05MS2FGOG5tc1BoL0tiY29UU0FHVzhFbVU5d3lQK3hKYnlUQUxLdDU0RXlvNVBmNjI3cis5ZGJFM1RUdTY4MW05QUNuYTAxU0F6bE5RbU5pQjJKYXNJWUd5TEZKVE14YjE2MkFkSE13WlNtdXVHOG1vdVI2Qk1GZk9LanlwTlZBdTVBUHU0UmhaUmcxSTVEVnNzTWVYU29NUnp6UXdsYmtGQjdhdDJ5aW81enRvUUw4SHpnbkUxcUF6TmxySVVWSld4SGlVQ0hQZUxiZTJXY1VxNyt5cXVGbHZLVFZSOWprK0htR2tPbHR5dFFQbnRPcFRjVXU0eFFFbHlyemcrR2E5eUJ3dWF6eitsNi9WZnJWbzZsSlVQRVVxaGQxT2hISDBGdEs1dUtIZkREUk9WbHM0RE9HaVdzV2F5M0FtckFDeUdFcUQ4NDcwTHA1ak04bHk0ZmRMOEVHRlh6MFJWcjdUMk5uMXA4akRmTXQ2YmNsNk0rSTVxVWhPV3N2NW9ackNVakQwaGxPUnpTN09VdUVXZEphTFpFL2RSUVljaURQclYwYzVBNzErcFFwblA0d2N6NVFZVEhmRnJsRW9hbEhpb1ZpaVRkVGt3U3h3N3NLQ3FMV2hVOFJHSjFZdkl3bnFzRGlXa1g3OVJyM3ZkWTRMeVd5RFpieUN5a2dSS1dJQlNMTjh6bTRUeUR6MUxoN0pzZ3hJeDNMcXJ0WFdYc0pxUWZ0MXBZSEoxdHZ1S1VKcVhaR1RhbHR5dDJ5Y3NFV1UwVkhudUUxYXZPTkFpU3BvWmF1YUdFdGRtWjBidkI0OHk3L2RYVW1jUnFzNldEbVVRMXA5SGl5bDdoeHF6bEpVSVN2eDJzSXhUZ3BZSVpSZ1ZIR0NlUnk4NnJZbTUzWXlsUTZsTW8rbjNnMEhNb3NJOTdZK2ZmYTBSOTFWVVN2bFQ5Tk9IWThWOW1melJBVTBtTFJES2I0c1JFWjU1amFFVUVTWDJBQkZGcjFpSkRrenk3blYxNXhVenIzSjl1MWZmU1VENXp5ZHdYNnQvZTB1cnNudm5UQnFVTzRGSmdTRlF1WnBiemQzclZyZEd0d0ZUcWVpYUJVcWptT2wydVAreTBST05kWGpzcjVkV0hHTWlOWFFoWTR4eUZkOTN5NW45a2FGa0RTOXg2cmgreTBMTjBHSFNtT2lSVUtkQlNTM2xaRVhUZU5oNDl0WHV2bElvOGUxNnVYTHlxOFJ0cWVFQkwvcWhNYWJNQnkyVDZCdTRDMHJwUkhGUWc1S3gxSEhLaGNWdVZmMmQycnZHSlg0bXVsUDZldVVDODFpYjNrZ1k0ZVJRUmhWMlB3SkxtUUxsOTJUL1pWeU1VaXZsV2N1NzE2M2xVRVpJeXZYdHRpV2gvSHZ6WndubExzNFp2NkNFODFyZklGSStvN3RTeFBjd1dFcnJpZ1htSFhJWDVzZE1nS0dhVDk2KytzbVZVNmVPSFF1UDNqaVVOYlVaMmxMeWlQSktEcDBhcTRROUNZWnh6QXd6SFU1RDQ1Uks4WURKVXZaMWpuUXFHc0gwaWhWS2xOZWdwVVJmUlRZV3dwblpPR05VcWc4ZGFRcWwwbG1zWTBWOGVMMnd1b2dPcFRSbnRLSW5IeWh5WGV5YXBZOTVCSDdMZUVvVEVpeFpaQTJjVGdnbDF6ZmlZcDQ5SUxnaWNxOXdpV1pzUmNLT2tsRS9kQ0JTRkE0b3E2WnZGU3VsZjVaUS91bHRVdnBLWUFQbkZUR01yS2JnYjNYRUtjb0tKWXFHQU9hMmRyLzRZemFUaHcrUE5hOGF1M3dORmdVNWZmWFcxZm1UNXZyMUtLTGNENnVIa0hrbDBrR2o3Y054S2tVNFVDWXVWSUJVa29vZUlWclJZNWdsNHZ1dUlnK1B6NUxvUVdGdGpnMUs5V0hCb3VLcUZrTVA1UHBxVTVGNmxRMUxnZExKTCtBN2F5a29IVWVLQTVQMm1CSnFYOGtRS2k1RHJRdzBNaS93c0ZrbkZzL3JnVkhta3ZNc2hsTE9vOVFxN0FTWllDb2pKbVBKVlFxaVFuUVFkMStsNjRxV2t1djlCSlMvKzluU29mdzdRaWw3MlFGc29OYlZzUUREM2Evc2xEY2k1eFh2SmJKUGNqYktVR0J6N09wY3J6SEpNOWJjYzZnWDFOUjA1UDdkdTVmblp1ZnZhY1U4OURHckhzemdQRW84SUFUVFhFM3ArYzVDZTJJVmdGSUR0YStsS1IxS1pwb2xRbktHRmlpSnROclhxblJmQzF5OU5LYVVjcXZLbk1YT2xnbXV6amExMVRQbVRrbE02ZUJiNkcwYlZIcHpJWlNXZGlDV3VlNzRWUm42SzZZbms5MmlQV3NraEdJSTVZdWc3MmhRdnZnakRpV0VrMHBUeVhwQUdZMkhpQ0ZLQVNYOFJrU0NnRW13bE51KzlGb21sQWNUYWhES2x4RktLY1J3OTI3QWNBZGMzYkhqd0c3UUtMK0d2MEk3NUI4VGxNeGV3MFBGb3FxZStlUHBXVlFBa2dhYUo3WmtPSzh5b2p4MzY1aTVReEJUb1dBb25uSndnNmx5b2wreGk5R1NyODRTNFZBeU9rdWtNT3hGcjVFNW41SXBxNkRhb1VSTEVTWm1pY0NXOE5GaUc2akRCR1U0b29SNGszVzE5eXBES0dqMEdZSFN3eG1uMVhGc1orUlM5NVd4OUc1MjlHVEFxbFlVM3g3bWg2c0YzVkdCaDJmV24rTVZNNVNpS1hvRXBleGZKNUhrVU1wQlNpMzVHdWQ0b25YVHhhcm83eVVHS2o5Vm9SejdXVUsxOWd4TnZvRlF5aXE3WGFzbGxwSzUxdDFnS0VlalRlb05LcjYvRWNvTTdpeURJemxJOWZSUzMzV3NSOXRJMVV1ZFYxRFBmUkZSTmpwTzZtSzhFNTB1cFU0RUE3dlpTU2o3dFU1eVRKdlhqOE41ZkpzRlNrM01BQ1gxLzhsOFNvNTF3RnVyNXNzRVNzTThtTlFrc3pHbVpFcWprVm9GdTRqdzdzNDBwclJiU2hTTFBuMVhmdnBSTHhBLzFQcXZGMWE2K3Bjb2hWSGJRS0g4VGgzS1BUR1VPTGtaZTZLRGNEd0VmZGZJZStWVUVpai9wdGJaL2ZQVHh5cEkvL0N0QkpRWFk5ZVVPSzlvTlROa0hLZGtKaUN0SXhOWHJzNGVTZUFGUnJMSnBrT3JZbXlSeWVZb29zeVJLWVdtTGowamRUbE90Q0VZaVF3Q0ZuREhEL2Y3MWM0RHNRM1EyMitaT3c5NHpEQTBaSUNTMkpYMHpnTk16TTQwUWNrd08wV0VYUVZnUHhPVVBrM0FGR0JwNThhaHhJeHAxcWN2TndTQlJtV2JHNnBBcXRjWlNjYnFNZVh6a2FXVTh5Z2xsSEtJVXN4dGxsQkdRUExmdFRoZGF3ME1VS0wzdWdGRTZ1d1VLTWQrOEhoVHR5SW1zYURudFdkMnIwczZyM0VNdVZHa2ZKVDdkeEVtTjlvcmVpem1JQjZMVjlyYTdmK2p6dVNZSFVuWWJkVVlSSnk5OGtaUFZQM1QrM0JtLy82cnAvUlhOTW9kR2EvR2dta1FVZVBSc0tLOHlHQWVEMXp2MFJQRXRKYTZHK25SSTVLY2V1VWVBbXFldXBXWXJxdzhZMGVuWXVHTWxqS0FleXdhREdqeEFFSzVtRExhNkdJRFdIdE1TU1ZaVWovOUFWOTZJOUNOZ0RiUlJPeVFSOE53U1FUbGkzVW9vMm1VRWtwWk53QU5CeVNSd0NUODdOMExhTW9KV3h4S3pMdUt6T3VHclFDbHJMTkRxWmJ5NzY4dllaSXoxZzY4OXh3djF0a1k4OWE2RzdSdVl3U2NzSnFqRzNkRlFBckJYNTFSQzVSazJSVVVac09UOEY0NWZibFo0YUNuVHByZFZzSjZJUkJscjFyVlBIWTRxbHdYeFR4bmM2UUZTUG9DK1VHbmtsa1lDbGkwRmF3UnFzM0h4d1JUdldrbTFQTVh0RzUyK0RFWTJvRmd2UlBXQUdZVnBET2xmNk15K2pLcHJEb1FFaWhsWFM0T05KcTFnR3N0RUNpeDBBQlZEVVROWVJxVXpPNitZaThXZFozMmJqaG9tY3FlVkk4c05PVUdrRlVLSmZpdUVzb1hZeWhCRVpSNnExZkE4YVY5Ky9hOTlQbk5hK3U5NnlJb0paSmZBbTFJZ2ZKMUJjcWVmeTRSeXFmcVVJSXgzQWtVU3UzY0RjN3JEZ25sS0FBcVBWa3F1NlcwaTBBYUY4NGROd1NMTml5YnQyanF1Y3NqeW1PVVFsSnVSOVphTEFDVTlmWHVhZ1JLSVhYSy9pVDJmZFZhemZTNUFDVjc3TDZ2ekdncDhkd2ovY09uZ3BoYUNxVXNvc2VtWG1iMWViaDZMSEZmTVZHRUFKVWNnQWVodERiT1lxa3hZS2pVeGZkQ2YwOXBLanNyNU91Q3RKakpYRjVkbE5mRlVINUZ1cTljQWtnd2xHcjdaUW5sY3dBa3YzQWk1ZFFRR1UwQ2xJRGxxMitTa3A0bmhySys5N3ZQN2VZQ1l5bnlOZ0xEMW8wN3VHVG1kY2ZxSFZTNHpkSjV3RjQ3UUptRXlybjkxeE1PNjViNzE2L2ZPSCtveVN4MFcxR3JUdkxPUEdkTkE2VjRQUTNLbGI2MGxOclFlbHRlU1lMZzd0anlPTEdhWFRlNmdnMUR5Wmg5U0FUbksyc1JsOWxTU21GSGN5SjlIUjBKRDRVU0IwS1ZUeW9KSmJmMjJaYVN0Z1ZHS0VIVFVTTkIyVytlUWlsZERPdFpobENLZjBYWlFOMVM3dVBOc29CTFJKSVBoa1JRaWhtVVlqeEVyYTZUaGhMMDR6Zk4xUU1IL3dDTzZPTkQrWmEwbE8rYzJRWWNjdXQ0WUtPSUlVRUhnRG1SakFXcktSamxFTWFqSWVJNjN4SnRhdHhTTXVOL0J0VUhWODhjMFZCN2NQc2E2TjdzK1VaQ1M4VlFmandEaGpKUmVtN0tOekdPWDBYckZoNDl5blhLNmxibGNhNTZ2cFRpSUVyOWJoOUVmNDNHbE1iMU91MVFwbmRqOXl4UU1zOHJHeGFMVkEzb1FHRE92cTZvVjYvalpvaStVeTBsUzdPVWNXTXZ1aEtZVTFFckdrTytEYUVrTWFVbGY4ZzBTd25TS3V3MndXWFRQdUJ5M3lZczVsSGRWMEZrSXFDRW9SRDQyUkJCK1ZRV2xQOVlFcFJ5WjZpeWc4aFJzQWRNcnViWFJqZktVVWhCcXpTV1J0bUhST3cxc1BSV3p0dXY0ZmZnV2wxenpYWXNZMlBaZk9MTVRKUjZSV1haY09hRjZscHN2T1U1UzFTR1RxNHNxV2FuTzYzWVIxLzdnRUJKWWtwalhZVzVRem9xMzYwbFhNeFFNbUcyL09FYUhzRkVDMnBpV0gzclFXaUcwaDFPUktWbDJBMmh0Q1o2ekpsMzlRdWo3QVNNWVROM01vUktlajdwMjVscUtTTWtkU2g1MmFzd2x3QWx6dGo2S3VESW1keTNWektKSmE5U0FrcFkyZXJINyt2Y3Zmekdad2ZsN0VhSlg2djh1N05PNEFGK28yNHNIenVtWktab1BrUHlVYkpYajBMZjJQeWRPcFIzNXJBdzF0WTE1SER6Zlp4SDJWaVlHMVRWdkduQXVEeC8wVFFyMTFYV0xTajBRKzlnanBLZjA5YXo5T0s2QU5hUSs4cFlwcVZFa0JrWkUyMWFCSjlQcG9sU1kwbzlSenBZOGxCQmFWeFBHY3VYb2xCS2J4NjE0RGNPWll2dkpxVDh6d1RqV29QMHFJaEFXNmw2d00xSXRKS2JCTXB2Q2loZkJDYUY5bkVvK1NwYndHU2t2ZnVFWHRxM2QwME1wYXdaQUVYUkpEQ1pDdVVZUXZuN1QxOS9JaWgzclFZc1c4RjczYmhSeEpDdE95QzYzQWhSWldRMUQwUm05TURxamFwV1J4ZGcwZ0NsQ1VQV0lCM1FkZWQ0d2xEZXVYTkgvTG5jMDZBTEM0YnlwcWg2WlZneEl5NkdkbExpRkovdVZScWtCL25BZFlOOGk3NldzT0o0YWF1Y2RuUVZBOWR6OC82MFZoaUdBMnRQdU1BUHRURTRvUnBuVU1FaGVIRFFmanFVWGxEVnl4cHdOcXRHOXlQWFVQdkt3SjU1eUE0NnV3MUN1WEtrTXlIVFl2Vjl1UkwvOUdYeEJnYTdJR2JwYW1HQ0VpcGVSYkpIekErUmxuS2Yxc0Z1THljU2pPVkxIRXBaOUNxaDVON3IxZzFjb3dMS3hMcXhMLy91eWFHVW1QL2xON3NFWTZPanNmTXFOY3B2QUhTdGNBVzNFelVPcGJJdERWaDl1TzdLMlhzUGUyTTZMdCs1ZHVmZVBKUzVDaTZqTzZob3d3RVJVVHE1ckw0UkxORjE1MUc3YWdJbWNtRnVaS0NTbkx5RnJkNkNSZFdONndJZXZKRkYvaFNZd3NVWFpEU21OSGY3WTQzRmxJeXZuNFVxRDRXQXBKY2JHZExMN0xBTE0yN3Z3QkZVSnVlYmtkWUJGRXJhQjdMVzZhVkN5VkxXRXVtdEpOVTNnbTY1WG14VUhjNkZZVzZvVEpmRlpBMEZRa1lvbi8rZVhMYjVlV0VwMVZLZWw2U2hGRkN1VWFDTVJpZ2pPeWtzNWVoN0NTZy8vQmxDK2JNM2xnQWxscjRDa3lEZ2NWVFF0N051RWRjSlQzYmpEcmdJWTNrQXJnakJmZkFyeEEycTNYMmxMSkt1dzBUSFR1Mi9qQ1d0dlhOMzdsMC9Ec1U1NSsvT2N6eFBORlJKUUthSGFQV3V5VC9xdW82b0RtaDNVOFlUQlR2WWlNZVErR3F5T2o3ZVY5YWJXTGhxWWt1SDByUDBzaUJRSXJVS3ZLVkhpVU5ZV0JpdmxxTnRDR1gwQUszc3BnOXBJRU1QZlFFeldrcm85NWNvQnc1eDlkaEdKemxycXhJeFdmWHJoVldOZHZqMHE1UGF6RGw4WGpPYjhpNjBsTi9oUkdwUWdqaVUrN2lsck9kNHZ2b1MxMTc0a1paU1RnNFJhVmY0QnkybEhjcm1OMTVQNk8wTXZaV3dsTzhMMU1CVjNTa2lTR0FQdEI1KytKWUQ2em1FNi9tTlVkZ3ZsbnA5ZlJhVUZBT1dPaU9DMFVXWlp3ODJLVkJlZXlDdm5yZ01idXpjb2FZRzFIejRCa1NVRjA1Ulo1VW1QTW15QlVRNHNkZUpzL0VNbXlFYk5EbVVad3FVeEgybFlSRE9uYUZRWWdzSHZkT1VhWkNESm5xMFJmcjZBKzM5ZTY0YVR6dWhFVXFHWFVBdytjS2gxTXZzV09OUTRuTDFnOWx0TTVSWnpuaUZPbDBzSGNwdkNpajM3SkZRdnJBSm9heUhrM3UvRGhWMkhNNHY0TlFRanVTWEFjaXRHRkdDMXAxNU0yRU0xWXIwdi85T2w2WDBWYThkZUEyWUEzczNDa1NLMFpDTlhMQnRWUFZZMTY4ZWJZVzlpUGcyQTVUNFNWRlgwVjRPKzRFK1Q2VDM0NGRZSFhCKy9zNmQrdzJWRXh5Y3UzUlVtMGRKcjFDNUV4MVprTFg0anY3UUFPeUxXZDE1VHkxWG9sRFNLTmZ1dnVwenozaFVXYk5ES1Uydm1wUWR4bFZvU2ZxMHNESmFMWUJDS1o0bC9ockFXZHptTWpzN2xQSVE5QndTMVdROEhNWG9aMFZ2VUNqUmZRVTdpVkNDUk9JVjlGV1lRaW1nL1B5enNwK2tjRjIzNGZna0tCM0tsd0ZLMU05MHRSZk1xdjNyMTBrb2hYYXNBeVlSdy9XUjg3bytobkxuemxRcXpWRFM5c3YyTVFtMTl2V3VocDJXMmpreWQrZmF5YVpHQkhtZXExZHNxYVhrRjRlZjhXVmRXQ3pKdzhlb01vL1R0SWlxVHFDNUJpU216UHlPWURZb2NhWGJkaXVVOEtCRS9VODU1K2xRbG9ZbTFiRjd4eFJUUXJhb1d5OThaZWdaTHdWS3hWbnhwOHlmWmtFMEhxQmlodXBYaEZKWkpGWmMyZmY4dnE5QWZaMkVVcVplWHhDV0VncGU5eUtVRVpQYlFJVEpkYk0vVFJhL1preW96UEx0T2o1TVFQbWVtdGVwazdkZWpGd3FHSEpET3JwaktWRFNVTW11M0tuVHMxdXlsaTY0Y1dlV3YwbTdIdXcvZXlwelBVcTZHYzg0cXZiQklDUkpxdEJmYVRybnhvRkpmUnJJazJkZjA1WXpDLzJCeWNZc3BUcUNPaDJFMnJNeFZ4MjdyNFNlQVVxUXI0NVNWQ080ay9NcFdlTlFLb2NCYjZWbVluSTZjQmx4OUNtaG1WQitCY3RlWHhEYUpGSTdZRGVqa1BJTHNKQ1BnSEx6czJ1MEtaUWdSRkxvMVNTVS8xeGk1NEhLM3hMdTY3dVNMVEVBc201OURDR1BJbU8xUXJTNUU1QmRFcFEyS0NnZXgyNWR1cHRXMVhyaTQrdHpjNWZ2bjFqVmMvOGF0NlIySGJsNTlZcHBCQXRGcU95dnBaNFVsUUUvVEhsalliNnJYRWhqWWNFSmhJV3lsdG14dEtRMHMzWklSNXpDWUlnZUFpMEFaRnBIbjRFZ21RRExLL2RPZGdXT0NVb214L054K1MyTHBhdzFDS1dJZWdjN3hQOHRYZENGOTNKdlhJeEFDVWdpbFBzRWxEQVdzbWtQcDFLVW9JTjRYeDRKSlJjMWxNSks4dCtMbngyVXBQUTFEY01ESE1JZEFCei9BV0FGa3FBRElvNlUyN09odEJObzN1UFkxVm55SG5wUFhMNTNlMzUyRHRwLzNMNDNkK1QrdmZOTmplamhERGVWbVVoU1pMMWdZcUZXU0NKVzZSOEowcWQvT3NHS3dYSjc0bmhyZlYySms0aEZVTWFTVTdjMEdLbWx4UDBmWVFoSUZZUUQxY2tVTG52YkoydmxLUWlFNnpBVjZtcVg5ZllvQjVwRTR0M1RKUWxsMEIxdm5Cd29zYWpndG9ySEJYQkxLQ2ZqYlVsTFdUQXJnbEtOdXp1bk8raW4zejNoV3hwV2tPcG1oQkxYYlVZbzZ5dmZiZG9YUS9uTTU4VnNyUmpLTDhmVG1yZUtLdlNucGRieHkvWlgvNUlJS3YrK1JDai84SFlDeWpPUTFBRWRBT1FnaG93RWFSKzhBWUtia1hpWVNXUXBTTGVLdGg4N2UrNnZUUWtkdm52djluVVpTSjY4ZnZ2YWpjdHpZdzJaeWpOUkZ6djc5NE8rYkhwK2VMcmNVYXROQ3RWcUhaWHhnVEFQakxGb2Q1b0FYVEhRVnhFUGFCZjdsNmVIL2JSMmlHNUxkMTNUQTZHWGZod29iOFhnZFB5QWlkQncrUElRZ3E3cGFuUU04aUE2S3VXK2hmNmhUcytMOHp3VDJPQ3hiUVJmbnR3TkduQ2xRK2tOeGNldzJCSVpkeS9FNDJycmxPMU9nbUY4OUVwUGZkck9OdGpib09sK2VSdzROdU5DZjBuOTArOGJIQ201eGtSZDlvTE9DQ1VnaVZCK1JVTDVoWmRpS0VVTEVJUnlqYVJ5SzVkTXUyNkl1VnhIb2Z6QndhVkJXYTVEaVZWMkFrTmhCM2tlZHIxa2REUzZnc0J5VWtHdGp3RWxzNlE2bVFIS1cvTkhFbC8zUjJhdjNWQWdiSDU0Ky9abDJNZXUzcnNRVlJweXZFUXM1b0l4djdSaVltaHFZR0J3Y0dCcVpkZUVreTk1bUhhbEhYOGRyK1NQREE5TlRRMUUrM3RGUDlVWGdQMktkUkc3bTJhRi9XS3hKRlFzZVN4ei9USW56SmZjenBhdWxWUGlvQjhORGJkMGhrR3BtQTg4eFFuSUY3bEsvRWs5Um4wRXVFUGNCN3NFVHV4RXd5M1lFaDBESGxla1VueGNqZ3Q3U0FYNENURW1YaFVlTEY4NmVyWjRTejVNbkNlZ29PUk44RGNTZlpvdEkzN0pkVElYdzZPVU1xWkRDVXpXMTZPVWxqSXFlVVVvOThwNXpUS21qR1pyY1NpVmVMSStIQ0tnZkQ4QjVSdExoSEw4N1VTVjNieWdiQlJ3QXd4UmFCRVJXTmhwZDhOUUtyNkV2TUtNcm1PeXcrUFYyYVM5dTMzdlpNSnl6bUZmU2FJdFNoYm8vTXpWWXdnL0FWQVh3OE54SE5mUGwrUjVsL2RoWWowWjN0RnpmczRLTjE4cXhmczdqdkxtMUY2V1Rpek1BUmtkTUFhNHg2S1R0Sk5ZT2w2QUIxM0s1d00zakY2SG9TK0pXcUdLM3EyOGdycFJ2bkZsR3g1VHlvTnhaNk53VGlRK3d2SElwNCtOeFpoeGpJMlJYQ3dqN3V2M0VFcXVMMndTUUlLK0VFV1VFc3ExVWRtQXNKTWt5U080UEpDc3MvdDBpVkQrS1FrbFVJYk9LeEVDRzdtMUFHZkRVRkx3VUtTaE5WT2dESTllVDZSNFp2V0ZETFk4dVAveCtkbjB1cDdla3cvbjVoL2k3Wk0zNVVnbEZWMUtnZW5XVHhIdWl0ZndZZktPN0JQTlBQQ1I0VFhRcG0xSU9ENWU1d2VGTDArdklBRFdCb05ZSXhPOUdMUHNUYi9tRFBzbjJ5MFlQMzNhOU02NHZrOFNXMjRwb2R1QWxKZ2RFcm12OVNXMjluR0pwdWpQUFNNTXBZQnk3MXF3a1ZHV0o3S1VxdnU2RGdTVzhqT0NzdkRuWHllZ1BGQzNoYTFmUzBYeWF3Slk2ZFZ1UExEamEyUUhHNVRNc0p5d3NRN1B1NWxJNHR5SStSTnRRVmJ4b3A1cjkrN005ZWpEbUlVanh6KytQbnZ2enIwNXhZaENmMG5zTHNsMEdpbUw5SUFvRi9iUTJQek1lSnV1VG1OK1lXYUdtbHA3MmpmVHRJZDk3TmJvVFNUT2U5TThWYVRTWEM2U2NiZjVtNFRLWExISjI0RkVwYStjU1Y1Y3R5bUtLZVVDc1ZFNENhcXZzYlZHUUFsbWtrS0pTSUlPdlBmVFJPdXNwVUhaL2tZQ3l2Y0JxeWp6dWo2ZHlSMXFJTW5MMWdtVjFoNDlkbWs5NjNObmIrcmg0b2w3TitxKzZQbGVVZE56Nzg3dDJkbHJkeDdFNW5EdSt2M3JjN08zNzEyN2MyM3UvSkZWcXBXOVBuTWhaN1RhelBUZFRlR2tPNUN6azRvWlVMZUpXVGFpZ2JVOHVmMmw2S21mUlRSamRwZ05zRFIrS0hZeDgvR3dsT0tCNy85SWFJL1FpL3YySVpUZ3ZuNEZSMFBFdWlHYkkwc0pQTUpGSkY2M1JVdytQUXBBSXBYYlc5OU5RUG5ESjRUeWh3cVVZZ0JrWThRZy9JaS9YNE5yL0YvcHZINk5LN0thQjNBL3U2VzBuN0QwV3U3Q2JFL0NVRzZwWDVNbThQTGRMYzFqSitabjY3bWY0L2Z1UkRPNzV1OUtJbEYzWjY0eU1zblp0QnFmWGZZVHRYRVk2TDcyVFl3MU5BbU9lbmxQcm15MzFiS1JQY2FIWVFmTnZndUZFckdVdFFOeWdWajRzMWZtZU1CM2hXNVpDQ1ZnS1F3bEJwUG92SUxPSktFY08waGxyK2lwZmZwV29xRG5hNUV0M01FUmpIRUVpWnZpVG1RU2JvQit2RVBja050TVVCcXRrWTBDZ1BKTWs2Ylo2NGZxOEcxQkx4WXNhTndiNU1nOHVMUHpseDlzV1VXSG5lL1BZT2NCR2d6KzM0aFo5Ti8xVVRCR3QxZ3RKZlNVMUtIOEZrZ3NVaUR0SkFjU0pLSGtFbzJYdDNJckdWZlhJWlFYNXlNb1VUODA2eDkvVS9XNVA2bFFmcGlFVXFSNVNQNEdnT1RFUlZUdUVCdGt5a2NsMkc0cGFWREJTSnhGb1p6VjBOb3lmejdSMXU2UWhQVHV3N2l5NFB6eEk5RkdBNVRzL3duQS8zMG8wNW9IazN1b3BkekRmeEJLa0xydTNYTlJxNncxRVpUYjRrWlpZb3hTZzNLNzBDNEM1Y3RtNmZNcDM5YWdsRlYyV05ERFRkNk9BL3hmRGhpUnZGTmNBTjQ2bEZ4eTd5OGFMQ1cxUnl4MU5tVWFsQWRWcW83ZlBwRXNmYjFmOTJLYjdMbzd3N3UrR3NTVzUwVC9ueUxnditQTjBKeTIxbUpTK3E0dm9xV1VBeUpjQU9VemthWGtuVjdYckgwSjlIT2xleDNXb1hORmRySVZvUHpKTzlnUXhLWUVsTDlTNjlGL25Tem9BY0JpeFZDbTB5bDQ1TU1pdU0wTXBUMXZhVWlwaU5xQlhqT1VSODVmdm5QN2ZEUDA3YmwvRGVDMHFlZnl6TkZiTVpUL0JYN3JmeHdELzNFSEpNVWFhZlVVUWZrOFRtM2VCQmZRUzV1MFRxK2d6V0lwU29SU2pGQ1NDVnZyaEZxRkFNbzNsd3JsSDlUU1Z4T1VkZ25uOWNBWHVlWDhvaDFLeERGck1YV2FQcFJESW1wSDlKTTZsQTk0UjVCN2MzZnZ6dDI3OXJDUk9yczZsSi8xMmZOa3ArcC9qNDM5TjN0bi85Tm1GY1h4LzBtZnpIbTdnRU9jQm1YUnFacy80Sk5saVNhUytGTGphMUlUZm1tSXZNUTQwRGhLUWxMU3pGbWpscGRVUXhtU0VkQ3VqSVl3YXZFRkprYW1pQ3pOVEdEYkQ1NTdudFBlK3p5bmwwdkZKWnZ5WGRmbjViWVBmWkorZXM0OTk5eHo5L0tCYnRmTk9HeDB4akVORndHVTMraFEwam9GcW9EZGcvY2ZSRDFFUzZsN1VCNDg1YS95U2thU21DUW9nM2wyN2I3VlEzYUE4dno3K3Z5K0lKVGpBZlRxMkdGZEhUNmg4M3BPbnVraEt1dXNsbEpuMFR5aG1VUFp1eFFWV2s3ZDdJWS9sK2RuV1QwTFZNeGFMV1hIdmVudjBYMzFXZVU3eE9QYTE1N2tzQTE3UVJCS1hDQVdwZGQ1VlNPVXlLUUhaY3ZEdUlZNkVxbVFKTmVWb1B3Nm1HZlh1YW1wczkwSTVjeDFmV0o4VnhES3I0RTNrdHhEMFBBWkRvbEk3NXpudk1MK0dZcS9FcFIxQmloM2lwTTdPNGZLWDU4YUYzRXRiSk9sTEFHU20vMFpWWnljTGRtZ2pNVnlXUGZWTUJCeVo1dW9mZTB5d2NFNHVLS2d4THJvejREMGxlOFVreTBhazQwdENDVk8xNklhcnloQ0VwZzBRcm1WTDVTVkwyeCt0anNvTzVZRHVRTmZLaWgxTkxrZTdYa1RPcE93UTNCcU1rTVpDTUh5dFg2Y3F2M0wxcm5aVkRLa0hOajFRRUpkcURRK081dmRpSzVlc2Vha2k3NzFzZDRwcDVWVmRQbTN2YmovUjh6bmpoZlBHa1FvTVpmbk9RVHpaWUt5VXVuMUlJZ1cyUEtnUE5xQ1dYWTBoVktIVW5LcG1IemhiWmJTc3htRkpadmhuOXlJUzJZb3oyOTlvV1haUldaOFVMYi84UzV5eGFuMHpDWHRrUFBhZzhkbkVNNnlXMnUybEdacnlQMy80TlN0ajMrSXVrS1JOWnVOQlV0aXhVUDNwdGFXT214Um5wQmNjMnNSVXJudmhoRFB2dllneDlRclFpZ3JhOTg5UXBieWVSQWhLUVZJbHFGc0pDZ2Z4cmdyTjVSQUpYQ0owZGN3eTdPTGFpazhPMEY1UzRmeTZRQ1V2My9OVFNRN2cvYnhIT1FRMFA0WkJOVm1LY2trMlZPd3F2bXYyYWlyT2JDbGFqT2FROWxaMTlhampQZHR6UGVPK0ZkV3Yyc0IzVGZDcGl3Q3Znb3RoL0k1TmJVWjlIekZlejNvczVTSFFXWW9ENzJBQWlUaFA2eC9IcjY2QTVTeG9SMmdIUHBjZy9LV25qdEFVSElJVldlU3VwbG9LY093eGVNZXBKSWFMZEZYNTUrRXR5L01YZmtocGxOWi9JNVJHWlhuT3NoVXhsS3BXQlVtazBrd2xGajRkVi8vZVJsK2F4RktyUWdJdXE4VTVkRXRKWTZGQUpJTmpVZFBJNVNCZ3BMZ3U3NXdoS0I4NEVsYXJYVTZDR1ZCV3cwdjB0NXVndktuU0llVytycmxYNXp5eTkrSUxXSlBja2xQZXRRSEh0SStVbVFIK0VTajZiM2NES1U1a0cxVDYrc2oyV1RTVFZaQUM0MnY1WVFQT0hmcHUxVTRQekhoQ3ZCUjA4VjBGU1pEYmw5dWZnUzdsSTRoQlpzckw1Ymh1VitJQ0d4V1JONXZkcUFWbm1VcmJLQlZ2eXB2dEtsdEpTOUVQdExHR3lMUTBEWE0zeUZJL3FhTVlPZlpoWmk2aE1oVS93UE5jaWNpOEQ2VThCekpmQ04yRFJTRVNDemI3MW4vbzh1NFIzL1pMZzRsVG0yV3EvdThKeGNSb2FSWHFRZHBOTVFib1BSVzhqa29vZVJ6S0k4QWxVK3FLTS9iWUNySGQ0SnkrNEFaeWhVZHlrME9KV0JXaStyRDRNanFrUjQ3bERvRnUvdTV1enczLzhPOXJwdXNmUFRZd3M5Wkxkb1RTODkrZHcyM1M2c2J1ZlhWRGJjcWsyZ29SMzVVUlhyWVZDT3VqTWpBYzBTSUZUem9xcUZWTlNJb1hWWW1Dd0tWY1FJcU4vUTdRZFVLWmZsQzkzQWxxbjdGSzYvTzJLSGtOMks2VTM2TlJKdmhHdjNWM29DL2I4UDhMN1BDM2t6a3Zrb29RWTk1SmRFZlF5WlJhb0FTUkZDaXBUeUtUQ29zY1ZySUVjOVN2djBrR0VwcEs4YzcyLzBaNlRkMUtEdk5VQzdyazBSbUFsQmVyV2ZRMFQ4UzdXaUhGSVpWcDJxdDBlTVladzA2ZW9IMGxIRFJWcEpXcjZ3Vk55YmpIZmUrNUU2V0Z0YksrYkNoeWNrYzVhc3pKdDNRRWhsS0xTYkg4di80ZDhEN1NtYndpeHV4dDVvYkxWb1dpV0hIV1JaaTBQRXJJaHZhb0xtTlFXbThLcld3anp0d1Qxc1hRd0MvNG9VRU1zeWhYTWFkNmxBYWIwUStpMEVyazgxNCtXRjRadGVHYStBOVY2TzR1YnpEKzVRTVV0cm9VR0xGQVJ3T2VZUUt2UUtWQmlnYkpaVGQzYWUwQ2lCSEtQTDZKQ0lwOVlCSDVUaW05R2hRYmtlMXhaeHZtS0c4cVZlWVZyWHNPSlFrSFVmZUNzNXJ6NXM5ZFhZb3pWNnFXalBVSEp1OThPMTh0aS9rb3pLMVByNjJOcHZOWm1mWDFySWx2V0RQdWx1ZHlhaDBYdEZRT2tqanJvejFBSDREOGtJazhKczVZRzgxTjFxVUZ5c0tKOTdRVnNWczJLRmtEaldDTUZDRjE1V3VLbThSSWlNS3lHekdBcVh0UmtpY1BRL2pndkdlK1IvTjRPZlB3RmJzVUo2SEQzc3BLT1dDUHNBa1FhbWNWeS9sbFpnc3IzbDNFSmlVN3FzdnRZNkNydmdNbnF2VUNVcnBNVUw1bVFIS0dWL3E2d2RCS0tlcjAxaHZkbDU3ZW5xd1IybUYwanpMaHBzcUR1MmZjL09ySXU2NjhhaVd5NU8rdHBBZHp4WkxhVGlwSkVvNS9YQ2lOT0d0R3RzM09kMExobkswVmZzbzlqV2ttOUVIRkFVaDJ1UVBlck85MWQ2NE0wZVJTTUJnRGVKMTBBT3VGVXIrYVUxdEJkRWZFWmxxbDRHUEwxR0lXS0MwM3dnWGt1VzdrdjJlNWVkQVlHRkw3N0lrcHVndER2VXBuNUZacjQrUit4b004bEI2SFVGNXNoc3M1VmxnOGhBeHFZMkdrSjFFS01GU2Z2aTdIOG9EUTFGOU5Uek10V05RbnYvcHA2MFA5Q3k3QUpRZmZXaUNqenV1RkhrRlEzbUd6bGlodE0rb05GZEErbk5xN1pwd1FjS1hvU05DZk1wa2VxTmlUVGVnL3NDU2U2K1E3NU5acjZiUUs5RnArb1lOaTY2TUdJYVlUWUpPNnY2ajQ3VTYwT29vOFVaMlpjNUZucm1WMUhuQzh5c2lzemNvNlVKY2FKS2FzWmxmQnUxU2x4aTJRc2x2eEs2Q2Q5SG00V0hqUGZNL0NxNjJ4RFlEdTd2ckVoR2ZHcFRZb1FROUEwSlg5Z21jSEFLK2F3czVyN1RDRmxqS2JyQ1VaMVZ2a29EMG9KVHhuYkpPbUtBazVUUGJsenFKUzRKeTV2ejU2N2UyMy9lVnRlMHEyMDhmbFBYMWxZNmszS05EZUZidzBSNDVyOVJjajdKQ3lXVXYxSXpkeWlzYmZTNG9GTE90R0FKUXhsSzVqWTMxWXJFMGtWNFNTZm11MUFJd09USjN3VnpNMGpIOGxpOERqWkZsK1BZd1U4SmFMWTNXbUVlK3YvcDV0YTBkU2p0RUdDUE9rNHZOTHJNaTdWSkN0Rm1ndE42SStXUFdkTS9TY3NORCt0dXFrWGxXNXVVeENFcVY5ZnI4WTdJaytoT2VvYVI2QTRlZlBZeFE0clRtcytDOW5wYkRJWWNVbENBdjZBcDJNaHgrSUl4UW52ajZrMEQ0OVpJT1pWODBsTWpmSE5vOFVKNVBPWFBmVnVUOXQ0SUxUS3o0b1d6LzVjTnFOdEtzOExtZWN6MlArbDlpaE5KaE9jTWNDSE9GS2djV0ZMbHlyUzhPZk1XRklUZWdJeGFMUmFNaVhTd3RGWmRLazI1SW10R09ZZ3JlRTUyUWRySjNVV09TVndYaXArbTNPaUlHcE11VUVSRkxxNlhSR3VtUm93T0R0VUJKMmpPVXk5Sk5MRWo4MkdVRzRDNEd3VGFabzY4Unc0M2NMaWpoZ3c2RDdSN0F4cHAvNEQwb1FlV3NWNndwK1FSTURxSGl5eWpKSkUyaGxKYnlkS1hZZ0Q4SlhjSVlCaW9KeWtCS3oyZWJCS1cyeWs4U3dMeDBvN1B6dnV1M1BuM3JEV1VpVFZCK3FiTHNkTHRZYjFKZER5aXNuNENIR2NxYWxsVG5oSXgrTy9MOXVodHlRY2xvaDhaaVZDVGpibW95RGJZeFYxcGZLbWF6cFFuUlVYbEZjVEtlN0V0N1RJN3laQ0tITm1ZYklnQ3BRWWgwUVBCaHdONXFiclJyZURtQm93QzNFOHJocW9NVmVmbnlGVUNQWHdic0V0ekppaDFLZmlPM0M4b1ZlRmRldFBGR1IxVjhaaTI2cFVRazRZRWpsQjZVWHNXQmgwQnlHcVczT0t6WHB6eUxVQ0tSbXZkNkJKa2trYVU4Wm9DU3E3QnRYT3ZsbGpZaVFsRFcxNkF6d09TWjREdWFiSUVleTRKWDVpcGxyVDllbk0rbVJES0FaU2kzdEFBcUZ0YzMwaE1wNkhOT3J2dnJmK1NpOFd2emtzbXBVZU5uMEk5WXlLRTVMNkRUbGJnSDlpeXR0a2E3K2hQc3BYdDNYem1VL0pNTzRvOUlHNytNdEV2TFlxQTZsSllidVUxUWd2RnVGZ1hlYUhXREZKUnFkZ2haU29pOTR0Um1LZ0VDVU5MNldrY1J5a04rNzVYc3BBYmxDWUR5N2VrZ2xBbERRVHZWQjdOQytjbTdOU0RaRk80QkhXdmFQWlJPRmRnTS9qKzNaYkFkQlNxbmMwbmhlbGpHUEM1RHFhV2xpYVRlcDF6eTNYRTZON0V3M3l1Wk5HQm9FUVVXRW1KQUpDeXR0a2E3RUpyKzJ4VG82YTk4MDNuMGhEUlE1VExRSjg2TFppT1U5aHV4QjNyNk01a2FBajB5ak53dmxuRzN4alJtZ3BJNmxKRHdTb0oxNzU1NTVZbVdnelJmQ3g0QUpTSjU2bVEzU0VLcElxK1V4UE1BRElZb0tFRU15aHY1dnBwTFRHN3RBVXJtdk5xaFZPTVBodkw4ZU1DcU0xTWJlckJUWS9QRnlhaUhaVHhFWEc3ay9BdU5MTG0rd3dXWTF3d3hua1VjREtsZEJRRnhlWXphY0NnTXJiWkdvM0VveDJ4OWtzTUREc3NZUXRVY2ZSMzB1bnc4SkVWYTRaY0JsZ3NRQnJKQXlVL3JiN0FQaVNScUdCS1IzallNNGFpL0g2d1JULytNVUphalBKVlpsRjk1cXpZLzY5WGxBU3pSVEdKRnlZY0pTcENxL2xFTzg0REtvVmQ0QUpSZnNqeTdtcUc4SHN5eTJ6MlVUWjd6eWhzc3lRTnFvMEQwb2NnblY2b2pTQ0pZN0oyZlhwMk1oVndVOUJaRkZLRDBtY2JVNm9SMkZFdGlkL0xpM0FWS2VXVzVDdGJ3QzNXNEVtTEYwbXBwdEtjcHlKdzZuazRIQStuVXNEY28yK2hrbmtGSkRWMml3QnVrWFJMTEJpaE5OOElIL3JtSXhqYjg5ZXFxSVhuQWl5UTFzNy92c0hncmM3NElTb3J5WUVsMFNlV0RIcFFZZWozOGJLTnZkZGpHczkxbkVVcFZhVUF4cWFCRVRSOW85ME41TTdwWEtEKzYybFNqODFyWFZLT2w1TEZydTNSbVIwZm5MbzdOVHk5TnhLSnhseFFOUU9tdXAzVW8rNHE5NExwK0MweVNqS3RPbUxNekI3eE52N1hWM01pYk9ES1pObE5tMlRETGpxdlZmZlZzYlFKUytDSXN2WFlBYlRHMk5EUHE1WStDNk9jV0hGL3VWQkhlQ0tVRjJsNHYwK3l3b1o5ZmU5akJlK1lOT0VFZ3I2NW4reUxwalFTbDU3eEtlWGtEWlV2cGpVOGVKaVpsWFo2blRrb29HeEZLRWtGSlJJWkJKMGlRWjdkWEtMOG9RM2xnVjFBMjRYL2FKK2NWVGdUZVk4MTlaWEV4dGpLTnNaZUFWUDQ0TlRJMk5sMHN1YkdReDJWZnpnOWxzcFRUb1F5VnhrWVc3N25BTDgySU4vYU54Q0J0TEszV1JnNGw3OWdwZm5seTloNmhIRXg0UG1vUXloWDZkZzhqSEF6S0x2ajQxYUVrR2M3Mzd3TGlpRFVKbjc4QlBmb3VIVXJFa3VBMFpOMHhLSitIUnlYbDlmNVhRTjB3SW5JWVJIYVM2a25pT09YSlN0M2xGMURJcEJaNkxVTVp5TE03c0hVekZPMnJCY29Qbmc0bTlJei82a2VzcVltMmNrYytVTHJ6MnVRVEhGb3NKV3ozdU1oTTY2Z3pOOVhiTy9iOWRERWRoMkdmdUN0eXVhZ3Z6VFhuczVSSldHakxHVFhYdTdkS0lEOXR1TEcybWh2dHJ0OUFSb2dFelZheVQyT3lROGsxQ0h6bEkvY0UzRmZsejRMZDRwZWhIcDlsbG9qaFJxenU3a0FCUDFJdFU3Y292NSs3cjRhaEVHNHAwWGtsMTFYTjJFSXdHNURKUm9ra1FubW84U3pvcEdRU1pqVWY4cUQwRFllRUFVa09KVkhaZWVQU2RyNnZiMWRRdnRFMXRIbTlraENyb0d3aUZzdHMwbkZsanhCbHppc1JhWGRmSGZXa2UvcTgrS1RaWExhMkFwWWpIcGZydVZROG1zNEpIY3ErOUtSK0dFOU5xMklEd2FwNis3WHMvaXV5ek5uaVVBYnExN1U4SktGOGo2Q0VJQTh5Q1ZBMmdLV1VVS0l3OG9wSUt1Rm9TQmlXdTNyMEJPVFpzUnJwc0hqQjV0RE5SQkl5Qjh4UXZ2VEdCeXRiQU9UTWpJS1NzSjQ5aHVBUlg5b1dwVkY2VERMNXFHSlh0WnFodE5zbk15R2N6UjhCUytCeWJCN0lMSmI4bG5KU2h6SVdkN085Y3hmdTVzSWYrN0tJaCswQ25TVU9wYXlVcFVNSkdhOWtLU25LYzRxS3ZCNXE2RVpMQ2NMQUswbEhranFWQU9XN0JDVURzNzN6MG5ZaGtSQUFKb1B5cGMvZjZob0NJRW1CaEo1ZlpvK0VrVVJTUFQweG9mTUtMNjBxeTZwYjFzWEs3SzNVdDF5OE9FSmdyc2Q4bG5JeTNhRkRHUytPTFY0MlhQeHVxWk8rTHp1VVhHWW9uNUJoSG8xSkJTVW0xMUdRaDZBRUtzOVIxZ0JGZU1wUVF0YnJDUWtrSWdsNlYwOStEUlptYmdlRFdjaUxLSUNwb1B6OHJmZFh0dTQ3RHdiU0FPVWZINTZEREoybUhWVi9yUDQ0T3ErbUZ4NjNKdzl3ZDUrSFhQamF5aXprYy9uQ2o0dFRGMkVFY216ZFp5bkZaQ21rRHFOdWNtTU1KbXhwZi9ET1hXWnJ2eGpXdnl1SEh4S1Vra2wvb2RlR2x2dTdRYkRUY0pRc0pZeUlsS0U4SWtYSmRXOUQzZ0FDS2JuMGdDUUY4K3hZd2ZTWnJlMmJoVkFVcWs1aXBQWDlUNGMyenlPUlJpaC9CeWpCQXU0SVpSZ3M1REV2bGNjZ0k1UjZHZ0NIa011eFdETGs4dHU1eGNXTHhaQXYzRHE1bmxLSHdrMm14MkRHRm1WYXdhWUN3TjNkbzl3SFdKTmpTa1BCSjI0cGtVazFqOUpMR3BBNTZGaVFCOTFYRUM1RStZNTBYNS95VlVOSEtFbEFwTkt2REVyTzVZSE5vZTFNb3VPbEQ3b2l0Kzc3aVlqazZ0U2hCQ3JOeHZLNDVQRk1tS0ZydDVRN3J2dHR3STZuRmZENDl1amx5My9OWFhWOTRkYUoxUWtkU2hsK3hYb0Q1dCtBL1lqUFhTNlR3NlZ2YUU5Q2lVT1VXazNKaDNDQUVuUzBtNkE4aFV2ZVNTaFBTeWdQcVdyb2FvQlNXc213WWhMS1cvMTY5Y3QyVGlKZllPVEcxaENZU0NPUmV1N0FKKzhlazUxRktCbUpkTW5IOGVQd1h4N0JubnhBTzVyS00zUVdYd0xDelU1UUdxeWZXY1owQTlZNit0bzNLYjNZWkR5MXJrVjZRbTV5NG51Y1IybGVadCs1RTEzWmZkVm1KODFSUVc0cEswd2U5QUt2TGJMR0syYThsaGVJcGZJZkVrcGc4blF3aytlQk1Ba05wYUtTVW5wc1hBS1lQK0hpQkhZb2Yzdnh1QXpoNEFna2dlWVRkU2FCdkxvNnBCUlpKUkdlRmlpTmpxdGpwSkQ5NGpGcitXb3ZXa1psR3EvbDFHRlNGckhybmJzY1RPRDV2d1Y0blArd2RzMnVzcFJsNXhYN2s5SlFOa2d1Q2NxSFR4MTlXRUhaTGFFRStRWW93eXBsUURGcGg1TFg2TEZEQ1dSVmpDV1pRdHdTZm1BaEljQ0QrS21UNVJkWUxHWHR5UUs3VGNSei91ek42U1dYWGJHeG9RN2pianlWaGZCcnE4bGpkZjRmV0RyL1lXbmwxNnFEcUJMR0NFb1FMUStMaGxMV2VmWGMxNGFHbHBiVHArRnhrcGc4UjVZeW1ESUFvaUFQVVlrcktWT2UzWjZoVkFrOTA3OUt0TEFZRm81NDhKRVFGdUJoc2tOcHlhMnBYYzVmdmFzeDFhVjBYWkV1Q1JWOGRlUHV3dGpVNHdqbC93YkJmUmtMc3lrbzBYbWxhZ01JSmFYWE5XQy9raW9Oa1BzYVNCb0lTd1VOSlloU2V2WU01VXluQmlYcVVjK0ZyVHVPUW5OWUwrMGpCbmpra2M5bkpSK1crcGRHS0hra1ZUMDd4bFVySFVNNVQ3M0orV3Rrb1U5NXJ4TEtZa3AxS1FISzR2eVV2MkNXWTQzdjdFZEo3eUtaWXdMc2kwVlFBcEVWS0IrVVVNb3U1ZUcvMlR1ZjE2YUNJSTcvSDU2OWVwRkJSSTN4QnlwUkVCSHBSU25SZzlCQ1FFL2lvU0NvK0FzdlJhVCs2Q0VpcUJWdkZpTWhGTEdKK0FNRUxRVU5Ic1FRa3hvRlBlalYyZG5KbTQyVGwvRWxDRmJ6dFhsdjl5V21Odlh6Wm5aMmRoYUpKQ2d2b2hCS1luS2ZnM0lpekJud29kZE9LTnM3S2VjSGdGS0F2Q0NqejBLcHpvQTVrM2hGQUhRQkh1eVE4NXAyNUluQ01BKzNrMXRLRWZUbHhYNlpMOTBOeHBDajF6NjhueE83ZVdQZGFLWFlxNHFkY255R1VDNDdnUWxvR09nNUhLVzhJcFpidHgyUTRuVk9odzRjd2JJODJmYXk1azRvQ1VrT3ZaSUl5UWpML05KZ1VENGhFeWtxMUVwMUQ1Z3psc2dmSWVqa1owS09Pa081ZDhTUUFhVVJMZ1BwMk00dUJCc0FqUWJlNjkzUlp4OGZ0ZTNtK3ROM0gzMnFjbW5KMkRjYWJocTd6QVhTMGcwRjVjTTJrK3k4RXBNQzVaYUxtTzY2ZTk4T2dmS1ltcC8wdFFaMlJZWnlFQ2dGU0Vla2dqS0twcWJZV083YW1hSU90amVpKzNwbEpHVXhtYktnWk9rVnp4QTB1MlFaeER1MzQ2dGZQUW9NNWVtNTI2OGVjSmhuZE83Rm0rcXJvTjRyeEJoRkdNNVQva09DbUdXN3dKYnljRmdRZmRzV1RoemdkYzBZZTgxbXQweWlzaHUyQzVTVXlpTXA2T3k5eW9DU05tZE56eVNHVW9ERUhGa0ZaU3RmRDlqQ01DeTVzR25rOENpMmpqbzRFZEdCb0JUVXdqWjBoNVE3WXN2VWk0RmYrcVg0N1h4N2t2THErYXR2aTVld2hOMVYzR1RrN1VLaldxVDZQTFBqcXRaQitLYkRBTkF5RjlnbWxCNWlLZGRHTVo3UWVlWEprQTIwaW5MTGhnMWord2hLckFEQ2hwSnk2d2pJa0VtQ0VsV2ZtVHFUR0VvSEpCR3BkR1lxaEpMdEkvcXdWL2I2bVpDZDdpcGU3aE5LZ1N6eDBOTFdsK2NMYkNpdmpzNTlYcWhpT215MXNWQ3B2aW9XQ2NsTG1OR2owdXBnbU16emJ3bFcyeElvdWZieU5vSnlDeFliWUR1WmphREV0U0U0TzRsUVR0N0tFcFNiSWtWRStpR2wxMGFuU3V2Q0ZHZjFtRkNLejZyL0FnVjVwcVphaldsaVVmQnFqeXlkMGlsRWtqUkNEMjdLMFRkdFM4a3RaYVdNREFLUWh0YnN1K3FiRjNPUFhueDZzOUNva0dsOGZ0L3hlSW1Xa2R5ZmYwbk9xOFp2dUVia241S1JhOGROZ1hLcjI2UEFWNVJrN3pXTGFlaGlLUjJVWXd5bDdCaUNFak1aR2twUytuS3BNdE95dWJ3UXhGbGppS3d0TmZMNWNzUWowdVZKU3lPT0JPWmVwbytaNU9hSWdDcjYzZHhYc0pnQU9lcGFXdUUxd0ZCUHNZcENEbEd1VEJZVzJFSVJrWXZ2WUhaV0w1d2VrdmdQQ25wZEJyR1Vuc2tvRHgzRnBRYlFVREtVTktiRWJlK3lDT1hrSFJ4T1NwRXNuL0xLZ1ZkU1J3bno5TGx6cGViU210NWNYcUNweURnVjFyU2FsZngwcmw1M1JsTDRZdHIyZWl6bHFqelZ2WjB6MWxQS1VROGVrODRGZzF4NHpnelN3YzFLdmx5Y24xOWNmUG5VVlNwWS9iL3J2NTZXQVQ2SFVFWWJiRkhXQUZXVWJETjVpS0FrSVk5ZWR5UU4zYStnWk1lVm1XUXFSYmplUDk5bzF0YjBKMmNpY3ptaVVTa3dsdW5VYnlzVEE2V3BCQy9SQ0dQMWRBL2w4M2tFRVRIMEpPNFpGeUxOYlBlaDJWeitncGd4amx3U0tIRTh1WTB6ZVJqSzNiSTFyTk4yalBFd2xNemtVVWw1OVVnS2t3R1hVUmtPTkppMUdwcE10cGxtbW5xaGdFQTJuMDBMZm5IQzJPdmVuSFJOOWJTVWtJQkVnTmhQVi9PSmRYc1dVVGg2bkowZDc0a2gvTVVydDVhYlJZTmsrbFB2bm1TN1U0SnlxOSt4bWNhVGlDUkRlUWlaM0JFd0tWQmlrcDFEMHBsSllsS2lyaVFtVXBEY3lIV3I2anZ6RFFSempUM0dKQ0JiTTQxU3BrNDBta3JqeTNwam1jTS9odnRxd0tqbVFFQy9RSjFDamM4K1JnbVE0aDVMeDhEVHVHN3VxUStEUnBQdHpmbnMwYmo5VVVHM0NEaEFYRTZqOU8xdnJPK1p0a3RwbzJsZUFlTjNvS0YwVlhra2s0Y3FaVEdVdERzc0FrbFFNcE1UR09YaEFhV2FDUW14WkJ6WlVIclY2N2xualpsV3JkQUR6QUpHZFZwTGpXZmx1aEJwS1NQTjVPN3JPdXFlNkFJR1NLUG5WcndROXN4ZkhqZnQvNmlRSU92Ty9qdTZCWFphcHAwaEx5dXpJZmJuc3RyNk80REZpMzBORkFpcW95cE14SUFEZkFIOHlVN29BdFZQY3I5eVVFWUx0amJUcGlGa0tBK2hmSkFuMnFJZ2k1cVluSmljSER2dXFmd2xZeUNjREJFb0JjaUl5M3ErMGx4cU1aZDY0Z045MWtvZWlVejlLWlY5dGxzRTVWM3EzN095OS9VZEwvNEpYY0lNRkhvOTdReFlUaTJvYjJVbkJrSU1kR3I3RkR4cGk2di80VG9OSDR6WklqbXFteGwydTRNSndYTjAwdGp3Vy9sRERQTXdnUGNmZndjRHpUbEE3MUE5cUE4eXpESnBXMHJlSE5iYnljM3RZdWk0YjRqc2VPYzBobDVyOWhaWlNxbUZIaTRNMFZDaU5KVWpqc3ZwVXFYcEpqRUxuVVFXV3MxRzZSUStuOFJDWnRvZEVwNndHWDE1WVRONkluWFE1NXhHVUs2ay9rMnpqcHp0c2RsZXA1MlZESU5WUzRQKzNoR3N2aklRS2c4ZnRPTUEycVFhVHFYaEhNTWdzYmdlL295UkxnbjlqZXJqYjFHbSsvcDFMVE9Ka3F5QmJHQW5aZHVRTERMcG9TUWlWWkJISWFtbzVQWC95RjA1WDJvczFhYW1QSmNGbW9vczVjc3hSR2I4a2RselIvcGlFVzUwcHBNOCtDQmNvazRTaEN0K2dmS0g0VnBDMzlRb255ZTV3R0F4bG50SWxpbWQ3RTRCM2MrUWpLVUU0MEY3S0tIcG82OVlxemQ0QXFQeGVRTWZyQWx0Nlhvb2FTNkU5dzN4T3hRUWxQc0NRem5HT29aTVRzaHdVZ3hsSjVRZFFIWWdpYUpEaXNETVRPY3hKbHR3b3FuSS9iOENTU0RoaVdHa3RpQW9GSEkzYkdnUnhxanZCT0hLQ01wVjFMOXVXSXpFMWE4TmluV3lnUDJMVkRBcXJ3cm9HWk1xaUF1a0pISU53RFRlb1gvV2pTZXdBMGNtNGFEdkNwYjdBbm8yMmpCcVlKUlhUbkJYTklOUUJPVTJ4eVJCeVJzMkk1SFpNUEFxdXhNZ2xKTVRLbzlIRm9aRU81NkhlMzJFUVBLRFp4MFJ6RXg1T3Q5QW4zVzZuT2trVW1nVFU1Y1NEcnNxNTRVTjE4UWo5L0VyMEZtQ2NOVXZVTDd1UlZ5dnV6UDA3M3hDLzlrZllBTmllOHZRSzlaaCtiVmdCeUQxNjZ4N2cwMDdKTFRFRUg4Q1kxVzU4VE9iVGkwa0RrZUwrMG9iTm52ZmxlUURyMkluR1VuU1Q5Yk8zRVdLSUFyakhqdWVDRHFlSUlzWWlBYWpHL2lNUEZBUVlSQXpFeDBRM2N4Z2cwMUVNNC9FMUZoQjBjak1UREF4Mm4vSlRMRDZ2YzkrTmYyNityTjZmZHZUM2RYSDlPak1yOTlaWFhmdWZMMmpVQUpJblRtUUpkc1ZMTHJrcGFuemphMEdtbWJWSGNMTU8zUXViVVdoTXdnTEV2WVlwd0QwZHdmS05XMS95bk9QUVQ4UjRmYVJzTitLRUNYaExUOVlxQmtLOER4NlU2Uk1hbFJTM1k5UWlQTklXdHQxNG1oZ2xKeFZpdDhVT3U5SmJ5WmJoSHZ0a2tHcFplZ2FlRFZSZjlMMVpQNHc5SnVRV08yYVF4bU4xOENrOGVpaXdHRVJQRVlUNXcycldPcStPUk03VHcrMG5vMXJMWlNITHlNbkFnbDVReG9mSFM5YzlmSWNaRHlPdUdUMEFiYkRtUUtwaUcrTmpaMlJKUEdBbjcvZEVDdS9HVGxrZ29ubGFyaEkwSlRvMkF3cS93NGJzaHg0ZmRvdGVFMU1waGVJekUzWEZrcFlycUF5S2twZzZUb1FVSFk0ZEJwMXNXMTVhQXdlZGlndDB2T1JoREpJRmpBMHFWcVJtRTJMVytJMXViT1lMekdQVkltL0tNOHN3emRvNW92djQ4b3pzaWIraWRHZ3R3VHhGM0hWeHlBci9hamlvMUl6bmhzWkNtVmp2RFpRUWxFMlRLNWZ5NkdFOVFvbVFlVm10MklnOHljRGxlNU9tblE4Unl5aDhveEVYWGNNZTJuY1dLUS9IS2l2eFVhellaRjJ6TUV4enZPRDVqOHN6cE5CZWJHMVg2bHpFTC80WVJpbEFrcHl0ZTM4bWlyOXJ4RnZLZi85MDBSTHNGVC9nNGxLbFZLWGNlZVJNUk81T0pSZ0VnNGxURmRuRWxBNmtmQWxBNVc1b2dTUkRtV2FYOCtoaExUUTVIWnBsNzU4WmJGUS9wSWtKdUV1YWtObk5zZk8xSUxNZFYvRDdIZHpLVE1vMTB4M2ZobjRuUlVTdm80WDF6RGVJaVNFaDQzRXUzMUZuVjlvK0pMN21uRjdmaGFtb0h3eHp6NW9QQmtKZjE0MEhEK1BONFRWT2tuNXlibTg1eXJPWnZERkVtaW1Hd252Q3VVdHEzbE5RT3JqUDlZYkpPK0RTREQ1d3JXazVpYzN1MHlHVXRlTVNkZVE2Ti9vQXFUK1NvNmZZWmRXUUpRUnQ5VmdCdG8yYk50Y2RXTVNPMXJQdEUxNkl0NXVvWG8xTlg4WmdXc1psTk5IaUwrU2lDdHgwTWhkdjFEaVE0MWhFZUh2MjJ1OGllOE03bWc0T01lcjJpSUhuS1g3VUdTSXgxUjUxSWx1NFR6eG5JOHdFejZ1azFzbUszOENsTGViUHd6am8xMURZb1lTVUc1YTBjRGRWZ3FtcXcwYUNTd0xURHFLYm1NcVhTRE10WndkcG0wQStnRHF6MXBPbm01S0xkQ010OFBDanJMWTY2TnBDK1c1dzlNTE5uYjB2WnBoQ2NiWm1GRno4WWdMdjVZSTgyR2tnTWY0cWdadWJaYlJsbDdRaFJJbEhDUjIrZGhQdGlvN1N6V285Q1ZVYWg3d0FpamJxZ0V3cVVRaUc0Sjh5RjhtN2JGMUVjcE1VOGJLdWhEY0FaRlJPeTV5VXhRY2drSG9UU0FMNm13M1pHc3JUZW1sZjdwQlgrbGNiTlUzZW1NRFJWNllIajVuVUo1SVVNN2V1Nm9zT3k2eFRGRVhVcEdCRzhzQVQ1ZGhsVU1kQ1ltSGNvOG9EdFBIZVNuVmZGTWprU3BUNlF2c1NEbXY3TWVTUURjUllnRXdoVm9xSURZb3JiYnVjWktjU1ROZGsvalRQMEl1eER0UWxrdnJZTDR1bWEyNVJ3bERVOFg0QkltS1lSZStoRmNTWFM1cVpNc3VZWXJ5L1N4QmVjS2dQTDkvMytyQnl5cFgvRTdudGgxTkFrVHllQm9RMjNoUnpIaUllYjVSeWhoU2ExRzRicEVCOVMrRE9wei9ka1ZpUjVlQjJoN0JmcTVjYWYyL2JMUHp1WENESUlNU1RPWlFQZ1dVTi9OSGYyeEdLS09hZElHV2pBSlhFaEVaTEpWRk1PbzhxVEFHUWZLd3dLTTh1THB2Ly9rR3lsMjc5MTdhdjI5eXhwNy8rSTZWZVBhU05iNGJJZ2VJeDIrNWp1Tis2L2dBSzcycnNIaWtDSTlFWXpVQVI0UVl2M1NYaUpCdlpMUnc4N1ZsRXNZcm9QUmNTUHNnOU1Sazhpa0wvaVFjeWxCL0hwOGEwQ1Fucm52WlRiT1dBelZ2V1N5ajl5Q0p6V3lPRnRiTDh0T2VnSHhtc20vL3BiMkhkalZRSGtoUW5vS3FmRjI4ZFFvcGtoN1NpTkc0NGtWQW5FZ2VOU2hEeW9NZzNNOERUYVJpVk5pZ0s3NGlKTlJDT3lWR2Vya0k3UXZEVFlFb3NlaFhKRmFNRFVHNXpHU2VvVXhBd3AvTU8yc1prV2tDa3JGb1lFbExJZzJTRzZ6SWZqU2VaVEpRWWFpYUk2a29CaUFUYWs1ajVBNXM1a3RNcWEwenlGc295bE1KeWdON2R5dVV4NDRlbjV5ZVlmanpENVdweXBqdDRQR0ZpZ3ZVZlB1MG5vdmNZYVRxWnhmaGxCTEg4V01SMHBuWEtrelhWR1djZVZLTDc2T2xGTDZKbTBZR0phakVDT3B0RmJvUDFBd29senpLY2xjdDR4Rk1Ram9GZFcxUmdIdUwwVUoxSHNIWUtGR2VsNW04T2pzOU9YNzBtRUY1SkVFNVBibHlGcU1Jdk1KTmpYU05vQVppTEswWko5S3pGSDZTOEd2eWtlTGpndGUraVF6ZHVpaEZRanVDaWRCL285UkdUYVBoV2tnZDh3c2djaWI5TlNJUzd5dlJ5MitoZkx4dS9pVEc4YkhhT2lRbzhTQjBWNU9ab2dTVU1jS0RJVnBOVStiQm5UYk1DdEdJYWJSUGl3d0dQSi9vSy8wOVNXdEZhWGIrd3NnQloxZE9UaE9VUnhLVU95MVJ1YnBuQjBiQit2YnkzN1NUUk11MHB3QkZ3dDNmeitNbW15eHRGSjBpRERwSk9KL1ZZT05GSFZSaDFkM1NhUkJqVXpvUkdhRmRJcm5OSUNWNFpOQi82TzZOL3k5b2xkM2gwQXdiQi91V1NDK2hEcVV5R1NycjFKL2MxQUZET2pVRGQ0MUppRDhleThXSURKMnhraGlOemVRQm5TSjFpeWVLbk9QVnl4d1dtTVZHa29jWWplN25qajJybHFiY21hRFU4T3Rrejhyc3MrMTlmcTlvYWVnMi85cGxaTDkra25naDkzWmFXejZ1ekh0a1FrWkl3TC9laWg1WjFEN2UxaFRlSllaL2VTTHN2MVJJVGlWQXVaNllYSGNtMDVTWU5ERWs0VkhHb1FrY1NrT3k1ZElIL01qRittbW9la1FPY2xpM2xYZWFZT210QjlpRWVkNTRnOEhvUHM5Vzlrd3MrSnFnYkNJOWpWTzVzdU1NeGxwK2h1N09qS2RpRWxJcXl3cWtuTE9UZ2E4eGVuRThHc3d6Z1dWTzZRTzBjQXNodEZQN3NpcHd5UkVsdFh4eHQxdVVsVDZDL09zakVsaEpvME9KZmlFZWRrMVllblZkQ3J0MlN3YnUzb0RFQ3ZUZ1MxcTlBRUt1YzB1QkZLSHNnOUdJQTNMYUFMTytBYWNHZlltMXQzL1lPNXZWSnFJd0RKOUZ0VlRiMHFZMUlYU1JtVkRhTE1UTnljb2JFQVJYMGtVMnZRTXZ3SFVwaE5DTkMzZmlvdXVDdUNwMEkxMzBBc1JyY09VMUJQek9tYmZ6RFh5WnZrNm5FUXJuR1JOMU1saHErdVQ3T1QvekdyZUhITGlWVUZLR1BvOUlHWXZLclU3L3FYTzVCMGROUG5qVlJoS3pXS1RpMWR1WS9vaERMQjRUNjBiUWVXdUsrRVRtUnhBUEcrakZKay9jczNsRkZyeVFBR3IrNTh3L1J5ZCtRTXJiMi9qWTlaT1l4MVBrcm5yL3lRSUlHUTYxVWxBaHNYQXkraWhQT3ZlOE1vVnVRbEFUbzREcVp2d0xmQTJuQ0ZNUGN1ZWU5anRiVWxKR0tVUCtlaER6VitjeUQzNjkrOGUzcnZuZ3BLMGpyTnM4eitWWTFlaUlvYm1lcitScy90WEpOMGkyMWlKeU4reGMyMzE2ck5WMXE5VllNaXlIdlp5UG1hbVV1cytBY091azlIZ2tlY1h3Skc0S3Ewb0tVRktlRVNXcmc1TlJ4dkQ4SVI3d0VVUWJFU2x0WElSaFVBOS9WRHZ2eGNuY2c4eTVtTDBlaE94VnBFVCsydW1KbEc3a0FWSlk4Z2xKcWhBYmx3ZzZXbTI3bGp6ell3R1BENzNhWWJuNlRNdHVTbTFibUhST0hCbTZzMnZqK0R2QVQ0OWJMSFp1T08rWEorcTJad0VwMzZpVXFxUThLamVGRlJBcXBjRmo2OG0zQzZmeG1CMndTcXFqSFlvR1BYMkVrKzJSMUJXTW5FalpRL1lLS2JlTC9tdXdNcHQ1OE9rcmU3OTR3MFRQMWl6a05XZllEM09EU1Z0VU0yM2N0dWkya1Aya3lNYnZwZ0MxeVRkWGgzelBqYnBENDdvZGtHejFRQWM4VFpsQVp1Mk5xNXN4LzlTTjY3VHppaVlQQ0Q0aWV5Mk5OQzBlT2FvclFzSUJRaWxaSmVvNHVabW9sQWlKV2hnaVFENElWejg4bUdYQnlhTDN1ZzBwSlg5ZEhhNjllQ0toVXNoUGZhbmxGNXZFMnJMYzZLYXZOR1pjbnd3MTNCNlZ0VWJnbzRtWGJYcktkaUZsdmJMV0JIMjFXcDdXV2JKWU5WTHhqYTNGZkRtSGptNnhmVDVWWVBySlNRaFNZdjFrVmNtUGNUOGVOSG4wbnJCNnU1RGF2VjBocFEyVUJXVWRlVk5ReWdnaGpZcHRPWm1La3VBMGR3aVVhOE5WeVY2amxMSFZnMUFwRFBhOWNpWmV0cmFMWS9ZZjFUTnN5SjVJZmIvMWhYenpUQUtQM3JROEpOZXhaaGUvMEg2RmNkME5LL1FWVzQ3Y0hheDV5V09IWkVzcHE0RVNQWjczQzdaM2haTGhnYkZKalpNdzBqcXBHd25vN0owUzdlVzBaN0xBeUV1djdBOWNHU2hqbXdkU0ZxR3kweXVzWEJuTmZJVnZuODh1TGk2T0Vvbi94KzgvVjNjd2xWL2htSmEvUFJMbTgvbmxkN0ZMbVkxV0NpZDduU0pRUXNyYnFsSm1wY3NGQ0phSnhDTmlKdmlaZjNSSW1JeXN5RngwVkpTbGxPdWhBWXNFTnBJZiswUWlzVlNPY3hkQThycnpUQUtsU2ltaGNtUHpVQkxZdmxnSjhoUXRFNGtsc3ArNzBzbStKSytIbXhzU0tDRmxZRDMwZW1RR1FTd3J3V0IwN2hPSnhCSTRIdzJjT3RtVGVRT2h5eE5hcjVBU3ZaN2RIU2tyOTJBbHZNeXVrNWlKeElOeWZKM0JTRGk1SndYbHppNlNWMGdKSzd1aHJJU1ZGVjRPOGl6TG5pY1NpWmFJU0xuNnFFNkdnckliblZRcFVWWjJoMkpsekdBVGljVHlRZTRxVGc2N29hQTBVa3BadWZsS010aGdaZEl5OGJjOXUxbHhHQVNqTUV5SEpxMHlhS3ZtUnlTYlFOTGQzUC9selRFVkxMZ1FKc21zem5zUEQ5OFIyVDkwaGNtNFhYOFVIcFFmS0V1Vm5pb1pPN05zMHBjbUU4cXNVa0tsbVFKWk1uWnlJQmttQTVNeW1TeFFKcFc5MUtJempSL0prckVUQThuUk42WVRXdmJKWklFeXFjVFB5SUpqU1phTTVjNGlpVE81NEM4a21jd29DNVZxdG1KakdkcjJTcGlNSFJ0UXRXM1lTQW83cTJ5eVFQazVZZDFxUlFlV2t4OUd3R1NNSFJROHR1UGdKNURzaEYxZG1xNEZ5dUpZUHBWYmNDMmpTOEQwd3hEQ2lGckcyQjhiVVFqRDRBRXlpc1NWWEp4NmJtZXlnaElxM3h2V3ZiU0lMdS9HbUlZeGRrU21NZVllUlFyOWN1L2xDcE5WbFBGWWdpVkdyRnkxQmN4SGgrNk1zWjExNkFHUVZxOFN3eFVrMDVtc29jd3NiNzF6ODZxMVJZSXh0aThySUVucmRYYXF2eFVrS3lqVGlJVkx3RlFPU2NiWTdrQkpSWkFRbVlackRXWHBNc0tFVE5oa2pPM3NDWTN3R0VGbWtUV1VwVXZBaEV6RzJFRjlBMlFoc29xeXBIbjVZb3dkMHFYZUwxMmRKRU5ES3E1Y0FBQUFBRWxGVGtTdVFtQ0M"
}, {
    name: "__ASSET__:bitmap_Logo",
    data: "aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQWdZQUFBUFdDQVlBQUFDYmRsQTdBQUFnQUVsRVFWUjRuT3pkZlhSYzkzM2YrYzl2SGpBREVTUWhVaFJGR2RFREk1bVNRRDE1Ull1eFJaWDIycWZIcWQxWVNiUmJ0Vld6Sjk0a1MrMzZwTTFHUGpseDExSzY2M3BQRXljNTBYWmRiOUp5Y3hyWHJSQTdmcWpMMktKdHRvclhsSjlvdDVMOFVNVm1MTWFrTFptaVFGQVl6TVA5N2g4ekY3d1l6Z0R6OEx0ejc1MTV2ODdCQVRFWTNMbUE5TU45NDNlZkpBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFQVEVKYjBDNk03TXd2OCtydTJ0L2JGZW5qUG8xMFUvWG5MT25mUHozUUdUZzdHTUxDRU1Vc0RNdGt2NmtLU3JsZnd2alBVZU95L3BiT3Z0bEtUamtwNXl6bjE1aUc4ZkdCdU1aWXlEc1FpRFZvM25KT1ZiNzZOdlhSOXp6bjAva1JWdVkyWjNTL3BpMHVzeGhDOUsrdGVTL3JWejdrTFNLNE9tckkrTExHSXNZeHhjRWdabXRrM1NMMGlhMGdDL1ZCSjRiSml2ZjU5ejduMEQvL1E4TWJQWHFsbnNXZmNWTlgraFBKYjBpdmpHdUVBdkdNdmp3OHdLa2w0ejRwY05KQzJxT2FPem1GU2NGVG84OWpwSjd4LzFpaVJrWjlJcjBHSkpyNEFuZDBtNnk4eHVrL1JienJsVFNhK1FSNHdMRDh6c0Z5Vk5TNnBKcWtmZWFqMzhlOTNucFdTZk9XTjVmUHd6U2Y4d2dkZXRxeFVHWm5aZTBqT1NuZzNmTytlK0ZmY0tkQXFEVG8rTks2K0QyTXp5YXY1RkdiNHRPK2VXUnIwZUtmQU9TWHZON0JIbjNHZVNYaGxQR0JmREx0VHNIMGo2SXcrTDZoZ0tadmJQblhQLzFNUHloOEZZSGg5WEp2UzZCVW1YdDk0a2FXL2tjeGZNN0lpa0k1S09PT2ZPeExVQzdmSnh2RkJLQmQwK1lXWVBTYnBKelExOFVXczMrTjBlYTMvOFJUTzd4em4zMHFEcmtXRjNTM3JNekg3Rk9YY3M2Wlh4Z0hFeHZBT2VsbE5RNTk5ZGI1V1VkQmd3bHNkSEd2OWJicEwwODYyMzc1dlpuMHI2bDg2NWIvcDhFV1lNdXZ1N2FrNGZEMk9McEcyU05ncURjZnNySTNTanBQK3I5UXZsQzBtdnpKQVlGOE1zMEd5ei9JVkJOL3ZON0c3bjNGTXh2ODU2R012am81SDBDbXpnR2ttL0p1a0JNL3VYYWdiQ1gvbFljSzdEWS94bDVFOTRNTmRHeHZXWGlTVGRvdVpmRzd1VFhwRWhNUzZHYzBEU3EyTllicWZYU1JKamVYeWtQUXhDdXlUOVkwbi93Y3oram84RmR0cG84WmRSazQ5VE9YTTlMbWVjZjVsSTBoMXEvbytiWll5TDRZeHFnMzN2aUY2bkc4YnkrTWhLR0lSdWx2UnZ6T3lmbXRuME1BdGl4cUE3SDJFUW5rYyt6SHFNaS8vQnpONlo5RW9NZ1hFeG5GR0Z3UUV6KzhrUnZWWW5qT1h4a2JVd0NQMkdwQStiMmFzR1hRQXpCdDB4WStEZnU4M3NMVW12eElBWUY0TXVySGx1LzdESDYvUnFxNUxkbmNCWUhoOVpEUU5KK3R1U1BtQm1jNE44OGFUUEdNUWRCaExIR0VSZEtla2ZtZGxVMGlzeUFNYkY0RWE5b1NZTTRwZmxzZHlyck0vK3ZGWE5PTGltM3krYzlCbUR1SGNsOUxxY1NmbGxJa2x2VWpJWERSa1c0Mkp3SXc4RE05czY0dGNNTVpiSFI1Wm5ERUovUzlMLzN1OFhNV1BRM1NobkRJSU4xbVhjL0NNenV6bnBsZWdUNDJLUUJabGRyOUdId1EwSnZHYUlzVHcreGlFTUpPbEJNM3QzUDEvQWpFRjNvOTZWTUVtL1RIYXFlWjJJTEdGY0RPWmVYYnlDMnlnbEZRYU01ZkV4TG1FZ1NmL0V6Tzd2OWNtVEhnYWptREhvZFZkQzF2ZG45ZXVCUVErTVNRampZakJKYmFDVERBUEc4bmdZcHpCd2tuNjFkYUd4RGJFcm9UdG1ET0sxVzlJRFNhOUVIeGdYL1M1a05GYzc3R2EvbWUxUDRIVVp5K05qM0FMdmRaTCtsMTZlT09rekJtazUrSERTOWt1Ry90dWtWNkFQakl2K0hWRHpVcnBKU1NKS0dNdmpZNXhtREVML3M1bmR1dEdUbURIb2pobUQrTDJoZFZ2WExHQmM5Qy9wcXhBbUVRYU01ZkV4am1Gd3RhUUhOM29TTXdiZGNZeEIvSXFTM3BqMFN2U0ljZEcvcE85YmtNUlZFQm5MNDJNY3cwQ1NmbjZqcXlJeVk5QWRNd2FqY1VmU0s5QWp4a1UvQzJoZTdmQ25QS3pMTUpLNENpSmplWHlNYXhoY3ArWnRtN3VhOUJrRHdpQjVTZTZEN2dmam9qOUp6eGFFQ0lQUnljcFk3dFc0aG9Fa3JYdnE0cVRQR0tSbFY4S2tIckFrU1RlWTJWVkpyMFFQR0JmOVNVc1kzRHZpcXlBeWxzZkhPTzhTZWwxclZxOGpaZ3k2WThaZ05IYW9lYVc2dEdOYzlQckZacnVWL0lHSG9aL1VhQ09Gc1R3K3hubkdRSkplMyswVG5YN1o4WmRSVTlZUFB2eXdwQVZKTHcyNW5KMnR0LzJTZms1U0hEZE51VUhTWDhTd1hKOFlGNzA3SUduV3g0cDRja0RTdngvUmF6R1cweitXZXpYdVlmQTZTYi9YNlJPZHdpQXIweWVCbXYvaDZwSDM5VDRlT3lmcFJLY0ZtNW12S0pDU216SDRmZWZjbHowdTd6RXorejFKLzZmOEgzMThyZWZseFdIaXgwVWYwckliSVpUMUdRUEdjakxHUGd6TWJMdHo3c2Z0bitnVUJuOHM2VnRxL29LSnZsbUh4OWI3M0ZWcUh1RGc4OElYVDByNko1SitxRDUrNFRubjZuMitqbE8yanpHb1NIclI0L0lrU2M2NXI1aloveVRwRHlYOURZK0xudkc0ckxnd0xucGdabHVVdmpEWWIyYjduWFBIUi9CYWpPWHg4VzFKMzVDMEthSFgzNnptREU5Y2RxbTVxMjNqTUdpVnFaYzZOYk9uSkIyWFZQS3hQRW4vd1RuM1dVL0xXby9QTUJpcll3eWNjOCtaMllJbTdKY0o0NkpuU1YvdHNKc0RhdjdNNDhaWUhoUE91YytaMlQ3MTlqczhEbHNsemFtNTYrY1hKZjAzTWJ6R2JrbGZhbjh3MW0vWU9mY05TZi9aNHlJWFBTNXJQVW1FUVZhbXFpWHBUeVU5NzNGNVNSVjVJakk4TG5xUnR0bUMwS2pXaTdFOFJweHpkZWRjTmFHM0Y1eHpKNXh6SDFCemh2RmpNWHlMdXpzOU9Jb1Nxb3pnTlh3YjlhNkV6UHlWSVVuT3VSOUpPdU54a1dQelYwWWZzamd1ZXBIYU1EQ3pVUnd4ejFpR2Q4NjVSVW0vSWVtYm5oZDlYYWNIUnhFR1BnL2tHNVZSenhoazhkeG5mcGtNSjR2allsMW1kcmVTdjlwaE42TzZDaUpqR2JGd3puMUgwcWM5TDdiakRNOG93aUNwL1RQRFlNWmdZOHNlbDFYMHVLeXN5T0s0MkVoYVp3dENvMWcveGpMaVJCZ2tpR01NRUxjc2pvdU5wRDRNUm5BVlJNWXk0blRLOC9JU0M0T3NUcGt5WTRBNFpYVmNkTlM2Mm1IYXcyQVVWMEZrTENOT0w2ckQ2WVZEWU1hZ0R4eGpnTGhsY1Z5czUxNmw2MnFIM2NRZEJveGx4R2xaZm5mOWREd0ltakRvak9zWUlHNVpIQmZyaVdPRCsxd015NHo3SGc2TVpjUnBXK3ZObHd1ZEhtUlhRbWRKSEh6SWZzbkprc1Z4MFZGTVZ6dDhXTkkrU1ljOEwvZHVNOXZ2ZVpsUmpHWEVhWnVreXp3dWI2blRnOHdZZE1hTUFlS1d4WEhSelFINXZhdmVmNUgwZnp2blhuYk9mVkRTZi9LNGJDbmUzUW1NWmNUcEpzL0xTMnpHSUl1L0FEbGRFWEhMNHJqb3h2ZjAvQmVkYzlIOXFFOTVYajVoZ0t4NmcrZmxuZTcwSUdIUUdRY2ZJbTVaSEJmZCtON1F0dC9Ud0hzWXhIZ1ZSTVl5WW1GbXQ4dC9HSHkzMDRNY1k5QVpNd2FJV3hiSHhTVmFWenYwdWMvK0ZVbGZiSHZzdUtRZmVYeU5PSytDeUZpR2QyWldsUFNvdXR6YllBaC8yZWxCWmd3NjR3SkhHNXYydUt4eHZXL0Flckk0TGpyeHZZSDlvblB1MjlFSG5ITS9rUDg3SThZWkJveGxlR0ZtMjgzczV5WDl1YVNmOGJ6NGw5UWxEQzY1N2JKUFpwWlRObjhCK3Z4cmJseG5ESzd5dUt5T0I4Q01xd3lQaTA2OGgwR1h4NStTOUxjOXZzNEJNOXZxbkh2WjR6SWx4dkpFamVYMW1Oa09OUS9LRGQrMnFua3ZpVTJ0OXh0dGY3ZEt1bGJTcnBoVzhZUno3cTg3ZlNMV01GRHpsMThXcDB3NXhtQWRaalludi8relR0b3ZrNnlPaXpYTTdDY1Z3NEdIWFI3M2ZaeEJ1TzZmOUx4Y3h2SUVNN01Ea3Y1RzYyMWVmcVBMdDcvbzlvbFJoRUVXL3pMaWRNWDEvUjFKY3g2WE4ybS9UTEk2THRvZFVQT3ZHbDlPcXZzdWcrT1N2aTFwajhmWE95RC9ZY0JZbmpCbWRwMmt2NnZtVlArK1pOZW1MMS9vOW9tNHc4QXBtNzhBdWNCUkYyWjJyNlMvNzNteEhTK3lNY2F5T2k3YXhYRjh3VXVkUHVHY2U4WE1ucEwvTVBDTnNUd2h6R3l2bWtIdzl5VDlSTUtyMDY5dmFwMFpnN2gvT1dWMXluU2tNd2JPT2Q5L1paVGw5NjhBbWRrV00vc0hrdjVRMG0wK2x5M3ArNTZYbDNaWkhSZXJXbmNwSE5YeEJTSGZ1eE84WHdXUnNUd1pZOW5NM2lucFU1SitROW1MQWtuNlJOdTFRdFpnVjBKbm81NHhrUHhQUC82T21UMGhhZGlEcTY1c3ZiMUd6WDFtY2VoNFpPd1l5K3E0aVBKOXRVTnA0ekR3ZldhQzFQdytmQytYc1R5bXpPeW5KUDI2cFB1U1hwY2hMRW42ZCtzOWdWMEpuWTM2R0FQSi95K1RmY3JHL3E0VnhYT3puRFRMNnJpSThqMWI4SlJ6N3F2clBjRTVkNksxTytGdWo2OTdRTkp2ZTF5ZXhGZ2VTMmIyYzJyK3YzSmR3cXN5ck1lZGMxOWY3d25zU3Vnc2lSbURUT3lYak1GZmFzei95dWdncStNaUt1NnJIWGJqZTNmQ3ZURmNCWkd4UEdiTTdKQ2tQMWIybzBEYVlMWkFHazBZWlBFdm8zR1lNY2lLWjV4emsvYUxOS3ZqUXBMVTJpL3YrdzZGRysxR0NQa09nemp1RE1sWUhpTm05bXVTL3JuODN0VXdLWTg1NTU3WTZFbHgvM0xLOHBRcFlUQWFUeWE5QWduSThyaVEvRzlJWDFUdllYQmMwam5QcjA4WStERjJZN2wxa09idkpMMGVuanduNmJGZW5zaU1RV2ZqY1BCaEZqUTBocjlNZXBEVmNSR0s0elRGNTN0NW9uUHVlNHJucGtxekhwZkhXQjREWnZhM0pMMC82Zlh3NkRIblhFL0hnSENNUVdkSjdFb1l1eW00SGp6cG5QdEcwaXVSZ0t5T0M3WDJ4eWQxZkVFb2pxc2crdnllR01zWloyWlhTbnBFMHZhazE4V1QvOGM1MTlOc2djU3VoRzZZTVJpTnNmb0xvdzlaSFJlUy82c2RTcjN2UmdqNURnUEpieGd3bHJQdjF5VGRsZlJLZVBKWlNmOWJQMS9Bcm9UT09QZ3dmdWNrTFNTOUVnbko2cmlRL004V1BLdit3K0M0bXBkUDlva3dHTnhZaldVeis1dHFoc0U0K0k2a2YreWNlNkdmTDJKWFFtZk1HTVR2M3pubm5rNTZKUktTeVhFUjE5VU9uWE1yL1h4QjY3TEpjVndGOGFjOExZdXhuRzIvb3ZpdjhUTUtYNWYwUHpybitoNHJ6QmgweG94Qi9QNXQwaXVRb0t5T2l3TnE3by8zYWRDckRxWjVkd0pqT2FQTTdJMlMzcDcwZW5qdy82a1pCVjN2aDdBZWpqSG9qSU1QNDdYZ25QdVBTYTlFZ3JJNkxuemZZbmxGL2U5R0NNVjFlV1FmR012WjlkOG52UUllZkVqU081eHpYeHQwQWV4SzZJeGRDZkY1U2RMdko3MFNDY3ZxdUloak44S3pBMzd0VTJwT2xmcDB3Tk5WRUJuTEdkUzZXK0ovbC9SNkRPR3NwUC9WT2ZlZ2MrN2J3eXlJWFFtZCtmeWx6YTZFdFg3Zk9UZm9YNG5qSW5Qam9uVzFRNS8zS0pBR255MEk3MktZMXFzZ01wYXo2Vjc1UCtObVZENHM2ZWVjYzcvblkySHNTdWlNR1lONFBDbkp5Lys0R1pmRmNlRjd0a0FhZm5kQVdvOHpZQ3huVXh6L2o4ZnQzMHQ2dTNQdTcvbmNwVE9LMnk1bmNjcVVZd3o4VzVUME84NjVwYVJYSkFXeU9DNTgvOUo4WGtQTUdMUWNsN1FzYVhyNDFWbDFyNW5OT3VlR3Vld3lZemxqekd5WHNoTUdUMHY2aktUUE9PYytFOGNMakNJTXN2YVhrY1NNUVJ4K3d6bjN5YVJYSWlVeU5TNWErOTE5SDNqNFJlZmNpOE1zd0RuM3JkWnRtQS82V1NWSjBtNDFOeEREL0wvS1dNNmVleVJkbmZSS2RMQXM2VnVTdnRsNmUxck5JRmlPODBYakRvTXNUcGxLbks3bzIzdWRjLzhpNlpWSWtheU5pd05xN24vM3lkZSthZDloSUJFRzZ4blhzZXo3Tk55by95cnBvMnBlbEd1aldaYUdwUE90NTUyWGRONDU5MTlqWExlT21ESG9qRER3NXcrZGMzMWRqbk1DWkcxY3BQSDRBdC9MaVJyMisyVXNaMDljWWZCdkpQMm1jKzc3TVMwL0ZxTTRLeUdMa3RpVk1JNzdKZC9qblB1VnBGY2loVEl6TGxwM0hmUWRCbDhkNUdwc1hUd2w2YlNuWllXR3ZRb2lZemw3Zkp5bTJ1NkxrdDZWdFNpUVJuTldRaFl4WXpDY0gwbjZSZWZjLzVIMGlxUlVsc1pGSEZjNzlIYUttM1B1ak5KM2RnSmpPVU5hOFJ2SGpNR0NjKzRITVN3M2Rzd1lkTWZCaC8yclNmcUFwTGM0NS83ZmhOY2x6YkkwTHVMWWplRDczSGZDd0w5SkdzdGJKVjN1ZVptTGtqN21lWmtqTTRwakRMS0lDeHoxNTBkcW5qN3pSODY1LzVUMHltUkFsc2FGN3pCNFNmN0RJSmJqRE16c0J1ZmNjd044TFdNNVd6YTEzbng2MWpsMzB2TXlSMllVWnlWa2tjLzFIcmRqREY2VzlPUFcyMU9TdmlEcEM4NjVVNG11VmJaa1lseTA5clA3dnRyaDhSaCtZVDZsNXFsY04zdGM1aFkxVDlFY0pBd1l5OW5pT3dxazV2K1BtY1dNUVdmak1HUHdwMm9lRWZ0amo4dGMvVVhpbkt0NFhPNmt5Y3E0aUdVM2dwbHRqbUc1VDhsdkdFak43LzlmRGZCMWpPVnNpU01NTW4zeEo4S2dzM0VJZzk4YnMrdVlqNU9zaklzNHd1Q1hXbSsreFRFTGMyREFxeUF5bHJQRjU1VXpRNFRCT3JMeUM3QmRFcnNTZlA0eXFVZzY0M0Y1OEN2MTQ4TE1ibFE4WWZBVE1Td3pMb05lQlpHeGpFelB3bkM2WW1mak1HT0E5TXJDdUlqamFvZFpORWdjTVphUmFaeXUyQmtISHlKT1dSZ1hXYm1oVE53RytUa3dscEZwaEVGbnpCZ2dUcWtlRnpGZDdUQ3JCcmtLSW1NWm1jYXVoTTZ5Zm93QjBpM3Q0K0tBbXZ2WDBkUnZKREdXa1duTUdIVEdqQUhpbFBaeDRmc1d5MWxIR0tCZjVhUlhZQmljbGRCWkVtSEFmc25Ka2ZaeHdXNkV0UTZZMlkxOTNQNldzWXg3ek93dVNkOXJmV3hkM3JwOWJzT3ZjYzdGRnFCYytiQXpkaVVnVHFrZEY2Mzk2YTlOZWoxU1pvdWFzZFJyR0RDV2NVRFNsOVM4eEhSZkcveGVIemV6UVpmM1kwbi8wRG4zblc0cno0eEJaK3hLUUp6U1BDNllMZWlzbjZzZ01wWVJ1akxwRmVoaVhsTFhNT0FZZzg2WU1VQ2Mwand1Q0lQT0RyVE8xdWdGWXhscHQrN3ZJTTVLNkl4akRCQ25WSTZMMXRVT09mQ3dzOTNxL1dmRFdFYmFyZnM3aUJtRHpwZ3hRSnpTT2k0T1NJcmpCa2Zqb3RmWkZNWXkwbzR3R0FESEdDQk9hUjBYN0VaWUgyR0FjWkhvcm9TMC9nSWNKY0lBN1ZJM0xzenNjaEVHRzNsdGoxZEJaQ3dqN1JLZE1Vamx2dFFlY0s4RXhDbU40NEtySGZhbWwzaGlMQ1B0bURFWUFMc1NFS2Mwamd0bUMzclR5OCtKc1l5MDR4aURBWER3SWVLVXhuRkJHUFRtM3RiWkcrdGhMQ1B0T0YxeEFNd1lJRTZwR2hkbTlqcHh0Y05lYmRiR0VjVllSdG94WXpBQVpnd1FwN1NOQzJZTCtrTVlJT3NJZ3dGd2dTUEVLVzNqZ2pEb3o0SFdXUnpkTUphUmR1ditEdUltU3AyeEt3RnhTczI0TUxOWEs1NHcrR2N4TEhNUTc0cGhtYnZWL0psOW9zdm5HY3RJdTNWL0IzRVRwYzdZbFlBNHBXbGN4SEcxdzcrVzlEdk91UmM5TDdjdlpuYVZwTDh2NmVvWUZrOFlJTXM0WFhFQXpCZ2dUbWthRjNITUZudzE2U2lRSk9mY0dVbGZpR254Ni8zY0dNdElPeTV3TkFBdWNJUTRwV0pjeEhpMXc2L0VzTXhCeFJVRzYxMEZrYkdNdEdQR1lBRE1HQ0JPYVJrWEJ5UmRIOE55dnhyRE1nY1ZWeGhJM2UrMnlGaEcybkZXd2dBNHhnQnhTc3U0aU9NV3l6OVFpc0xBT2ZkVlNWK01hZkhkWmxzWXkwZzd3bUFBekJnZ1Rta1pGM0VkWC9DakdKWTdqTmlPTStoeUZVVEdNdEtPS3g4T2dPc1lJRTZKajR2VzFRNzN4YkRvMU13V1JNUVZCdDJ1Z3NoWVJ0b3hZekFBZGlVZ1Rta1lGM2RKcXNldzNMU0d3ZmRqV25hbk1HQXNJKzBTdmNEUlNzekxqMHNTTXdaUFMvcTBwOWY4bm5QdWU1NldCZjhTSHhmT3VUOHdzNk9TcGlRVnU3eGY3M09kbnZPeWMrNVRvLzFPTnVhY2U5SE12aURwbWhnV2Y4RE1MbmZPdlJSNWpMR010RXZ1QWtmT3VUODJzeFZKbXlUbFc2L1gvcjdUWTkzZWZ5UE85WTFKVDVIaG5Qc2pTWDhVODdvZ0JkSXlMcHh6enc3MWpXVExGeVE5RU1OeWQ2dDVBNnJWRUdBc1owNGNNMmVqMEZCenQxV250L1UrZDBIU1g2NjM0TGhuRE9TYys3ZHh2MFlNa3BneHdBVEo2TGpJc285THVsMytyL0o0VHRuOGd3VVgvWVdhbDg2K1hMMXRXRGY2ZkZ4ZjYyMjV6cmxsUHorNkNXSm05NWhaNE9HdGJtYi9LdW52QndDQVhpVitkSFJhbWRtYnduL3EwdnJxK1RIbjNMZEd1K1lBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFDQlpabFl5czJ2TnJKVDB1bUF5dUtSWEFBQndxVllJWENmcHFzakRaeVNkZE02dEpMSlNtQWlFQVFDa1NKY2dhRWNnSURhRUFRQ2tnSmx0a2pTbjlZT2dIWUVBN3dnREFFaVFtVzFWYzRaZ2RzQkYxQ1dka25US09kZnd0VjZZWElRQkFDVEFReEMwSXhEZ0JXRUFBQ01VUXhDMEl4QXdGTUlBQUVaZ0JFSFFqa0RBUUFnREFJaFJBa0hRamtCQVh3Z0RBSWhCQ29LZ0hZR0FuaEFHQU9DUm1XMVg4N1REdEFSQk93SUI2eUlNQU1BRE05dXA1Z3hCT2VGVjZWVkZ6V3NnL0REcEZVRzZFQVlBTUlRTUJrRTdBZ0ZyRUFZQU1JQXhDSUoyQkFJa1NibWtWd0FBc3VZZDczakh0WC8yWjM5Mms4WW5DcVRtOTNLVG1kMzl3UTkrY0d2U0s0UGs1Sk5lQVFESW1rcWxNdnU1ejMxdTY4Yy8vbkUzTXpPam0yKytPZWxWOHVMSWtTTjY5N3ZmWGZqeWw3OWMrZDczdnZkeTB1dURaTEFyQVFENk5EOC9mNDJaWFd0bVRwTG01dWJjb1VPSGROOTk5eVc5YWdNNWN1U0lEaDgrckJkZmZGR1M1Snc3K2JuUGZlNnZFbDR0SklRd0FJQSs3ZDI3OXlmTTdCcEp6c3hjTkJBZWZ2aGh2Zm5OYjA1NERYdlRIZ1Fod21DeUZaSmVBUURJbWx3dVoyWVd0SUxBT2VlY21ibFRwMDdwVjMvMVY3Vi8vMzUzNk5BaDdkdTNMK2xWdmNUUzBwSVdGaGEwc0xDZ1NxV1M5T29naFFnREFPaVRjODRrV2ZqdjlrQTRmdnk0amg4L25xcEFJQWpRSzhJQUFQcFVxVlNzVUNnRStYemVxYlZMTnEyQlFCQ2dYNFFCQUF6QU9SYzBHZzBueWFVeEVBWU5BdWVjNVhJNWkzSFZrSEtFQVFEMEtaZkxXV3QzZ2lSWm1nSmhtQ0FJM3dpRHlVWVlBRUNmY3JtYzVYSzVJSHBHZ2hJT0JCOUJFTDdsODNuQ1lJSVJCZ0RRSitlYzFldDFrMlNGUXNINUNJUjN2ZXRkdXVtbW0vcGVGNTlCd0V3QkpNSUFBUHFXeStVc0NJS2dXQ3k2YXJVcWVRaUVuLzNabjlYYjMvNTI5OUJERDJsdWJtN0RkVGh6NW93T0h6NnNKNTU0b3VmMURnTWcrdTh3Q0tLUEV3aVRqUXNjQVVDZjdyenp6aDJOUm1ObkdBS3RRSENTRkEyRU1CTENFQWdESWZwNCtMbm84OWNMaExpRG9QVzV2LzdFSno3eGc2RitTTWdzd2dBQStuVG5uWGZ1Q0lMZ1N1bml4ajN1UUJoUkVGanIrSWtmZlBTakh6M3Q3eWVHTENFTUFLQlByMzcxcTYrWW1ablpZV1l1Q0lJMUcvYzRBdUdlZSs1eHp6MzNYTS9yTjBRUW1DVGw4L2tmTEN3c25QSDE4MEsyY0l3QkFQUXBsOHRadlY0UHdnaG9CY0xxOFFQMWV0MDU1NXl2WXhDKy92V3ZhMlptWnNNLzVJWU5ndkRqUXFIQU1RWVRqREFBZ0Q3bDgvblZEV3U5WG5jakNJU2MxcG5oYlQrN0lIeXNQUUNpencyRElIeCsrSEV1bDdOS3BVSVlURERDQUFENmxNdmxMSi9QQitGdWhMZ0R3VG5YTVFwOEIwSGtGRXpDWUlJUkJnQXdnRnF0Rmt4TlRZVVJFSHNnUk1VZEJFRVF4UDNqUTRvUkJnRFFwM3crYjBFUVdMaHhqenNRT2gwM0VFY1FSSTQzWU1aZ2doRUdBTkNuMWpFR1FSZ0RjUWRDRUFSQkxwY0w0ZzZDZkQ2LzVtc3dtUWdEQU9oVG9WQ3dvR24xeklFNEE2RzFvUSs2QlVBMEdLSkJFRDNqb0QwSW9vK0hRUkIrdmxnc0VnWVRqREFBZ0Q2ZE8zZk9TcVdTbFVxbDhQTElzUVpDTHBjTFdzY2JqQ1FJcHFhbUNJTUpSaGdBUUo4S2hZTGw4L21nV3EwNk0zTnhCMEpydGlBWGR4RGs4M25MNS9PMnZMeE1HRXd3d2dBQUJsQW9GSUlnQ01JQWlEVVFuSE9XeitlRHVJT2dWcXRaTHBjelpnd21HMkVBQUgwS043RFM2cDBXWXcyRVhDNFg1SEk1Rjc1ZVhFRlFLcFU0WFJHRUFRRDBxMWdzV3JWYURScU5ocHVlbmw3ZFlNY1ZDUGw4UGlnVUNxdlBhVC9EWUdwcVN2VjZmVFVJd2hnSTF5dmMrQmVMeGRYSDI0T2dVQ2hZclZhemNya3NicnM4MlFnREFPalQxTlNVVmF0VnkrVnlWcTFXWGR5QjBENURFQVpCb1ZBSWw3c2FCWjJDd0RtM3VudWdXeERrODNrRlFXQm1adFBUMDRUQkJDTU1BS0JQcDArZnRsMjdkZ1d0Q3hBcDdrQm9OQnBCNit5RTJJT2dXcTNhMHRJU1lUREJDQU1BNkZPaFVMRGw1ZVdnMFdpNG1aa1o1eXNRYXJXYW1abHJENFR3dmd4eEI0R1pXYkZZRlBkS21HeUVBUUFNSUhKcW4vTWNDR29QaEhBM1F0eEIwRHAyd21abVpnaURDVVlZQUVDZlNxV1NsY3Zsb0Y2dmgzL1J4eG9JaFVKaGRWZEM5QXlEVXFta2FCQ0VNUkMrVGpRSWdpQ3dmRDZ2OWlDNDdMTExyRnF0bWlTWm1jM016TmpMTDc5TUdFd3d3Z0FBK2xRdWwrMzgrZk5CbzlGd3M3T3pMdTVBYURRYVFYZ1FZcjFldDJLeHFDQUlMQWlDTlVFUUJFRjQ4YVZMZ3FCUUtGZzRJeEFOZ21xMXFtS3hhS1ZTeVZaV1ZreVNiZDI2bFRDWVlJUUJBUFJwOCtiTmR2NzhlU3NXaTNiKy9IblhTeUMwL3RKM2d3UkNlREdsdUlQQXpLeFNxYWhjTGlmNjgwV3k4a212QUFCa3pjbVRKOTJlUFh0eTRjZXRneEcxc3JLaW1abVoxZWZsODNtclZxdXFWcXVyRzl2V25SbFZyOWRWcTlVME5UVWxxUmtJemptRm42dlg2eW9XaThybGNqWXpNNU9ibVpseHpqa3JGb3RXTEJhdDBXaXNCa0d4V0xTcHFTbHJOQnJoYVkwcUZBcFdLcFdzMFdoWUxwZXpjcmxzalViREdvMkdpc1dpWFhiWlpkWm9OS3hRS0ZpOVhyZDZ2YTV5dVd3ek16UDJ3eC8rc1A2bEwzMnBNZUlmSzFLQ0dRTUFHTUFMTDd3UXJLeXN1TG01T2JleXN1S2s1b1dQZXBsQkNCL3JkUWFoV0N3R1UxTlRMc1laQWl1WHkxYXBWTXc1Wjl1M2IyZFh3Z1FqREFDZ2YxWXVsMDJTWG5qaEJZczdFQnFOUmhBRWdZdGV0amdhQktWU2FmVXl4KzFCRUo1eDBCNEVrbXgyZHRZa0tRd0NTWmJMNWV3SFAvZ0JZVERCMkpVQUFBTTRmZnEwNXVmbkZRU0J5dVd5TFM0dWFuRnhVVHQyN0ZoOWpxOWRESmRmZnJtYm5aMTE0UzZDY0pmQjFOU1VsVW9seStmekNxL0VHTzR5YUozQm9IQjNRcmpMb0ZBbzJNek1qQlVLQlZVcUZTc1dpK0VaRGxhcjFheFdxMm56NXMyTlk4ZU9jY09FQ2NXTUFRRDB6eVFGeDQ0ZGM1TGN3WU1IbmRROFcrR0ZGMTV3dm1jUTJuY1p0TThRaE1jTTlETkQwTHJzY1hpekpidHc0WUsyYk5saWk0dUxkc3N0dHpCak1NRUlBd0FZVExqeHRCRUVRaEFFZ1lzN0NGcFhQTFJubjMyV01KaGc3RW9BQUQvczVNbVRPbjM2dFBiczJlTjFGOE9PSFR2Yzl1M2JuZTlkQmx1MmJMR1ZsUlhidEdtVExTOHYyK3pzckczZXZGbS8vbjhvN3gwQUFDQUFTVVJCVk91L3ptNkVDY2FNQVFBTUwvb1h0dmNaaEVxbFltWVdTRkowaG1CbVppYWNIWkRhWmdncWxZcFZLaFcxenhDMExxVzhlZ0NqcFBDQVJ2dmxYLzdsUnVzZ1JFd3dsL1FLQU1BWWNwSDM3dURCZys3OCtmTk9raXFWeXBwQXFGYXJUcEpxdGRxYVFBZ2pvZEZvdUp0dnZybHcvZlhYNThQZEI1SGRCU3FWU2xhcFZDeDZ5cUVrVFU5UDIvTHlzbTNhdE1rdVhMaGc0ZTRDU2RxMmJadWRQWHZXZHUzYVphZFBuN1pISG5tRUlNQXF3Z0FBNHVNbEVIYnYzcDIvNFlZYjhnUUJSb0V3QUlENERSVUkxMTU3YmVIYWE2L05TY01Id2RHalI0UEhIMzg4SUFqUURXRUFBS016VUNEczJiT25NRDgvbnljSU1BcUVBUUNNWGwrQmNQdnR0K2V2dWVhYWZCZ0VZUXhJVW5zUWJOdTJ6U1NKSU1DZ0NBTUFTRTVQZ1hETExiY1Vycnp5eWh4QmdGRWdEQUFnZWVzR3d1dGYvL3JDMVZkZm5aTUlBc1NQTUFDQTlPZ1lDTGZlZW10K2ZuNCtUeEJnRkFnREFFaWZOWUh3em5lK3MzRDk5ZGZud2lBSVkwQ1NDQUw0eHBVUEFTQjkxbHhKY1dWbEpTZ1VDbExyS29XN2R1M1MwYU5IZzRXRmhVQ1NPY2ZmZVBDSE1BQ0E5REpKZXVtbGw0SlNxYVQySUVoNDNUQ21DQU1BU0xuNStYa2pDQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUdKcExlZ1hTenN4MlNycXU5ZUZKNTl3UEUxd2RBQUJpUlJoMEVRbUNjdHVuS2lJUUFBQmppakJvczA0UXRDTVFBQUJqaHpDUVpHWjVTWE90dDBLZlgwNGdBQURHeGtTSHdaQkIwSTVBQUFCazNrU0dnZWNnYUVjZ0FBQXlhNkxDSU9ZZ2FFY2dBQUF5WnlMQ1lNUkIwSTVBQUFCa3hsaUhRY0pCMEk1QUFBQ2szbGlHZ1ptVjFEemw4QW9sSHdUdENBUUFRR3FOVlJoRWd1Q3FoRmVsRndRQ0FDQjF4aUlNTWhZRTdRZ0VBRUJxWkRvTU1oNEU3UWdFQUVEaU1oa0dZeFlFN1FnRUFFQmlNaFVHWXg0RTdRZ0VBTURJWlNJTXpHeVRtcWNjVGtJUXRDTVFBQUFqaytvd01MT3RhczRRekNhOEttbEFJQUFBWXBmS01DQUkxa1VnQUFCaWs2b3dJQWo2UWlBQUFMekxKYjBDVVFjT0hManVBeC80d095NWMrZVNYcFVzS0V1NjZmbm5uNzg3NlJVQkFJeVBmTklyRURVOVBiM3p5MS8rY3ZrakgvbUlxMWFydXZIR0cxVXVsNU5lclZRNmMrYU1IbnZzTWIzLy9lOHZuRHg1OHErU1hoOEF3SGhJMWE2RW0yNjY2ZFpjTGpkclprNlNabWRuM1lNUFBxZ0hIbmhBczdQc1haQ2FRWEQ0OEdFOThjUVRxNDk5L3ZPZi80OEpyaElBWUl5a0tneHV2dm5tdmRFd2lBYkN3dzgvclB2dXV5L1pGVXpRaVJNbmRQandZVDM5OU5PWGZJNHdBQUQ0a3Fvd3VPV1dXK2FkYytIVWdHc1BoTG01T1hmbzBLR0pDb1QxZ2lCRUdBQUFmRWxWR016UHo5OFNoa0VZQTVyUVFPZ2xDRUtFQVFEQWw5U0ZRVDZmMzJKbWw4U0FKaVFRK2dtQ0VHRUFBUEFsVldHd2QrL2VtM081M0JhMTFtdVNBdUhKSjUvVXdzSkNYMEVRSWd3QUFMNmtLZ3oyN05tenAxQW9iTTNuODZzUklJMTNJQnc1Y2tTSER4L1dpeSsrT1BBeUNBTUFnQzlwRElNdHJRL2RNSUh3OE1NUDY4MXZmdk1JMTc0L1BvTEFPV2ZPT2Z2c1p6LzdwTWRWQXdCTXNGUmQ0R2pIamgzYjgvbDh5Ym5tTnQrYWxNczFMOURvbkpOenpzTG5oODlyYlNCWEgxdGNYTlNmLy9tZjY2dGYvYXE3K3VxcjlhcFh2V3JVMzBwWFI0NGMwYnZmL1c0ZFBYcFVyN3p5eWtETGNNNVpMcGV6OE9meDNlOSs5L3VlVnhNQU1LRUtTYTlBVkd1REYwUm1BMlJtYWpRYXB1WU1Rdmc4T2Vlcy9YbXRhRmg5N1BqeDR6cCsvTGoyNzkvdkRoMDZwSDM3OW8zd3Uxbkw1d3hCKzc4QkFQQWxWV0hRK2l0NGRjT1g5VUJZV2xyU2tTTkh0TEN3RUVzUUVBWUFBTjlTRlFhU1ZLL1hyVkM0dUZwWkRJU2xwU1V0TEN4b1lXRkJsVXBsNE9Xc0Z3UzVYSTQ0QUFCNGw2b3d5T1Z5UWFGUXNHcTFLa25LV2lBa0VRU0VBUURBcDFTRmdYUE9hcldhT2Vlc1dDeTZyQVNDanlCbzM5RDNFZ1RoWXdBQStKS3FNSkF1YnZocXRacEdIUWh2ZXRPYjNMdmU5UzdOemMzMXRLNUpCd0d6QlFBQTMxSVZCcmxjenN4c3pWa0pvd3lFbzBlUDZ1alJvM3I3MjkvdUhucm9vYTZCRU43NitNa25uMHdzQ01MSG1UVUFBUGlVcWdzYzNYbm5uZGRLMmhRRVFkY0xHclVDd1VsU29WQlk4N2x1RjBBYTlFSko3WUVRQnNFVFR6d3g4UGZvT3doeXVaeDk5S01mL2RyQUt3UUFRRVNxd21CK2Z2NmFVcW0wS2R3d3B5a1FObS9lN0MwSU9zWEJJRUVRUHZhUmozemt4TUFyQmdCQVJLcDJKWVFISDBxeVlySG93aXNlQmtGd3lhNkFVZTVpK05qSFBxYXJycnBxb0lpS013allqUUFBOEMxVllkRGEwSzBlZktoMEJVSmZZZEF0Qk1MMy9RUkIrM09qa1VBY0FBQjhTbFVZdERhSWx4eDhxSFFFUXE2UDc2SHJjUVREQmtFMENxVG1CYUY2V1M4QUFIcVJxakNRbWh1OGJodCtKUmdJRytrbkNEWjZyTmNnYUQzZTZ5b0NBTENoVklWQnRWb05McnZzTXR0b3c2OFVCVUo3RUxUSFFaeEJ3RzRFQUlCdnFRcURYQzVuMVdyVkpOblUxTlNHRzM2Tk1CRGFqVElJNnZXNkJVR2c5aURnR0FNQWdHK3BDZ1BwNHNheHRSRlBWU0NFejlzb0NIcU5oSDZDb05QbkpTbWZ6eE1HQUFCdlVoVUd6am5MNS9PQm1ia2dDQ1NsSnhBR0RZSk9qL2tLQW1ZTEFBQytwU29Nd2cxZ0VBVEs1L09XcGtBSVkyQ2pVdzdENzJNVVFWQ3YxNjFVS2czNVV3Y0E0S0pVaGNFcnI3eGlsMTkrK2VwZndXa0toRnd1RjRRZjkzSmpveUdPSWJqa1dnVlM1eUFJZ3NDQ0lHRFdBQURnVGFyQ0lKZkwyY3JLaWtteVVxbTB1dkVlZFNCSXNtcTE2dG9Eb2RjZ2FOK29EeG9FNGZFRDNZSWduODl6akFFQXdLdlVoVUc0RVYxWldaRVNDZ1JKbXBxYWtpS0IwTDU3b05jZzZMVEJyOWZyRmk2ejF5QUl6MGhvRHdMQ0FBRGdVNnJDSUovUFc2RlFDSUlnV04zd3B5VVF3dU1MMWpzTnNaOGdDSUxna2xNUDI0TWduODliclZhelhDNjNKZ1RDZjlkcU5RdS9md0FBZkVoVkdFaHJONlJwQ29SOFByOTZqRUduSU9nV0NmMEdRYjFldDJLeHVMclI3eFlFa2xRb0ZJd1pBd0NBVDZrS2cyS3hHTFNmZ3BlV1FPZ25DS0s3QVBvTmdpQUlyRmFyclFtQjlZS2dVQ2dRQmdBQWIxSVZCdmw4M3BhWGwwMlNUVTlQcjduY1lOS0IwTDU3WUtNZ21KcWE4aG9FaFVMQkNvV0Nva0ZRcTlVc2V2RWxBQUNHbGFvd2tDNXVESmVYbDZVVUJVS2hVRmpkbFJDdVIvaCsyQ0RvZGtEaFJrRVF4Z1FBQUw2a0tnd0toWUsxMzBZNExZR3cwWTJOZkFWQmVHeEJMMEZRS0JTc1dDeXlLd0VBNEUzcXdpQ1h5d1dOUnVPU3V4WWxIUWpkZ2lCNkdxR3ZJQWdmQy8rOVhoQzBiam9GQUlBWHFRcURjK2ZPV1M2WHM1bVpHZVh6ZVV0VElMVHZNZ2lEb05NdUJaOUJVQzZYRlFTQm1aa1ZDZ1ZGZzZCWUxGcXhXQnp5cHc0QXdFV3BDb1B3c3I5TFMwdVNwRFFGUXRDMDdxMlBSeDBFeFdMUm1ERUFBUGlVcWpCb2Jmd3NqSUUwQlVLbkVCZzJDTnBQT2V3M0NLclZxampHQUFEZ1U2ckNZR3BxYXMxTmdkSVVDTjJDSUxwN1laZ2dhSjJtcUg2RG9GUXFFUVlBQUc5U0ZRYlBQLys4dG03ZEdzek96cTdadUtjaEVOcDNHVVNEb051Tmpmb0pndkN4OW8zL2VrR3dzckppcmU4REFBQXZVaFVHNGNiejNMbHprbVJwQ29SaXNSaUVYeThOSGdTMVdpMTZJYU91UWREdHNXZ1FsRW9scTFRcXpCZ0FBTHhKVlJoczJyUXBLQmFMdWZEak5BV0N6eUFJSDR2dUxoZ2tDQ3FWaXNybE1tRUFBUEFtVldFZ05ZOHptSnFhc21xMXVycUJUa01nYkhUcjQwR0RRRks0eTZCakpLd1hCRVFCQU1DM1ZJWEJNODg4WXdjUEhsemQyS1VwRUtJWExPcDA2Mk1mUVJBK0ZoNVF1RkVRc0JzQkFPQmJxc0pBa3Izd3dndkJ5c3FLbTV1YlczMHdEWUVReHNCR2R6cjBGUVNTTmd5QzZlbnA4S1pUQUFCNGtib3dDRGQrTDd6d2dxVXBFS2FtcGdKcDhDQ0lubUVRUGlZTkZ3VEx5OHZhdEdrVFlRQUE4Q1oxWWJCNTgrWTFHN3EwQkVJdmR6b01IOXNvQ01MSGhnMkNDeGN1MklVTEYvci9LUU1BMEVYcXd1RFlzV01teVE0ZVBMaG1BNTEwSUhTYUlWanZ4a2E5QmtHcFZMSlNxYVJCZ21ETGxpM01GZ0FBdkVwZEdMVGVkT3pZTVdtRWdkQWVDdTJCRU43TG9KOGdhTDlRVWJjZ2tEUlFFQ3d1THRxMmJkdUlBd0NBTi9ta1Y2Q0ROUnU2a3lkUDZ2VHAwN1pueng2MWp2NlhKTDN5eWl2MjBrc3ZhZHUyYmF1UFRVMU5tU1NabVhLNW5KYVhsMVd0VnUyeXl5NlRKSVgzUGdqLzhsOVpXVkcxV2xXNVhMN2tjODQ1NVhJNVZhdFZOUm9OdSthYWEvSlRVMU15czlXekVFcWxrdVh6ZVZXclZXdWR0YUJpc1dpTlJzTWFqWWFLeGFMbDgzbVZTcVhWeDhMZEVaVkt4ZXIxdXNybHNzM016S3g1YkhwNjJ1cjF1dFhyZFczYXRHbjErSVV0Vzdhc25ycTRhZE1tbTU2ZTF0bXpaKzNZc1dPTkVmeDNBUUJNZ0xUTkdJVENtWVBWditCSE5ZUFEvcm5veDRQY3h5QjZ5cUhVbkExb3pRNm9ueG1DeGNWRlcxeGNWRGhEY1Bic1dkdTFhNWZ0MnJWcjBKOHhBQUNYU09PTVFidFV6Q0JjZi8zMStYQUdvSjhaZ2xLcHREb2JFTTRXbE12bDFjZkNzTmhvaG1EYnRtMnJNd1N6czdPMmVmTm1uVDU5MnA1NjZpbDc5dGxuMlowQUFQRGlrb1B2VXM3cDRqbzdTVHA0OEtBN2YvNjhrNlJLcGVJa3FUV0RzUHB2U2FwV3E2NVdxemxKQ21jQ1ptZG5YYjFlZDVJVXZtODBHaTc4L016TXpPcGpCdzhlTElVekJOTEZ5eGFILzVZdXpoQ0UvNDRlUHhCOVg2bFViSHA2MmlRcHZBNUJPRU1nYVhXR1FOSWxNd1NTZFByMGFYdm1tV2RzWVdFaFVGczRBUUF3akt5RlFXamtnWERQUGZkTVNZTUhRWFIzZ1RSNEVFZ0tIbjMwMGRXRE5BRUE4Q21yWVJBYVdTQzg3VzF2bS9JVkJPRkZpUVlJZ3NEN1R4QUFnSWlzaDBFbzlrQjR3eHZlVUNJSUFBRGpibHpDSUJSYklMenhqVzhzclJjRW5jNHdrQWdDQUVDMmpGc1loTHdId3IzMzNqc2w5UllFMGVNSEpJSUFBSkFkNHhvR0lXK0JjUC85OTA4TkVnVFJxeFJLQkFFQUlOM0dQUXhDUXdmQ1QvLzBUMDhOR3dSbno1NDFTWW9Hd1NPUFBOSnd6bkdHQVFBZ0ZTWWxERUlEQjhMUC9NelBUTFdlMHpFSW9yc0xKSUlBQUpCTmt4WUdvYjRENGVEQmcxTlNiMEVRM1YwZ0VRUUFnT3lZMURBSTlSd0l2L1JMdnpRMVNCQzBqaDhRUVFBQXlJSkpENFBRaG9Gdy8vMzNUL1ViQk04ODg0dzkvdmpqQVVFQUFNZ0t3bUN0cm9Id3RyZTlyU2gxUCtWUUlnZ0FBTmxIR0hSMlNTRDg3dS8rN2xRdk56WWlDQUFBV1ZaSWVnVlNLcnhKMFdvNHRlOHkyTFZybCszYXRldVNJSENPMWdJQVpCZGhzTDdWUUFoUE95UUlBQURqakREb2paVktwU0FNQWtWdWZVd1FBQURHQ1dIUW8vWWdTSHA5QUFCQXNwZ2FBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBTXlzWkdhbHBOY2pUVnpTS3dBQXdLaTFZdUE2U1ZlMUhqb2o2YVJ6YmlXeGxVb0p3Z0FBTURFNkJFRzdpUThFd2dBQU1QYk1iS3VhTWRBdENOcE5iQ0FRQmdDQXNkVUtndXNrelE2NGlGTnFCa0xEMjBxbEhHRUFBQmc3SG9JZ3FxNW1JSnlhaEVBZ0RBQUFZOE56RUxTYmlFQWdEQUFBbVJkekVMUWI2MEFnREFBQW1UWGlJR2czbG9GQUdBQUFNc2ZNZHFvWkJPV0VWMFVhczBBZ0RBQUFtWkd5SUdnM0ZvRkFHQUFBVWkvbFFkQXUwNEZBR0FBQVVpdGpRZEN1THVrNTU5d1BrMTZSZmhBR0FJRFV5WGdRdEt1b2VaR2tUQVFDWVFBQVNBVXp5MHU2UXVNVEJPMHlFUWlFQVFBZ1VhMGdtR3U5RlJKZW5WRklkU0FRQmdDQVJFeGdFTFJMWlNBUUJnQ0FrU0lJTHBHcVFDQU1BQUFqUVJCc0tCV0JRQmdBQUdKRkVQUXQwVUFnREFBQXNUQ3prcHBuR0Z3aGdtQVE1OVFNaEpkSCthS0VBUURBcTBnUVhKWHdxb3lMa1FZQ1lRQUE4SUlnaU4xSUFpRVg1OElCQUpQak4zL3pOL2VmT25XS0tJalByS1E3ek96MjF1Mm1ZNUdQYThFQWdNbnk0eC8vK05vUGYvakQ3dm5ubjllZVBYdTBaY3VXcEZkcDdDd3RMZWxESC9wUStUM3ZlVS81TzkvNVRpd0hKN0lyQVFEZ3hTMjMzSExBekp3a0ZRb0Y5OWEzdmxVUFBmU1E1dWJta2w2MXpGdGFXdExDd29JV0ZoWlVxVlFrNmR6blAvLzViOFR4V29RQkFNQ0wrZm41ZThJd0lCRDhPSFBtakk0Y09SSU5nbEJzWWNEcEl3QUFYOHk1dFg5djF1dDFmZXhqSDlPeFk4ZmNndzgrcUFjZWVFQ3pzN01KclY1Mm5EbHpSb2NQSDlZVFR6d3g4dGRteGdBQTRNWGV2WHRmRjg0VXFMVjlhWjlCbUoyZEpSRFcwVWNReERaandNR0hBQUF2ZHU3Y09TZEowVmtENTl6cXg4NDVWU29WZmVsTFg5SkhQdklSVjYxV2RlT05ONnBjSHNjN0xQZm56Smt6ZXV5eHgvVGJ2LzNiK3U1M3Y5dkxsMVJPbmp3Wnk4R0hoQUVBd0l1cnJycHFUUmdRQ0JzYklBaENoQUVBSU4xMjd0ejVxdllBaUw0UC8wMGdEQlVFb2RqQ2dHTU1BQUJlek0vUHZ6YWZ6Njk3ak1Ha0g0Tnc0c1FKTFN3czZQang0OE11aXRNVkFRRHBOajgvdjArdDdRcUJzTmFKRXlkMCtQQmhQZjMwMDE2V2w4dmxYdnJzWnovN243MHNyQTFoQUFEd1l1L2V2WGUxYi9COUJjS2hRNGRHOGozNDVqc0luSE1tTmNQZzZOR2ovOFhMUXR0d2pBRUF3SXVkTzNmdWt0WWVVMkJtTWpQbGNzMWI4d3g2RE1MSFAvNXhOek16bzV0dnZuazAzOHlRVHB3NG9mZTk3MzM2a3ovNUUvM29SejhhZW5uT09XdjliTUwzbGU5Kzk3dkRMN2pUYThXeFVBREE1TG50dHR0ZXM5R013TEF6Q0hOemMrN1FvVU82Nzc3N1l2OStCaEhYREVINysxd3VkKzR6bi9tTW54ZHBmODA0RmdvQW1EeTMzMzc3bmQwMjlPTWVDS01LZ21nWWZQclRuMzdHeTR1MXYzWWNDd1VBVEo3NStmazdDb1hDdWh2NmNRdUVJMGVPNlBEaHczcnh4UmU5TEs5VENJVC9Eai9PNVhMbW5IdjV5SkVqejNwNTBmWjFpR09oQUlESmMrZWRkOTVlclZaWGI1NGtqVzhnSkJVRWtlY3NFZ1lBZ0ZUYnUzZnZiY1ZpMFVuU3VBWkNDb0lnZk03aXB6NzFxVzk2V1luMmRZcGpvUUNBeVhQcnJiZmVHbTZneHkwUTRnaUM5Z0RvY0J4QnQrTUx6RG0zK01sUGZ2SmJYbGFtZmQzaVdDZ0FZUExjZHR0dGU5czMwR2tJaFBlKzk3M2F0Mi9mUU45VDJvSWc4aldMbi9qRUo3N3RaYVhhRk9KWUtBQmc4a1EzZUtGYXJTWkptcHFha2lSVnExVkpVcUd3L3ViSHJMbW9ScU1oU2NybjgrRnJyUHY4OXMrZk9uVkt2L0FMdjZEOSsvZTdRNGNPOVJRSVMwdExPbkxraUJZV0ZtSUpnblhPTk9qcjhiZ1FCZ0FBTDNLNW5BVkIwUEZ6U1FmQzhlUEhkZno0OFhVRFlXbHBTUXNMQzFwWVdGQ2xVbGwzdlhvVlJ4RGtjam5MNS9PZGY5QWVFQVlBQUM5YUI4cEprcklVQ0ZrS2d2QnpjU0lNQUFCZTFHbzFLeGFMa3FTc0JNTGV2WHZkMHRLU2x5RFlLQVI4QlVIMFRJVTRFQVlBQUMrY2N4WnU4TE1TQ04vNjFyZDB4UlZYREhVZ3ZzOGdpQjQvRUEyQ2JvL0hnVEFBQUhnUjNYaGxKUkJhN3djS2d5U0RJSi9QRXdZQWdIUmI3NnlFdEFkQ1A1SU1ndkI5clZZakRBQUE2ZGJMV1FscEN3VDFNVnZRU3hDMEh3dlE3ZkgyU0dnUGd2Ykh3L2YxZXAyRER3RUEyZERQV1FscENZUmVyZ21RbGlDWW1wcTY1UGx4SUF3QUFGNVVxMVVMTitBWkNvU3VHMWdmUWRCdE44SWdRVkN2MXdrREFFQjJPT2NzM0dCbktCQXUyY0IyQ29Ebzh6cHQrTHM5N2lNSWdpQlluWW5oNEVNQVFHWkVqekhJV2lCSTJRaUMxbFVQdXg3TDRRTmhBQUR3b3RNeEJoa0loSTVYS1BSeFVhSk9ueDgyQ01MMVo4WUFBSkI2MFJtRHJBU0NKRXNxQ09yMXVnVkJvUFlnaUI2M0VBMkN0b2dnREFBQTZSYmRvR1VsRU1JWVNDb0lXdi91T1FoS3BaS0NJTEJxdFVvWUFBRFNiV1ZseFVxbDBwckgwaDRJN1dHUTlpQ28xV3JpR0FNQVFDWTQ1MnhsWlVXU2xKVkFDS05na0NEb2RLcGkrK1BSSUFnZmJ3K0M5ak1OMWd1QzhIa1dIaVFSQThJQUFPQkY5QmlEckFSQ3FWU3lYQzdYMTY2RVFZT2cyL3QrZ2lEeW5qQUFBS1JicDJNTTBoNEkvZXhLU0VrUXFGYXJXWnlYUmlZTUFBQmVSRGVRb2JRSFFybGN2bVJYd3FBM05vb3pDR3ExMnVwc1RLRlFZTVlBQUpCK25jSWdsTlpBQ0tOZzJDQ0lmanhJRUFSQllPSEZsdFlMZ3NqMUN3Z0RBRUM2TFM4djIvVDA5THJQU1ZzZ3RNSmc5Y0ZPUWRCdFE1OUVFTFJtQzlhTnNHRVJCZ0FBTC9MNXZDMHZMMHVTc2hJSTBkMEljUVpCdUp1aFBRamFyMllZQmtFWUFPMUJVS3ZWd3NlNy8zQ0hSQmdBQUx5SS9oV2JsVURvZDRZZ2V1dmpmb09ndGRFZk9Baks1YktDSUxEVzk4Mk1BUUFnM1RwZHZ6L3RnZERwaklUMWdpQjY2K09OZ3FCWUxDcWZ6M3NMZ2xxdHR2bzRZUUFBU0wzMWJ1eVQxa0NZbnA2K1pGZENweURvNWNaRzBTQ0lubUVRRFlMb0tZZURCRUd4V0RSSnFsUXFoQUVBSU4yV2xwWnNabVptM2Vla0xSRHE5WHJIc3d4OEJJSFUrUm9Fa2dZT2dtcTFhdUcvNDBJWUFBQzh5T2Z6dHJTMEpFbktTaUJFRHo3TVFoQ0V1MEJLcFJJekJnQ0FkSXR1TkxNU0NQbDhQdWdVQk8xWE0reDB5dUdvZ3lENkdMc1NBQUNwRjI3VW90SWVDSzEvRDNXblE2bS9JS2pWYWxhcjFkUWVCTkZkQk4yQ1FHcEd3M3JIY3d5TE1BQUFlRkVvRkt4UUtGaTlYbmZ0bjB0cklPVHorU0I2eW1McmEySVBndkRmL1FaQjYzdGR2VjVFSEFnREFJQVg1ODZkTTBtYW5aMVZWZ0poOCtiTkZnMERIMEVRL1dzK0dnU1I1NjRKZ3VpR2Y2TWdhSDJ2OXNvcnJ6QmpBQUJJdDNERGQrN2NPVWxyQTZFOUZGSVVDT1pyaG1DaklBZ2Y3N2JoN3lVSXdvOGJqUVpoQUFCSXQvYlQ2S0tCRUVwYklJUlJrSlVna0pyWE1ManNzc3NJQXdCQXVuVzdHbC9LQThIQzB3Nkh2YkZSZXhCME9zTWcrdkVnUVNBMWJ4VzlhZE1td2dBQWtHNGJuVnVmeGtBSVp3eUdEWUxvMS9nTWdrcWxZcFZLUlZJekNNcmxza25TaFFzWENBTUFRTHFkT25YS0pHbHVibTdkNTZVcEVGcW5LZ1paQ1lJNHIxOFFJZ3dBQUY2RUc3aFRwMDVKeWtZZ2JOMjZkYzB4QW4zZStuamtRVEE5UFcyU2RPYk1HV1lNQUFEcEZtN0VRbGtJaEhCalBjaXRqM3NKZ21xMWF1R3BrZEVnV0ZsWnNjanN4V29RaEQvRGJrR3d2THhzVWpObzF2MEdoMEFZQUFDODJMeDVjOGVObFk5QXlPZnoxbWcwbk85QUNIY2xESE9udzFFR1FYalE0ZmUvLzMzQ0FBQ1Fic2VPSFROSk9uandZTWZQRHhNSUlkK0JrTXZsTEk0Z2lKNjZHUTJDNkJrR2d3UkJlTkRoOXUzYkNRTUFRT3FaSkIwN2RreFNOZ0lobjg5M1BLaXduenNkOWhzRWtnWU9naTFidHRqaTRtS3NCeUFTQmdBQVg5WnNzTElRQ05FWmd5d0V3ZUxpb2lScDE2NWR6QmdBQUZLdjQ4WXF6WUd3ZmZ0MjZ4UUV2ZHpZS0JvRTBUTU00Z3lDYmR1Mm1TU2RQbjJhTUFBQVpFWm1BbUZsWmNWYVp5UU1mS2ZEY0RuUmp3Y0pnZ3NYTHRpRkN4Y2tyUTJDTUFZazZlelpzN1pyMXk2NzVaWmJDQU1BUU9ha1BoRHkrYnhsS1FoMjdkcWwwNmRQMjlHalI5ZjkyUXpqa2x0aUFnQVFFOWZwL2NHREI1MGtuVDkvM2tsU3BWSnhrclN5c3VJa2FXNXViczNIMVdyVlNWS3RWbk9TMUdnMG5DVE56czQ2U1FxdmZ4QytEei9mYURUY3pNek1tc2UyYjkrZXUvWFdXNHMrNzJNUWZiOVJFSVEvbU9oQmhaMkNRRnF6K3lCNDlORkhneDUvNW4wakRBQUFvNWFhUUNpVlNyazc3cmlqNkNNSW9oZDRpZ1pCR0FQUzJpRFlzbVdMU1ZKN0VKdzllOWFraXdjWWppb0lRb1FCQUNBcGlRZkNsVmRlbVh2TmExNVRUSE1RUFBMSUl3M25YS3luS0VZUkJnQ0FwQ1VXQ0s5NjFhdmM3YmZmUGhWSEVIUTZ3MEJLYnhDRUNBTUFRRnFNUEJBMmI5N3M3cnJycnFtTmJtd1VybUMzT3gyT1F4Q0VDQU1BUU5xTUxCQTJiOTdzOXUzYk41VjBFRHp6ekRQMitPT1BCMGtHUVlnd0FBQ2tWZXlCc0dYTEZuZjMzWGRQZFFxQ1lTNUtKR1V2Q0VKY3h3QUFrRllkTjVhK3I0T3dzckppdzl6cGNNQmRCc0Vqanp4aXpqbHpMbDEvbzZkcmJRQUE2TTc3RE1LMmJkdmMvdjM3aTlKb1pnZ1VDUUt2UHhtUENBTUFRTlo0QzRUdDI3ZTcxNzN1ZFd2Q0lLNGdlUFRSUjAxZFprSFNoREFBQUdUVjBJRnd4UlZYdU5lLy92WEYxdk42RG9Mb3JZK2pRUkM5NjJIV2dpQkVHQUFBc203Z1FOaXhZNGVibjU4dlNnUkJpREFBQUl5THZnTmhibTdPdmVVdGJ5bEtCRUdJTUFBQWpKdWVBK0dhYTY1eGQ5OTlkMUZLOTQyTlJva3dBQUNNcXcwRFlmZnUzZTYxcjMxdGtTQzRpREFBQUl5N3JvSHc2bGUvMmwxOTlkVkZxWE1RSkgybnd5UndnU01Bd0xoYjkwSkpOOTEwa3kwdUx0cmk0dUpFQjBHSU1BQUFUSXBMQW1ISGpoMWFYRnkwdE4vWWFKVFlsUUFBbUZUdTBVY2ZkZHUyYlNzU0JCY1JCZ0NBU2VZZWZmVFJJa0Z3RVdFQUFKaGs3b01mL0dBaHJYYzZCQUFBbytYdXYvLyt2Sm54aHpJQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUJCTEF5UUFBRTFGSlJFRlVBQUFBQUFBQUFBQUFBRUQydUtSWEFKZ2tacGFYTk5kNlc1SjAwam4zY3JKckJRQVhFUWJBQ0xRRlFhSHQwK2RFSUFCSUNjSUFpSkdabGRTTWdhdDBhUkMwSXhBQUpJNHdBR0xRQ29McjFBeUNmaEVJQUJKREdBQWVEUmtFN2M2b0dRZ3JIcFlGQUQwaERBQVBQQWRCT3dJQndNZ1FCc0FRWWc2Q2RnUUNnTmdSQnNBQXpHeVRMaDVVT0dvRUFvRFlFQVpBSDh4c3E1b3pCTE1KcjRwRUlBQ0lBV0VBOUNCbFFkQ09RQURnRFdFQXJDUGxRZENPUUFBd05NSUE2Q0JqUWRDT1FBQXdNTUlBaU1oNEVMUTdLZW1VYzY2UjlJb0F5QTdDQUpCa1pqdlZESUp5d3F2aVcxM1NLUkVJQUhwRUdHQ2lqWEVRdENNUUFQU0VNTUJFbXFBZ2FFY2dBRmdYWVlDSk1zRkIwSTVBQU5BUllZQ0pRQkIwUlNBQVdJTXd3Tmd5czd5YWx5eWVFMEd3RVFJQmdDVENBR09vRlFSenJiZEN3cXVUTlFRQ01PRUlBNHdOZ3NDcnVwb1hTZnJycEZjRXdHZ1JCc2c4Z2lCV0ZUVUQ0WWRKcndpQTBTQU1rRmtFd1VnUkNNQ0VJQXlRT1daVzBzV0RDZ21DMFNJUWdERkhHQ0F6V2tGd25acFJnR1FSQ01DWUlneVFlZ1JCcWhFSXdKZ2hESkJhQkVHbUVBakFtQ0FNa0RvRVFhWVJDRURHRVFaSURZSmdyRlFrUGVlYyszSFNLd0tnUDRRQkVtZG1XOVVNZ3RtRVZ3WCtuVk56QnVIbHBGY0VRRzhJQXlTR0lKZ29CQUtRRWJta1Z3Q1Q1dy8rNEE5S0w3MzAwdTJTN2hCUk1DbG1KZDFoWnJlM2doQkFTakZqZ0pIYnZYdjMxcDA3ZDk3eDRJTVA2b0VISHREc0xHMHdnWmhCQUZJcW4vUUtZUEpjZnZubFpVbFhmZVVyWDlIQ3dvS3ExYXB1dlBGR2xjdmNHWGtTTEMwdDZVTWYrbEQ1UGU5NVQvazczL2tPWnk4QUtVTVlZT1F1di96eWNpNlgyeGtFZ2VyMXVpTVFKa01yQ1BSYnYvVmIrdHJYdnFaYXJWWTVlZklrWVFDa0RMc1NNSEs3ZCsvZVdpNlhiek96MWYvL0NvV0NrNlNycnJwS2h3NGQwbjMzM1pmY0NzS3JNMmZPNlBEaHczcnl5U2RWcVZTaW56cjMrYzkvL2h0SnJSZUF6Z2dEak56dTNidTNUazlQM3hvTmcvRGZCTUw0Q0lQZ2lTZWU2UFlVd2dCSUljSUFJM2ZERFRkc0taVkt0NFVmRXdqanBZY2dDQkVHUUFvUkJoaTVWaGpjMnZyd2tpaUkvcHRBeUk0K2dpQkVHQUFwUkJoZzVHNjQ0WVl0NVhKNWJ6UUVSQ0JrMW5QUFBhZUZoWVYrZ2lCRUdBQXBSQmhnNU1Jd0NEOG1FTExweElrVE9uejRzSjUrK3VsQkYwRVlBQ2xFR0dEa2JyamhoaTNUMDlQelV1ZU5mMHZQZ2ZEZTk3NVgrL2J0aTMyOTBlUWhDRUtFQVpCQ2hhUlhBSlBKT1dkbTVweHpKalUzK05GL1M3S0xUNzMwT2ZWNlhaSjA1c3daOTQ1M3ZFTjMzWFdYRGgwNlJDREV5R01RQUVneFpnd3djbnYyN05sY0twVnVVZXYvdjI2ekJvUE1JQkFJL3NVWUJNd1lBQ2xFR0dEa0ltRVFJaEJTNk1pUkkxcFlXTkRKa3lmamVnbkNBRWdod2dBanQrZi9iKzl1ZXR1bzlnQ00vMmVPRXlmTlM4T0xTbEtja2pacDBsdVhJQlN4Nkk0UHdJWkZLckZnaldBUEd4YjBtL1FEV0FpcElFVkFLa1hpRzl3TDBYMnBFQUlFMVZYcExVa29pUjNQdVl2NG1KUEpPSDZkT2NlZTU3ZkpaRHh4YkxmU2VUSStuck8yTmxNb0ZQNG1JcUtVT2pQb0V3aHViVzF0eWIxNzkrVHg0OGRwL3lyQ0FQQVFZWURNTmNMZ2hsai8vd2dFOXpJTUFoRVJDY1B3Znc4ZVBQaDdKcjhNUU1jSUEyVE9DZ09EUUhBb3l5QXdrMGRGVHNKZ2UzdjdINm4vVWdCZFlYVkZaTzdGRjE4c0txVmVDSUpBNUhTY0JscHIwVnBMR0liTi9VRVFpRG0yMWJaOUgwbkhSRkVrVVJUSm8wZVBndnYzNzh0UFAvMGthMnRyTWpzN20vYlQ5ZExCd1lFOGVQQkFQdjc0WTluZTNwWm56NTZsK3Z1Q0lOQ05mNVBtZGhBRWg5OS8vLzEvVS8zRkFMckdHUU5rcmx3dVQ0ZGh1TmJKWC85cG4wRjQ2NjIzNUlNUFBwQlNxZFRYY3hvV0J3Y0hVcWxVcEZLcHhGYzZUSVY5aGlCaCszZk9HQUQrSVF5UXVYSzVQSzJVV2pXRE5JR1FQcytDd0p3MStQMnJyNzdpb2dpQVp3Z0RaTTZFZ2ZtZVFFaVBxeUN3WTZEVi9qQU1uMzc1NVpmZnBmNmdBSFNGTUVEbXl1WHlkS0ZRdUM2U1BFZ1RDUDN6T1FqTXRsTHE2ZGJXMW03cUR3NUFWd2dEWks1Y0xrK0x5SW9aaEVVSWhFRXhTeDkvODgwM3pvS2czWFlZaHVabmZpY01BUDhRQnNqYyt2cjZWTDFldjI2K0g1WkErT2lqajJSdWJxN2o1NWtsRXdROUxIM2NrMzZDd05xM1J4Z0EvbUVSSlRneFBqNnVSVVNxMVdwd2ZIeXNSVTRHNGFRRms0enpGbHFxMSt2bTlIUnp2L2w0M0NBV2EvcmlpeStDblowZGVmZmRkK1dkZDk3eEpoQ0dOQWdrdmgrQVB6aGpnTXl0cjY5UFJWRzBQRFkyMXZ6L1Y2MVdtOXUrbjBHWW5wNTJIZ2pESEFUV0hJUGZQLy84ODMrbSs4Z0JkSXN3UU9iVzE5ZW50TmJYekdCTElIVHU0Y09IVXFsVXZBaUNWaE1OMndXQk5jZGdqekFBL0VNWUlITW1ETXozQkVKN0tTNTluQ2pOSUREN2dpRFl1My8vL3IvU2VnNEFla01ZSUhQcjYrdFRJbkpWSkhtd0pSRCs0bXNRdEpvcjBPVmJDb1FCNENIQ0FKbmIyTmk0Y0h4OGZMWGRnSnpuUUJqeElERGIrNFFCNEIvQ0FKa3pZV0MrSCtWQStQREREK1h0dDk4Kzh4cTBrcE1na0RBTWRSQUUrNTk5OXRtL0IvbDhBUFNQTUVEbU5qWTJMa1JSdENRaUVrVlIyMEY0MkFOaGZuNWUzbi8vL1hNRFlXdHJTeXFWaXZ6d3d3OHRqeG1VVHRZeFNMcTlseUNJejBjd3g1Z3crUFRUVC84em1HY0ZZRkFJQTJSdVkyUGpndGI2RlhzZ3pXc2diRzF0eWIxNzkrVHg0OGVTdGw2Q0lINnRnVjZDd0w3ZDNsWks3VlVxbFlmOVBpOEFnMFVZSUhPWEwxKytNRDgvLzRyNVBvK0JzTG01S1Y5Ly9YVXVnOEQ2K1gzQ0FQQ1BjdjBBa0Q4WEwxNHNqSStQWDR5aVNKUlNRUkFFNWlxRnplM0cxUWZQN0xlMzYvVzZtUHRRU29sU1N1cjFlaEJGa1VSUkpHRVl0cnFQeFB1MUhtS2d0UmF0dFlSaDJOemY3dkhFN3lQcG1DaUtaRzl2VDc3OTl0dkFYRlV4TFkyUEJMYmNUdHJYT01VZlA2NlRZNXI3N051VGpqWDdSYVM2dTd2N0pOVVhBVURYdUNReW5EQi9OZFpxTlJFNStldmY3Tk5hQitZdnpDaUtUdTFQMnJidlkxZ3V0V3h1NitNbGJLblYrL3VkbmlIb1pvNUJOMmNJN1AyTnI2Y2VId0EvRUFad0lnZ0MzV3B3ejBNZ0RPSTFqQnVpSUJBUkVhVVVZUUI0aURDQU0rMEc5MUVPaElTM0hucDIzc0RmYW51UVFYRGVmSVNrWTh4MnJWWWpEQUFQRVFad29wdkJmVlFEWVZDdm9ROUJFSC90emdzQzgvb0Q4Qk5oQUNmQ01OVGREdTdERmdodDdxTm5veEFFalgvL3pwODBnTXdRQnNoY29WQTROWGlNYWlDSU5hOGdmaC94L1oxSUl3aGF2UTNRVFJDMG1tTVFENEx4OGZGVGNjQWNBOEJQaEFHY0dNVGdQc3lCME10cmxUU3d4KyszbHlCb2R3WmhVRUZnUHA1cGJ0ZWFMZ0I4UkJqQWlXcTEyaHcwUkFpRUpLTVVCUEV6RTJFWWFrMFpBRjRpRE9CRUVKeDhYSkZBU0g1dDdLL3Q5b2tNUnhERTQ4QzhwUVRBTDRRQm5MRUgwNXdHUXVMcjRXc1FKUDNWTDlKZEVNVHZBNEIvQ0FNNDBXckF6a3NnMlBJV0JHYlNJWjlLQVB4RUdDQnpoVUpCbTdjUzhod0lXUVZCL0hIMUVnVDJkcjlCWVBhZjkzWUtBSGNJQXpqVHlZQTlxb0VRQktjL3NwaDJFUFI2MmVJMGdzRGNWOUxaRXdEdUVRWndvdFhBbkpkQU1NNExndk11TlR6TVFWQXNGa1VwSlVkSFI0UUI0Q0hDQUU3RUI3MDhCa0tyc3diblhWblE5eUNJWDdRb0tRaFlJd0h3RzJFQUo0Nk9qblN4V0F6eUdnaDJGTFFMZ25adktmZ1dCUEg3aWdjQmt3OEJ2eEVHeUZ5eFdOUWkwanlWbk1kQXNNUEFoeUN3TDFXY2RoQ1liUzV3QlBpSk1JQVQ5a0NaeDBBUVNXOWhvMDZPU1FvQ2ExK3FRV0MydWNBUjRDZkNBRTZFNGRuVkZmTVlDSU1NZ3ZoOGhHNkRvSlB0UVFTQjJhN1g2d0xBUDRRQm5HazEyT1loRUpMbUdOaXZpYjEvMUlMQUhHYy9GZ0QrSUF6Z2hEM0E1akVRUlB4WStyaVhJREEvMzJzUWlKeThqV0JXV3dUZ0Y4SUFUcGkzRXZJYUNFRVE2RzdtR0F3cUNPSkxIN2ZhYmhjRXRWcE5tK2ZUYlJBa2JRUHdCMkdBekUxTVRKd2FGUE1ZQ0ozT01SaGtFTVJmTTFkQllHN25qQUhnSjhJQXppUU43c01XQ0NJaVkyTmpYZDlIdXprR2FRVkJxempJTWdqTWZpNkpEUGlKTUlBVGYvNzVweFlSbVp5Y1RCemNoeVVRdE5hQkdRaTdDUVFSdjFZNlRMcXZ0SUxBSERzMk5rWVlBQjRpRE9DRVVrclg2L1VncjRFUUgraEhMUWppbDBhMmcwQkVaR0ppNHRSWkZ3RCtJQXpnalBWNTl0d0ZncGw4MkUwUXhEOG1hQjVuR2tFUUg5aDdDUUw3ckVFc0NEUlJBUGlMTUlBVDlrQ1p4MEN3b3lDUFFWQW9GSFQ4M3dhQUh3Z0RaRzVtWmtZL2UvWk0xK3YxSUsrQklPTEgwc2RKUWRBcURnWVZCSTNYUXNkL0R3QS9FQVp3d2g0VThoZ0labjhhUWRETjBzZnQ1ZytJREQ0SXpMR0hoNGVFQWVBaHdnQ1oyOW5aa2R1M2I1OFp3UElVQ01mSHgyZm1HQXd5Q09MMzVWTVFtTmN3Q0FJQjRCL0NBRTRjSEJ4b0VaSHA2ZWtnajRGZ0poK0t1RjM2T0dtNzB5Q3dqK3NtQ013K0xuQUUrSWt3Z0JQbTQ0cDVEUVFSUDVZKzdqY0lyUGtIcDQ0NUx3ak1Obk1NQUQ4UkJuRGgxS0NUeDBBSXcxRDdzTktoU0g5QllOOHUwbGtRbUczbUdBQitJZ3pnaEQyNDV6RVE0cE1QTzlsT1krbGpJOHNnTUxjRDhCTmhBQ2NheSs0R2VRMEVlK0poTDBFd3FLV1BrNDVOSXdqaU1jQmJDWUMvQ0FNNFlROHVlUTJFZm9NZ3pYVU1SUDZhVUpqMGMvMEVnUUR3R21FQVoreUJSaVJmZ1hCZUhQZ1NCUEVKaFNLOUJVRThCb3JGb2hZUitlMjMzNGdFd0VPRUFaeDQrdlNwRmhHWm01c0w4aGdJU1c4bCtCb0U4WUc5bHlBd01TQWlZbDVIQUg0aURPQ0NOaDlYekdzZzFHbzFQVXhCMEdyQTd6VUlpc1dpcnRmckJBTGdJY0lBenRnRGRoNERJZTBnaUw4ZXZnU0J5TWxIRlM5Y3VFQVlBQjRpRE9DRUdVUnF0VnFReDBCb2RkVkRWeXNkMnY4bUl1a0dnUUR3R21FQUo4Ykh4M1cxV2czeUhBajJSWTd5RkFRVEV4TmFSR1JxYW9wSUFEeEVHTUNaOGZGeE05Z01SU0RZK2cyRU1BeTFVa29yeDBzZm0yUDdEWUw0aE1MemdzQjhCZUFud2dBdWFHdEFDWVlsRU93WU1Ib05oTVp6UERPdzkzdlpZdnZZWGhZMk1ub0pBdnVzUWJzZ2FOeE9JQUFlSWd6Z3hNOC8vNnhGUkVxbGtvamtMeERNR1FQejh6a0xBaEVSbVoyZEpRd0FEeEVHY0tKWUxPcWpvNk1ncjRGZzdudVFDeHYxR2dTZHZLVXd5Q0NZbkp3a0NBQ1BFUVp3eG40N0lXK0JVSzFXZFZJY1pMMzBjZnoyK1A0MGdzQzhobzhlUFJJQS9pRU00SVFaUEE0UEQ0TThCb0tJSDBzZnV3Z0M0K0xGaTV3NUFEeEVHTUNKbVprWnZiKy9IK1ExRUpSUzJwZWxqenNOZ3ZnMUNIb0pBdnNqaWovKytDTmhBSGlJTUlBTFd1UWtEa1JFOGhnSVpyL3JwWS9OZHFkQllFZEFyMEh3eHg5L0VBU0F4d2dET0xHenM2TkZSTjU4ODgwZ2o0RWcwdGtaZ3JTWFBuWVZCSTFQSkJBSWdJY0MxdzhBdVJVMnZnWWlKNEZnYnRqZjMyOXVIeDRlTnJlUGpvNmEyNlZTS1lqdnExYXJ6ZTFhcmRiY3J0ZnJ6ZTI1dWJubTl2SHhjV0IvalI5cmIwOVBUNS9aYjk4ZVJWSGl6MDFPVGlZZXM3aTRXRmhZV0ZEbSs3U0RvTlhTeDQ2Q1FQYjI5clNJUkhmdjNxMEtBSzhRQm5BbGtOUC8vM0lWQ0V0TFMrclNwVXVGVG9NZ3phV1Awd2lDK05zRnNTQVFFWkdGaFlYNmUrKzlWeE1BWGlFTTRNcVpLTEMzUnowUXJsNjlxbDU2NmFWQ0hvUGcrZWVmMTQzZkh4RUdnSDhJQTdpV3kwQllXbG9xbEVvbDFVa1FaTG13VVh3ZGcxNkN3TDZpWVZJUWlJZzhlZkxFdkpWd0xBQzhRaGpBRjdrS2hKV1ZGZlh5eXkrZm1XUGdReERFUDVhWVFoREl3c0tDZnU2NTU2STdkKzdVQllCWENBUDRKaGVCc0xLeW91Ym41d3Q1REFLemIzdDdPNnBVS29RQjRCbkNBTDRhNlVDNGR1MWFvVlFxS1IrV1BtNjFqa0ZhUWZEcnI3K2E3ZWp1M2J1UkFQQUtZUURmaldRZ3JLNnVxc1hGUmRYNC9Za1REYk5jNmJDWElMQmpRS1R6SUxoNTg2YmUzZDNWUkFIZ0o4SUF3MktrQW1GdGJVMjk4TUlMU29RZ0FPQVh3Z0REWmlRQ29WUXFxYVdscGVia1E1ZExIL2NTQkhZTWlCQUV3Q2doRERDc1Vna0VlMythZ1hEanhvM0MwdEpTUjNNTXNsanBzSmNnTURFZzBqb0lOamMzSTN0RlNRRCtJd3d3N0lZeUVHN2R1cVd1WHIxNmFvNkJDRUVBd0QzQ0FLTmlxQUpoZlgxZFhicDBLZkd0aEN5WFBpWUlBTVFSQmhnMVF4RUlWNjVjS1N3dkw2dGVnaURsaFkxRWhDQUE4b3d3d0tqeU9oQ3VYYnVtVmxaV2xBaEJBTUF2aEFGR25aZUJzTHk4ckZaWFYxWGpmcndNQWpzR1JBZ0NJQzhJQStTRlY0RncvZnAxdGJDdzBKeGo0SHFsUTVHMlZ5a1VFWWsrK2VRVFRSQUFvNDB3UU41NEVRaHZ2UEZHWVdGaFFSRUVBSHhER0NDdm5BYkN6WnMzVmJsY1ZoNHNmVXdRQURpRk1FRGVPUW1FVjE5OXRibFdnZzhySFJJRUFBekNBRGlSYVNEY3VIR2pjUDM2OVZDRUlBRGdGOElBT0MyVFFIanR0ZGZVNnVwcWFQMzhtYmNMUk5JUEFyT09BVUVBd0NBTWdHU3BCc0xycjcrdXJseTVvdm9OZ241WE9pUUlBTVFSQnNENVVnbUV4Y1ZGdGJ5OHJFU2NMWDJzUllRZ0FIQUdZUUIwWnFDQmNQdjI3Y0t0VzdlYWJ5Vmt1UFF4UVFEZ1hBWFhEd0FZRW1Zd0RaSzJkM1oyUk9Ra0VHWm1aclRJU1NDWWlZV0hoNGVCZGVuallISnlVbWUxMHVIdTdxNitjK2NPUVFDZ0k1d3hBSHJUMXhrRWN4MERrWFNEZ0RNRUFMckZHUU9nTjMyZFFaaWFtdEtjSVFEZ0k4SUE2RTlQZ1NCQ0VBRHdFMkVBREVaWGdXQWlnU0FBNEJ2Q0FCaXNUZ05Cejg3TzZuNldQbTRFUVpUTzB3Q1FWNFFCa0k1ekErR1hYMzVwL29YZnpXV0xDUUlBYVNNTWdIUzFDZ1NDQUlDWENBTWdHNmNDNGZMbHkxcUVJQURnSDhJQXlKWVdFZm51dSs5MHVWeldCQUVBM3hBR2dBTjJGQkFFQUh4Q0dBQ08ySjh3RUJIWjNOeU1XT2tRZ0d1RUFlQUlRUUFBQUVSRVJHc2RhSzFacXdTQWQvNFB0dEVyZ3lkM2JJb0FBQUFBU1VWT1JLNUNZSUk9"
}, {
    name: "__ASSET__:bitmap_ProgressBarBg",
    data: "aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQVlRQUFBQTNDQVlBQUFBTWxEMjhBQUFBQ1hCSVdYTUFBQXNUQUFBTEV3RUFtcHdZQUFBNEpXbFVXSFJZVFV3NlkyOXRMbUZrYjJKbExuaHRjQUFBQUFBQVBEOTRjR0ZqYTJWMElHSmxaMmx1UFNMdnU3OGlJR2xrUFNKWE5VMHdUWEJEWldocFNIcHlaVk42VGxSamVtdGpPV1FpUHo0S1BIZzZlRzF3YldWMFlTQjRiV3h1Y3pwNFBTSmhaRzlpWlRwdWN6cHRaWFJoTHlJZ2VEcDRiWEIwYXowaVFXUnZZbVVnV0UxUUlFTnZjbVVnTlM0MkxXTXdOamNnTnprdU1UVTNOelEzTENBeU1ERTFMekF6THpNd0xUSXpPalF3T2pReUlDQWdJQ0FnSUNBaVBnb2dJQ0E4Y21SbU9sSkVSaUI0Yld4dWN6cHlaR1k5SW1oMGRIQTZMeTkzZDNjdWR6TXViM0puTHpFNU9Ua3ZNREl2TWpJdGNtUm1MWE41Ym5SaGVDMXVjeU1pUGdvZ0lDQWdJQ0E4Y21SbU9rUmxjMk55YVhCMGFXOXVJSEprWmpwaFltOTFkRDBpSWdvZ0lDQWdJQ0FnSUNBZ0lDQjRiV3h1Y3pwNGJYQTlJbWgwZEhBNkx5OXVjeTVoWkc5aVpTNWpiMjB2ZUdGd0x6RXVNQzhpQ2lBZ0lDQWdJQ0FnSUNBZ0lIaHRiRzV6T21SalBTSm9kSFJ3T2k4dmNIVnliQzV2Y21jdlpHTXZaV3hsYldWdWRITXZNUzR4THlJS0lDQWdJQ0FnSUNBZ0lDQWdlRzFzYm5NNmNHaHZkRzl6YUc5d1BTSm9kSFJ3T2k4dmJuTXVZV1J2WW1VdVkyOXRMM0JvYjNSdmMyaHZjQzh4TGpBdklnb2dJQ0FnSUNBZ0lDQWdJQ0I0Yld4dWN6cDRiWEJOVFQwaWFIUjBjRG92TDI1ekxtRmtiMkpsTG1OdmJTOTRZWEF2TVM0d0wyMXRMeUlLSUNBZ0lDQWdJQ0FnSUNBZ2VHMXNibk02YzNSRmRuUTlJbWgwZEhBNkx5OXVjeTVoWkc5aVpTNWpiMjB2ZUdGd0x6RXVNQzl6Vkhsd1pTOVNaWE52ZFhKalpVVjJaVzUwSXlJS0lDQWdJQ0FnSUNBZ0lDQWdlRzFzYm5NNmRHbG1aajBpYUhSMGNEb3ZMMjV6TG1Ga2IySmxMbU52YlM5MGFXWm1MekV1TUM4aUNpQWdJQ0FnSUNBZ0lDQWdJSGh0Ykc1ek9tVjRhV1k5SW1oMGRIQTZMeTl1Y3k1aFpHOWlaUzVqYjIwdlpYaHBaaTh4TGpBdklqNEtJQ0FnSUNBZ0lDQWdQSGh0Y0RwRGNtVmhkRzl5Vkc5dmJENUJaRzlpWlNCUWFHOTBiM05vYjNBZ1EwTWdNakF4TlNBb1YybHVaRzkzY3lrOEwzaHRjRHBEY21WaGRHOXlWRzl2YkQ0S0lDQWdJQ0FnSUNBZ1BIaHRjRHBEY21WaGRHVkVZWFJsUGpJd01UWXRNRE10TVRWVU1URTZNREE2TURNck1ESTZNREE4TDNodGNEcERjbVZoZEdWRVlYUmxQZ29nSUNBZ0lDQWdJQ0E4ZUcxd09rMXZaR2xtZVVSaGRHVStNakF4Tmkwd015MHhOVlF4TVRvd01qb3hNU3N3TWpvd01Ed3ZlRzF3T2sxdlpHbG1lVVJoZEdVK0NpQWdJQ0FnSUNBZ0lEeDRiWEE2VFdWMFlXUmhkR0ZFWVhSbFBqSXdNVFl0TURNdE1UVlVNVEU2TURJNk1URXJNREk2TURBOEwzaHRjRHBOWlhSaFpHRjBZVVJoZEdVK0NpQWdJQ0FnSUNBZ0lEeGtZenBtYjNKdFlYUSthVzFoWjJVdmNHNW5QQzlrWXpwbWIzSnRZWFErQ2lBZ0lDQWdJQ0FnSUR4d2FHOTBiM05vYjNBNlEyOXNiM0pOYjJSbFBqTThMM0JvYjNSdmMyaHZjRHBEYjJ4dmNrMXZaR1UrQ2lBZ0lDQWdJQ0FnSUR4NGJYQk5UVHBKYm5OMFlXNWpaVWxFUG5odGNDNXBhV1E2TXpZMk16RTRaamt0TW1GbE1TMHhORFJrTFdGallXWXRaR015WXpZelpHSXdaREZoUEM5NGJYQk5UVHBKYm5OMFlXNWpaVWxFUGdvZ0lDQWdJQ0FnSUNBOGVHMXdUVTA2Ukc5amRXMWxiblJKUkQ1NGJYQXVaR2xrT2pNMk5qTXhPR1k1TFRKaFpURXRNVFEwWkMxaFkyRm1MV1JqTW1NMk0yUmlNR1F4WVR3dmVHMXdUVTA2Ukc5amRXMWxiblJKUkQ0S0lDQWdJQ0FnSUNBZ1BIaHRjRTFOT2s5eWFXZHBibUZzUkc5amRXMWxiblJKUkQ1NGJYQXVaR2xrT2pNMk5qTXhPR1k1TFRKaFpURXRNVFEwWkMxaFkyRm1MV1JqTW1NMk0yUmlNR1F4WVR3dmVHMXdUVTA2VDNKcFoybHVZV3hFYjJOMWJXVnVkRWxFUGdvZ0lDQWdJQ0FnSUNBOGVHMXdUVTA2U0dsemRHOXllVDRLSUNBZ0lDQWdJQ0FnSUNBZ1BISmtaanBUWlhFK0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4eVpHWTZiR2tnY21SbU9uQmhjbk5sVkhsd1pUMGlVbVZ6YjNWeVkyVWlQZ29nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0E4YzNSRmRuUTZZV04wYVc5dVBtTnlaV0YwWldROEwzTjBSWFowT21GamRHbHZiajRLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnUEhOMFJYWjBPbWx1YzNSaGJtTmxTVVErZUcxd0xtbHBaRG96TmpZek1UaG1PUzB5WVdVeExURTBOR1F0WVdOaFppMWtZekpqTmpOa1lqQmtNV0U4TDNOMFJYWjBPbWx1YzNSaGJtTmxTVVErQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4emRFVjJkRHAzYUdWdVBqSXdNVFl0TURNdE1UVlVNVEU2TURBNk1ETXJNREk2TURBOEwzTjBSWFowT25kb1pXNCtDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJRHh6ZEVWMmREcHpiMlowZDJGeVpVRm5aVzUwUGtGa2IySmxJRkJvYjNSdmMyaHZjQ0JEUXlBeU1ERTFJQ2hYYVc1a2IzZHpLVHd2YzNSRmRuUTZjMjltZEhkaGNtVkJaMlZ1ZEQ0S0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnUEM5eVpHWTZiR2srQ2lBZ0lDQWdJQ0FnSUNBZ0lEd3ZjbVJtT2xObGNUNEtJQ0FnSUNBZ0lDQWdQQzk0YlhCTlRUcElhWE4wYjNKNVBnb2dJQ0FnSUNBZ0lDQThkR2xtWmpwUGNtbGxiblJoZEdsdmJqNHhQQzkwYVdabU9rOXlhV1Z1ZEdGMGFXOXVQZ29nSUNBZ0lDQWdJQ0E4ZEdsbVpqcFlVbVZ6YjJ4MWRHbHZiajQzTWpBd01EQXZNVEF3TURBOEwzUnBabVk2V0ZKbGMyOXNkWFJwYjI0K0NpQWdJQ0FnSUNBZ0lEeDBhV1ptT2xsU1pYTnZiSFYwYVc5dVBqY3lNREF3TUM4eE1EQXdNRHd2ZEdsbVpqcFpVbVZ6YjJ4MWRHbHZiajRLSUNBZ0lDQWdJQ0FnUEhScFptWTZVbVZ6YjJ4MWRHbHZibFZ1YVhRK01qd3ZkR2xtWmpwU1pYTnZiSFYwYVc5dVZXNXBkRDRLSUNBZ0lDQWdJQ0FnUEdWNGFXWTZRMjlzYjNKVGNHRmpaVDQyTlRVek5Ud3ZaWGhwWmpwRGIyeHZjbE53WVdObFBnb2dJQ0FnSUNBZ0lDQThaWGhwWmpwUWFYaGxiRmhFYVcxbGJuTnBiMjQrTXpnNFBDOWxlR2xtT2xCcGVHVnNXRVJwYldWdWMybHZiajRLSUNBZ0lDQWdJQ0FnUEdWNGFXWTZVR2w0Wld4WlJHbHRaVzV6YVc5dVBqVTFQQzlsZUdsbU9sQnBlR1ZzV1VScGJXVnVjMmx2Ymo0S0lDQWdJQ0FnUEM5eVpHWTZSR1Z6WTNKcGNIUnBiMjQrQ2lBZ0lEd3ZjbVJtT2xKRVJqNEtQQzk0T25odGNHMWxkR0UrQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDancvZUhCaFkydGxkQ0JsYm1ROUluY2lQejdtNjJGa0FBQUFJR05JVWswQUFIb2xBQUNBZ3dBQStmOEFBSURwQUFCMU1BQUE2bUFBQURxWUFBQVhiNUpmeFVZQUFBZzVTVVJCVkhqYTdKMC9hTnQ0RzhkN2NEUXZITGNjT0JEd1ZqSUZQQlE2WlBZVWJnZ0oxSXROck1ndjNneFpPaG5LVGM2THBwQk5OblF3M0hRSVRrc2hhT29XOEtRdXZ6U0REQm9FRWhpQkNob0V3dTl3ZnN5VFh5WFpzWjAvN1gyLzhDSGQ2dW41OEgxK1Awa3ZYbXc0QndjSFB3RUFBSGg0WGp5blpQM0FScVB4TXdBQWdJZm5XVWhpa1FEcTlmcExqcXFxVzFtOGZmdjJQd0FBQVA0aGIxYXFxcm9sejlWRmduZzBFV1FOZno3ZzYvWDZMNXZnNU9Ua1Z3QUErSkhZeEd5VUpaSWxpUWNUUTU0SVNBSjVRN3pSYVB3R0FBQmdjK1RKaGN2aHdjUWd5NkJlcjcva0VwQ0h2NnFxMjR5ZEhNb0FBQUFLeVp1Zjh4a3JTNExtc2l5R2pVaEJGc0hzUDVtTFFKTEFOOE8rMVdxOTRpaUtzZ3NBQUdCNTVEbWFJNDA3Y3NocURHdEpJYThWa0Fpa0ZsRG1RNy9kYnU4UnpXYXowdWwwM2dBQUFGaWRack5ab2JrcXk0TEpJVk1NY2x0WWVVMVVJSU1kVlZYTFhBQ2FwdTBUM1c2M09oZ01xdDF1dDNwK2Z2NDdBQUNBMWFCWlNuLzVyS1g1bXlXR0xDbmNxeW5reVlDTGdKcEFyOWVyMEk4YURBWlZYZGNQZFYwL05BemplRGdjTnJQNDhPSERmK1cvQUFBQS9vSFB4enhvMXVxNmZqZ1lET2FDNlBWNmxTd3haRW5oWHF1aUlobVFDRWdDaG1FY202WjVhbGxXeTdLc004dXl6cTZ1cnY3Z2ZQcjA2WDhBQUFEdWp6eFBhYzVhbHRVeVRmUFVNSXhqTGdjbWh0V2x3TThONkFENTVPVGtWMWtHZzhHZ2FoakdzV0VZeDVabG5ZMUdvL2VqMGVpOWJkc1h0bTFmQ0NINlFvais3ZTN0WHpKZnZuejVHd0FBd0dLeVppak5WNXEzbzlIb1BjbkJNSXpqd1dCUUhRd0dWVmtLdEQ1U1ZYVnJxZFVSYndmU21jRTNNckFzcTBVU0VFTDBIY2NadXE1cityNS83ZnYrZFJBRUlnekRtekFNWFFBQUFHdHpFNGJoVFJBRWd1YXM2N3FtNHpoREVzUk1Ebk14Y0Nud000V2xXZ0sxQTJsVmxDc0RJVVNmSkJDRzRVMGN4NU1rU2RJa1NkSTBUYWNJZ2lESVpwT202VFJKa2pTTzQwa2N4NU13REc5SURrS0lmb0VVN3F5T0NvV1ExUTVtcTZLeW9paTdtcWJ0Y3hrNGpqUDBQTThpRVVBQUNJSWdUeU1JRW9QbmVaWXNCVTNUOWhWRjJaMGRORzh2MVJKSUNFWHR3RFROVXk2REtJckdFQUdDSU1qVEowbVNOSXFpTVplQ2FacW5XYXVqaFMxaHlYWndadHYyQldTQUlBanlQTnRDRkVWajEzVk4yN1l2TE1zNnkyc0ovTVpSNGJxSTJvR3FxdVYydTcwbnQ0TXdERytTSkpuYm9GYXJUV3UxMnJSVUtnRUFBSGhFYXJYYXROZnIzV2tLUVJBSXgzR0d2Q1cwMiswOUVnSzFoTXkxVWRHNlNOTzBmVjNYRDNrN2lPTjRRdi81eDQ4ZnA2VlNhWHAwZERSOTkrNGRBQUNBUitUbzZHaGFLcFh1U0NHTzQ0bm5lUmExQkYzWER6Vk4yNWZYUnZ3S2FxWVFpdFpGUW9pKzcvdlhmRlZVcTlXbXIxKy9ubDVlWHFLdklRaUNQSEl1THkvblRZRzNCTi8zcjRVUS9VVnJvMHdoWkowZnlPdWkyOXZidjZJb0d2TWZBeUVnQ0lJOEx5R2thVG9Ody9DbWFHM0VieHZkRVVMVytVR3IxWHJWYnJmM3V0M3VYQWl1NjVwOFhRUWhJQWlDUEQ4aFRLZlQrZUV5Q2FIYjdWYlpTL0IyNUhPRXdnUGxWcXYxcXRsc1ZuUmRQelJOOHpUci9BQkNRQkFFZVo1Q2lPTjRRcmVOVE5NOFBUOC8vNzNaYkZhV0VnSzl1MmdtaExLaUtMdWRUdWVOZktETWJ4ZEJDQWlDSU05VENFbVNwUExCY3FmVGVUTTdSMWhmQ0w3dlgwTUlDSUlnMzRjUWZOKy96aEZDV2I1cGxIbkRhSkVRNUlmUklBUUVRWkR2WHdnSEJ3Yy9GVjQ1NVVLZ0s2ZG9DQWlDSU4rUEVPanFxU3dFdW1tMGxoRFFFQkFFUVNBRU5BUUVRWkIva3hCd2hvQWdDUExqQ0dHbE13VGNNa0lRQlBuM0NxSG8ydWtPbmtOQUVBVDV2b1d3OG5NSWVGSVpRUkRreHhFQ2YrUHAwazhxNDExR0NJSWdQNTRRNUhjWjBjdnRGZ3BoMmJlZE9vNHp4TnRPRVFSQm5yY1ExbnJiNlgyL2h5Qi9MWTJFOFBYclZ3QUFBSS9JZzN3UElldGcrYjVmVEFNQUFQRDR5RjlNaTZKb3ZQWVgwNlJ6aE55MVVSQUVncmVFWHE4My82NHlBQUNBeDJXajMxVG1COHVMMWthMmJWKzRybXRHVVRTV0gxSkRFQVJCbmk1SmtxUjBtRXp0b0doZDlNMkJjdFk1Z3J3MjZ2VjZGZDRTaEJCOXovT3NLSXJHOG5NSkNJSWd5TlBKd1BNOFN3alI1KzJnMSt0VlpqSW9YaGZsclkwS1drS0xTeUVNdzVzNGppZG9Dd2lDSUU4amdqaU9KMEVRQ0M0RHk3SmFlZTJnY0YyMG9DVnM4NWJBcFdEYjlvWGpPRVBQODZ3Z0NFUVVSZU00amlkSmtxUkVtcVpUQUFBQTYwTnpOWTdqU1J6SGt5aUt4aVFDeDNHR3RtMWZjQmxRTzVnZEpzL1BEakp2RnkzVEVySldSNFpoSEp1bWVXcFoxaGtYZyt1NnB1ZDVsdS83MTBRUUJBSUFBTUQ2MEZ6MVBNL3lQTTl5WGRlVVJIQm1tdVpwaGd4MkdvM0diMHUzQXhLQ2ZBV1ZyWTdtVXRBMGJaKzNCUklEeWNHMjdRc2hSRjhJMGYvOCtmT2ZBQUFBMWtjSTBhY1pTeElnRWZCV29HbmFmcDRNK05sQm9SRGtsa0Nyb3lJcDhNWkFyWUZ6ZFhYMUJ3QUFnUFdRWnl1MUFkNElzbVRBenczNHphS0ZNbGdrQlZvZnFhcGFKakhJY3RCMS9UQ0w0WERZQkFBQXNCbzBSL2xjbFNYQVJGQ1dtOEZLTXBCWFJ6bFMyT1ppVUJSbHQ5MXU3N1hiN1QxTjAvWTUzVzYzMnUxMnEvemZBQUFBbGtPZW94eWF1NHFpN0hJUjBBRnluZ3p1SllSbHBDQ0xnY3VCb0IvTGFUYWJGZm9MQUFBZ202ejVTY09mWUJLNEl3TDJKUEw2TXNpVGdxcXFXd1ZpSURuc3NCODRGd1VBQUlEVmtHY3FFOEFPelY5cUJMd1Z6QzRIclMrRExDbGtpWUhra0NPSWJVa1dYQm9BQUFDSzJaWUhQMjhCc2dTeVJMQXhHY2hTa01WQXF5UXVCeTRJV1JRQUFBQldRNTZyZk9heU9md3lTd1FiazBGUlc1RGxRTTBoU3hJQUFBRFdoODlZYWdKY0FnL1NDdTdiR1BJa2tZZXFxbHNBQUFDK1pkSDh6SnU3RDlvSTdpdUhSWklBQUFDd1BsbHo5OGtrc0lva0FBQUFiSTZIbU4zL0h3Q2gwcGlNUXhJRGd3QUFBQUJKUlU1RXJrSmdnZz09"
}, {
    name: "__ASSET__:bitmap_ProgressBarBody",
    data: "aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFFQUFBQVJDQVlBQUFBY3c4WVNBQUFBQ1hCSVdYTUFBQXNUQUFBTEV3RUFtcHdZQUFBNEkybFVXSFJZVFV3NlkyOXRMbUZrYjJKbExuaHRjQUFBQUFBQVBEOTRjR0ZqYTJWMElHSmxaMmx1UFNMdnU3OGlJR2xrUFNKWE5VMHdUWEJEWldocFNIcHlaVk42VGxSamVtdGpPV1FpUHo0S1BIZzZlRzF3YldWMFlTQjRiV3h1Y3pwNFBTSmhaRzlpWlRwdWN6cHRaWFJoTHlJZ2VEcDRiWEIwYXowaVFXUnZZbVVnV0UxUUlFTnZjbVVnTlM0MkxXTXdOamNnTnprdU1UVTNOelEzTENBeU1ERTFMekF6THpNd0xUSXpPalF3T2pReUlDQWdJQ0FnSUNBaVBnb2dJQ0E4Y21SbU9sSkVSaUI0Yld4dWN6cHlaR1k5SW1oMGRIQTZMeTkzZDNjdWR6TXViM0puTHpFNU9Ua3ZNREl2TWpJdGNtUm1MWE41Ym5SaGVDMXVjeU1pUGdvZ0lDQWdJQ0E4Y21SbU9rUmxjMk55YVhCMGFXOXVJSEprWmpwaFltOTFkRDBpSWdvZ0lDQWdJQ0FnSUNBZ0lDQjRiV3h1Y3pwNGJYQTlJbWgwZEhBNkx5OXVjeTVoWkc5aVpTNWpiMjB2ZUdGd0x6RXVNQzhpQ2lBZ0lDQWdJQ0FnSUNBZ0lIaHRiRzV6T21SalBTSm9kSFJ3T2k4dmNIVnliQzV2Y21jdlpHTXZaV3hsYldWdWRITXZNUzR4THlJS0lDQWdJQ0FnSUNBZ0lDQWdlRzFzYm5NNmNHaHZkRzl6YUc5d1BTSm9kSFJ3T2k4dmJuTXVZV1J2WW1VdVkyOXRMM0JvYjNSdmMyaHZjQzh4TGpBdklnb2dJQ0FnSUNBZ0lDQWdJQ0I0Yld4dWN6cDRiWEJOVFQwaWFIUjBjRG92TDI1ekxtRmtiMkpsTG1OdmJTOTRZWEF2TVM0d0wyMXRMeUlLSUNBZ0lDQWdJQ0FnSUNBZ2VHMXNibk02YzNSRmRuUTlJbWgwZEhBNkx5OXVjeTVoWkc5aVpTNWpiMjB2ZUdGd0x6RXVNQzl6Vkhsd1pTOVNaWE52ZFhKalpVVjJaVzUwSXlJS0lDQWdJQ0FnSUNBZ0lDQWdlRzFzYm5NNmRHbG1aajBpYUhSMGNEb3ZMMjV6TG1Ga2IySmxMbU52YlM5MGFXWm1MekV1TUM4aUNpQWdJQ0FnSUNBZ0lDQWdJSGh0Ykc1ek9tVjRhV1k5SW1oMGRIQTZMeTl1Y3k1aFpHOWlaUzVqYjIwdlpYaHBaaTh4TGpBdklqNEtJQ0FnSUNBZ0lDQWdQSGh0Y0RwRGNtVmhkRzl5Vkc5dmJENUJaRzlpWlNCUWFHOTBiM05vYjNBZ1EwTWdNakF4TlNBb1YybHVaRzkzY3lrOEwzaHRjRHBEY21WaGRHOXlWRzl2YkQ0S0lDQWdJQ0FnSUNBZ1BIaHRjRHBEY21WaGRHVkVZWFJsUGpJd01UWXRNRE10TVRWVU1URTZNREE2TURJck1ESTZNREE4TDNodGNEcERjbVZoZEdWRVlYUmxQZ29nSUNBZ0lDQWdJQ0E4ZUcxd09rMXZaR2xtZVVSaGRHVStNakF4Tmkwd015MHhOVlF4TVRvd01qb3pOaXN3TWpvd01Ed3ZlRzF3T2sxdlpHbG1lVVJoZEdVK0NpQWdJQ0FnSUNBZ0lEeDRiWEE2VFdWMFlXUmhkR0ZFWVhSbFBqSXdNVFl0TURNdE1UVlVNVEU2TURJNk16WXJNREk2TURBOEwzaHRjRHBOWlhSaFpHRjBZVVJoZEdVK0NpQWdJQ0FnSUNBZ0lEeGtZenBtYjNKdFlYUSthVzFoWjJVdmNHNW5QQzlrWXpwbWIzSnRZWFErQ2lBZ0lDQWdJQ0FnSUR4d2FHOTBiM05vYjNBNlEyOXNiM0pOYjJSbFBqTThMM0JvYjNSdmMyaHZjRHBEYjJ4dmNrMXZaR1UrQ2lBZ0lDQWdJQ0FnSUR4NGJYQk5UVHBKYm5OMFlXNWpaVWxFUG5odGNDNXBhV1E2WXpoa01qRmxZamt0TlRCak5pMHdOalE0TFdJM1ptSXRNamRtTnpKbE1qUmpZamt5UEM5NGJYQk5UVHBKYm5OMFlXNWpaVWxFUGdvZ0lDQWdJQ0FnSUNBOGVHMXdUVTA2Ukc5amRXMWxiblJKUkQ1NGJYQXVaR2xrT21NNFpESXhaV0k1TFRVd1l6WXRNRFkwT0MxaU4yWmlMVEkzWmpjeVpUSTBZMkk1TWp3dmVHMXdUVTA2Ukc5amRXMWxiblJKUkQ0S0lDQWdJQ0FnSUNBZ1BIaHRjRTFOT2s5eWFXZHBibUZzUkc5amRXMWxiblJKUkQ1NGJYQXVaR2xrT21NNFpESXhaV0k1TFRVd1l6WXRNRFkwT0MxaU4yWmlMVEkzWmpjeVpUSTBZMkk1TWp3dmVHMXdUVTA2VDNKcFoybHVZV3hFYjJOMWJXVnVkRWxFUGdvZ0lDQWdJQ0FnSUNBOGVHMXdUVTA2U0dsemRHOXllVDRLSUNBZ0lDQWdJQ0FnSUNBZ1BISmtaanBUWlhFK0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4eVpHWTZiR2tnY21SbU9uQmhjbk5sVkhsd1pUMGlVbVZ6YjNWeVkyVWlQZ29nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0E4YzNSRmRuUTZZV04wYVc5dVBtTnlaV0YwWldROEwzTjBSWFowT21GamRHbHZiajRLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnUEhOMFJYWjBPbWx1YzNSaGJtTmxTVVErZUcxd0xtbHBaRHBqT0dReU1XVmlPUzAxTUdNMkxUQTJORGd0WWpkbVlpMHlOMlkzTW1VeU5HTmlPVEk4TDNOMFJYWjBPbWx1YzNSaGJtTmxTVVErQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4emRFVjJkRHAzYUdWdVBqSXdNVFl0TURNdE1UVlVNVEU2TURBNk1ESXJNREk2TURBOEwzTjBSWFowT25kb1pXNCtDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJRHh6ZEVWMmREcHpiMlowZDJGeVpVRm5aVzUwUGtGa2IySmxJRkJvYjNSdmMyaHZjQ0JEUXlBeU1ERTFJQ2hYYVc1a2IzZHpLVHd2YzNSRmRuUTZjMjltZEhkaGNtVkJaMlZ1ZEQ0S0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnUEM5eVpHWTZiR2srQ2lBZ0lDQWdJQ0FnSUNBZ0lEd3ZjbVJtT2xObGNUNEtJQ0FnSUNBZ0lDQWdQQzk0YlhCTlRUcElhWE4wYjNKNVBnb2dJQ0FnSUNBZ0lDQThkR2xtWmpwUGNtbGxiblJoZEdsdmJqNHhQQzkwYVdabU9rOXlhV1Z1ZEdGMGFXOXVQZ29nSUNBZ0lDQWdJQ0E4ZEdsbVpqcFlVbVZ6YjJ4MWRHbHZiajQzTWpBd01EQXZNVEF3TURBOEwzUnBabVk2V0ZKbGMyOXNkWFJwYjI0K0NpQWdJQ0FnSUNBZ0lEeDBhV1ptT2xsU1pYTnZiSFYwYVc5dVBqY3lNREF3TUM4eE1EQXdNRHd2ZEdsbVpqcFpVbVZ6YjJ4MWRHbHZiajRLSUNBZ0lDQWdJQ0FnUEhScFptWTZVbVZ6YjJ4MWRHbHZibFZ1YVhRK01qd3ZkR2xtWmpwU1pYTnZiSFYwYVc5dVZXNXBkRDRLSUNBZ0lDQWdJQ0FnUEdWNGFXWTZRMjlzYjNKVGNHRmpaVDQyTlRVek5Ud3ZaWGhwWmpwRGIyeHZjbE53WVdObFBnb2dJQ0FnSUNBZ0lDQThaWGhwWmpwUWFYaGxiRmhFYVcxbGJuTnBiMjQrTVR3dlpYaHBaanBRYVhobGJGaEVhVzFsYm5OcGIyNCtDaUFnSUNBZ0lDQWdJRHhsZUdsbU9sQnBlR1ZzV1VScGJXVnVjMmx2Ymo0eE56d3ZaWGhwWmpwUWFYaGxiRmxFYVcxbGJuTnBiMjQrQ2lBZ0lDQWdJRHd2Y21SbU9rUmxjMk55YVhCMGFXOXVQZ29nSUNBOEwzSmtaanBTUkVZK0Nqd3ZlRHA0YlhCdFpYUmhQZ29nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUFvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0NpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQUtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQW9nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBS0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lBbzhQM2h3WVdOclpYUWdaVzVrUFNKM0lqOCtxR0c5N0FBQUFDQmpTRkpOQUFCNkpRQUFnSU1BQVBuL0FBQ0E2UUFBZFRBQUFPcGdBQUE2bUFBQUYyK1NYOFZHQUFBQUkwbEVRVlI0Mm1MWXZIbnpmNFkxYTliOFo1ZzBhUkpSUkhWMU5SNmlvcUtpSGpBQXJ3TXNTd0RJZGRnQUFBQUFTVVZPUks1Q1lJST0"
}];
ua.__alpha16 = Array(256);
for (var kg = 0; 256 > kg;) {
    var lg = kg++;
    ua.__alpha16[lg] = 65536 * lg / 255 | 0
}
ua.__clamp = Array(510);
for (var mg = 0; 255 > mg;) {
    var ng = mg++;
    ua.__clamp[ng] = ng
}
for (var og = 255; 511 > og;) {
    var ug = og++;
    ua.__clamp[ug] = 255
}
null != window.createjs && (createjs.Sound.alternateExtensions = ["ogg", "mp3", "wav"]);
V.__instanceCount = 0;
V.__worldRenderDirty = 0;
V.__worldTransformDirty = 0;
hb.resourceType = "image/png";
hb.resourceName = "__ASSET__:bitmap_Logo";
ib.resourceType = "image/png";
ib.resourceName = "__ASSET__:bitmap_ProgressBarBg";
jb.resourceType = "image/png";
jb.resourceName = "__ASSET__:bitmap_ProgressBarBody";
kb.resourceType = "image/png";
kb.resourceName = "__ASSET__:bitmap_SoftgamesLogo";
Ka.onMobile = !1;
Ka.isIE = !1;
sc.__defaultPoint = new ja(0, 0);
vc.showTime = .9;
vc.hideTime = .3;
vc.visibleTime = 3;
L.inited = !1;
Cb.USE_CACHE = !1;
Cb.USE_ENUM_INDEX = !1;
Cb.BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%:";
cb.DEFAULT_RESOLVER = O;
cb.BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%:";
cb.CODES = null;
Hc.CHARS =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%2b/index.html";
Hc.BYTES = Db.ofString(Hc.CHARS);
hc.count = 0;
ac.escapes = function(a) {
    a = new pa;
    a.set("lt", "<");
    a.set("gt", ">");
    a.set("amp", "&");
    a.set("quot", '"');
    a.set("apos", "'");
    a.set("nbsp", String.fromCharCode(160));
    return a
}(this);
x.__toStr = {}.toString;
H.cache = new bf;
H.libraries = new pa;
H.initialized = !1;
Ia.images = new pa;
Ia.loaders = new pa;
la.actuators = [];
la.actuatorsLength = 0;
la.addedEvent = !1;
A.defaultActuator = la;
A.defaultEase = lf.get_easeOut();
A.targetLibraries =
    new hc;
Y.cache = new ae;
Wb.__rootURL = window.document.URL;
Kc.currentDomain = new Kc(null);
da.__identity = new da;
S.current = new be;
S.__sentWarnings = new pa;
h.SIN45 = .7071067811865476;
h.TAN22 = .41421356237309503;
ha.blendModesWebGL = null;
ha.glContextId = 0;
ha.glContexts = [];
Q.__UID = 0;
Lc.defaultVertexSrc = ["attribute vec2 aVertexPosition;", "attribute vec2 aTextureCoord;", "attribute vec2 aColor;", "uniform vec2 projectionVector;", "uniform vec2 offsetVector;", "varying vec2 vTextureCoord;", "varying vec4 vColor;", "const vec2 center = vec2(-1.0, 1.0);",
    "void main(void) {", "   gl_Position = vec4( ((aVertexPosition + offsetVector) / projectionVector) + center , 0.0, 1.0);", "   vTextureCoord = aTextureCoord;", "   vec3 color = mod(vec3(aColor.y/65536.0, aColor.y/256.0, aColor.y), 256.0) / 256.0;", "   vColor = vec4(color * aColor.x, aColor.x);", "}"
];
k.__fillIndex = 0;
F.bucketPool = [];
F.objectPosition = new ja;
F.objectBounds = new za;
w.ACTIVATE = "activate";
w.ADDED = "added";
w.ADDED_TO_STAGE = "addedToStage";
w.CHANGE = "change";
w.COMPLETE = "complete";
w.DEACTIVATE = "deactivate";
w.ENTER_FRAME = "enterFrame";
w.OPEN = "open";
w.REMOVED = "removed";
w.REMOVED_FROM_STAGE = "removedFromStage";
w.RENDER = "render";
w.RESIZE = "resize";
w.SOUND_COMPLETE = "soundComplete";
Bb.FOCUS_IN = "focusIn";
Bb.FOCUS_OUT = "focusOut";
Qc.HTTP_STATUS = "httpStatus";
Ub.IO_ERROR = "ioError";
Tb.KEY_DOWN = "keyDown";
Tb.KEY_UP = "keyUp";
D.CLICK = "click";
D.DOUBLE_CLICK = "doubleClick";
D.MIDDLE_CLICK = "middleClick";
D.MIDDLE_MOUSE_DOWN = "middleMouseDown";
D.MIDDLE_MOUSE_UP = "middleMouseUp";
D.MOUSE_DOWN = "mouseDown";
D.MOUSE_MOVE = "mouseMove";
D.MOUSE_OUT = "mouseOut";
D.MOUSE_OVER = "mouseOver";
D.MOUSE_UP = "mouseUp";
D.RIGHT_CLICK = "rightClick";
D.RIGHT_MOUSE_DOWN = "rightMouseDown";
D.RIGHT_MOUSE_UP = "rightMouseUp";
D.__buttonDown = [!1, !1, !1];
Rc.PROGRESS = "progress";
Sc.SECURITY_ERROR = "securityError";
xb.TIMER = "timer";
xb.TIMER_COMPLETE = "timerComplete";
lc.__registeredSounds = new pa;
$c.GET = "GET";
$c.POST = "POST";
Pa.LOSE_DELAY = .8;
ad.OBJECT_REFERENCE_PREFIX = "@~obRef#";
oa.main()
})("undefined" != typeof window ? window : exports);